// $URL: http://subversion:8080/svn/gsc/trunk/drivers/LINUX/16AI64SSA/include/16ai64ssa_api.h $
// $Rev: 54954 $
// $Date: 2024-08-07 15:24:55 -0500 (Wed, 07 Aug 2024) $

// 16AI64SSA: API Library: header file

#ifndef	__16AI64SSA_API_H__
#define	__16AI64SSA_API_H__

#include <stdlib.h>

#include "16ai64ssa.h"



// prototypes *****************************************************************

int	ai64ssa_close(int fd);
int	ai64ssa_init(void);
int	ai64ssa_ioctl(int fd, int request, void* arg);
int	ai64ssa_open(int device, int share, int* fd);
int	ai64ssa_read(int fd, void* dst, size_t bytes);



#endif
