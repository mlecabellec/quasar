// $URL: http://subversion:8080/svn/gsc/trunk/drivers/LINUX/OPTO16X16/OPTO16X16_Linux_1.x.x.x_GSC_DN/include/opto16x16_utils.h $
// $Rev: 53728 $
// $Date: 2023-09-14 10:47:24 -0500 (Thu, 14 Sep 2023) $

// OPTO16X16: Utilities: header file

#ifndef	__OPTO16X16_UTILS_H__
#define	__OPTO16X16_UTILS_H__

#include "opto16x16_api.h"
#include "gsc_utils.h"
#include "gsc_utils_pci.h"



// prototypes *****************************************************************

// API utility services

int	opto16x16_close_util		(int fd, int index, int verbose);
int opto16x16_init_util			(int verbose);
int opto16x16_ioctl_util		(int fd, int index, int verbose, int request, void* arg);
int	opto16x16_open_util			(int device, int share, int index, int verbose, int* fd);
int opto16x16_read_util			(int fd, int index, int verbose, void* dst, size_t bytes, size_t* got);

// IOCTL utility services

int	opto16x16_clock_divider		(int fd, int index, int verbose, s32 set, s32* get);			// OPTO16X16_IOCTL_CLOCK_DIVIDER
int	opto16x16_cos_polarity		(int fd, int index, int verbose, s32 set, s32* get);			// OPTO16X16_IOCTL_COS_POLARITY
int	opto16x16_debounce_ms		(int fd, int index, int verbose, s32 set, s32* get);			// OPTO16X16_IOCTL_DEBOUNCE_MS
int	opto16x16_debounce_us		(int fd, int index, int verbose, s32 set, s32* get);			// OPTO16X16_IOCTL_DEBOUNCE_US
int	opto16x16_initialize		(int fd, int index, int verbose);								// OPTO16X16_IOCTL_INITIALIZE
int	opto16x16_irq_enable		(int fd, int index, int verbose, s32 set, s32* get);			// OPTO16X16_IOCTL_IRQ_ENABLE
int	opto16x16_led				(int fd, int index, int verbose, s32 set, s32* get);			// OPTO16X16_IOCTL_LED
int	opto16x16_query				(int fd, int index, int verbose, s32 set, s32* get);			// OPTO16X16_IOCTL_QUERY
int	opto16x16_reg_mod			(int fd, int index, int verbose, u32 reg, u32 value, u32 mask);	// OPTO16X16_IOCTL_REG_MOD
int	opto16x16_reg_read			(int fd, int index, int verbose, u32 reg, u32* value);			// OPTO16X16_IOCTL_REG_READ
int	opto16x16_reg_write			(int fd, int index, int verbose, u32 reg, u32 value);			// OPTO16X16_IOCTL_REG_WRITE
int	opto16x16_rx_data			(int fd, int index, int verbose, s32* get);						// OPTO16X16_IOCTL_RX_DATA
int	opto16x16_rx_event_counter	(int fd, int index, int verbose, s32 set, s32* get);			// OPTO16X16_IOCTL_RX_EVENT_COUNTER
int	opto16x16_tx_data			(int fd, int index, int verbose, s32 set, s32* get);			// OPTO16X16_IOCTL_TX_DATA
int	opto16x16_wait_cancel		(int fd, int index, int verbose, gsc_wait_t* wait);				// OPTO16X16_IOCTL_WAIT_CANCEL
int	opto16x16_wait_event		(int fd, int index, int verbose, gsc_wait_t* wait);				// OPTO16X16_IOCTL_WAIT_EVENT
int	opto16x16_wait_status		(int fd, int index, int verbose, gsc_wait_t* wait);				// OPTO16X16_IOCTL_WAIT_STATUS

// Auxiliary utility services

int opto16x16_api_listing		(int fd);
int opto16x16_id_device			(int fd, int index, int verbose);
int	opto16x16_count_boards		(int verbose, s32* get);
int	opto16x16_reg_list			(int fd, int detail);

const gsc_reg_def_t*			opto16x16_reg_get_def_id(u32 reg);
const gsc_reg_def_t*			opto16x16_reg_get_def_index(int index);
const char*						opto16x16_reg_get_desc(u32 reg);
const char*						opto16x16_reg_get_name(u32 reg);



#endif
