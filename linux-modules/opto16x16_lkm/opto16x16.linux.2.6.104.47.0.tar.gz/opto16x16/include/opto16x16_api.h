// $URL: http://subversion:8080/svn/gsc/trunk/drivers/LINUX/OPTO16X16/OPTO16X16_Linux_1.x.x.x_GSC_DN/include/opto16x16_api.h $
// $Rev: 53728 $
// $Date: 2023-09-14 10:47:24 -0500 (Thu, 14 Sep 2023) $

// OPTO16X16: API Library: header file

#ifndef	__OPTO16X16_API_H__
#define	__OPTO16X16_API_H__

#include "opto16x16.h"



// prototypes *****************************************************************

int	opto16x16_close(int fd);
int	opto16x16_init(void);
int	opto16x16_ioctl(int fd, int request, void* arg);
int	opto16x16_open(int device, int share, int* fd);
int	opto16x16_read(int fd, void* dst, size_t bytes);



#endif
