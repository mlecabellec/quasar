// $URL: http://subversion:8080/svn/gsc/trunk/drivers/LINUX/OPTO16X16/OPTO16X16_Linux_1.x.x.x_GSC_DN/include/opto16x16_main.h $
// $Rev: 51394 $
// $Date: 2022-07-14 13:03:55 -0500 (Thu, 14 Jul 2022) $

// OPTO16X16: main header file

#ifndef	__OPTO16X16_MAIN_H__
#define	__OPTO16X16_MAIN_H__



#ifdef __cplusplus
extern "C" {
#endif

#include "opto16x16.h"
#include "opto16x16_api.h"
#include "opto16x16_dsl.h"
#include "gsc_utils.h"
#include "gsc_utils_pci.h"
#include "opto16x16_utils.h"
#include "gsc_pci9056.h"

#ifdef __cplusplus
}
#endif



#endif
