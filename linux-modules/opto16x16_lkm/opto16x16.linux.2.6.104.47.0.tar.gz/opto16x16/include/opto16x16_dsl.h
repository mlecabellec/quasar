// $URL: http://subversion:8080/svn/gsc/trunk/drivers/LINUX/OPTO16X16/OPTO16X16_Linux_1.x.x.x_GSC_DN/include/opto16x16_dsl.h $
// $Rev: 53728 $
// $Date: 2023-09-14 10:47:24 -0500 (Thu, 14 Sep 2023) $

// OPTO16X16: Document Source Library: header file

#ifndef	__OPTO16X16_DSL_H__
#define	__OPTO16X16_DSL_H__

#include "opto16x16_api.h"



// prototypes *****************************************************************

int	opto16x16_close_dsl	(int fd);
int	opto16x16_init_dsl	(void);
int	opto16x16_ioctl_dsl	(int fd, int request, void* arg);
int	opto16x16_open_dsl	(int device, int share, int* fd);
int opto16x16_read_dsl	(int fd, void* dst, size_t bytes, size_t* qty);



#endif
