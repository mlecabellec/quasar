#ifndef _GR_COMMON_H
#define _GR_COMMON_H

void    GR_ModeToStr(GL_MODE mode, char* modeStr);
void    GR_DynToStr(GL_DYN dyn, char* dynStr);
void    GR_getUbxVersion(TSYNC_ReceiverInfoObj *pRI, char* pSwVer, char* pTimVer, char* pProtocol, char* pHwVer);

#endif // _GR_COMMON_H

