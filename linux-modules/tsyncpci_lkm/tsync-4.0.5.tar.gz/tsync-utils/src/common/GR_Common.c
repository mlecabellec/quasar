// (C) Copyright 2017 Orolia All rights reserved.

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "tsync.h"


static int GR_FindLine(char* pLine, char* pMatchStr, UBX_RCV_INFO* pRec)
{
    int  ret = -1; // Not Found
    int  i;
    char lbuf[UBX_EX_VER_STR_LEN+1] = {0};

    for (i = 0; i < UBX_HW_VER_STR_NUM; i++)
    {
        strncpy(lbuf, pRec->exten[i], UBX_EX_VER_STR_LEN);

        if (strstr(lbuf, pMatchStr) != NULL)
        {
            strcpy(pLine, lbuf);
            ret = 0;
            break;
        }
    }

    return (ret);

} /* End - GR_FindLine() */


static int GR_FindDigitString(char* pStr, char* pLine)
{
    int ret = -1; // Not Found
    int i;

    for (i = 0; i < strlen(pLine); i++)
    {
        if (isdigit(pLine[i]))
        {
            char* pStart = &pLine[i];
            sscanf(pStart, "%s %*s", pStr);
            ret = 0;
            break;
        }
    }

    return (ret);

} /* End - GR_FindDigitString() */


void GR_ModeToStr(GL_MODE mode, char* modeStr)
{
    switch (mode)
    {
        case GL_MODE_1SAT: strcpy(modeStr, "SINGLE-SAT"); break;
        case GL_MODE_STND: strcpy(modeStr, "STANDARD");   break;
        case GL_MODE_CONT: strcpy(modeStr, "CONTINUOUS"); break;
        case GL_MODE_AVRG: strcpy(modeStr, "AVERAGING");  break;
        case GL_MODE_TIME: strcpy(modeStr, "TIME-ONLY");  break;
        case GL_MODE_STBY: strcpy(modeStr, "STANDBY");    break;
        case GL_MODE_SELF: strcpy(modeStr, "SELF-TEST");  break;
        default:           strcpy(modeStr, "UNKNOWN");    break;
    }
}

void GR_DynToStr(GL_DYN  dyn, char* dynStr)
{
    switch (dyn)
    {
        case GL_DYN_LAND:   strcpy(dynStr, "LAND");       break;
        case GL_DYN_SEA:    strcpy(dynStr, "SEA");        break;
        case GL_DYN_AIR:    strcpy(dynStr, "AIR");        break;
        case GL_DYN_STAT:   strcpy(dynStr, "STATIONARY"); break;
        case GL_DYN_AIR_1G: strcpy(dynStr, "AIR1G");      break;
        case GL_DYN_AIR_4G: strcpy(dynStr, "AIR4G");      break;
        default:            strcpy(dynStr, "UNKNOWN");    break;
    }
}

void GR_getUbxVersion(
        TSYNC_ReceiverInfoObj *pRI,
        char*   pSwVer,
        char*   pTimVer,
        char*   pProtocol,
        char*   pHwVer)
{
    int  ret;
    char line[UBX_EX_VER_STR_LEN+10] = {0};
    UBX_RCV_INFO* pRec = (UBX_RCV_INFO*)&pRI->info;

    // Initialize to defaults
    strcpy(pSwVer, "0.0");
    strcpy(pTimVer, "0.0");
    strcpy(pProtocol, "0.0");
    strncpy(pHwVer, pRec->hwVer, UBX_HW_VER_STR_LEN);

    (void) GR_FindDigitString(pSwVer, pRec->swVer);

    ret = GR_FindLine(line, "TIM", pRec);

    if (ret == 0)
    {
       (void) GR_FindDigitString(pTimVer, line);
    }

    ret = GR_FindLine(line, "PROT", pRec);

    if (ret == 0)
    {
        (void) GR_FindDigitString(pProtocol, line);
    }
}

