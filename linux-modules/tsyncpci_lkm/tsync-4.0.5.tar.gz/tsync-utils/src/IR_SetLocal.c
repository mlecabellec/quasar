#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_example.h"


int main (int argc, char *argv[])
{
    TSYNC_BoardHandle   hnd;
    int                 rc;
    int                 ret     = 0;
    int                 devIdx;
    char               *devName = DEFAULT_DEV;
    char                fullDevName[32];
    char               *pgmname = argv[0];
    TSYNC_ERROR         err     = TSYNC_SUCCESS;
    unsigned int        index;
    TSYNC_LocalClockObj local;


    /* If invalid number of arguments... */
    if (argc != 14)
    {
        printf(" Usage: IR_SetLocal <device index> <index> <ref> <in.mon> "
               "<in.wom> <in.dow> <in.hr> <out.mon> <out.wom> <out.dow> "
               "<out.hr> <offset> <tz>\n");
        return (1);
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        return (1);
    }

    /* Build Set Local message */
    index                = atoi(argv[2]);
    local.rule.ref       = (ML_DST_REF)atoi(argv[3]);
    local.rule.in.month  = (ML_MONTH)atoi(argv[4]);
    local.rule.in.wom    = (ML_WOM)atoi(argv[5]);
    local.rule.in.dow    = (ML_DOW)atoi(argv[6]);
    local.rule.in.hour   = atoi(argv[7]);
    local.rule.out.month = (ML_MONTH)atoi(argv[8]);
    local.rule.out.wom   = (ML_WOM)atoi(argv[9]);
    local.rule.out.dow   = (ML_DOW)atoi(argv[10]);
    local.rule.out.hour  = atoi(argv[11]);
    local.rule.offset    = atoi(argv[12]);
    local.tz             = atoi(argv[13]);

    printf("\n  IR (%d) Time Local:\n", (index));

    printf("\n    DST Ref:        %d\n", local.rule.ref);

    printf("\n    DST IN Month:   %d\n", local.rule.in.month);

    printf("\n    DST IN WOM:     %d\n", local.rule.in.wom);

    printf("\n    DST IN DOW:     %d\n", local.rule.in.dow);

    printf("\n    DST IN Hour:    %d\n", local.rule.in.hour);

    printf("\n    DST OUT Month:  %d\n", local.rule.out.month);

    printf("\n    DST OUT WOM:    %d\n", local.rule.out.wom);

    printf("\n    DST OUT DOW:    %d\n", local.rule.out.dow);

    printf("\n    DST OUT Hour:   %d\n", local.rule.out.hour);

    printf("\n    DST OUT Offset: %d\n", local.rule.offset);

    printf("\n    TZ:             %d\n", local.tz);

    // Send Set Format transaction
    err = TSYNC_IR_setLocal(hnd, index, &local);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        return (1);
    }

    /* Close the TSYNC/TSAT device */
    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }

    return (ret);

} /* End - main() */
