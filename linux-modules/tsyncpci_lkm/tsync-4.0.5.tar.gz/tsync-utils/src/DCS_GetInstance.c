#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_example.h"

#include "spec_ktsal_en.h"


int main (int argc, char *argv[])
{
    TSYNC_BoardHandle             hnd;
    int                           rc;
    int                           ret     = 0;
    int                           devIdx;
    char                         *devName = DEFAULT_DEV;
    char                          fullDevName[32];
    char                         *pgmname = argv[0];
    TSYNC_ERROR                   err     = TSYNC_SUCCESS;
    TSYNC_OptCardSlotFeatInstObj  lfi;
    int                           inst;


    /* If invalid number of arguments... */
    if (argc != 5)
    {
        printf(" Usage: DCS_GetInstance <device index> <slot> <id> <inst>\n");
        return (1);
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        return (1);
    }

    /* Build Get Local message */
    lfi.slot = atoi(argv[2]);
    lfi.featId = atoi(argv[3]);
    lfi.inst = atoi(argv[4]);

    // Send Get Local transaction
    err = TSYNC_DCS_getInstance(hnd, &lfi, &inst);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        return (1);
    }
    
    /*
      * On definition of the environment variable SPEC_KTSAL_EN
      * to true, print out the information in the format used
      * for the equivalent set's command line.
      */
    if ((getenv(SPEC_KTSAL_EN) != NULL) && 
            *getenv(SPEC_KTSAL_EN) == *ENV_TRUE)
    {
        // Print a blank line.  There is no set for this information.
        printf("\n");
    }

    printf("\n  DCS Feature System Instance:\n");

    printf("\n    Card Slot:               %d\n", lfi.slot);

    printf("\n    Feature ID:              %d\n", lfi.featId);

    printf("\n    Local Feature Instance:  %d\n", lfi.inst);

    printf("\n    System Feature Instance: %d\n", inst);

    /* Close the TSYNC/TSAT device */
    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }

    return (ret);

} /* End - main() */
