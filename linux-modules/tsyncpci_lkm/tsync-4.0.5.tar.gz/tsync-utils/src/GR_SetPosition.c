#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_example.h"


int main (int argc, char *argv[])
{
    TSYNC_BoardHandle  hnd;
    int                rc;
    int                ret     = 0;
    int                devIdx;
    char              *devName = DEFAULT_DEV;
    char               fullDevName[32];
    char              *pgmname = argv[0];
    TSYNC_ERROR        err     = TSYNC_SUCCESS;
    unsigned int       index;
    TSYNC_LLAObj       pos;


    /* If invalid number of arguments... */
    if (argc != 6)
    {
        printf(" Usage: GR_SetPosition <device index> <index> <lat> <lon> <alt>\n");
        return (1);
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        return (1);
    }

    /* Build Set Position message */
    index   = atoi(argv[2]);
    pos.lat = atof(argv[3]) * DEG_TO_RAD;
    pos.lon = atof(argv[4]) * DEG_TO_RAD;
    pos.alt = atof(argv[5]);

    printf("\n");
    printf(" GR (%d) Position:\n", (index));
    printf("  Lat (deg): %f\n",     pos.lat * RAD_TO_DEG);
    printf("  Lon (deg): %f\n",     pos.lon * RAD_TO_DEG);
    printf("  Alt (m)  : %f\n",     pos.alt);

    // Send Set Position transaction
    err = TSYNC_GR_setPosition(hnd, index, &pos);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        return (1);
    }

    /* Close the TSYNC/TSAT device */
    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }

    return (ret);

} /* End - main() */
