#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_example.h"


int main (int argc, char *argv[])
{
    TSYNC_BoardHandle       hnd;
    int                     rc, i;
    int                     ret     = 0;
    int                     devIdx;
    char                   *devName = DEFAULT_DEV;
    char                    fullDevName[32];
    char                   *pgmname = argv[0];
    TSYNC_ERROR             err     = TSYNC_SUCCESS;
    unsigned int            index;
    TSYNC_CustomMessageObj  cm;


    /* If invalid number of arguments... */
    if (argc < 7)
    {
        printf(" Usage: GR_SendCustom <device index> <index> <B0 B1 ... Bn>\n");
        return (1);
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        return (1);
    }

    /* Build Send Custom Message message */
    index = atoi(argv[2]);
    cm.len = argc - 3;
    for (i = 0; i < (argc - 3); i++)
    {
        cm.msg[i] = (char)strtoul(argv[3 + i], NULL, 16);
    }

    printf("\n");
    printf(" GR (%d) Custom Msg Sent:\n", (index));
    printf("  ------------------------\n");

    for (i = 0; i < (cm.len); i++)
    {
        if ((i % 20) == 0)
        {
            printf("  ");
        }

        printf("%02X ", ((unsigned int)(cm.msg[i]) & 0x000000FF));

        if (((i + 1) % 20) == 0)
        {
            printf("\n");
        }
    }

    printf("\n");

    // Send Send Custom Message transaction
    err = TSYNC_GR_setCustom(hnd, index, &cm);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        return (1);
    }

    /* Close the TSYNC/TSAT device */
    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }

    return (ret);

} /* End - main() */
