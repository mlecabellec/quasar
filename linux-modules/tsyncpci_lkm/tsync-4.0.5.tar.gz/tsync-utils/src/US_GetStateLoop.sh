#!/bin/sh

if [ -e /usr/bin/CS_GetTime ]; then
    DIR="/usr/bin"
else
    DIR="."
fi

while [ 1 ]
do
 tput clear
 $DIR/US_GetState $1
 sleep .1
done
