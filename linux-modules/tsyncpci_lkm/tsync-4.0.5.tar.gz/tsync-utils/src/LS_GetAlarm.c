#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_example.h"

#include "spec_ktsal_en.h"

int main (int argc, char *argv[])
{
    TSYNC_BoardHandle  hnd;
    int                rc;
    int                ret     = 0;
    int                devIdx;
    char              *devName = DEFAULT_DEV;
    char               fullDevName[32];
    char              *pgmname = argv[0];
    TSYNC_ERROR        err     = TSYNC_SUCCESS;
    TSYNC_AlarmObj     type;
    TSYNC_FlagObj      alarm;


    /* If invalid number of arguments... */
    if (argc != 3)
    {
        printf(" Usage: LS_GetAlarm <device index> <alarm type>\n");
        return (1);
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        return (1);
    }

    /* Build Get Alarm message */
    type.index = (LS_ALARM)atoi(argv[2]);

    // Send Get Alarm transaction
    err = TSYNC_LS_getAlarm(hnd, &type, &alarm);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        return (1);
    }
    
    /*
      * On definition of the environment variable SPEC_KTSAL_EN
      * to true, print out the information in the format used
      * for the equivalent set's command line.
      */
    if ((getenv(SPEC_KTSAL_EN) != NULL) && 
            *getenv(SPEC_KTSAL_EN) == *ENV_TRUE)
    {
        printf("%d\n", type.index);
    }

    printf("\n");

    switch (type.index)
    {
        case LS_ALARM_SYNC:
            printf(" Sync Alarm (%d): ", LS_ALARM_SYNC);
            break;

        case LS_ALARM_HOLDOVER:
            printf(" Holdover Alarm (%d): ", LS_ALARM_HOLDOVER);
            break;

        case LS_ALARM_FREQ_ERR:
            printf(" Frequency Error Alarm (%d): ", LS_ALARM_FREQ_ERR);
            break;

        case LS_ALARM_SELF_REF:
            printf(" Freerun Alarm (%d): ", LS_ALARM_SELF_REF);
            break;

        case LS_ALARM_SW_ERR:
            printf(" Software Error Alarm (%d): ", LS_ALARM_SW_ERR);
            break;

        case LS_ALARM_1PPS:
            printf(" 1PPS Specification Alarm (%d): ", LS_ALARM_1PPS);
            break;

        case LS_ALARM_REF_CHG:
            printf(" Reference Change Alarm (%d): ", LS_ALARM_REF_CHG);
            break;

        case LS_ALARM_HW_ERR:
            printf(" Hardware Error Alarm (%d): ", LS_ALARM_HW_ERR);
            break;

        default:
            return (1);    
    }

    ((alarm.flag) == 1) ? printf("Active\n") : printf("Inactive\n");

    /* Close the TSYNC/TSAT device */
    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }

    return (ret);    

} /* End - main() */
