#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_example.h"


#define TO_BCD(a)       ((((a % 10000) / 1000) << 12) |                     \
                         (((a % 1000)  / 100)  << 8)  |                     \
                         (((a % 100)   / 10)   << 4)  |                     \
                         (((a % 10)    / 1)    << 0))


int main (int argc, char *argv[])
{
    TSYNC_BoardHandle  hnd;
    int                rc;
    int                ret     = 0;
    int                devIdx;
    char              *devName = DEFAULT_DEV;
    char               fullDevName[32];
    char              *pgmname = argv[0];
    TSYNC_ERROR        err = TSYNC_SUCCESS;
    ML_TIME_TYPE       timeType;
    TSYNC_TimeObj      doyTime;
    TSYNC_TimeBCDObj   bcdTime;
    unsigned int       seconds;
    unsigned int       ns;


    /* If invalid number of arguments... */
    if (argc < 3)
    {
        printf(" Usage: CS_SetTime <device index> <time type> <time>\n");
        return (1);
    }

    /* Build Get Time message */
    timeType    = (ML_TIME_TYPE)atoi(argv[2]);

    switch (timeType)
    {
        case ML_TIME_DOYTIME:
            if (argc != 8)
            {
                printf(" Usage: CS_SetTime <device index> 0");
                printf(" <year> <doy> <hour> <minute> <second>\n");
                return (1);
            }
            timeType        = (ML_TIME_DOYTIME);
            doyTime.years   = atoi(argv[3]);
            doyTime.doy     = atoi(argv[4]);
            doyTime.hours   = atoi(argv[5]);
            doyTime.minutes = atoi(argv[6]);
            doyTime.seconds = atoi(argv[7]);
            doyTime.ns      = 0;
            break;

        case ML_TIME_BCDTIME:
            if (argc != 8)
            {
                printf(" Usage: CS_SetTime <device index> 1");
                printf(" <year> <doy> <hour> <minute> <second>\n");
                return (1);
            }
            timeType        = (ML_TIME_BCDTIME);
            bcdTime.years   = (TO_BCD(atoi(argv[3])));
            bcdTime.doy     = (TO_BCD(atoi(argv[4])));
            bcdTime.hours   = (TO_BCD(atoi(argv[5])));
            bcdTime.minutes = (TO_BCD(atoi(argv[6])));
            bcdTime.seconds = (TO_BCD(atoi(argv[7])));
            bcdTime.ms      = 0;
            bcdTime.us      = 0;
            break;

        case ML_TIME_SECONDS:
            if (argc != 4)
            {
                printf(" Usage: CS_SetTime <device index> 2 <second>\n");
                return (1);
            }
            timeType = (ML_TIME_SECONDS);
            seconds  = (atoi(argv[3]));
            ns       = 0;
            break;

        default:
            printf(" Usage: CS_SetTime <device index> <time type> <time>\n");
            return (1);
    }

    switch (timeType)
    {
        case ML_TIME_DOYTIME:
            printf("\n");
            printf(" DOY Time:\n");
            printf("  Year: %04d\n", doyTime.years);
            printf("  DOY:  %03d\n", doyTime.doy);
            printf("  Hr:   %02d\n", doyTime.hours);
            printf("  Min:  %02d\n", doyTime.minutes);
            printf("  Sec:  %02d\n", doyTime.seconds);
            printf("  Nsec: %09d\n", doyTime.ns);
            break;

        case ML_TIME_BCDTIME:
            printf("\n");
            printf(" BCD Time:\n");
            printf("  Year: %04X\n", bcdTime.years);
            printf("  DOY:  %03X\n", bcdTime.doy);
            printf("  Hr:   %02X\n", bcdTime.hours);
            printf("  Min:  %02X\n", bcdTime.minutes);
            printf("  Sec:  %02X\n", bcdTime.seconds);
            printf("  Msec: %03X\n", bcdTime.ms);
            printf("  Usec: %03X\n", bcdTime.us);
            break;

        case ML_TIME_SECONDS:
            printf("\n");
            printf(" Sec Time:\n");
            printf("  Sec:  %d\n", seconds);
            printf("  Nsec: %09d\n", ns);
            break;
            
        default:
            break;    
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        return (1);
    }

    switch (timeType)
    {
        case ML_TIME_DOYTIME:
            err = TSYNC_CS_setTime(hnd, &doyTime);
            break;

        case ML_TIME_BCDTIME:
            err = TSYNC_CS_setTimeBcd(hnd, &bcdTime);
            break;

        case ML_TIME_SECONDS:
            err = TSYNC_CS_setTimeSec(hnd, seconds, ns);
            break;
            
        default:
            printf("  Error: Bad time type\n");
            return (1);
    }

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        ret = (strstr(tsync_strerror(err), "RC_CHG_PENDING") != NULL) ? 2 : 1;
    }

    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }

    return (ret);

} /* End - main() */
