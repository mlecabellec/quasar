#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_example.h"

#include "GR_Common.h"

int main (int argc, char *argv[])
{
    TSYNC_BoardHandle  hnd;
    int                rc;
    int                ret     = 0;
    int                devIdx;
    char              *devName = DEFAULT_DEV;
    char               fullDevName[32];
    char              *pgmname = argv[0];
    TSYNC_ERROR        err     = TSYNC_SUCCESS;
    unsigned int       index;
    GL_MODE            mode;
    GL_DYN             dyn     = GL_DYN_LAND; // ALWAYS default to LAND
    char               modeStr[32] = {0};
    char               dynStr[32] = {0};


    /* If invalid number of arguments... */
    if ((argc < 4) || (argc > 5))
    {
        printf(" Usage: GR_SetMode <device index> <index> <mode> <dyn>\n");
        return (1);
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        return (1);
    }

    /* Build Set Mode message */
    index = atoi(argv[2]);
    mode  = (GL_MODE)atoi(argv[3]);

    // Set Dynamics value if provided. 
    // Otherwise, set the mode to their respective default dynamic
    if (argc == 5)
    {
        dyn = (GL_DYN)atoi(argv[4]);
    }
    else
    {
        // all non-continuous modes default to Stationary
        switch (mode)
        {
            case GL_MODE_1SAT:
            case GL_MODE_AVRG:
            case GL_MODE_TIME:
            case GL_MODE_STND:  dyn = GL_DYN_STAT;  break;
            case GL_MODE_CONT:
            default:            dyn = GL_DYN_LAND;  break;
        }
    }

    GR_ModeToStr(mode, modeStr);
    GR_DynToStr(dyn, dynStr);

    printf("\n  GR (%d) Rcvr Mode: %s (%d) Dynamics: %s (%d)\n", (index), modeStr, (mode), dynStr, (dyn));

    // Send Set Mode transaction
    err = TSYNC_GR_setMode(hnd, index, mode, dyn);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        return (1);
    }

    /* Close the TSYNC/TSAT device */
    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }

    return (ret);

} /* End - main() */
