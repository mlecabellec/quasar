#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_example.h"


int main (int argc, char *argv[])
{
    TSYNC_BoardHandle    hnd;
    int                  rc;
    int                  ret     = 0;
    int                  devIdx;
    char                *devName = DEFAULT_DEV;
    char                 fullDevName[32];
    char                *pgmname = argv[0];
    TSYNC_ERROR          err     = TSYNC_SUCCESS;
    TSYNC_TableEntryObj  entry;


    /* If invalid number of arguments... */
    if (argc != 6)
    {
        printf(" Usage: RS_AddEntry <device index> <enable> <priority> ");
        printf("<time source> <1PPS source>\n");
        return (1);
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        return (1);
    }

    /* Build Add Entry message */
    entry.enab    = atoi(argv[2]);
    entry.prio    = atoi(argv[3]);
    entry.time[4] = '\0';
    strncpy(entry.time, argv[4], 4);
    entry.pps[4] = '\0';
    strncpy(entry.pps, argv[5], 4);

    printf("\n");
    printf("  En  | Pri | Time | 1PPS\n");
    printf("  -----------------------\n");
    printf("  ");
    ((entry.enab) == 1) ? printf("EN  | ") : printf("DIS | ");
    printf("%-3d | ", (entry.prio));
    printf("%-4s | ", entry.time);
    printf("%-4s\n", entry.pps);

    // Send Add Entry Reference transaction
    err = TSYNC_RS_addEntry(hnd, &entry);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        return (1);
    }

    /* Close the TSYNC/TSAT device */
    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }

    return (ret);

} /* End - main() */
