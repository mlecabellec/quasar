#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_example.h"


int main (int argc, char *argv[])
{
    TSYNC_BoardHandle     hnd;
    int                   rc;
    int                   ret     = 0;
    int                   devIdx;
    char                 *devName = DEFAULT_DEV;
    char                  fullDevName[32];
    char                 *pgmname = argv[0];
    TSYNC_ERROR           err     = TSYNC_SUCCESS;
    TSYNC_TimeDSTRuleObj  dr;


    /* If invalid number of arguments... */
    if (argc != 12)
    {
        printf(" Usage: CS_SetDstRule <device index> <ref> <in wom> <in dow> <in mon> <in hr> <out wom> <out dow> <out mon> <out hr> <offset>\n");
        return (1);
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        return (1);
    }

    /* Build Get Time message */
    dr.ref       = (ML_DST_REF)atoi(argv[2]);
    dr.in.wom    = (ML_WOM)atol(argv[3]);
    dr.in.dow    = (ML_DOW)atol(argv[4]);
    dr.in.month  = (ML_MONTH)atol(argv[5]);
    dr.in.hour   = atol(argv[6]);
    dr.out.wom   = (ML_WOM)atol(argv[7]);
    dr.out.dow   = (ML_DOW)atol(argv[8]);
    dr.out.month = (ML_MONTH)atol(argv[9]);
    dr.out.hour  = atol(argv[10]);
    dr.offset    = atoi(argv[11]);

    printf("\n");
    printf(" DST Rule:\n");
    printf("   Ref: %s\n", ((dr.ref) == ML_DST_REF_UTC) ? "UTC" : "Local");
    printf("   IN:  w%u d%u m%u h%u\n", dr.in.wom, dr.in.dow, dr.in.month,
           dr.in.hour);
    printf("   OUT: w%u d%u m%u h%u\n", dr.out.wom, dr.out.dow, dr.out.month,
           dr.out.hour);
    printf("   Off: %d\n", dr.offset);

    /* Set DST Rule */
    err = TSYNC_CS_setDstRule(hnd, &dr);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        ret = (strstr(tsync_strerror(err), "RC_CHG_PENDING") != NULL) ? 2 : 1;
    }

    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }

    return (ret);

} /* End - main() */
