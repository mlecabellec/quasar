#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_example.h"

#include "spec_ktsal_en.h"

int main (int argc, char *argv[])
{
    TSYNC_BoardHandle  hnd;
    int                rc;
    int                ret     = 0;
    int                devIdx;
    char              *devName = DEFAULT_DEV;
    char               fullDevName[32];
    char              *pgmname = argv[0];
    TSYNC_ERROR        err     = TSYNC_SUCCESS;
    INT_TYPE           src;
    unsigned int       idx;
    int                en;


    /* If invalid number of arguments... */
    if (argc != 4)
    {
        printf(" Usage: HW_GetIntMask <device index> <src> <index>\n");
        return (1);
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        return (1);
    }

    /* Build Get interrupt Mask message */
    src = (INT_TYPE)atoi(argv[2]);
    idx = atoi(argv[3]);

    /* Send Get interrupt Mask transaction */
    err = TSYNC_HW_getIntMask(hnd, src, idx, &en);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        return (1);
    }
    
     /*
      * On definition of the environment variable SPEC_KTSAL_EN
      * to true, print out the information in the format used
      * for the equivalent set's command line.
      */
    if ((getenv(SPEC_KTSAL_EN) != NULL) && 
            *getenv(SPEC_KTSAL_EN) == *ENV_TRUE)
    {
        printf("%u\n", en);
    }

    printf("\n");
    switch (src)
    {
        case INT_1PPS:
            printf(" 1PPS Received");
            break;

        case INT_SVC_REQ:
            printf(" Timing System Service Request");
            break;

        case INT_LCL_UC_FIFO_EMPTY:
            printf(" Local / uC Bus FIFO Empty");
            break;

        case INT_LCL_UC_FIFO_OVER:
            printf(" Local / uC Bus FIFO Overflow");
            break;

        case INT_UC_LCL_FIFO_DATA:
            printf(" uC / Local Bus FIFO Data Available");
            break;

        case INT_UC_LCL_FIFO_OVER:
            printf(" uC / Local Bus FIFO Overflow");
            break;

        case INT_GPIO_IN:
            printf(" GPIO Input %u", idx);
            break;

        case INT_TMSTMP:
            printf(" Timestamp Data Available");
            break;

        case INT_GPIO_OUT:
            printf(" GPIO Output %u", idx);
            break;

        default:
            return (1);
            break;
    }
    printf(" Interrupt Mask: %s\n", (en == 1) ? "EN" : "DIS");

    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }

    return (ret);

} /* End - main() */
