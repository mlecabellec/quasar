#!/bin/sh

if [ -e /usr/bin/CS_GetTime ]; then
    DIR="/usr/bin"
else
    DIR="."
fi

while [ 1 ]
do
 tput clear
 $DIR/CS_GetTime $1 0
 $DIR/CS_GetTime $1 1
 $DIR/CS_GetTime $1 2
 sleep 1
done
