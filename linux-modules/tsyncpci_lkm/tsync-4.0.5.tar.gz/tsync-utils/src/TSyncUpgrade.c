#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "tsync.h"
#include "tsync_example.h"


// Macro to byte swap a 32-bit value
#define SWAPL(lword)                                                    \
    (((lword & 0x000000FF) << 24) |                                     \
     ((lword & 0x0000FF00) <<  8) |                                     \
     ((lword & 0x00FF0000) >>  8) |                                     \
     ((lword & 0xFF000000) >> 24))

// Constants
#define EEPROM_FILE "patch_img.bin"
#define GG_FILE     "rt_gnss0E_fw.bin"
#define UBX_FILE    "rt_gnss0F_fw.bin"
#define FPGA_FILE   "rt_fpga.bin"
#define FW_FILE     "rt_fw.bin"

#define UBX_BL       "M8"    // BootLoader returns this value
#define UBX_MDL      "M8T"
#define UBX_VER      "3.3.9"

#define GG_MDL      "RES-SMT GG"
#define GG_VER      "3.1.5"
#define AC_MDL      "Acutime GG"
#define AC_VER      "3.3.2"

/*
 * Function declarations
 */
int sendFile(FILE* inFile, TSYNC_BoardHandle* hnd);
void runStatusLoop(TSYNC_BoardHandle* hnd, int pct, int printMessages);


/*
 * Global variables.
 */
char fullDevName[32];


/**
 * Runs the tsync_upgrade program.
 */
int main(int argc, char* argv[])
{
    FILE                    *inFile;
    int                      devIdx;
    int                      eeUpg     = 0;
    int                      imgUpg    = 0;
    int                      ggUpg     = 0;
	int                      ubxUpg    = 0;
    int                      haveError = 0;
    int                      rc        = 0;
    TSYNC_BoardHandle        hnd;
    char                    *devName   = DEFAULT_DEV;
    TSYNC_ERROR              err       = TSYNC_SUCCESS;
    TSYNC_FirmwareVersionObj ver;
    TSYNC_ManModObj          mm;


    // Parameter checking
    if(argc != 2)
    {
        printf("  Usage: TSyncUpgrade <device index>\n");
        return 1;
    }

    // Construct the TSYNC/TSAT device name
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    // Open the device
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        printf("  Error: could not open <%s> : rc <%d>\n", fullDevName, rc);
        return 1;
    }

    // Check for eeprom patch file
    if ((inFile = fopen(EEPROM_FILE, "rb")) != NULL)
    {
        fclose(inFile);
        eeUpg = 1;
    }

    // Check for firmware image files
    if ((inFile = fopen(FW_FILE,   "rb")) != NULL)
    {
        fclose(inFile);
        imgUpg = 1;
    }

    // Check for fpga image files
    if ((inFile = fopen(FPGA_FILE, "rb")) != NULL)
    {
        fclose(inFile);
        imgUpg = 1;
    }
    
    // Check for GG file
    if ((inFile = fopen(GG_FILE, "rb")) != NULL)
    {
        fclose(inFile);
        ggUpg = 1;
    } 

    // Check for UBX file
    if ((inFile = fopen(UBX_FILE, "rb")) != NULL)
    {
        fclose(inFile);
        ubxUpg = 1;
    }    	

    // Print error if no files present
    if ((eeUpg == 0) && (imgUpg == 0) && (ggUpg == 0) && (ubxUpg == 0))
    {
        (void) printf("  Error: no upgrade files.\n");
    }

    // Process eeprom upgrade
    if (eeUpg == 1)
    {
        printf("\n  Starting EEPROM upgrade process.\n\n");

        // Open eeprom patch file
        inFile = fopen(EEPROM_FILE, "rb");

        // Error if can't open file
        if (inFile == NULL)
        {
	      (void) printf("  Error: can't find file <");
          (void) printf(EEPROM_FILE);
          (void) printf(">.\n");
            return rc;
        }

        // Send the eeprom patch file
        haveError = sendFile(inFile, &hnd);

        // Run the status loop
        if(haveError == 0) { runStatusLoop(&hnd, 100, 1); }
        else { printf("  Error: failed to send eeprom patch file.\n\n"); }

        if(haveError == 0)
        {
            printf("  EEPROM upgrade process completed successfully.\n");
            printf("  Reset required to take effect.\n\n");
        }
    }

    // Process GG Upgrade (like eeprom upgrade)
    if (ggUpg == 1)
    {
        printf("\n  Starting GNSS Receiver upgrade process.\n\n");

        // Open Res SMT GG Upgrade file
        inFile = fopen(GG_FILE, "rb");

        // Error if can't open file
        if (inFile == NULL)
        {
            (void) printf("  Error: can't open GNSS Receiver Upgrade File.\n");
            return rc;
        }

        // Check for GG model
        err = TSYNC_GR_getMfrMdl(hnd, 0, &mm);

        if (err != TSYNC_SUCCESS)
        {
            printf("  Error: %s.\n", tsync_strerror(err));
            fclose(inFile);
            return 1;
        }

        // TBD: Upgrade will fail if RES-SMT GG is in bootloader reporting
        //      NO Model of version information.
        if ((strcmp(mm.mdl, GG_MDL) != 0) &&
            (strcmp(mm.mdl, AC_MDL) != 0))
        {
            printf("Wrong Receiver Type for Receiver Upgrade\n");
			fclose(inFile);
            return 1;
        }

	    // Check Version
        err = TSYNC_LS_getVersion(hnd, &ver);

        if (err != TSYNC_SUCCESS)
        {
            printf("  Error: %s.\n", tsync_strerror(err));
			fclose(inFile);
            return 1;
        }

        if (((strcmp(mm.mdl, GG_MDL) == 0) && (strcmp(ver.version, GG_VER) < 0)) ||
            ((strcmp(mm.mdl, AC_MDL) == 0) && (strcmp(ver.version, AC_VER) < 0)))
        {
            printf("Must upgrade timing firmware before applying GNSS upgrade\n");
			fclose(inFile);
            return 1;
        }

        // Send the eeprom patch file
        haveError = sendFile(inFile, &hnd);

        // Run the status loop
        if(haveError == 0) { runStatusLoop(&hnd, 100, 1); }
        else { printf("  Error: failed to send GNSS Receiver Upgrade file.\n\n"); }

        if(haveError == 0)
        {
            printf("  GNSS Receiver upgrade process completed successfully.\n");
            printf("  Reset required to take effect.\n\n");
        }
    }

	// Process UBX Upgrade (like eeprom upgrade)
    if (ubxUpg == 1)
    {
        printf("\n  Starting GNSS Receiver upgrade process.\n\n");

        // Open UBX Upgrade file
        inFile = fopen(UBX_FILE, "rb");

        // Error if can't open file
        if (inFile == NULL)
        {
            (void) printf("  Error: can't open GNSS Receiver Upgrade File.\n");
            return rc;
        }

        // Check for GG model
        err = TSYNC_GR_getMfrMdl(hnd, 0, &mm);

        if (err != TSYNC_SUCCESS)
        {
            printf("  Error: %s.\n", tsync_strerror(err));
            fclose(inFile);
            return 1;
        }

        if ((strcmp(mm.mdl, UBX_MDL) != 0) &&
            (strcmp(mm.mdl, UBX_BL)  != 0))
        {
            printf("Wrong Receiver Type for Receiver Upgrade\n");
			fclose(inFile);
            return 1;
        }

	    // Check Version
        err = TSYNC_LS_getVersion(hnd, &ver);

        if (err != TSYNC_SUCCESS)
        {
            printf("  Error: %s.\n", tsync_strerror(err));
			fclose(inFile);
            return 1;
        }

        if (((strcmp(mm.mdl, UBX_MDL) == 0) || (strcmp(mm.mdl, UBX_BL) == 0)) && (strcmp(ver.version, UBX_VER) < 0))
        {
            printf("Must upgrade timing firmware before applying GNSS upgrade\n");
			fclose(inFile);
            return 1;
        }

        // Send the eeprom patch file
        haveError = sendFile(inFile, &hnd);

        // Run the status loop
        if(haveError == 0) { runStatusLoop(&hnd, 100, 1); }
        else { printf("  Error: failed to send GNSS Receiver Upgrade file.\n\n"); }

        if(haveError == 0)
        {
            printf("  GNSS Receiver upgrade process completed successfully.\n");
            printf("  Reset required to take effect.\n\n");
        }
    }
		
    // Process image upgrade
    if ((imgUpg == 1) && (haveError == 0))
    {
        printf("\n  Starting image upgrade process.\n\n");

        // Open first image file
        inFile = fopen(FW_FILE, "rb");

        // Error if can't open file
        if (inFile == NULL)
        {
            (void) printf("  Error: can't find file <");
            (void) printf(FW_FILE);
            (void) printf(">.\n");
            haveError = 1;
        }

        // Send the first image file
        haveError = (haveError == 0) ? sendFile(inFile, &hnd) : haveError;

        // Run the status loop
        if(haveError == 0) { runStatusLoop(&hnd, 12, 0); }
        else { printf("  Error: failed to send image file.\n\n"); }

        // Process second image file
        if(haveError == 0)
        {
            // Open second image file
            inFile = fopen(FPGA_FILE, "rb");

            // Error if can't open file
            if (inFile == NULL)
            {
	        (void)printf("  Error: can't find file <");
                (void)printf(FPGA_FILE);
                (void)printf(">.\n");
                haveError = 1;
            }

            haveError = (haveError == 0) ? sendFile(inFile, &hnd) : haveError;

            // Run the status loop
            if(haveError == 0) { runStatusLoop(&hnd, 100, 1); }
            else { printf("  Error: failed to send image file.\n\n"); }
        }

        if(haveError == 0)
        {
            printf("  Image upgrade process completed successfully.\n");
            printf("  Reset required to take effect.\n\n");
        }
    }

    // Close the device
    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("  Error closing <%s>, rc: <%d>\n", fullDevName, rc );
    }

    return rc;
}


/**
 * Reads in the specified file and sends it to the specified
 * device. Returns 1 if there is any sort of failure.
 */
int sendFile(FILE* inFile, TSYNC_BoardHandle* hnd) {
    unsigned int            fileLen;
    unsigned int            i;
    TSYNC_ERROR             err = TSYNC_SUCCESS;
    TSYNC_ULImageIdObj      imgId; 
    TSYNC_ULImageHeaderObj  hdr;
    TSYNC_UpdateDataObj     data;
    TSYNC_UpdateEndObj      trl;


    // Read image header from file
    (void)fread(&hdr, 1, sizeof(TSYNC_ULImageHeaderObj), inFile);
    hdr.mark = SWAPL(hdr.mark);
    hdr.type = (UL_IMG)SWAPL(hdr.type);
    hdr.len  = SWAPL(hdr.len);

    // Build Image ID
    imgId.type = (UL_IMG)(hdr.type & 0xFFFF);
    imgId.slot = 0;    

    // Determine file length
    (void)fseek(inFile, 0, SEEK_END);
    fileLen = ftell(inFile);

    // Read image trailer from file
    (void)fseek(inFile, 0 - (sizeof(TSYNC_UpdateEndObj) - sizeof(UL_IMG)),
                SEEK_CUR);
    (void)fread(&(trl.ver[0]), 1, sizeof(TSYNC_UpdateEndObj) - sizeof(UL_IMG),
                inFile);
    trl.crc = SWAPL(trl.crc);

    // Print image info
    printf(" Image file:\n");
    printf("  Mark:    0x%08X\n", (hdr.mark));
    printf("  Type:    0x%08X\n", (hdr.type));
    printf("  Length:  0x%08X\n", (hdr.len));
    printf("  Version: %c%c%c%c\n", trl.ver[0], trl.ver[1], trl.ver[2],
           trl.ver[3]);
    printf("  CRC:     0x%08X\n\n", (trl.crc));

    printf("  Sending...");
    fflush(stdout);

    // Send UpgradeStart or UpgradeStartComp based on Image ID
    // Assumes TSync will always have a single GPS receiver at gps0
    if ((hdr.type == UL_IMG_RES_GG_FW) || (hdr.type == UL_IMG_RES_UBX_FW))
    {
        err = TSYNC_US_startComp(*hnd, &imgId, &hdr);
    }
    else
    {	
        err = TSYNC_US_start(*hnd, &hdr);
    }

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        fclose(inFile);
        return 1;
    }

    // Move back to beginning of image
    (void)fseek(inFile, 0, SEEK_SET);

    for (i = 0; i < fileLen; i += TSYNC_DATA_BLOCK_SIZE)
    {
        // Build upgrade data message
        data.type = hdr.type;
        (void)fread(&data.data, 1, TSYNC_DATA_BLOCK_SIZE, inFile);

        // Send upgrade data transaction
        err = TSYNC_US_data(*hnd, &data);

        if (err != TSYNC_SUCCESS)
        {
            printf("  Error: %s.\n", tsync_strerror(err));
            fclose(inFile);
            return 1;
        }
    }

    // Build upgrade end message
    trl.type = hdr.type;

    // Send upgrade end transaction
    err = TSYNC_US_end(*hnd, &trl);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        fclose(inFile);
        return 1;
    }

    printf(" done\n\n");

    // Close the file.
    fclose(inFile);

    return 0;
}


/**
 * Runs a loop that continues retreiving the status
 * from the specified device until an error occurs or
 * the device returns a status of "pct" complete.
 */
void runStatusLoop(TSYNC_BoardHandle* hnd, int pct, int printMessages) {
    TSYNC_ERROR    err      = TSYNC_SUCCESS;
    TSYNC_StateObj state;
    int            complete = 0;


    do
    {
        err = TSYNC_US_getState(*hnd, &state);

        if (err != TSYNC_SUCCESS)
        {
            printf("\n  Error: %s.\n", tsync_strerror(err));
            return;
        }

        complete = state.complete;

        if(printMessages)
        {
            printf("  Upgrade status: %d%% complete...\r", complete);
        }

#if WIN32
		Sleep(100);
#else
        usleep(100000);
#endif
    } while (complete < pct);

    if (printMessages)
    {
        printf("\n\n");
    }
}
