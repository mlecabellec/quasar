#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "tsync.h"
#include "tsync_example.h"


// Macro to byte swap a 32-bit value
#define SWAPL(lword)                                                    \
    (((lword & 0x000000FF) << 24) |                                     \
     ((lword & 0x0000FF00) <<  8) |                                     \
     ((lword & 0x00FF0000) >>  8) |                                     \
     ((lword & 0xFF000000) >> 24))


int main (int argc, char *argv[])
{
    TSYNC_BoardHandle       hnd;
    int                     rc;
    int                     ret     = 0;
    int                     devIdx;
    char                   *devName = DEFAULT_DEV;
    char                    fullDevName[32];
    char                   *pgmname = argv[0];
    TSYNC_ERROR             err     = TSYNC_SUCCESS;
    FILE                   *inFile;
    unsigned int            fileLen;
    unsigned int            i;
    TSYNC_ULImageHeaderObj  hdr;
    TSYNC_UpdateDataObj     data;
    TSYNC_UpdateEndObj      trl;


    /* If invalid number of arguments... */
    if (argc != 3)
    {
        printf(" Usage: US_Upgrade <device index> <image file>\n");
        return (1);
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /* Open image file */
    inFile = fopen(argv[2], "rb");

    /* Error if can't open file */
    if (inFile == NULL)
    {
        printf("Could not open image file <%s>\n", argv[2]);
        return (1);
    }

    /* Read image header from file */
    (void)fread(&hdr, 1, sizeof(TSYNC_ULImageHeaderObj), inFile);
    hdr.mark = SWAPL(hdr.mark);
    hdr.type = (UL_IMG)SWAPL(hdr.type);
    hdr.len  = SWAPL(hdr.len);

    /* Determine file length */
    (void)fseek(inFile, 0, SEEK_END);
    fileLen = ftell(inFile);

    /* Read image trailer from file */
    (void)fseek(inFile, 0 - (sizeof(TSYNC_UpdateEndObj) - sizeof(UL_IMG)),
                SEEK_CUR);
    (void)fread(&(trl.ver[0]), 1, sizeof(TSYNC_UpdateEndObj) - sizeof(UL_IMG),
                inFile);
    trl.crc = SWAPL(trl.crc);

    /* Print image info */
    printf("\n Image Info:\n");
    printf("  Mark:    0x%08X\n", (hdr.mark));
    printf("  Type:    0x%08X\n", (hdr.type));
    printf("  Length:  0x%08X\n", (hdr.len));
    printf("  Version: %d.%d.%d.%d\n", trl.ver[0], trl.ver[1], trl.ver[2],
           trl.ver[3]);
    printf("  CRC:     0x%08X\n\n", (trl.crc));

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        fclose(inFile);
        return (1);
    }

    // Send upgrade start transaction
    err = TSYNC_US_start(hnd, &hdr);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        fclose(inFile);
        return (1);
    }

    /* Move back to beginning of image */
    (void)fseek(inFile, 0, SEEK_SET);

    for (i = 0; i < fileLen; i += TSYNC_DATA_BLOCK_SIZE)
    {
        /* Build upgrade data message */
        data.type = hdr.type;
        (void)fread(&data.data, 1, TSYNC_DATA_BLOCK_SIZE, inFile);

        // Send upgrade data transaction
        err = TSYNC_US_data(hnd, &data);

        if (err != TSYNC_SUCCESS)
        {
            printf("  Error: %s.\n", tsync_strerror(err));
            fclose(inFile);
            return (1);
        }
    }

    /* Build upgrade end message */
    trl.type = hdr.type;

    // Send upgrade end transaction
    err = TSYNC_US_end(hnd, &trl);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        fclose(inFile);
        return (1);
    }

    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }
    fclose(inFile);

    return (ret);

} /* End - main() */
