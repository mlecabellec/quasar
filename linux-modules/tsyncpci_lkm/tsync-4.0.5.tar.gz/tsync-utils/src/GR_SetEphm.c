#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_example.h"


int main (int argc, char *argv[])
{
    TSYNC_BoardHandle  hnd;
    int                rc;
    int                ret     = 0;
    int                devIdx;
    char              *devName = DEFAULT_DEV;
    char               fullDevName[32];
    char              *pgmname = argv[0];
    TSYNC_ERROR        err     = TSYNC_SUCCESS;
    unsigned int       index;
    TSYNC_EphmObj      ephm;


    /* If invalid number of arguments... */
    if (argc != 33)
    {
        printf("Usage: GR_SetEphm <device index> <index> <prn> <svHealth> "
               "<Week> <codeL2> <L2Pdata> <iodc> <tgd> <toc> <af2> <af1> <af0> "
               "<svAcc> <iode> <fiFlag> <crs> <deltaN> <m0> <cuc> "
               "<e> <cus> <sqrtA> <toe> <cic> <omega0> <cis> <io> <crc> "
               "<omega> <omegaDot> <idot>\n");

        //printf("argc=%d\n", argc);
        return (1);
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        return (1);
    }

    /* Build Set Ephemeris message */
    index   = atoi(argv[2]);

    ephm.ephm.prn          = atoi(argv[3]);
    ephm.ephm.svHealth     = atoi(argv[4]);
    ephm.ephm.tephem       = 0.9999E9;      // TBD RFD A-GPS Client
    ephm.ephm.weekNumber   = atoi(argv[5]);
    ephm.ephm.codeL2       = atof(argv[6]);
    ephm.ephm.L2Pdata      = atof(argv[7]);
    ephm.ephm.uraIdx       = 0;             // TBD RFD A-GPS Client
    ephm.ephm.iodc         = atof(argv[8]);
    ephm.ephm.tgd          = atof(argv[9]);
    ephm.ephm.toc          = atof(argv[10]);
    ephm.ephm.af2          = atof(argv[11]);
    ephm.ephm.af1          = atof(argv[12]);
    ephm.ephm.af0          = atof(argv[13]);
    ephm.ephm.svAcc        = atof(argv[14]);
    ephm.ephm.iode         = atof(argv[15]);
    ephm.ephm.fit_interval = atof(argv[16]);
    ephm.ephm.crs          = atof(argv[17]);
    ephm.ephm.deltaN       = atof(argv[18]);
    ephm.ephm.m0           = atof(argv[19]);
    ephm.ephm.cuc          = atof(argv[20]);
    ephm.ephm.e            = atof(argv[21]);
    ephm.ephm.cus          = atof(argv[22]);
    ephm.ephm.sqrtA        = atof(argv[23]);
    ephm.ephm.toe          = atof(argv[24]);
    ephm.ephm.cic          = atof(argv[25]);
    ephm.ephm.omega0       = atof(argv[26]);
    ephm.ephm.cis          = atof(argv[27]);
    ephm.ephm.io           = atof(argv[28]);
    ephm.ephm.crc          = atof(argv[29]);
    ephm.ephm.omega        = atof(argv[30]);
    ephm.ephm.omegaDot     = atof(argv[31]);
    ephm.ephm.idot         = atof(argv[32]);

    printf("\n  GR (%d) Ephemeris: SV ID: (%u) : \n", (index), (ephm.ephm.prn));
    printf("\tSV Health: %u\n", ephm.ephm.svHealth);
    printf("\tWeek Num: %u\n", ephm.ephm.weekNumber);	
    printf("\tcodeL2: %u\n", ephm.ephm.codeL2);
    printf("\tL2Pdata: %u\n", ephm.ephm.L2Pdata);
    printf("\turaIdx: %u\n", ephm.ephm.uraIdx);
    printf("\tiodc: %u\n", ephm.ephm.iodc);
    printf("\ttgd: %f\n", ephm.ephm.tgd);
    printf("\ttoc: %f\n", ephm.ephm.toc);
    printf("\taf2: %f\n", ephm.ephm.af2);
    printf("\taf1: %f\n", ephm.ephm.af1);
    printf("\taf0: %f\n", ephm.ephm.af0);
    printf("\tsvAcc: %f\n", ephm.ephm.svAcc);
    printf("\tiode: %u\n", ephm.ephm.iode);
    printf("\tfiFlag: %u\n", ephm.ephm.fit_interval);
    printf("\tcrs: %f\n", ephm.ephm.crs);
    printf("\tdeltaN: %f\n", ephm.ephm.deltaN);
    printf("\tm0: %f\n", ephm.ephm.m0);
    printf("\tcuc: %f\n", ephm.ephm.cuc);
    printf("\te: %f\n", ephm.ephm.e);
    printf("\tcus: %f\n", ephm.ephm.cus);
    printf("\tsqrtA: %f\n", ephm.ephm.sqrtA);
    printf("\ttoe: %f\n", ephm.ephm.toe);
    printf("\tcic: %f\n", ephm.ephm.cic);
    printf("\tomega0: %f\n", ephm.ephm.omega0);
    printf("\tcis: %f\n", ephm.ephm.cis);
    printf("\tio: %f\n", ephm.ephm.io);
    printf("\tcrc: %f\n", ephm.ephm.crc);
    printf("\tomega: %f\n", ephm.ephm.omega);
    printf("\tomegaDot: %f\n", ephm.ephm.omegaDot);
    printf("\tidot: %f\n", ephm.ephm.idot);

    // Send Set Ephemeris transaction
    err = TSYNC_GR_setEphm(hnd, index, &ephm);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        return (1);
    }

    /* Close the TSYNC/TSAT device */
    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }

    return (ret);

} /* End - main() */
