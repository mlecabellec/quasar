#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_example.h"

#include "spec_ktsal_en.h"

int main (int argc, char *argv[])
{
    TSYNC_BoardHandle     hnd;
    int                   rc;
    int                   ret     = 0;
    int                   devIdx;
    char                 *devName = DEFAULT_DEV;
    char                  fullDevName[32];
    char                 *pgmname = argv[0];
    TSYNC_ERROR           err     = TSYNC_SUCCESS;
    unsigned int          index;
    TSYNC_IRIGMessageObj  msg;


    /* If invalid number of arguments... */
    if (argc != 3)
    {
        printf(" Usage: IR_GetMessage <device index> <index>\n");
        return (1);
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        return (1);
    }

    /* Build Get Message message */
    index = atoi(argv[2]);

    // Send Get Message transaction
    err = TSYNC_IR_getMessage(hnd, index, &msg);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        return (1);
    }
    
     /*
      * On definition of the environment variable SPEC_KTSAL_EN
      * to true, print out the information in the format used
      * for the equivalent set's command line.
      */
    if ((getenv(SPEC_KTSAL_EN) != NULL) && 
            *getenv(SPEC_KTSAL_EN) == *ENV_TRUE)
    {
        printf("%X %X %X %X %X %X %X %X %X %X\n",   (msg.subframes[0]),
                                                    (msg.subframes[1]),
                                                    (msg.subframes[2]),
                                                    (msg.subframes[3]),
                                                    (msg.subframes[4]),
                                                    (msg.subframes[5]),
                                                    (msg.subframes[6]),
                                                    (msg.subframes[7]),
                                                    (msg.subframes[8]),
                                                    (msg.subframes[9]));
    }

    printf("\n  IR (%d) Message:\n", (index));
    printf("\n    Sub P0: %04X\n",    (msg.subframes[0]));
    printf("\n    Sub P1: %04X\n",    (msg.subframes[1]));
    printf("\n    Sub P2: %04X\n",    (msg.subframes[2]));
    printf("\n    Sub P3: %04X\n",    (msg.subframes[3]));
    printf("\n    Sub P4: %04X\n",    (msg.subframes[4]));
    printf("\n    Sub P5: %04X\n",    (msg.subframes[5]));
    printf("\n    Sub P6: %04X\n",    (msg.subframes[6]));
    printf("\n    Sub P7: %04X\n",    (msg.subframes[7]));
    printf("\n    Sub P8: %04X\n",    (msg.subframes[8]));
    printf("\n    Sub P9: %04X\n",    (msg.subframes[9]));

    /* Close the TSYNC/TSAT device */
    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }

    return (ret);

} /* End - main() */
