#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <netinet/in.h>

#include "tsync.h"
#include "tsync_example.h"

#include "spec_ktsal_en.h"


int main (int argc, char *argv[])
{
    TSYNC_BoardHandle       hnd;
    int                     rc;
    int                     ret = 0;
    int                     devIdx;
    char                   *devName = DEFAULT_DEV;
    char                    fullDevName[32];
    char                   *pgmname = argv[0];
    TSYNC_ERROR             err     = TSYNC_SUCCESS;
    unsigned int            index;
    TSYNC_ReceiverParmObj   parm;
    float                   val; 
    char                    fixStr[16] = {0};


    /* If invalid number of arguments... */
    if (argc != 4)
    {
        printf(" Usage: GR_GetParm <device index> <index> <parm>\n");
        return (1);
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        return (1);
    }

    // Clear the structure
    memset(&parm, 0, sizeof(TSYNC_ReceiverParmObj)); 

    /* Build Get Parameter Message message */
    index       = atoi(argv[2]);
    parm.parm   = atoi(argv[3]);

    // Send Get Custom Message transaction
    err = TSYNC_GR_getParameter(hnd, index, &parm);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        return (1);
    }

    /*
     * On definition of the environment variable SPEC_KTSAL_EN
     * to true, print out the information in the format used
     * for the equivalent set's command line.
     */
    if ((getenv(SPEC_KTSAL_EN) != NULL) && 
            *getenv(SPEC_KTSAL_EN) == *ENV_TRUE)
    {
        printf("%d %d %d %d %d", parm.parm, 
                                 parm.cfg[0], parm.cfg[1], 
                                 parm.cfg[2], parm.cfg[3]);

        printf("\n");
    }

    printf("\n");
    printf(" GR (%d) Parameter Msg:\n", (index));
    printf("  ------------------------\n");

    switch (parm.parm)
    {
        case GL_PARM_UBX_GPS_WEEK:
            printf("Current GPS Week Rollover: %d\n", parm.cfg[0]);
            printf("Default GPS Week Rollover: %d\n", parm.cfg[1]);
            break;
        case GL_PARM_UBX_SURVEY:

            switch (parm.cfg[2])
            {
                case GL_FIX_DIM_NONE:     strcpy(fixStr, "NONE");     break;
                case GL_FIX_DIM_DEAD:     strcpy(fixStr, "DEAD");     break;
                case GL_FIX_DIM_2D:       strcpy(fixStr, "2D");       break;
                case GL_FIX_DIM_3D:       strcpy(fixStr, "3D");       break;
                case GL_FIX_DIM_GPS_DEAD: strcpy(fixStr, "GPS+DEAD"); break;
                case GL_FIX_DIM_TIME:     strcpy(fixStr, "TIME");     break;
                default:                  strcpy(fixStr, "UNKNOWN");  break;
            }

            printf("Survey Duration (sec): %d\n", parm.cfg[0]);
            printf("Survey 3D Variance:    %u\n", parm.cfg[1]);       
            printf("GPS Fix:               %s (%d)\n", fixStr, parm.cfg[2]);
            printf("Survey Progress (%%):   %d\n", parm.cfg[3]);
            break;
        case GL_PARM_UBX_ACCURACY:
            printf("Time Accuracy (nsec):    %d\n", parm.cfg[0]);
            memcpy(&val, &parm.cfg[1], sizeof(float));
            printf("Horizontal Accuracy (m): %f\n", val);
            memcpy(&val, &parm.cfg[2], sizeof(float));
            printf("Vertical Accuracy (m):   %f\n", val);
            memcpy(&val, &parm.cfg[3], sizeof(float));
            printf("GDOP:                    %f\n", val);
            break;
        case GL_PARM_UBX_ALTITUDE:
            printf("Altitude:                        %d (%s)\n", parm.cfg[0], ((parm.cfg[0] == 0) ? "MSL" : "GEOID"));
            printf("Geoid Datum:                     %d (%s)\n", parm.cfg[1], ((parm.cfg[1] == 0) ? "WGS-84" : "USER"));
            memcpy(&val, &parm.cfg[2], sizeof(float));
            printf("Height above Mean Sea Level (m): %f\n", val);
            memcpy(&val, &parm.cfg[3], sizeof(float));
            printf("Height above Geoid (m):          %f\n", val);
            break;
        case GL_PARM_GSSIP_KEY_STATE:
            printf("Keys State:   %s\n", 
                   ((parm.cfg[0]) ? "VALID" : "INVALID"));
            printf("Keys Warning: %s\n", 
                   ((parm.cfg[1]) ? "EXPIRING" : "NONE"));
            break;
        case GL_PARM_GSSIP_COM1_EN:
            {
                printf("Com1 Enable: %s (%d)\n",
                       ((parm.cfg[0]) ? "TRUE" : "FALSE"), 
                       parm.cfg[0]);
            }            
            break;
        case GL_PARM_GSSIP_COM1_CFG:
            {
                switch (parm.cfg[0])
                {
                   case GL_GSSIP_COM1_HS_IN:
                       printf("Com1 Use: Idle/HotStart Input (%d)",
                           parm.cfg[0]);
                       break;
                   case GL_GSSIP_COM1_HS_OUT:
                       printf("Com1 Use: Idle/HotStart Output (%d)",
                           parm.cfg[0]);
                       break;
                   case GL_GSSIP_COM1_HVQK:
                       printf("Com1 Use: HaveQuick Output (%d)", parm.cfg[0]);
                       break;
                   case GL_GSSIP_COM1_PPS:
                       printf("Com1 Use: PPS Output (%d)", parm.cfg[0]);
                       break;
                   default:
                        printf("Unrecognized COM1 Config parameter: (%d)",
                            parm.cfg[0]);
                       break;
                }
            }            
            break;
        case GL_PARM_GSSIP_PWR_CTRL:
            {
                printf("Power Off: %s (%d)\n",
                       ((parm.cfg[0]) ? "TRUE" : "FALSE"), 
                       parm.cfg[0]);
            }            
            break;
        case GL_PARM_POS_SERVICE:
            printf("Positioning Service: %s (%d)\n",
                   ((parm.cfg[0]) ? "PRECISE" : "STANDARD"),
                   parm.cfg[0]);
            break;
        default:
            printf("Unrecognized parameter:");
            printf("parm: cfg[0]: %d cfg[0]: %d cfg[1]: %d cfg[2]: %d cfg[3]: %d", 
                parm.parm, parm.cfg[0], parm.cfg[1], parm.cfg[2], parm.cfg[3]);
            break;
    }

    printf("\n");

    /* Close the TSYNC/TSAT device */
    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }

    return (ret);

} /* End - main() */
