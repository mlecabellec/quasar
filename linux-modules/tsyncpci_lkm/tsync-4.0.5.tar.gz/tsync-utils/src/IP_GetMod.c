#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_example.h"

#include "spec_ktsal_en.h"

int main (int argc, char *argv[])
{
    TSYNC_BoardHandle  hnd;
    int                rc;
    int                ret     = 0;
    int                devIdx;
    char              *devName = DEFAULT_DEV;
    char               fullDevName[32];
    char              *pgmname = argv[0];
    TSYNC_ERROR        err     = TSYNC_SUCCESS;
    unsigned int       index;
    IL_MOD             mod;


    /* If invalid number of arguments... */
    if (argc != 3)
    {
        printf(" Usage: IP_GetMod <device index> <index>\n");
        return (1);
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        return (1);
    }

    /* Build Get Mod message */
    index = atoi(argv[2]);

    // Send Get Mod transaction
    err = TSYNC_IP_getMod(hnd, index, &mod);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        return (1);
    }
    
    /*
      * On definition of the environment variable SPEC_KTSAL_EN
      * to true, print out the information in the format used
      * for the equivalent set's command line.
      */
    if ((getenv(SPEC_KTSAL_EN) != NULL) && 
            *getenv(SPEC_KTSAL_EN) == *ENV_TRUE)
    {
        printf("%d\n", mod);
    }

    printf("\n  IP (%d) Modulation: (%d) ", (index), (mod));

    switch ((mod))
    {
        case IL_MOD_DCLS:           printf("DCLS\n");           break;
        case IL_MOD_AM:             printf("AM\n");             break;
        case IL_MOD_MAN:            printf("Manchester\n");     break;
        case IL_MOD_AM_AND_DCLS:    printf("AM and DCLS\n");    break;
        case IL_MOD_UNKNOWN:
        default:                    printf("Unknown\n");        break;
    }

    /* Close the TSYNC/TSAT device */
    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }

    return (ret);

} /* End - main() */
