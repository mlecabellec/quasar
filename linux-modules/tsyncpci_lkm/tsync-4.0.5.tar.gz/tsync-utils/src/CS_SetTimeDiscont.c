#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_example.h"


int main (int argc, char *argv[])
{
    TSYNC_BoardHandle    hnd;
    int                  rc;
    int                  ret     = 0;
    int                  devIdx;
    char                *devName = DEFAULT_DEV;
    char                 fullDevName[32];
    char                *pgmname = argv[0];
    TSYNC_ERROR          err     = TSYNC_SUCCESS;
    TSYNC_TimeDiscontObj disco;


    /* If invalid number of arguments... */
    if (argc != 13)
    {
        printf(" Usage: CS_SetTimeDiscont <device index> <active> <from hr> <from min> <from sec> <from doy> <from yr> <to hr> <to min> <to sec> <to doy> <to yr>\n");
        return (1);
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        return (1);
    }

    /* Build Get Time message */
    disco.bActive               = atoi(argv[2]);
    disco.effectiveTime.hours   = atol(argv[3]);
    disco.effectiveTime.minutes = atol(argv[4]);
    disco.effectiveTime.seconds = atol(argv[5]);
    disco.effectiveTime.doy     = atol(argv[6]);
    disco.effectiveTime.years   = atol(argv[7]);
    disco.effectiveTime.ns      = 0;
    disco.newTime.hours         = atol(argv[8]);
    disco.newTime.minutes       = atol(argv[9]);
    disco.newTime.seconds       = atol(argv[10]);
    disco.newTime.doy           = atol(argv[11]);
    disco.newTime.years         = atol(argv[12]);
    disco.newTime.ns            = 0;

    printf("\n");
    printf(" Time Discontinuity: %s\n",
           ((disco.bActive) == 1) ? "Active" : "Inactive");
    printf("   %02u:%02u:%02u %03u/%04u --> %02u:%02u:%02u %03u/%04u\n",
           (disco.effectiveTime.hours), (disco.effectiveTime.minutes),
           (disco.effectiveTime.seconds), (disco.effectiveTime.doy),
           (disco.effectiveTime.years),
           (disco.newTime.hours), (disco.newTime.minutes), 
           (disco.newTime.seconds), (disco.newTime.doy), 
           (disco.newTime.years));

    /* Get Time Discontinuity */
    err = TSYNC_CS_setTimeDiscont(hnd, &disco);
        
    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        return (1);
    }

    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }

    return (ret);

} /* End - main() */
