#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "tsync.h"
#include "tsync_example.h"


// Macro to byte swap a 32-bit value
#define SWAPL(lword)                                                    \
    (((lword & 0x000000FF) << 24) |                                     \
     ((lword & 0x0000FF00) <<  8) |                                     \
     ((lword & 0x00FF0000) >>  8) |                                     \
     ((lword & 0xFF000000) >> 24))


int main (int argc, char *argv[])
{
    TSYNC_BoardHandle       hnd;
    int                     rc;
    int                     ret     = 0;
    int                     devIdx;
    char                   *devName = DEFAULT_DEV;
    char                    fullDevName[32];
    char                   *pgmname = argv[0];
    char                    compName[4];
    TSYNC_ERROR             err     = TSYNC_SUCCESS;
    FILE                   *inFile;
    unsigned int            fileLen;
    unsigned int            i;
    TSYNC_ULImageIdObj      imgId;
    TSYNC_ULImageHeaderObj  hdr;
    TSYNC_UpdateDataObj     data;
    TSYNC_UpdateEndObj      trl;


    /* If invalid number of arguments... */
    if (argc != 4)
    {
        printf(" Usage: US_UpgradeComp <device index> <inst> <image file>\n");
        return (1);
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /* Open image file */
    inFile = fopen(argv[3], "rb");

    /* Error if can't open file */
    if (inFile == NULL)
    {
        printf("Could not open image file <%s>\n", argv[3]);
        return (2);
    }

    /* Read image header from file */
    (void)fread(&hdr, 1, sizeof(TSYNC_ULImageHeaderObj), inFile);
    hdr.mark = SWAPL(hdr.mark);
    hdr.type = (UL_IMG)SWAPL(hdr.type);
    hdr.len  = SWAPL(hdr.len);

    /* Build image ID */
    imgId.type = (UL_IMG)(hdr.type & 0xFFFF);
    imgId.slot = atoi(argv[2]);

    /* Determine file length */
    (void)fseek(inFile, 0, SEEK_END);
    fileLen = ftell(inFile);

    /* Read image trailer from file */
    (void)fseek(inFile, 0 - (sizeof(TSYNC_UpdateEndObj) - sizeof(UL_IMG)),
                SEEK_CUR);
    (void)fread(&(trl.ver[0]), 1, sizeof(TSYNC_UpdateEndObj) - sizeof(UL_IMG),
                inFile);
    trl.crc = SWAPL(trl.crc);

    // Set component name based on image type
    if ((hdr.type == UL_IMG_RES_GG_FW) ||(hdr.type == UL_IMG_RES_UBX_FW))
    {
        (void)sprintf(compName, "GPS");
    }
    else
    {
        printf("Incorrect component image <%s>\n", argv[3]);
        fclose(inFile);
        return (3);
    }

    /* Print image info */
    printf("\n Image Info for %s %u:\n", compName, imgId.slot);
    printf("  Mark:    0x%08X\n", (hdr.mark));
    printf("  Type:    0x%08X\n", (UL_IMG)SWAPL(hdr.type));
    printf("  Length:  0x%08X\n", (hdr.len));
    printf("  Version: %c%c%c%c\n", trl.ver[0], trl.ver[1], trl.ver[2],
           trl.ver[3]);
    printf("  CRC:     0x%08X\n\n", (trl.crc));

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        fclose(inFile);
        return (4);
    }

    // Send upgrade start transaction
    err = TSYNC_US_startComp(hnd, &imgId, &hdr);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        fclose(inFile);
        return (5);
    }

    /* Move back to beginning of image */
    (void)fseek(inFile, 0, SEEK_SET);

    for (i = 0; i < fileLen; i += TSYNC_DATA_BLOCK_SIZE)
    {
        /* Build upgrade data message */
        data.type = imgId.type;
        (void)fread(&data.data, 1, TSYNC_DATA_BLOCK_SIZE, inFile);

        // Send upgrade data transaction
        err = TSYNC_US_data(hnd, &data);

        if (err != TSYNC_SUCCESS)
        {
            printf("  Error: %s.\n", tsync_strerror(err));
            fclose(inFile);
            return (6);
        }
    }

    /* Build upgrade end message */
    trl.type = imgId.type;

    // Send upgrade end transaction
    err = TSYNC_US_end(hnd, &trl);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        fclose(inFile);
        return (7);
    }

    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 8;
    }

    fclose(inFile);
    
    return (ret);

} /* End - main() */
