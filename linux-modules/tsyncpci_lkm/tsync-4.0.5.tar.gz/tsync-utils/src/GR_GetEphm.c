#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_example.h"

#include "spec_ktsal_en.h"

int main (int argc, char *argv[])
{
    TSYNC_BoardHandle  hnd;
    int                rc;
    int                ret     = 0;
    int                devIdx;
    char              *devName = DEFAULT_DEV;
    char               fullDevName[32];
    char              *pgmname = argv[0];
    TSYNC_ERROR        err     = TSYNC_SUCCESS;
    unsigned int       index;
    TSYNC_EphmObj      ephm;

    /* If invalid number of arguments... */
    if ( argc != 4 )
    {
        printf(" Usage: GR_GetEphm <device index> <index> <svID>\n");
        return (1);
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        return (1);
    }

    /* Build Get Ephemeris message */
    index = atoi(argv[2]);

    ephm.ephm.prn = atoi(argv[3]);

    // Send Get Ephemeris
    err = TSYNC_GR_getEphm(hnd, index, &ephm);

    if ( err != TSYNC_SUCCESS )
    {
        // Check the error code to determine if the error is due to not having
        // data for the specified SV.
        if ( err == HA_RC_UNKNOWN_ID )
        {
            printf(" Ephemeris data for SV %u has not been read yet.\n", 
                    atoi(argv[3]));
            printf(" Error: %s.\n", tsync_strerror(err));
            return (1);
        }
        else
        {
            printf("  Error: %s.\n", tsync_strerror(err));
            return (1);
        }
    }
    
         /*
      * On definition of the environment variable SPEC_KTSAL_EN
      * to true, print out the information in the format used
      * for the equivalent set's command line.
      */
    if ((getenv(SPEC_KTSAL_EN) != NULL) && 
            *getenv(SPEC_KTSAL_EN) == *ENV_TRUE)
    {
        printf("%u\n", ephm.ephm.prn);
    }
	
    printf("\n  GR (%d) Ephemeris: SV ID: (%u) : \n", (index), (ephm.ephm.prn));
    printf("\tSV Health: %u\n", ephm.ephm.svHealth);
    printf("\ttephem: %f\n", ephm.ephm.tephem);
    printf("\tWeek Num: %u\n", ephm.ephm.weekNumber);	
    printf("\tcodeL2: %u\n", ephm.ephm.codeL2);
    printf("\tL2Pdata: %u\n", ephm.ephm.L2Pdata);
    printf("\turaIdx: %u\n", ephm.ephm.uraIdx);
    printf("\tiodc: %u\n", ephm.ephm.iodc);
    printf("\ttgd: %f\n", ephm.ephm.tgd);
    printf("\ttoc: %f\n", ephm.ephm.toc);
    printf("\taf2: %f\n", ephm.ephm.af2);
    printf("\taf1: %f\n", ephm.ephm.af1);
    printf("\taf0: %f\n", ephm.ephm.af0);
    printf("\tsvAcc: %f\n", ephm.ephm.svAcc);
    printf("\tiode: %u\n", ephm.ephm.iode);
    printf("\tfiFlag: %u\n", ephm.ephm.fit_interval);
    printf("\tcrs: %f\n", ephm.ephm.crs);
    printf("\tdeltaN: %f\n", ephm.ephm.deltaN);
    printf("\tm0: %f\n", ephm.ephm.m0);
    printf("\tcuc: %f\n", ephm.ephm.cuc);
    printf("\te: %f\n", ephm.ephm.e);
    printf("\tcus: %f\n", ephm.ephm.cus);
    printf("\tsqrtA: %f\n", ephm.ephm.sqrtA);
    printf("\ttoe: %f\n", ephm.ephm.toe);
    printf("\tcic: %f\n", ephm.ephm.cic);
    printf("\tomega0: %f\n", ephm.ephm.omega0);
    printf("\tcis: %f\n", ephm.ephm.cis);
    printf("\tio: %f\n", ephm.ephm.io);
    printf("\tcrc: %f\n", ephm.ephm.crc);
    printf("\tomega: %f\n", ephm.ephm.omega);
    printf("\tomegaDot: %f\n", ephm.ephm.omegaDot);
    printf("\tidot: %f\n", ephm.ephm.idot);	
	
    /* Close the TSYNC/TSAT device */
    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }

    return (ret);

} /* End - main() */
