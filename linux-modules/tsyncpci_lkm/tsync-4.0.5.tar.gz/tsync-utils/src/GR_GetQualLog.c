#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_example.h"

#include "spec_ktsal_en.h"

#define DEBUG_QUAL_LOG        (0)


int main (int argc, char *argv[])
{
    TSYNC_BoardHandle  hnd;
    int                rc;
    int                ret     = 0;
    int                devIdx;
    char              *devName = DEFAULT_DEV;
    char               fullDevName[32];
    char              *pgmname = argv[0];
    TSYNC_ERROR        err     = TSYNC_SUCCESS;
    unsigned int       index;
    TSYNC_QualLogObj   ql;
    unsigned int       i;
    unsigned int       qsum = 0;


    /* If invalid number of arguments... */
    if (argc != 3)
    {
        printf(" Usage: GR_GetQualLog <device index> <index>\n");
        return (1);
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        return (1);
    }

    /* Build Get Qualification Log message */
    index = atoi(argv[2]);

    // Send Get Qualification Log transaction
    err = TSYNC_GR_getQualLog(hnd, index, &ql);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        return (1);
    }
    
     /*
      * On definition of the environment variable SPEC_KTSAL_EN
      * to true, print out the information in the format used
      * for the equivalent set's command line.
      */
    if ((getenv(SPEC_KTSAL_EN) != NULL) && 
            *getenv(SPEC_KTSAL_EN) == *ENV_TRUE)
    {
        // Send data array in raw numerical form terminated by a
        // line feed
        for (i = 0; i < TSYNC_QUAL_LOG_NUM; i++)
        {
            printf("%d ", ql.val[i]);
        }

        printf("\n");
    }

    // Display the Qualification log as a line beginning 
    // with GR (#) instance followed by the non-zero 
    // satellite entries #sat = #sec. A Q = # sec ends 
    // the line which is the sum of seconds with a 
    // satellite count > 0. 
    printf("GR (%d): ", index);

#if DEBUG_QUAL_LOG
    printf("0 = %d ", ql.val[0]);
#endif

    // Create the Qualification Log Entry
    for (i = 1; i < TSYNC_QUAL_LOG_NUM; i++)
    {
        if (ql.val[i] != 0)
        {
            printf("%d = %d ", i, ql.val[i]);
            qsum += ql.val[i]; 
        }
    }

    printf("Q = %d\n", qsum);

    /* Close the TSYNC/TSAT device */
    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }

    return (ret);

} /* End - main() */
