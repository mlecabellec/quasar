#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_example.h"

#include "spec_ktsal_en.h"

int main (int argc, char *argv[])
{
    TSYNC_BoardHandle      hnd;
    int                    rc;
    unsigned int           i;
    int                    ret     = 0;
    int                    devIdx;
    char                  *devName = DEFAULT_DEV;
    char                   fullDevName[32];
    char                  *pgmname = argv[0];
    TSYNC_ERROR            err     = TSYNC_SUCCESS;
    unsigned int           index;
    TSYNC_ReceiverInfoObj  ri;


    /* If invalid number of arguments... */
    if ((argc != 3) && (argc != 4))
    {
        printf(" Usage: GR_GetRcvInfo <device index> <index>\n");
        return (1);
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        return (1);
    }

    /* Build Get Rcvr Info message */
    index = atoi(argv[2]);

    memset(&ri, 0, sizeof(TSYNC_ReceiverInfoObj));
    
    // Send Get Rcvr Info transaction
    err = TSYNC_GR_getRcvInfo(hnd, index, &ri);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        return (1);
    }
    
    // Determine if this is a Trimble, or UBLOX
    if (ri.len == sizeof(TL_RCV_INFO))
    {

         /*
          * On definition of the environment variable SPEC_KTSAL_EN
          * to true, print out the information in the format used
          * for the equivalent set's command line.
          */
        TL_RCV_INFO riStruct;
        memcpy(&riStruct, ri.info,
               sizeof(riStruct) < sizeof(ri.info) ? sizeof(riStruct) : sizeof(ri.info));

        if ((getenv(SPEC_KTSAL_EN) != NULL) &&
            *getenv(SPEC_KTSAL_EN) == *ENV_TRUE)
        {
            printf("%s %s %s %s %s %s",
                    riStruct.serNo,
                    riStruct.serNoDate,
                    riStruct.appVer,
                    riStruct.appVerDate,
                    riStruct.coreVer,
                    riStruct.coreVerDate);
         }

        printf("\n");
        printf(" GR (%d) Rcv Info (%u bytes):\n", (index), ri.len);
        printf("  -------------------------------\n");
        printf("  Serial #: %s\n", riStruct.serNo);
        printf("  Date:     %s\n", riStruct.serNoDate);
        printf("  -------------------------------\n");
        printf("  Appl Ver: %s\n", riStruct.appVer);
        printf("  Date:     %s\n", riStruct.appVerDate);
        printf("  -------------------------------\n");
        printf("  Core Ver: %s\n", riStruct.coreVer);
        printf("  Date:     %s\n", riStruct.coreVerDate);
        printf("  -------------------------------\n");
    }
    else if (ri.len == sizeof(UBX_RCV_INFO))
    {
         /*
          * On definition of the environment variable SPEC_KTSAL_EN
          * to true, print out the information in the format used
          * for the equivalent set's command line.
          */
        if ((getenv(SPEC_KTSAL_EN) != NULL) &&
            *getenv(SPEC_KTSAL_EN) == *ENV_TRUE)
        {
            char swVer[UBX_SW_VER_STR_LEN] = "0.0";
            char timVer[UBX_SW_VER_STR_LEN] = "0.0";
            char protocol[UBX_SW_VER_STR_LEN] = "0.0";
            char hwVer[UBX_HW_VER_STR_LEN] = "0";

            TSYNC_GR_getUbxVersion(&ri, swVer, timVer, protocol, hwVer);

            printf("%s %s %s %s", swVer, timVer, protocol, hwVer);
        }

        printf("\n");
        printf(" GR (%d) Rcv Info (%u bytes):\n", (index), ri.len);
        printf("  -------------------------------\n");
        printf("  SW Ver:  %s\n", ((UBX_RCV_INFO*)&(ri.info))->swVer);
        printf("  HW Ver:  %s\n", ((UBX_RCV_INFO*)&(ri.info))->hwVer);
        printf("  -------------------------------\n");
        for (i = 0; i < UBX_HW_VER_STR_NUM; i++)
        {
           printf("  Ext Ver[%d]: %s\n", i, ((UBX_RCV_INFO*)&(ri.info))->exten[i]);
        }
        printf("  -------------------------------\n");
    }

    /* Close the TSYNC/TSAT device */
    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }

    return (ret);

} /* End - main() */
