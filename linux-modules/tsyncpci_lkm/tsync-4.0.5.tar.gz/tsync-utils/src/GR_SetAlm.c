#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_example.h"


int main (int argc, char *argv[])
{
    TSYNC_BoardHandle  hnd;
    int                rc;
    int                ret     = 0;
    int                devIdx;
    char              *devName = DEFAULT_DEV;
    char               fullDevName[32];
    char              *pgmname = argv[0];
    TSYNC_ERROR        err     = TSYNC_SUCCESS;
    unsigned int       index;
    TSYNC_AlmObj       almanac;


    /* If invalid number of arguments... */
    if (argc != 16)
    {
        printf(" Usage: GR_SetAlm <device index> <index> <prn> <svHealth> "
               "<Week> <e> <toa> <io> <omegaDot> <sqrtA> <omega0> <omega> "
               "<m0> <af0> <af1>\n");
        return (1);
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        return (1);
    }

    /* Build Set Almanac message */
    index   = atoi(argv[2]);

    almanac.alm.prn        = atoi(argv[3]);
    almanac.alm.svHealth   = atoi(argv[4]);
    almanac.alm.weekNumber = atoi(argv[5]);
    almanac.alm.e          = atof(argv[6]);
    almanac.alm.toa        = atof(argv[7]);
    almanac.alm.io         = atof(argv[8]);
    almanac.alm.omegaDot   = atof(argv[9]);
    almanac.alm.sqrtA      = atof(argv[10]);
    almanac.alm.omega0     = atof(argv[11]);
    almanac.alm.omega      = atof(argv[12]);
    almanac.alm.m0         = atof(argv[13]);
    almanac.alm.af0        = atof(argv[14]);
    almanac.alm.af1        = atof(argv[15]);

	printf("\n  GR (%d) Almanac: SV ID: (%u) : \n", (index), (almanac.alm.prn));
	printf("\tSV Health: %u\n", almanac.alm.svHealth);
    printf("\tWeek Num: %u\n", almanac.alm.weekNumber);	
    printf("\te: %f\n", almanac.alm.e);
    printf("\ttoa: %u\n", almanac.alm.toa);
    printf("\tio: %f\n", almanac.alm.io);
    printf("\tomegaDot: %f\n", almanac.alm.omegaDot);
    printf("\tsqrtA: %f\n", almanac.alm.sqrtA);
    printf("\tomega0: %f\n", almanac.alm.omega0);
    printf("\tomega: %f\n", almanac.alm.omega);
    printf("\tm0: %f\n", almanac.alm.m0);
    printf("\taf0: %f\n", almanac.alm.af0);
    printf("\taf1: %f\n", almanac.alm.af1);

    // Send Set Almanac transaction
    err = TSYNC_GR_setAlm(hnd, index, &almanac);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        return (1);
    }

    /* Close the TSYNC/TSAT device */
    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }

    return (ret);

} /* End - main() */