#include "spec_ktsal_en.h"
#include "tsync.h"
#include "tsync_example.h"

#include <cstdio>
#include <cstring>
#include <map>
#include <string>
#include <stdexcept>


int main(int argc, char *argv[])
{
    TSYNC_BoardHandle   hnd;
    int                 rc;
    char                fullDevName[32];
    char               *pgmname = argv[0];
    TSYNC_FileOptionObj fileOption;

    if (argc != 2)
    {
        printf(" Usage: DCS_GetOptions <device index>\n");
        return EXIT_FAILURE;
    }

    /* Construct the TSYNC/TSAT device name */
    int devIdx = atoi(argv[1]);
    sprintf(fullDevName, "%s%s%d", DEVICE_ROOT, DEFAULT_DEV, devIdx);

    /* open the device */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        printf("%s: !Could not open <%s> : rc <%d>\n", pgmname, fullDevName, rc);
        return EXIT_FAILURE;
    }

    // Send Get Local transaction
    TSYNC_ERROR err = TSYNC_DCS_getOptions(hnd, &fileOption);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        return EXIT_FAILURE;
    }

    /*
      * On definition of the environment variable SPEC_KTSAL_EN
      * to true, print out the information in the format used
      * for the equivalent set's command line.
      */
    const char* ktsal = getenv(SPEC_KTSAL_EN);
    if (ktsal != NULL && strcmp(ktsal, ENV_TRUE) == 0)
    {
        printf("%hhu ", fileOption.length);
        for (int index = 0; index < fileOption.length; ++index)
            printf("%hhu ", fileOption.type[index]);
        printf("\n");
    }

    std::map<int, std::string> licenses =
    {{DCS_MULTIGNSS, "MULTIGNSS"},
     {DCS_SKYLIGHT, "SKYLIGHT"},
     {DCS_TIMEKEEPER, "TIMEKEEPER"},
     {DCS_PLLLOCK, "PLL LOCK"},
     {DCS_TKPTPV1, "TK PTPv1"},
     {DCS_AGPS, "AGPS Server"},
     {DCS_PLL2, "PLL2 LOCK"},
     {DCS_PD1, "PeerD v1"},
     {DCS_SEM, "SEM"},
     {DCS_ELORAN1, "E-Loran"},
     {DCS_BSH, "BroadShield"},
     {DCS_HQF, "HaveQuick"},
     {DCS_TS1, "GPI Timestamp"},
     {DCS_BSL, "BroadShield Pro"},
     {DCS_BSD, "BroadShield Debug"},
     {DCS_PTP, "Base PTP Unit"},
     {DCS_EVENT_TIME_STAMPER, "Event Time Stamper"}};

    printf("\n  DCS Get Options (%d) available Licenses :\n", fileOption.length);
    for (int index = 0; index < fileOption.length; ++index)
    {
        int licenseType = fileOption.type[index];

        try
        {
            printf("\n    License %d: %s\n", index, licenses.at(licenseType).c_str());
        }
        catch (std::out_of_range &e)
        {
            printf("License Type (%d) unknown\n", licenseType);
        }
    }

    /* Close the TSYNC/TSAT device */
    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        printf("%s: error closing <%s> rc: <%d>\n", pgmname, fullDevName, rc);
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}
