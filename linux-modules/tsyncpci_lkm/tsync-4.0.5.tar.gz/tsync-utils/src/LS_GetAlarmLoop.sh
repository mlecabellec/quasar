#!/bin/sh

if [ -e /usr/bin/CS_GetTime ]; then
    DIR="/usr/bin"
else
    DIR="."
fi

while [ 1 ]
do
 tput clear
 $DIR/LS_GetAlarm $1 0
 $DIR/LS_GetAlarm $1 1
 $DIR/LS_GetAlarm $1 2
 $DIR/LS_GetAlarm $1 3
 $DIR/LS_GetAlarm $1 4
 $DIR/LS_GetAlarm $1 5
 $DIR/LS_GetAlarm $1 6
 $DIR/LS_GetAlarm $1 7
 sleep 1
done
