#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_example.h"


int main (int argc, char *argv[])
{
    TSYNC_BoardHandle  hnd;
    int                rc;
    int                ret     = 0;
    int                devIdx;
    char              *devName = DEFAULT_DEV;
    char               fullDevName[32];
    char              *pgmname = argv[0];
    TSYNC_ERROR        err     = TSYNC_SUCCESS;
    unsigned int       index;
    GL_RESET           reset;
    char               resetStr[20] = {0};


    /* If invalid number of arguments... */
    if (argc != 4)
    {
        printf(" Usage: GR_Reset <device index> <index> <reset>\n");
        return (1);
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        return (1);
    }

    /* Build Set Dynamics message */
    index = atoi(argv[2]);
    reset   = (GL_RESET)atoi(argv[3]);

    // Create reset string
    switch (reset)
    {
        case GL_RESET_COLD:       sprintf(resetStr, "Cold");              break;
        case GL_RESET_WARM:       sprintf(resetStr, "Warm");              break;
        case GL_RESET_HOT:        sprintf(resetStr, "Hot");               break;
        case GL_RESET_POS:        sprintf(resetStr, "Position");          break;
        case GL_RESET_FACT:       sprintf(resetStr, "Factory");           break;
        case GL_RESET_SAVE:       sprintf(resetStr, "Save");              break;
        case GL_RESET_SAASM_ZKEY: sprintf(resetStr, "Zeroize Keys");      break;
        case GL_RESET_SAASM_ZCLR: sprintf(resetStr, "Zeroize Clear");     break;
        case GL_RESET_SAASM_ZEMG: sprintf(resetStr, "Emergency Zeroize"); break;
        case GL_RESET_SAASM_RST:  sprintf(resetStr, "Reset Comm");        break;
        case GL_RESET_SAASM_URST: sprintf(resetStr, "Reset Interfaces");  break;
        default:                  sprintf(resetStr, "UNKNOWN");           break;
    }

    printf("\n  GR (%d) Reset: %s (%d)\n", index, resetStr, reset);

    // Send Reset transaction
    err = TSYNC_GR_reset(hnd, index, reset);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        return (1);
    }

    /* Close the TSYNC/TSAT device */
    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }

    return (ret);

} /* End - main() */
