#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_example.h"

#include "spec_ktsal_en.h"

int main (int argc, char *argv[])
{
    TSYNC_BoardHandle      hnd;
    int                    rc;
    int                    ret     = 0;
    int                    devIdx;
    char                  *devName = DEFAULT_DEV;
    char                   fullDevName[32];
    char                  *pgmname = argv[0];
    TSYNC_ERROR            err     = TSYNC_SUCCESS;
    ML_TIME_TYPE           timeType;
    TSYNC_TimeObj          doyTime;
    TSYNC_TimeBCDObj       bcdTime;
    unsigned int           seconds;
    unsigned int           ns;
    TSYNC_TimeDSTStateObj  ds;

    /* If invalid number of arguments... */
    if (argc != 3)
    {
        printf(" Usage: CS_GetTime <device index> <time type>\n");
        return (1);
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        return (1);
    }

    /* Build Get Time message */
    timeType    = (ML_TIME_TYPE)atoi(argv[2]);

    switch (timeType)
    {
        case ML_TIME_DOYTIME:
            err = TSYNC_CS_getTime(hnd, &doyTime);
            break;

        case ML_TIME_BCDTIME:
            err = TSYNC_CS_getTimeBcd(hnd, &bcdTime);
            break;

        case ML_TIME_SECONDS:
            err = TSYNC_CS_getTimeSec(hnd, &seconds, &ns);
            break;

        default:
            printf("  Error: Bad time type\n");
            return (1);
    }

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        return (1);
    }

    switch (timeType)
    {
        case ML_TIME_DOYTIME:
            /*
             * On definition of the environment variable SPEC_KTSAL_EN
             * to true, print out the information in the format used
             * for the equivalent set's command line.
             */
            if ((getenv(SPEC_KTSAL_EN) != NULL) && 
                *getenv(SPEC_KTSAL_EN) == *ENV_TRUE)
            {
                printf("%d %d %d %d %d", 
                        doyTime.years, doyTime.doy, doyTime.hours,
                        doyTime.minutes, doyTime.seconds);
            }

            printf("\n");
            printf(" DOY Time:\n");
            printf("  Year: %04d\n", doyTime.years);
            printf("  DOY:  %03d\n", doyTime.doy);
            printf("  Hr:   %02d\n", doyTime.hours);
            printf("  Min:  %02d\n", doyTime.minutes);
            printf("  Sec:  %02d\n", doyTime.seconds);
            printf("  Nsec: %09d\n", doyTime.ns);
            break;

        case ML_TIME_BCDTIME:
            //print command line formatted version for setter
            if ((getenv(SPEC_KTSAL_EN) != NULL) && 
                *getenv(SPEC_KTSAL_EN) == *ENV_TRUE)
            {
                printf("%x %x %x %x %x", bcdTime.years,
                        bcdTime.doy, bcdTime.minutes, bcdTime.minutes, 
                        bcdTime.seconds);
            }

            printf("\n");
            printf(" BCD Time:\n");
            printf("  Year: %04X\n", bcdTime.years);
            printf("  DOY:  %03X\n", bcdTime.doy);
            printf("  Hr:   %02X\n", bcdTime.hours);
            printf("  Min:  %02X\n", bcdTime.minutes);
            printf("  Sec:  %02X\n", bcdTime.seconds);
            printf("  Msec: %03X\n", bcdTime.ms);
            printf("  Usec: %03X\n", bcdTime.us);
            break;

        case ML_TIME_SECONDS:
            //print command line formatted version for setter
            if ((getenv(SPEC_KTSAL_EN) != NULL) && 
                *getenv(SPEC_KTSAL_EN) == *ENV_TRUE)
            {
                printf("%d", seconds);
            }
            printf("\n");
            printf(" Sec Time:\n");
            printf("  Sec:  %d\n", seconds);
            printf("  Nsec: %09d\n", ns);
            break;

        default:
            break;
    }

    /* Get DST State */
    err = TSYNC_CS_getDstState(hnd, &ds);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        return (1);
    }

    //print command line formatted version for setter
    if ((getenv(SPEC_KTSAL_EN) != NULL) && 
        *getenv(SPEC_KTSAL_EN) == *ENV_TRUE)
    {
        printf("%d\n", ds.state);
    }

    printf("\n");
    printf(" DST State: %s Time\n", (ds.state == 1) ? "Daylight" : "Standard");

    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }

    return (ret);

} /* End - main() */
