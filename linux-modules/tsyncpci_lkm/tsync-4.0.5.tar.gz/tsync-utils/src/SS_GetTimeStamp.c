#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_example.h"

#include "spec_ktsal_en.h"

int main (int argc, char *argv[])
{
    TSYNC_BoardHandle  hnd;
    int                rc;
    int                ret     = 0;
    int                devIdx;
    char              *devName = DEFAULT_DEV;
    char               fullDevName[32];
    char              *pgmname = argv[0];
    TSYNC_ERROR        err     = TSYNC_SUCCESS;
    SS_TS_SRC          src;
    ML_TIME_TYPE       type;
    TSYNC_TimeObj      doyTime;
    TSYNC_TimeBCDObj   bcdTime;
    unsigned int       seconds;
    unsigned int       ns;


    /* If invalid number of arguments... */
    if (argc != 4)
    {
        printf(" Usage: SS_GetTimeStamp <device index> <src> <time type>\n");
        return (1);
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        return (1);
    }

    /* Build Get Timestamp message */
    src  = (SS_TS_SRC)atoi(argv[2]);
    type = (ML_TIME_TYPE)atoi(argv[3]);

    // Send Get Timestamp transaction
    switch (type)
    {
        case ML_TIME_DOYTIME:
            err = TSYNC_SS_getTimestamp(hnd, src, &doyTime);
            break;

        case ML_TIME_BCDTIME:
            err = TSYNC_SS_getTimestampBcd(hnd, src, &bcdTime);
            break;

        case ML_TIME_SECONDS:
            err = TSYNC_SS_getTimestampSec(hnd, src, &seconds, &ns);
            break;

        default:
            return (1);
            break;
    }

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        return (1);
    }

/*
      * On definition of the environment variable SPEC_KTSAL_EN
      * to true, print out the information in the format used
      * for the equivalent set's command line.
      */
    if ((getenv(SPEC_KTSAL_EN) != NULL) && 
            *getenv(SPEC_KTSAL_EN) == *ENV_TRUE)
    {
        switch(type)
        {
            case ML_TIME_DOYTIME:
                printf("%d %d %d %d %d %d\n", doyTime.years, doyTime.doy,
                        doyTime.hours, doyTime.minutes, doyTime.seconds,
                        doyTime.ns);
                break;
                        
            case ML_TIME_BCDTIME:
                printf("%X %X %X %X %X %X %X\n", bcdTime.years, bcdTime.doy,
                        bcdTime.hours, bcdTime.minutes, bcdTime.seconds,
                        bcdTime.ms, bcdTime.us);
                break;
            
            case ML_TIME_SECONDS:
                printf("%d, %d\n", seconds, ns);
                break;               
            
            default:
                return (1);
                break;
        }  
    }

    printf("\n");
    printf(" TimeStamp of last ");

    switch ((src))
    {
        case SS_TS_TIME_REF: printf("time reference change:\n"); break;
        case SS_TS_1PPS_REF: printf("1PPS reference change:\n"); break;
        case SS_TS_TFOM:     printf("TFOM change:\n");           break;
        case SS_TS_SYNC:     printf("sync state change:\n");     break;
        case SS_TS_HOLDOVER: printf("holdover state change:\n"); break;
        case SS_TS_LOST_REF: printf("entry into holdover:\n");  break;
        default:             printf("unknown event:\n");         break;
    }

    switch ((type))
    {
        case ML_TIME_DOYTIME:
            printf("\n");
            printf(" DOY Time:\n");
            printf("  Year: %04d\n", (doyTime.years));
            printf("  DOY:  %03d\n", (doyTime.doy));
            printf("  Hr:   %02d\n", (doyTime.hours));
            printf("  Min:  %02d\n", (doyTime.minutes));
            printf("  Sec:  %02d\n", (doyTime.seconds));
            printf("  Nsec: %09d\n", (doyTime.ns));
            break;

        case ML_TIME_BCDTIME:
            printf("\n");
            printf(" BCD Time:\n");
            printf("  Year: %04X\n", (bcdTime.years));
            printf("  DOY:  %03X\n", (bcdTime.doy));
            printf("  Hr:   %02X\n", (bcdTime.hours));
            printf("  Min:  %02X\n", (bcdTime.minutes));
            printf("  Sec:  %02X\n", (bcdTime.seconds));
            printf("  Msec: %03X\n", (bcdTime.ms));
            printf("  Usec: %03X\n", (bcdTime.us));
            break;

        case ML_TIME_SECONDS:
            printf("\n");
            printf(" Sec Time:\n");
            printf("  Sec:  %d\n", (seconds));
            printf("  Nsec: %09d\n", (ns));
            break;

        default:
            return (1);
            break;
    }

    /* Close the TSYNC/TSAT device */
    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }

    return (ret);

} /* End - main() */
