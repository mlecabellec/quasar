#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_example.h"


int main (int argc, char *argv[])
{
    TSYNC_BoardHandle   hnd;
    int                 rc;
    int                 ret     = 0;
    int                 devIdx;
    char               *devName = DEFAULT_DEV;
    char                fullDevName[32];
    char               *pgmname = argv[0];
    TSYNC_ERROR         err     = TSYNC_SUCCESS;
    TSYNC_TimeScaleObj  ts;


    /* If invalid number of arguments... */
    if (argc < 3)
    {
        printf(" Usage: CS_SetTimeScale <device index> <time scale>\n");
        return (1);
    }

    ts.scale = (ML_TIME_SCALE)atoi(argv[2]);

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        return (1);
    }

    printf("\n");
    printf(" Time Scale: ");

    switch ((ts.scale))
    {
        case ML_TIME_SCALE_UTC:   printf("UTC\n");     break;
        case ML_TIME_SCALE_TAI:   printf("TAI\n");     break;
        case ML_TIME_SCALE_GPS:   printf("GPS\n");     break;
        case ML_TIME_SCALE_LOCAL: printf("LOCAL\n");   break;
        default:                  printf("Unknown\n"); break;
    }

    /* Set Time scale */
    err = TSYNC_CS_setTimeScale(hnd, &ts);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        ret = (strstr(tsync_strerror(err), "RC_CHG_PENDING") != NULL) ? 2 : 1;
    }

    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }

    return (ret);

} /* End - main() */
