#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <netinet/in.h>

#include "tsync.h"
#include "tsync_example.h"


int main (int argc, char *argv[])
{
    TSYNC_BoardHandle        hnd;
    int                      rc;
    int                      ret     = 0;
    int                      devIdx;
    char                    *devName = DEFAULT_DEV;
    char                     fullDevName[32];
    char                    *pgmname = argv[0];
    TSYNC_ERROR              err     = TSYNC_SUCCESS;
    unsigned int             index;
    TSYNC_ReceiverParmObj    parm;


    /* If invalid number of arguments... */
    if (argc < 5)
    {
        printf(" Usage: GR_SetParm <device index> <index> <parm> <cfg[0]> <cfg[1]> <cfg[2]> <cfg[3]> \n");
        return (1);
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        return (1);
    }

    /* Build Send Receiver Specific Parameter message */
    index       = atoi(argv[2]);
    parm.parm   = atoi(argv[3]); 
    parm.cfg[0] = atoi(argv[4]);
    parm.cfg[1] = atoi(argv[4]);
    parm.cfg[2] = atoi(argv[4]);
    parm.cfg[3] = atoi(argv[4]);
    parm.len   = sizeof(TSYNC_ReceiverParmObj);

    printf("\n");
    printf(" GR (%d) Set Parameter Msg Sent:\n", (index));

    switch (parm.parm)
    {
        case GL_PARM_UBX_GPS_WEEK:
            printf("GPS Week Rollover: %d\n", parm.cfg[0]);
            break;
        case GL_PARM_UBX_SURVEY:
        case GL_PARM_UBX_ACCURACY:
        case GL_PARM_UBX_ALTITUDE:
        case GL_PARM_GSSIP_KEY_STATE:
            {    
                printf("Read-Only Parameter!\n");
            }
            break;
            
        case GL_PARM_GSSIP_COM1_EN:
            {
                printf("Com1 Enable: %s (%d)\n",
                       ((parm.cfg[0]) ? "Enabled" : "Disabled"), 
                       parm.cfg[0]);
            }
            break;
        case GL_PARM_GSSIP_COM1_CFG:
            {
                switch (parm.cfg[0])
                {
                   case GL_GSSIP_COM1_HS_IN:
                       printf("Com1 Use: Idle/HotStart Input (%d)",
                           parm.cfg[0]);
                       break;
                   case GL_GSSIP_COM1_HS_OUT:
                       printf("Com1 Use: Idle/HotStart Output (%d)",
                           parm.cfg[0]);
                       break;
                   case GL_GSSIP_COM1_HVQK:
                       printf("Com1 Use: HaveQuick Output (%d)", parm.cfg[0]);
                       break;
                   case GL_GSSIP_COM1_PPS:
                       printf("Com1 Use: PPS Output (%d)", parm.cfg[0]);
                       break;
                   default:
                        printf("Unrecognized COM1 Config parameter:  (%d)",
                            parm.cfg[0]);
                       break;
                }
            }
            break;
        case GL_PARM_GSSIP_PWR_CTRL:
            {    
                printf("Power Off: %s (%d)\n",
                       ((parm.cfg[0] == GL_GSSIP_PWR_CYCLE) ? "POWER CYCLE" : 
                           ((parm.cfg[0] == GL_GSSIP_PWR_ON) ? "TRUE" : 
                                                               "FALSE")),
                       parm.cfg[0]);
            }
            break;
        default:
            printf("Setting Unrecognized parameter:");
            printf("parm: cfg[0]: %d cfg[0]: %d cfg[1]: %d cfg[2]: %d cfg[3]: %d", 
                parm.parm, parm.cfg[0], parm.cfg[1], parm.cfg[2], parm.cfg[3]);
            break;
    }

    printf("\n");

    // Send Send Custom Message transaction
    err = TSYNC_GR_setParameter(hnd, index, &parm);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        return (1);
    }

    /* Close the TSYNC/TSAT device */
    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }

    return (ret);

} /* End - main() */
