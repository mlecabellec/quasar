#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_example.h"


typedef struct TEST
{
    unsigned int arg1;
    unsigned short arg2[3];
} TEST123;

int main (int argc, char *argv[])
{
    TSYNC_BoardHandle   hnd;
    int                 rc;
    int                 ret     = 0;
    int                 devIdx;
    char               *devName = DEFAULT_DEV;
    char                fullDevName[32];
    char               *pgmname = argv[0];
    TSYNC_ERROR         err     = TSYNC_SUCCESS;
    unsigned int        index;
    TSYNC_IRIGCfDataObj cf;


    /* If invalid number of arguments... */
    if (argc != 6)
    {
        printf(" Usage: IP_SetCfData <device index> <index> <data> <data> "
               "<data>\n");
        return (1);
    }

    /* Construct the TSYNC/TSAT device name */
    devIdx = atoi(argv[1]);
    (void)sprintf( fullDevName, "%s%s%d", DEVICE_ROOT, devName, devIdx );

    /*
     * open the device
     */
    if ( (rc = TSYNC_open(&hnd, fullDevName)) != TSYNC_SUCCESS )
    {
        /*
         * if errors, close it
         */
        printf("%s: !Could not open <%s> : rc <%d>\n",
                        pgmname, fullDevName, rc);
        return (1);
    }

    /* Build Set CfData message */
    index        = atoi(argv[2]);
    cf.cfData[0] = (unsigned short)strtoul(argv[3], NULL, 16);
    cf.cfData[1] = (unsigned short)strtoul(argv[4], NULL, 16);
    cf.cfData[2] = (unsigned short)strtoul(argv[5], NULL, 16);

    // Display the CF Data values
    printf("\n  IP (%d) CFData: %04X %04X %04X\n", (index), (cf.cfData[0]), 
                                                            (cf.cfData[1]),
                                                            (cf.cfData[2]));

    // Send Set CfData transaction
    err = TSYNC_IP_setCfData(hnd, index, &cf);

    if (err != TSYNC_SUCCESS)
    {
        printf("  Error: %s.\n", tsync_strerror(err));
        return (1);
    }

    /* Close the TSYNC/TSAT device */
    if ( (rc = TSYNC_close(hnd)) != TSYNC_SUCCESS )
    {
        (void) printf("%s: error closing <%s> rc: <%d>\n",
                pgmname, fullDevName, rc );
        ret = 1;
    }

    return (ret);

} /* End - main() */
