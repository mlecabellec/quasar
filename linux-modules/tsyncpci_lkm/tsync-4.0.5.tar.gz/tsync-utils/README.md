# Tsync-Utils

Small group of programs to control the Tsync Card.

## Building

    $ cd src/
    $ make
    # make install
