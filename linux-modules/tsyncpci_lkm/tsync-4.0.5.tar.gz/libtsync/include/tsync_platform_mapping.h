#ifndef __TSYNC_PLATFORM_MAPPING_H__
#define __TSYNC_PLATFORM_MAPPING_H__ 1

#include <stdint.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <asm/byteorder.h>

#ifdef __LITTLE_ENDIAN
#define HOST_LITTLE_ENDIAN 1
#else
#define HOST_BIG_ENDIAN 1
#endif

#define TSYNC_BOARD_DESCRIPTOR_T int

#define TSYNC_ALLOCA alloca
#define TSYNC_SLEEP sleep
#define TSYNC_SAFE_SPRINTF(destStr, maxSize, formatStr, formatArgs) snprintf(destStr, maxSize, formatStr, formatArgs);

#endif
