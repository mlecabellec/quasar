
#ifndef _defined_TSYNCTEST_H
#define _defined_TSYNCTEST_H

/***************************************************************************
**  Module:     tsynctest.h
**  Date:       08/08/08
**  Purpose:    This is the header file for the test app.
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************/

#ifdef __cplusplus
extern "C" {
#endif


/*==========================================================================
        SUPPORT CONSTANTS
===========================================================================*/

/******************************************************
**     Define Enumerations
******************************************************/

#define TEST_MAX_EXPRESSION_VALUES 20
#define TEST_INVALID_VALUE_INDEX -1
#define TEST_MAX_EXPRESSION_LENGTH 256

#define VS_GET_BOARD_SET_USER   ( 0 | FA_SET )
#define VS_GET_USER_SET_USER    ( FA_GET | FA_SET )

typedef enum
{
    FA_GET = 0x01,
    FA_SET = 0x02,
} FUNC_ACC;

#define TEST_TimeSeconds_EXP_VALUES(phase, funcAcc)                    \
    TSYNC_X_EXP_VALUE_D_##phase(  unsigned int,   nSeconds,   "%u", \
                                "Seconds", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(  unsigned int,   nNanos,     "%u", \
                                "Nanos", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_Time_EXP_VALUES(phase, funcAcc)                    \
    TSYNC_X_DEFINITION_##phase(  TSYNC_TimeObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.years,   "%u", \
                                "Years", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.doy,   "%u", \
                                "Day of Year", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.hours,   "%u", \
                                "Hours", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.minutes,   "%u", \
                                "Minutes", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.seconds,   "%u", \
                                "Seconds", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.ns,   "%u", \
                                "Nanoseconds", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_HWTimeSeconds_EXP_VALUES(phase, funcAcc)                    \
    TSYNC_X_DEFINITION_##phase(  TSYNC_HWTimeSecondsObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.time.seconds,   "%u", \
                                "Seconds", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.time.ns,   "%u", \
                                "Nanoseconds", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_HWTime_EXP_VALUES(phase, funcAcc)                    \
    TSYNC_X_DEFINITION_##phase(  TSYNC_HWTimeObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.time.years,   "%u", \
                                "Years", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.time.doy,   "%u", \
                                "Day of Year", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.time.hours,   "%u", \
                                "Hours", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.time.minutes,   "%u", \
                                "Minutes", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.time.seconds,   "%u", \
                                "Seconds", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.time.ns,   "%u", \
                                "Nanoseconds", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_TimeBCD_EXP_VALUES(phase, funcAcc)                    \
    TSYNC_X_DEFINITION_##phase(  TSYNC_TimeBCDObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.years,   "%u", \
                                "Years", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.doy,   "%u", \
                                "Day of Year", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.hours,   "%u", \
                                "Hours", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.minutes,   "%u", \
                                "Minutes", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.seconds,   "%u", \
                                "Seconds", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.ms,   "%u", \
                                "Milliseconds", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.us,   "%u", \
                                "Microseconds", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_GPSPosition_EXP_VALUES(phase, funcAcc)                    \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,     "%u", \
                                    "Instance", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_DEFINITION_##phase(  TSYNC_LLAObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.lat,   "%le", \
                                "Latitude", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.lon,   "%le", \
                                "Longitude", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.alt,   "%le", \
                                "Altitude", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_Enable_EXP_VALUES(phase, funcAcc)                    \
    TSYNC_X_EXP_VALUE_D_##phase(    int,   bEnable,     "%u", \
                                    "Enabled", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_HWTimestampCount_EXP_VALUES(phase, funcAcc)                    \
    TSYNC_X_EXP_VALUE_D_##phase(    TMSTMP_SRC,   source,     "%u", \
                                    "TMSTMP_SRC Source", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nCount,     "%u", \
                                    "Timestamp Count", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_HWTimestampClear_EXP_VALUES(phase, funcAcc)                    \
    TSYNC_X_EXP_VALUE_D_##phase(    TMSTMP_SRC,   source,     "%u", \
                                    "TMSTMP_SRC Source", funcAcc, VS_GET_USER_SET_USER)

#define TEST_MatchTime_EXP_VALUES(phase, funcAcc)                    \
    TSYNC_X_EXP_VALUE_D_##phase(    OD_PIN,   index,   "%d", \
                                    "OD_PIN index", funcAcc, VS_GET_USER_SET_USER) \
    TEST_Time_EXP_VALUES(phase, funcAcc)

#define TEST_HWFPGAInfo_EXP_VALUES(phase, funcAcc)                    \
    TSYNC_X_EXP_VALUE_D_##phase(  unsigned short,   id,   "%hd", \
                                "ID", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(  unsigned short,   rev,     "%hd", \
                                "Revision", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_HWInterruptMask_EXP_VALUES(phase, funcAcc)                    \
    TSYNC_X_EXP_VALUE_D_##phase(    INT_TYPE,   intType,   "%u", \
                                    "Interrupt Type", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   index,     "%u", \
                                    "Index", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(    int,   bEnable,     "%d", \
                                    "Enable", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_ReferenceTable_EXP_VALUES(phase, funcAcc)                    \
    TSYNC_X_DEFINITION_##phase(  TSYNC_TableTypeObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(   pObj.type,   "%u", \
                                "RS_TABLE_TYPE", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_DEFINITION_##phase(  TSYNC_ReferenceTableObj,   pObj2)

#define TEST_HWTimestampData_EXP_VALUES(phase, funcAcc)                    \
    TSYNC_X_EXP_VALUE_D_##phase(    TMSTMP_SRC,   source,     "%u", \
                                    "TMSTMP_SRC source", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_HWTimeDataObj,   pObj)

#define TEST_HWTimestamp_EXP_VALUES(phase, funcAcc)                    \
    TSYNC_X_EXP_VALUE_D_##phase(    TMSTMP_SRC,   source,     "%u", \
                                    "TMSTMP_SRC source", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_HWTimeObj,   pObj)

#define TEST_Empty_EXP_VALUES(phase, funcAcc) ;

#define TEST_State_EXP_VALUES(phase, funcAcc)                    \
    TSYNC_X_DEFINITION_##phase(  TSYNC_StateObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(   pObj.image,   "%u", \
                                "UL_IMG Image", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(   pObj.step,   "%u", \
                                "US_PROCESS Step", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(   pObj.complete,   "%u", \
                                "%% Complete", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_TimeScale_EXP_VALUES(phase, funcAcc)                    \
    TSYNC_X_DEFINITION_##phase(  TSYNC_TimeScaleObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(   pObj.scale,   "%u", \
                                "ML_TIME_SCALE scale", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_TimeScaleOffset_EXP_VALUES(phase, funcAcc)                    \
    TSYNC_X_DEFINITION_##phase(  TSYNC_TimeScaleOffsetObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(   pObj.scale,   "%u", \
                                "ML_TIME_SCALE scale", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(   pObj.offset,   "%d", \
                                "offset", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_SubsecondAdjustment_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_DEFINITION_##phase(  TSYNC_TimeSubsecAdjObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(    pObj.adjust,     "%d", \
                                    "adjust", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_waitFor_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    INT_TYPE,   intType,     "%u", \
                                    "Interrupt Type", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(    uint32_t,   index,     "%u", \
                                    "Index", funcAcc, VS_GET_USER_SET_USER)

#define TEST_TimeDiscont_EXP_VALUES(phase, funcAcc)                    \
    TSYNC_X_DEFINITION_##phase(     TSYNC_TimeDiscontObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.newTime.years,   "%u", \
                                    "[New] Years", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.newTime.doy,   "%u", \
                                    "[New] Day of Year", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.newTime.hours,   "%u", \
                                    "[New] Hours", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.newTime.minutes,   "%u", \
                                    "[New] Minutes", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.newTime.seconds,   "%u", \
                                    "[New] Seconds", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.newTime.ns,   "%u", \
                                    "[New] Nanoseconds", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.newTime.years,   "%u", \
                                    "[Effective] Years", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.effectiveTime.doy,   "%u", \
                                    "[Effective] Day of Year", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.effectiveTime.hours,   "%u", \
                                    "[Effective] Hours", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.effectiveTime.minutes,   "%u", \
                                    "[Effective] Minutes", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.effectiveTime.seconds,   "%u", \
                                    "[Effective] Seconds", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.effectiveTime.ns,   "%u", \
                                    "[Effective] Nanoseconds", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.bActive,   "%u", \
                                    "Active", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_TimeLeapSecond_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_DEFINITION_##phase(  TSYNC_TimeLeapSecondObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.offset,   "%d", \
                                "Offset", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.utcDate.years,   "%u", \
                                "Years", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.utcDate.doy,   "%u", \
                                "Day of Year", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.utcDate.hours,   "%u", \
                                "Hours", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.utcDate.minutes,   "%u", \
                                "Minutes", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.utcDate.seconds,   "%u", \
                                "Seconds", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.utcDate.ns,   "%u", \
                                "Nanoseconds", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_TimeZoneOffset_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_DEFINITION_##phase(  TSYNC_TimeZoneOffsetObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(  pObj.tzOffset,   "%u", \
                                "Offset", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_TimeDSTRule_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_TimeDSTRuleObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.ref,   "%u", \
                                    "ML_DST_REF", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.in.month,   "%u", \
                                    "[In] ML_MONTH", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.in.wom,   "%u", \
                                    "[In] ML_WOM", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.in.dow,   "%u", \
                                    "[In] ML_DOW", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.in.hour,   "%u", \
                                    "[In] Hour", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.out.month,   "%u", \
                                    "[Out] ML_MONTH", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.out.wom,   "%u", \
                                    "[Out] ML_WOM", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.out.dow,   "%u", \
                                    "[Out] ML_DOW", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.out.hour,   "%u", \
                                    "[Out] Hour", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.offset,   "%u", \
                                    "Offset", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_Year_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_TimeYearObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.year,   "%u", \
                                    "Year", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_CRC_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_ULImageObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.image,   "%u", \
                                    "UL_IMG", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_FSCRCObj,   pObj2) \
    TSYNC_X_EXP_VALUE_##phase(      pObj2.crc,   "%u", \
                                    "CRC", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_ImageHeader_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_ULImageObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.image,   "%u", \
                                    "UL_IMG", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_ULImageHeaderObj,   pObj2) \
    TSYNC_X_EXP_VALUE_##phase(      pObj2.mark,   "%u", \
                                    "Mark", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj2.type,   "%u", \
                                    "UL_IMG", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj2.len,   "%u", \
                                    "Length", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_ImageVersion_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_ULImageObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.image,   "%u", \
                                    "UL_IMG", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_FSVersionObj,   pObj2) \
    TSYNC_X_EXP_VALUE_S_##phase(      pObj2.version,   "%s", \
                                    "Version", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_ErrorLog_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_ErrorLogObj,   pObj) \
    TSYNC_X_EXP_VALUE_S_##phase(     pObj.message,   "%s", \
                                    "Message", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_Alarm_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_AlarmObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.index,   "%u", \
                                    "LS_ALARM", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_FlagObj,   pObj2) \
    TSYNC_X_EXP_VALUE_##phase(      pObj2.flag,   "%u", \
                                    "Flag", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_FirmwareVersion_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_FirmwareVersionObj,   pObj) \
    TSYNC_X_EXP_VALUE_S_##phase(      pObj.version,   "%s", \
                                    "Version", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_registerMeter_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_MeterHandle,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.hnd,   "%u", \
                                    "TSYNC_METER_HANDLE", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_MeterWindowSize_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_MeterWinSizeObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.hnd,   "%u", \
                                    "TSYNC_METER_HANDLE", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.size,   "%u", \
                                    "Size", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_MeterData_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_MeterDataObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.hnd,   "%u", \
                                    "TSYNC_METER_HANDLE", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.state,   "%u", \
                                    "XS_STATE", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.size,   "%u", \
                                    "Size", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.elapsed,   "%u", \
                                    "Elapsed", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.frAccum,   "%u", \
                                    "frAccum", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.frPrev,   "%u", \
                                    "frPrev", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.phStart,   "%u", \
                                    "phStart", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.phAccum,   "%u", \
                                    "phAccum", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.phPrev,   "%u", \
                                    "phPrev", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_MeterCommand_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_MeterCommandObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.hnd,   "%u", \
                                    "TSYNC_METER_HANDLE", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.command,   "%u", \
                                    "XS_CMD", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_reset_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_ResetObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.type,   "%u", \
                                    "SS_RESET", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_Reference_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_ReferenceObj,   pObj) \
    TSYNC_X_EXP_VALUE_S_##phase(    pObj.time,   "%s", \
                                    "Time", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_S_##phase(    pObj.pps,   "%s", \
                                    "PPS", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_TableEntry_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_TableEntryObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.enab,   "%d", \
                                    "Enabled", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.prio,   "%u", \
                                    "Priority", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_S_##phase(    pObj.time,   "%s", \
                                    "Time", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_S_##phase(    pObj.pps,   "%s", \
                                    "PPS", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_TableEntryIndex_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    int,   index,     "%d", \
                                    "Index", funcAcc, VS_GET_USER_SET_USER) \
    TEST_TableEntry_EXP_VALUES(phase, funcAcc)

#define TEST_ReferenceTableType_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    RS_TABLE_TYPE,   tableType,     "%u", \
                                    "RS_TABLE_TYPE", funcAcc, VS_GET_USER_SET_USER)

#define TEST_uint_index_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   index,     "%u", \
                                    "Index", funcAcc, VS_GET_USER_SET_USER)

#define TEST_TableEntryPriority_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   index,     "%u", \
                                    "Index", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   priority,     "%u", \
                                    "Priority", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_TableEntryEnabled_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   index,     "%u", \
                                    "Index", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   enabled,     "%u", \
                                    "Enabled", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_ReferenceStateTable_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_ReferenceStateTableObj,   pObj) \

#define TEST_TFOM_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    TFOM,   tfom,     "%u", \
                                    "TFOM", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_Sync_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    int,   bSync,     "%u", \
                                    "Sync", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_Holdover_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    int,   bHoldover,     "%u", \
                                    "Holdover", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_HoldoverTimeout_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nHoldoverTimeout,     "%u", \
                                    "Holdover Timeout", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_SupervisorTimestamp_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    SS_TS_SRC,   src,     "%u", \
                                    "SS_TS_SRC", funcAcc, VS_GET_USER_SET_USER) \
    TEST_Time_EXP_VALUES(phase, funcAcc) \

#define TEST_SupervisorTimestampBCD_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    SS_TS_SRC,   src,     "%u", \
                                    "SS_TS_SRC", funcAcc, VS_GET_USER_SET_USER) \
    TEST_TimeBCD_EXP_VALUES(phase, funcAcc) \

#define TEST_SupervisorTimestampSeconds_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    SS_TS_SRC,   src,     "%u", \
                                    "SS_TS_SRC", funcAcc, VS_GET_USER_SET_USER) \
    TEST_TimeSeconds_EXP_VALUES(phase, funcAcc) \

#define TEST_Uptime_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nUptime,     "%u", \
                                    "Uptime", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_Freerun_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    int,   bFreerun,     "%d", \
                                    "Freerun", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_GPIValue_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    ID_PIN,   index,     "%d", \
                                    "ID_PIN", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(    int,   bEnabled,     "%d", \
                                    "Enabled", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_GPIEdge_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    ID_PIN,   index,     "%d", \
                                    "ID_PIN", funcAcc, VS_GET_USER_SET_USER) \
    TEST_Edge_EXP_VALUES(phase, funcAcc) \

#define TEST_GPITimestampEnable_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    ID_PIN,   index,     "%d", \
                                    "ID_PIN", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(    int,   bEnable,     "%d", \
                                    "Enable", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_NumberInstances_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstances,     "%u", \
                                    "Number of Instances", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_Instance_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,      "%u", \
                                    "GR_DEL_POS", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_setHostReferenceValidity_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    int,   bTimeValid,     "%d", \
                                    "Time Valid", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_PPSReferenceOffset_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,     "%u", \
                                    "Instance", funcAcc, VS_GET_USER_SET_USER) \
    TEST_Offset_EXP_VALUES(phase, funcAcc) \

#define TEST_PPSReferenceEdge_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,     "%u", \
                                    "Instance", funcAcc, VS_GET_USER_SET_USER) \
    TEST_Edge_EXP_VALUES(phase, funcAcc) \

#define TEST_PPSReferenceValidity_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,     "%u", \
                                    "Instance", funcAcc, VS_GET_USER_SET_USER) \
    TEST_ReferenceValidity_EXP_VALUES(phase, funcAcc) \

#define TEST_LEDMode_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    LE_INDEX,   index,     "%d", \
                                    "LE_INDEX", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(    EC_MODE,   mode,     "%u", \
                                    "EC_MODE", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_LEDState_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    LE_INDEX,   index,     "%d", \
                                    "LE_INDEX", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(    EC_STATE,   state,     "%u", \
                                    "EC_STATE", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_GPSReferenceOffset_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,     "%u", \
                                    "Instance", funcAcc, VS_GET_USER_SET_USER) \
    TEST_Offset_EXP_VALUES(phase, funcAcc) \

#define TEST_GPSReferenceValidity_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,     "%u", \
                                    "Instance", funcAcc, VS_GET_USER_SET_USER) \
    TEST_ReferenceValidity_EXP_VALUES(phase, funcAcc) \

#define TEST_GPSReceiverMode_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,     "%u", \
                                    "Instance", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(    GL_MODE,   mode,     "%u", \
                                    "GL_MODE", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_GPSDynamicsMode_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,     "%u", \
                                    "Instance", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(    GL_DYN,   mode,     "%u", \
                                    "GL_DYN", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_GPSFixData_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,     "%u", \
                                    "Instance", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_FixDataObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.nSats,     "%u", \
                                    "nSats", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.pdop,     "%f", \
                                    "pdop", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.hdop,     "%f", \
                                    "hdop", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.vdop,     "%f", \
                                    "vdop", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.tdop,     "%f", \
                                    "tdop", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.fom,     "%d", \
                                    "fom", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.tfom,     "%d", \
                                    "tfom", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.herr,     "%d", \
                                    "herr", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.verr,     "%d", \
                                    "verr", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_GPSFixData_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,     "%u", \
                                    "Instance", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_FixDataObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.nSats,     "%u", \
                                    "nSats", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.pdop,     "%f", \
                                    "pdop", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.hdop,     "%f", \
                                    "hdop", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.vdop,     "%f", \
                                    "vdop", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.tdop,     "%f", \
                                    "tdop", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.fom,     "%d", \
                                    "fom", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.tfom,     "%d", \
                                    "tfom", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.herr,     "%d", \
                                    "herr", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.verr,     "%d", \
                                    "verr", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_GPSSatData_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,     "%u", \
                                    "Instance", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_SatDataObj,   pObj) \

#define TEST_GPSSurveyProgress_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,     "%u", \
                                    "Instance", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nProgress,     "%u", \
                                    "Progress", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_ManufacturerModel_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_ManModObj,   pObj) \
    TSYNC_X_EXP_VALUE_S_##phase(    pObj.mfr,   "%s", \
                                    "mfr", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_S_##phase(    pObj.mdl,   "%s", \
                                    "mdl", funcAcc, VS_GET_BOARD_SET_USER)

#define TEST_GPSManufacturerModel_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,     "%u", \
                                    "Instance", funcAcc, VS_GET_USER_SET_USER) \
    TEST_ManufacturerModel_EXP_VALUES(phase, funcAcc)

#define TEST_GPSReceiverInfo_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,     "%u", \
                                    "Instance", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_ReceiverInfoObj,   pObj) \
    TSYNC_X_EXP_VALUE_S_##phase(    pObj.info,   "%s", \
                                    "info", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_CustomMessage_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_CustomMessageObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.len,     "%u", \
                                    "Length", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_S_##phase(    pObj.msg,   "%s", \
                                    "msg", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_GPSCustomMessage_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,     "%u", \
                                    "Instance", funcAcc, VS_GET_USER_SET_USER) \
    TEST_CustomMessage_EXP_VALUES(phase, funcAcc) \

#define TEST_IRIGReferenceOffset_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,     "%u", \
                                    "Instance", funcAcc, VS_GET_USER_SET_USER) \
    TEST_Offset_EXP_VALUES(phase, funcAcc) \

#define TEST_IRIGReferenceValidity_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,     "%u", \
                                    "Instance", funcAcc, VS_GET_USER_SET_USER) \
    TEST_ReferenceValidity_EXP_VALUES(phase, funcAcc) \

#define TEST_IRIGMode_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,     "%u", \
                                    "Instance", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(    IL_MODE,   mode,     "%u", \
                                    "IL_MODE", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_IRIGFormat_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,     "%u", \
                                    "Instance", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(    IL_FMT,   format,     "%u", \
                                    "IL_FMT", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_IRIGModulation_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,     "%u", \
                                    "Instance", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(    IL_MOD,   mod,     "%u", \
                                    "IL_MOD", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_IRIGFrequency_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,     "%u", \
                                    "Instance", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(    IL_FRQ,   freq,     "%u", \
                                    "IL_FRQ", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_IRIGCodedExpression_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,     "%u", \
                                    "Instance", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(    IL_CE,   ce,     "%u", \
                                    "IL_CE", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_IRIGControlField_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,     "%u", \
                                    "Instance", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(    IL_CF,   cf,     "%u", \
                                    "IL_CF", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_IRIGControlField_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,     "%u", \
                                    "Instance", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(    IL_CF,   cf,     "%u", \
                                    "IL_CF", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_IRIGMessage_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   nInstance,     "%u", \
                                    "Instance", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_IRIGMessageObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.subframes[0],     "%hd", \
                                    "Subframe P0", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.subframes[1],     "%hd", \
                                    "Subframe P1", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.subframes[2],     "%hd", \
                                    "Subframe P2", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.subframes[3],     "%hd", \
                                    "Subframe P3", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.subframes[4],     "%hd", \
                                    "Subframe P4", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.subframes[5],     "%hd", \
                                    "Subframe P5", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.subframes[6],     "%hd", \
                                    "Subframe P6", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.subframes[7],     "%hd", \
                                    "Subframe P7", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.subframes[8],     "%hd", \
                                    "Subframe P8", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.subframes[9],     "%hd", \
                                    "Subframe P9", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_PPSReferenceQuality_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_PPSQualityObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.enable,     "%d", \
                                    "Enabled", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.negRail,     "%u", \
                                    "negRail", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.posRail,     "%u", \
                                    "posRail", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.numPPS,     "%u", \
                                    "numPPS", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.interval,     "%u", \
                                    "interval", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_ReferenceValidity_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    int,   bTimeValid,     "%d", \
                                    "Time Valid", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(    int,   bPpsValid,     "%d", \
                                    "PPS Valid", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_Offset_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    int,   nOffset,     "%d", \
                                    "Offset", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_SignatureControl_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    SIG_CTL,   sig,     "%u", \
                                    "SIG_CTL", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_LocalClock_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_LocalClockObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.rule.ref,   "%u", \
                                    "ML_DST_REF", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.rule.in.month,   "%u", \
                                    "[In] ML_MONTH", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.rule.in.wom,   "%u", \
                                    "[In] ML_WOM", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.rule.in.dow,   "%u", \
                                    "[In] ML_DOW", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.rule.in.hour,   "%u", \
                                    "[In] Hour", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.rule.out.month,   "%u", \
                                    "[Out] ML_MONTH", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.rule.out.wom,   "%u", \
                                    "[Out] ML_WOM", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.rule.out.dow,   "%u", \
                                    "[Out] ML_DOW", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.rule.out.hour,   "%u", \
                                    "[Out] Hour", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.rule.offset,   "%u", \
                                    "Offset", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(      pObj.tz,     "%d", \
                                    "Time Zone", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_IRIGOAmplitude_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   mod,     "%u", \
                                    "Amplitude", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_IRIGOFormat_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    IL_FMT,   format,     "%u", \
                                    "IL_FMT", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_IRIGOModulation_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    IL_MOD,   mod,     "%u", \
                                    "IL_MOD", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_IRIGOFrequency_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    IL_FRQ,   freq,     "%u", \
                                    "IL_FRQ", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_IRIGOCodedExpression_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    IL_CE,   ce,     "%u", \
                                    "IL_CE", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_IRIGOControlField_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    IL_CF,   cf,     "%u", \
                                    "IL_CF", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_IRIGOControlField_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    IL_CF,   cf,     "%u", \
                                    "IL_CF", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_Frequency_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   freq,     "%u", \
                                    "Frequency", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_Edge_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    EDGE,   edge,     "%u", \
                                    "EDGE", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_PulseWidth_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   pw,     "%u", \
                                    "Pulse Width", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_DiscState_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    int,   disc,     "%d", \
                                    "Disc State", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_OscillatorMode_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    XO_MODE,   mode,     "%u", \
                                    "XO_MODE", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_OscillatorDAC_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned short,   dac,     "%hu", \
                                    "DAC", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_OscillatorAlarm_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   alarm,     "%u", \
                                    "Alarm", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_OscillatorSerialNumber_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    unsigned int,   sernum,     "%u", \
                                    "Serial Number", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_OscillatorDiscCommand_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_OscDiscObj,   pObj) \
    TSYNC_X_EXP_VALUE_S_##phase(     pObj.cmd,     "%s", \
                                    "cmd", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_S_##phase(     pObj.data,     "%s", \
                                    "data", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_MS_DI_INDEX_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(    MS_DI_INDEX,   index,     "%d", \
                                    "MS_DI_INDEX", funcAcc, VS_GET_USER_SET_USER) \

#define TEST_GPOSignatureControl_EXP_VALUES(phase, funcAcc)                    \
    TSYNC_X_EXP_VALUE_D_##phase(  OD_PIN,   gpo,   "%d", \
                                "OD_PIN index", funcAcc, VS_GET_USER_SET_USER) \
    TEST_SignatureControl_EXP_VALUES(phase, funcAcc)

#define TEST_GPOOutputEnable_EXP_VALUES(phase, funcAcc)                    \
    TSYNC_X_EXP_VALUE_D_##phase(  OD_PIN,   gpo,   "%d", \
                                "OD_PIN index", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(  int,   bEnable,   "%d", \
                                "Enable", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_GPOValue_EXP_VALUES(phase, funcAcc)                    \
    TSYNC_X_EXP_VALUE_D_##phase(  OD_PIN,   gpo,   "%d", \
                                "OD_PIN index", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(  int,   bValue,   "%d", \
                                "Value", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_GPOMode_EXP_VALUES(phase, funcAcc)                    \
    TSYNC_X_EXP_VALUE_D_##phase(  OD_PIN,   gpo,   "%d", \
                                "OD_PIN index", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(  OD_MODE,   mode,   "%u", \
                                "OD_MODE", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_GPOMatchEnable_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(  OD_PIN,   gpo,   "%d", \
                                "OD_PIN index", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(  LEVEL,   level,   "%d", \
                                "LEVEL level", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_EXP_VALUE_D_##phase(  int,   bValue,   "%d", \
                                "Value", funcAcc, VS_GET_BOARD_SET_USER) \

#define TEST_GPOSquareWave_EXP_VALUES(phase, funcAcc) \
    TSYNC_X_EXP_VALUE_D_##phase(  OD_PIN,   gpo,   "%d", \
                                "OD_PIN index", funcAcc, VS_GET_USER_SET_USER) \
    TSYNC_X_DEFINITION_##phase(     TSYNC_GPOSquareObj,   pObj) \
    TSYNC_X_EXP_VALUE_##phase(       pObj.off,     "%d", \
                                    "off", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(       pObj.per,     "%u", \
                                    "per", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(       pObj.pw,     "%u", \
                                    "dc", funcAcc, VS_GET_BOARD_SET_USER) \
    TSYNC_X_EXP_VALUE_##phase(       pObj.ae,     "%u", \
                                    "EDGE ae", funcAcc, VS_GET_BOARD_SET_USER) \


#define TEST_FUNCTION_FIELDS \
    TSYNC_X_FUNC(   CS_setTimeSec, TimeSeconds, ;, \
                    FA_SET, "Set Time Seconds", nSeconds, nNanos) \
                    \
    TSYNC_X_FUNC(   CS_getTimeSec, TimeSeconds, ;, \
                    FA_GET, "Get Time Seconds", &nSeconds, &nNanos) \
                    \
    TSYNC_X_FUNC(   CS_setTime, Time, ;, \
                    FA_SET, "Set Time", &pObj) \
                    \
    TSYNC_X_FUNC(   CS_getTime, Time, ;, \
                    FA_GET, "Get Time", &pObj) \
                    \
    TSYNC_X_FUNC(   CS_setTimeBcd, TimeBCD, ;, \
                    FA_SET, "Set Time BCD", &pObj) \
                    \
    TSYNC_X_FUNC(   CS_getTimeBcd, TimeBCD, ;, \
                    FA_GET, "Get Time BCD", &pObj) \
                    \
    TSYNC_X_FUNC(   GO_setSigCtrl, GPOSignatureControl, ;, \
                    FA_SET, "Set GPO Signature Control", gpo, sig) \
                    \
    TSYNC_X_FUNC(   GO_getSigCtrl, GPOSignatureControl, ;, \
                    FA_GET, "Get GPO Signature Control", gpo, &sig) \
                    \
    TSYNC_X_FUNC(   GR_setPosition, GPSPosition, ;, \
                    FA_SET, "Set GPS Position", nInstance, &pObj) \
                    \
    TSYNC_X_FUNC(   GR_getPosition, GPSPosition, ;, \
                    FA_GET, "Get GPS Position", nInstance, &pObj) \
                    \
    TSYNC_X_FUNC(   HW_getTime, HWTime, ;, \
                    FA_GET, "Get HW System Time", &pObj) \
                    \
    TSYNC_X_FUNC(   HW_getTimeSec, HWTimeSeconds, ;, \
                    FA_GET, "Get HW Seconds Time", &pObj) \
                    \
    TSYNC_X_FUNC(   HW_getTsEnable, Enable, ;, \
                    FA_GET, "Get HW Timestamp Enable", &bEnable) \
                    \
    TSYNC_X_FUNC(   HW_setTsEnable, Enable, ;, \
                    FA_SET, "Set HW Timestamp Enable", bEnable) \
                    \
    TSYNC_X_FUNC2(  HW_setTsReq, Empty, ;, \
                    FA_SET, "Set HW Timestamp Request") \
                    \
    TSYNC_X_FUNC(   HW_setTsClear, HWTimestampClear, ;, \
                    FA_SET, "HW Timestamp Clear", source) \
                    \
    TSYNC_X_FUNC(   HW_getTsCount, HWTimestampCount, ;, \
                    FA_GET, "Get HW Timestamp Count", source, &nCount) \
                    \
    TSYNC_X_FUNC(   HW_getTsData, HWTimestampData, HW_getTsDataOutput, \
                    FA_GET, "Get HW TimestampData", source, &pObj) \
                    \
    TSYNC_X_FUNC(   HW_getMatchTimeHi, MatchTime, ;, \
                    FA_GET, "Get HW GPO Match Time High", index, &pObj) \
                    \
    TSYNC_X_FUNC(   HW_setMatchTimeHi, MatchTime, ;, \
                    FA_SET, "Set HW GPO Match Time High", index, &pObj) \
                    \
    TSYNC_X_FUNC(   HW_getMatchTimeLo, MatchTime, ;, \
                    FA_GET, "Get HW GPO Match Time Low", index, &pObj) \
                    \
    TSYNC_X_FUNC(   HW_setMatchTimeLo, MatchTime, ;, \
                    FA_SET, "Set HW GPO Match Time Low", index, &pObj) \
                    \
    TSYNC_X_FUNC(   HW_getFpgaInfo, HWFPGAInfo, ;, \
                    FA_GET, "Get HW FPGA Info", &id, &rev) \
                    \
    TSYNC_X_FUNC(   HW_getIntMask, HWInterruptMask, ;, \
                    FA_GET, "Get HW Interrupt Mask", intType, index, &bEnable) \
                    \
    TSYNC_X_FUNC(   HW_setIntMask, HWInterruptMask, ;, \
                    FA_SET, "Set HW Interrupt Mask", intType, index, bEnable) \
                    \
    TSYNC_X_FUNC(   HW_getTsSingle, HWTimestamp, ;, \
                    FA_GET, "Get HW Timestamp", source, &pObj) \
                    \
    TSYNC_X_FUNC(   RS_getTable, ReferenceTable, getReferenceTableOutput, \
                    FA_GET, "Get Reference Table", &pObj, &pObj2) \
                    \
    TSYNC_X_FUNC(   US_getState, State, ;, \
                    FA_GET, "Get Update State", &pObj) \
                    \
    TSYNC_X_UNSP(   US_start ) \
                    \
    TSYNC_X_UNSP(   US_data ) \
                    \
    TSYNC_X_UNSP(   US_end ) \
                    \
    TSYNC_X_UNSP(   US_cancel ) \
                    \
    TSYNC_X_UNSP(   HA_getCaps ) \
                    \
    TSYNC_X_FUNC(   CS_getTimeScale, TimeScale, ;, \
                    FA_GET, "Get Time Scale", &pObj) \
                    \
    TSYNC_X_FUNC(   CS_setTimeScale, TimeScale, ;, \
                    FA_SET, "Set Time Scale", &pObj) \
                    \
    TSYNC_X_FUNC(   CS_getTimeScaleOff, TimeScaleOffset, ;, \
                    FA_GET, "Get Time Scale Offset", &pObj) \
                    \
    TSYNC_X_FUNC(   CS_setTimeScaleOff, TimeScaleOffset, ;, \
                    FA_SET, "Set Time Scale Offset", &pObj) \
                    \
    TSYNC_X_FUNC(   CS_subsecAdj, SubsecondAdjustment, ;, \
                    FA_SET, "Set Subsecond Adjustment", &pObj) \
                    \
    TSYNC_X_FUNC(   waitFor, waitFor, ;, \
                    FA_SET, "Wait For", intType, index) \
                    \
    TSYNC_X_FUNC(   CS_getTimeDiscont, TimeDiscont, ;, \
                    FA_GET, "Get Time Discontinuity", &pObj) \
                    \
    TSYNC_X_FUNC(   CS_setTimeDiscont, TimeDiscont, ;, \
                    FA_SET, "Set Time Discontinuity", &pObj) \
                    \
    TSYNC_X_FUNC(   CS_getLeapSec, TimeLeapSecond, ;, \
                    FA_GET, "Get Time Leap Second", &pObj) \
                    \
    TSYNC_X_FUNC(   CS_setLeapSec, TimeLeapSecond, ;, \
                    FA_SET, "Set Time Leap Second", &pObj) \
                    \
    TSYNC_X_FUNC(   CS_getTimeZoneOff, TimeZoneOffset, ;, \
                    FA_GET, "Get Time Zone Offset", &pObj) \
                    \
    TSYNC_X_FUNC(   CS_setTimeZoneOff, TimeZoneOffset, ;, \
                    FA_SET, "Set Time Zone Offset", &pObj) \
                    \
    TSYNC_X_FUNC(   CS_getDstRule, TimeDSTRule, ;, \
                    FA_GET, "Get Time DST Rule", &pObj) \
                    \
    TSYNC_X_FUNC(   CS_setDstRule, TimeDSTRule, ;, \
                    FA_SET, "Set Time DST Rule", &pObj) \
                    \
    TSYNC_X_UNSP(   CS_getDstState ) \
                    \
    TSYNC_X_UNSP(   CS_setDstState ) \
                    \
    TSYNC_X_FUNC(   CS_getYear, Year, ;, \
                    FA_GET, "Get Year", &pObj) \
                    \
    TSYNC_X_FUNC(   CS_setYear, Year, ;, \
                    FA_SET, "Set Year", &pObj) \
                    \
    TSYNC_X_FUNC(   FS_getCrc, CRC, ;, \
                    FA_GET, "Get CRC", &pObj, &pObj2) \
                    \
    TSYNC_X_FUNC(   FS_calcCrc, CRC, ;, \
                    FA_GET, "Calc CRC", &pObj, &pObj2) \
                    \
    TSYNC_X_FUNC(   FS_getHeader, ImageHeader, ;, \
                    FA_GET, "Get Image Header", &pObj, &pObj2) \
                    \
    TSYNC_X_FUNC(   FS_getVersion, ImageVersion, ;, \
                    FA_GET, "Get Image Version", &pObj, &pObj2) \
                    \
    TSYNC_X_FUNC(   LS_getErrorLog, ErrorLog, ;, \
                    FA_GET, "Get Error Log", &pObj) \
                    \
    TSYNC_X_FUNC(   LS_getAlarm, Alarm, ;, \
                    FA_GET, "Get Alarm", &pObj, &pObj2) \
                    \
    TSYNC_X_FUNC(   LS_setAlarm, Alarm, ;, \
                    FA_SET, "Set Alarm", &pObj, &pObj2) \
                    \
    TSYNC_X_FUNC(   LS_getVersion, FirmwareVersion, ;, \
                    FA_GET, "Get Firmware Version", &pObj) \
                    \
    TSYNC_X_FUNC(   XS_register, registerMeter, ;, \
                    FA_GET, "Register Meter", &pObj) \
                    \
    TSYNC_X_FUNC(   XS_unregister, registerMeter, ;, \
                    FA_SET, "Unregister Meter", &pObj) \
                    \
    TSYNC_X_FUNC(   XS_getWindowSize, MeterWindowSize, ;, \
                    FA_GET, "Get Meter Window Size", &pObj) \
                    \
    TSYNC_X_FUNC(   XS_setWindowSize, MeterWindowSize, ;, \
                    FA_SET, "Set Meter Window Size", &pObj) \
                    \
    TSYNC_X_FUNC(   XS_getMeterData, MeterData, ;, \
                    FA_GET, "Get Meter Data", &pObj) \
                    \
    TSYNC_X_FUNC(   XS_meterCmd, MeterCommand, ;, \
                    FA_SET, "Send Meter Command", &pObj) \
                    \
    TSYNC_X_FUNC(   SS_reset, reset, ;, \
                    FA_SET, "Reset Device", &pObj) \
                    \
    TSYNC_X_FUNC(   SS_getRef, Reference, ;, \
                    FA_GET, "Get Reference", &pObj) \
                    \
    TSYNC_X_FUNC(   RS_getBestRef, TableEntry, ;, \
                    FA_GET, "Get Best Reference", &pObj) \
                    \
    TSYNC_X_FUNC(   RS_getEntry, TableEntryIndex, ;, \
                    FA_GET, "Get Table Entry Reference", index, &pObj) \
                    \
    TSYNC_X_FUNC(   RS_addEntry, TableEntry, ;, \
                    FA_SET, "Add Table Entry Reference", &pObj) \
                    \
    TSYNC_X_FUNC2(  RS_setFactDef, Empty, ;, \
                    FA_SET, "Reset Reference Table To Factory Default") \
                    \
    TSYNC_X_FUNC2(  RS_setUserDef, Empty, ;, \
                    FA_SET, "Reset Reference Table To User Default") \
                    \
    TSYNC_X_FUNC2(  RS_saveUserDef, Empty, ;, \
                    FA_SET, "Save User Reference Table") \
                    \
    TSYNC_X_FUNC(   RS_deleteEntry, uint_index, ;, \
                    FA_SET, "Delete Reference Table Entry", index) \
                    \
    TSYNC_X_FUNC(   RS_getPriority, TableEntryPriority, ;, \
                    FA_GET, "Get Table Entry Priority", index, &priority) \
                    \
    TSYNC_X_FUNC(   RS_setPriority, TableEntryPriority, ;, \
                    FA_SET, "Set Table Entry Priority", index, priority) \
                    \
    TSYNC_X_FUNC(   RS_getEnable, TableEntryEnabled, ;, \
                    FA_GET, "Get Table Entry Enabled", index, &enabled) \
                    \
    TSYNC_X_FUNC(   RS_setEnable, TableEntryEnabled, ;, \
                    FA_SET, "Set Table Entry Enabled", index, enabled) \
                    \
    TSYNC_X_FUNC(   RS_getStateTable, ReferenceStateTable, getReferenceStateTableOutput, \
                    FA_GET, "Get Reference State Table", &pObj) \
                    \
    TSYNC_X_UNSP(   getInitStatus ) \
                    \
    TSYNC_X_FUNC(   SS_getMaxTfom, TFOM, ;, \
                    FA_GET, "Get Max TFOM", &tfom) \
                    \
    TSYNC_X_FUNC(   SS_setMaxTfom, TFOM, ;, \
                    FA_SET, "Set Max TFOM", tfom) \
                    \
    TSYNC_X_FUNC(   SS_getTfom, TFOM, ;, \
                    FA_GET, "Get TFOM", &tfom) \
                    \
    TSYNC_X_FUNC(   SS_getSync, Sync, ;, \
                    FA_GET, "Get Sync", &bSync) \
                    \
    TSYNC_X_FUNC(   SS_getHoldover, Holdover, ;, \
                    FA_GET, "Get Holdover", &bHoldover) \
                    \
    TSYNC_X_FUNC(   SS_getHoldoverTO, HoldoverTimeout, ;, \
                    FA_GET, "Get Holdover Timeout", &nHoldoverTimeout) \
                    \
    TSYNC_X_FUNC(   SS_setHoldoverTO, HoldoverTimeout, ;, \
                    FA_SET, "Set Holdover Timeout", nHoldoverTimeout) \
                    \
    TSYNC_X_FUNC(   SS_getTimestamp, SupervisorTimestamp, ;, \
                    FA_GET, "Get Supervisor Timestamp", src, &pObj) \
                    \
    TSYNC_X_FUNC(   SS_getTimestampBcd, SupervisorTimestampBCD, ;, \
                    FA_GET, "Get Supervisor Timestamp BCD", src, &pObj) \
                    \
    TSYNC_X_FUNC(   SS_getTimestampSec, SupervisorTimestampSeconds, ;, \
                    FA_GET, "Get Supervisor Timestamp Seconds", src, &nSeconds, &nNanos) \
                    \
    TSYNC_X_FUNC(   SS_getUptime, Uptime, ;, \
                    FA_GET, "Get Uptime", &nUptime) \
                    \
    TSYNC_X_FUNC(   SS_getFreeRun, Freerun, ;, \
                    FA_GET, "Get Freerun", &bFreerun) \
                    \
    TSYNC_X_FUNC(   GI_getValue, GPIValue, ;, \
                    FA_GET, "Get GPI Value", index, &bEnabled) \
                    \
    TSYNC_X_FUNC(   GI_getEdge, GPIEdge, ;, \
                    FA_GET, "Get GPI Edge", index, &edge) \
                    \
    TSYNC_X_FUNC(   GI_setEdge, GPIEdge, ;, \
                    FA_SET, "Set GPI Edge", index, edge) \
                    \
    TSYNC_X_FUNC(   GI_getTsEnable, GPITimestampEnable, ;, \
                    FA_GET, "Get GPI Timestamp Enable", index, &bEnable) \
                    \
    TSYNC_X_FUNC(   GI_setTsEnable, GPITimestampEnable, ;, \
                    FA_SET, "Set GPI Timestamp Enable", index, bEnable) \
                    \
    TSYNC_X_FUNC(   GI_getNumInst, NumberInstances, ;, \
                    FA_GET, "Get GPI Number Instances", &nInstances) \
                    \
    TSYNC_X_FUNC(   HR_getValidity, ReferenceValidity, ;, \
                    FA_GET, "Get Host Reference Validity", &bTimeValid, &bPpsValid) \
                    \
    TSYNC_X_FUNC(   HR_setValidity, ReferenceValidity, ;, \
                    FA_SET, "Set Host Reference Validity", bTimeValid) \
                    \
    TSYNC_X_FUNC(   PR_getOffset, PPSReferenceOffset, ;, \
                    FA_GET, "Get PPS Reference Offset", nInstance, &nOffset) \
                    \
    TSYNC_X_FUNC(   PR_setOffset, PPSReferenceOffset, ;, \
                    FA_SET, "Set PPS Reference Offset", nInstance, nOffset) \
                    \
    TSYNC_X_FUNC(   PR_getEdge, PPSReferenceEdge, ;, \
                    FA_GET, "Get PPS Reference Edge", nInstance, &edge) \
                    \
    TSYNC_X_FUNC(   PR_setEdge, PPSReferenceEdge, ;, \
                    FA_SET, "Set PPS Reference Edge", nInstance, edge) \
                    \
    TSYNC_X_FUNC(   PR_getValidity, PPSReferenceValidity, ;, \
                    FA_GET, "Get PPS Reference Validity", nInstance, &bTimeValid, &bPpsValid) \
                    \
    TSYNC_X_FUNC(   PR_getNumInst, NumberInstances, ;, \
                    FA_GET, "Get PPS Number Instances", &nInstances) \
                    \
    TSYNC_X_FUNC(   EC_getMode, LEDMode, ;, \
                    FA_GET, "Get LED Mode", index, &mode) \
                    \
    TSYNC_X_FUNC(   EC_setMode, LEDMode, ;, \
                    FA_SET, "Set LED Mode", index, mode) \
                    \
    TSYNC_X_FUNC(   EC_getState, LEDState, ;, \
                    FA_GET, "Get LED State", index, &state) \
                    \
    TSYNC_X_FUNC(   EC_setState, LEDState, ;, \
                    FA_SET, "Set LED State", index, state) \
                    \
    TSYNC_X_FUNC(   GR_getOffset, GPSReferenceOffset, ;, \
                    FA_GET, "Get GPS Reference Offset", nInstance, &nOffset) \
                    \
    TSYNC_X_FUNC(   GR_setOffset, GPSReferenceOffset, ;, \
                    FA_SET, "Set GPS Reference Offset", nInstance, nOffset) \
                    \
    TSYNC_X_FUNC(   GR_getValidity, GPSReferenceValidity, ;, \
                    FA_GET, "Get GPS Reference Validity", nInstance, &bTimeValid, &bPpsValid) \
                    \
    TSYNC_X_FUNC(   GR_setValidity, GPSReferenceValidity, ;, \
                    FA_SET, "Set GPS Reference Validity", nInstance, bTimeValid) \
                    \
    TSYNC_X_FUNC(   GR_getMode, GPSReceiverMode, ;, \
                    FA_GET, "Get GPS Reference Receiver Mode", nInstance, &mode) \
                    \
    TSYNC_X_FUNC(   GR_setMode, GPSReceiverMode, ;, \
                    FA_SET, "Set GPS Reference Receiver Mode", nInstance, mode) \
                    \
    TSYNC_X_FUNC(   GR_getDynamics, GPSDynamicsMode, ;, \
                    FA_GET, "Get GPS Reference Dynamics Mode", nInstance, &mode) \
                    \
    TSYNC_X_FUNC(   GR_setDynamics, GPSDynamicsMode, ;, \
                    FA_SET, "Set GPS Reference Dynamics Mode", nInstance, mode) \
                    \
    TSYNC_X_FUNC(   GR_getFixData, GPSFixData, ;, \
                    FA_GET, "Get GPS Fix Data", nInstance, &pObj) \
                    \
    TSYNC_X_FUNC(   GR_getSatData, GPSSatData, getGPSSatDataOutput, \
                    FA_GET, "Get GPS Satellite Data", nInstance, &pObj) \
                    \
    TSYNC_X_FUNC(   GR_getSurveyProg, GPSSurveyProgress, ;, \
                    FA_GET, "Get GPS Survey Progress", nInstance, &nProgress) \
                    \
    TSYNC_X_FUNC(   GR_getMfrMdl, GPSManufacturerModel, ;, \
                    FA_GET, "Get GPS Manufacturer Model", nInstance, &pObj) \
                    \
    TSYNC_X_FUNC(   TSYNC_GR_getUbxVersion, GPSUBXVersion, ;, \
                    FA_GET, "Get UBX Version", &pObj, &swVer, &timVer, &protocol, &hwVer) \
                    \
    TSYNC_X_FUNC(   GR_getRcvInfo, GPSReceiverInfo, ;, \
                    FA_GET, "Get GPS Receiver Info", nInstance, &pObj) \
                    \
    TSYNC_X_FUNC(   GR_getCustom, GPSCustomMessage, ;, \
                    FA_GET, "Get GPS Custom Message", nInstance, &pObj) \
                    \
    TSYNC_X_FUNC(   GR_setCustom, GPSCustomMessage, ;, \
                    FA_SET, "Set GPS Custom Message", nInstance, &pObj) \
                    \
    TSYNC_X_FUNC(   GR_getNumInst, NumberInstances, ;, \
                    FA_GET, "Get GPS Number Instances", &nInstances) \
                    \
    TSYNC_X_FUNC(   GR_delPos, Instance, ;, \
                    FA_SET, "Delete Stored Position", nInstance) \
                    \
    TSYNC_X_FUNC(   IR_getOffset, IRIGReferenceOffset, ;, \
                    FA_GET, "Get IRIG Reference Offset", nInstance, &nOffset) \
                    \
    TSYNC_X_FUNC(   IR_setOffset, IRIGReferenceOffset, ;, \
                    FA_SET, "Set IRIG Reference Offset", nInstance, nOffset) \
                    \
    TSYNC_X_FUNC(   IR_getValidity, IRIGReferenceValidity, ;, \
                    FA_GET, "Get IRIG Reference Validity", nInstance, &bTimeValid, &bPpsValid) \
                    \
    TSYNC_X_FUNC(   IR_getMode, IRIGMode, ;, \
                    FA_GET, "Get IRIG Mode", nInstance, &mode) \
                    \
    TSYNC_X_FUNC(   IR_setMode, IRIGMode, ;, \
                    FA_SET, "Set IRIG Mode", nInstance, mode) \
                    \
    TSYNC_X_FUNC(   IR_getFormat, IRIGFormat, ;, \
                    FA_GET, "Get IRIG Format", nInstance, &format) \
                    \
    TSYNC_X_FUNC(   IR_setFormat, IRIGFormat, ;, \
                    FA_SET, "Set IRIG Format", nInstance, format) \
                    \
    TSYNC_X_FUNC(   IR_getMod, IRIGModulation, ;, \
                    FA_GET, "Get IRIG Modulation", nInstance, &mod) \
                    \
    TSYNC_X_FUNC(   IR_getFreq, IRIGFrequency, ;, \
                    FA_GET, "Get IRIG Frequency", nInstance, &freq) \
                    \
    TSYNC_X_FUNC(   IR_setFreq, IRIGFrequency, ;, \
                    FA_SET, "Set IRIG Frequency", nInstance, freq) \
                    \
    TSYNC_X_FUNC(   IR_getCodedExpr, IRIGCodedExpression, ;, \
                    FA_GET, "Get IRIG CodedExpression", nInstance, &ce) \
                    \
    TSYNC_X_FUNC(   IR_setCodedExpr, IRIGCodedExpression, ;, \
                    FA_SET, "Set IRIG CodedExpression", nInstance, ce) \
                    \
    TSYNC_X_FUNC(   IR_getCtrlField, IRIGControlField, ;, \
                    FA_GET, "Get IRIG ControlField", nInstance, &cf) \
                    \
    TSYNC_X_FUNC(   IR_setCtrlField, IRIGControlField, ;, \
                    FA_SET, "Set IRIG ControlField", nInstance, cf) \
                    \
    TSYNC_X_FUNC(   IR_getMessage, IRIGMessage, ;, \
                    FA_GET, "Get IRIG Message", nInstance, &pObj) \
                    \
    TSYNC_X_FUNC(   IR_setMessage, IRIGMessage, ;, \
                    FA_SET, "Set IRIG Message", nInstance, &pObj) \
                    \
    TSYNC_X_FUNC(   IR_getNumInst, NumberInstances, ;, \
                    FA_GET, "Get IRIG Number Instances", &nInstances) \
                    \
    TSYNC_X_UNSP(   IP_getSigCtrl ) \
                    \
    TSYNC_X_UNSP(   IP_setSigCtrl ) \
                    \
    TSYNC_X_UNSP(   IP_getOffset ) \
                    \
    TSYNC_X_UNSP(   IP_setOffset ) \
                    \
    TSYNC_X_UNSP(   IP_getLocal ) \
                    \
    TSYNC_X_UNSP(   IP_setLocal ) \
                    \
    TSYNC_X_UNSP(   IP_getFormat ) \
                    \
    TSYNC_X_UNSP(   IP_setFormat ) \
                    \
    TSYNC_X_UNSP(   IP_getAmplitude ) \
                    \
    TSYNC_X_UNSP(   IP_setAmplitude ) \
                    \
    TSYNC_X_UNSP(   IP_getMod ) \
                    \
    TSYNC_X_UNSP(   IP_getFreq ) \
                    \
    TSYNC_X_UNSP(   IP_setFreq ) \
                    \
    TSYNC_X_UNSP(   IP_getCodedExpr ) \
                    \
    TSYNC_X_UNSP(   IP_setCodedExpr ) \
                    \
    TSYNC_X_UNSP(   IP_getCtrlField ) \
                    \
    TSYNC_X_UNSP(   IP_setCtrlField ) \
                    \
    TSYNC_X_UNSP(   IP_setMessage ) \
                    \
    TSYNC_X_UNSP(   PP_setSigCtrl ) \
                    \
    TSYNC_X_UNSP(   PP_getSigCtrl ) \
                    \
    TSYNC_X_UNSP(   PP_getFreq ) \
                    \
    TSYNC_X_UNSP(   PP_getOffset ) \
                    \
    TSYNC_X_UNSP(   PP_setOffset ) \
                    \
    TSYNC_X_UNSP(   PP_getEdge ) \
                    \
    TSYNC_X_UNSP(   PP_setEdge ) \
                    \
    TSYNC_X_UNSP(   PP_getPulseWidth ) \
                    \
    TSYNC_X_UNSP(   PP_setPulseWidth ) \
                    \
    TSYNC_X_FUNC(   XO_getDiscState, DiscState, ;, \
                    FA_GET, "Get Oscillator Disc State", &disc) \
                    \
    TSYNC_X_FUNC(   XO_getMode, OscillatorMode, ;, \
                    FA_GET, "Get Oscillator Mode", &mode) \
                    \
    TSYNC_X_FUNC(   XO_setMode, OscillatorMode, ;, \
                    FA_SET, "Set Oscillator Mode", mode) \
                    \
    TSYNC_X_FUNC(   XO_getDac, OscillatorDAC, ;, \
                    FA_GET, "Get Oscillator DAC", &dac) \
                    \
    TSYNC_X_FUNC(   XO_setDac, OscillatorDAC, ;, \
                    FA_SET, "Set Oscillator DAC", dac) \
                    \
    TSYNC_X_FUNC(   XO_getAlarm, OscillatorAlarm, ;, \
                    FA_GET, "Get Oscillator Alarm", &alarm) \
                    \
    TSYNC_X_FUNC(   XO_getSerNum, OscillatorSerialNumber, ;, \
                    FA_GET, "Get Oscillator Serial Number", &sernum) \
                    \
    TSYNC_X_FUNC(   XO_getMfrMdl, ManufacturerModel, ;, \
                    FA_GET, "Get Oscillator Manufacturer Model", &pObj) \
                    \
    TSYNC_X_FUNC(   XO_getMessage, CustomMessage, ;, \
                    FA_GET, "Get Oscillator Custom Message", &pObj) \
                    \
    TSYNC_X_FUNC(   XO_setMessage, CustomMessage, ;, \
                    FA_SET, "Set Oscillator Custom Message", &pObj) \
                    \
    TSYNC_X_FUNC(   XO_getCmd, OscillatorDiscCommand, ;, \
                    FA_GET, "Get Oscillator Disc Command", &pObj) \
                    \
    TSYNC_X_FUNC(   XO_setCmd, OscillatorDiscCommand, ;, \
                    FA_SET, "Set Oscillator Disc Command", &pObj) \
                    \
    TSYNC_X_UNSP(   FP_setSigCtrl ) \
                    \
    TSYNC_X_UNSP(   FP_getSigCtrl ) \
                    \
    TSYNC_X_UNSP(   FP_getFreq ) \
                    \
    TSYNC_X_UNSP(   MS_getData ) \
                    \
    TSYNC_X_FUNC(   MS_reset, MS_DI_INDEX, ;, \
                    FA_SET, "Shared Memory Reset", index) \
                    \
    TSYNC_X_FUNC(   GO_getSigCtrl, GPOSignatureControl, ;, \
                    FA_GET, "Get GPO Signature Control", gpo, &sig) \
                    \
    TSYNC_X_FUNC(   GO_setSigCtrl, GPOSignatureControl, ;, \
                    FA_SET, "Set GPO Signature Control", gpo, sig) \
                    \
    TSYNC_X_FUNC(   GO_getEnable, GPOOutputEnable, ;, \
                    FA_GET, "Get GPO Output Enable", gpo, &bEnable) \
                    \
    TSYNC_X_FUNC(   GO_setEnable, GPOOutputEnable, ;, \
                    FA_SET, "Set GPO Output Enable", gpo, bEnable) \
                    \
    TSYNC_X_FUNC(   GO_getValue, GPOValue, ;, \
                    FA_GET, "Get GPO Value", gpo, &bValue) \
                    \
    TSYNC_X_FUNC(   GO_getMode, GPOMode, ;, \
                    FA_GET, "Get GPO Mode", gpo, &mode) \
                    \
    TSYNC_X_FUNC(   GO_setMode, GPOMode, ;, \
                    FA_SET, "Set GPO Mode", gpo, mode) \
                    \
    TSYNC_X_FUNC(   GO_getDvmValue, GPOValue, ;, \
                    FA_GET, "Get GPO DVM Value", gpo, &bValue) \
                    \
    TSYNC_X_FUNC(   GO_setDvmValue, GPOValue, ;, \
                    FA_SET, "Set GPO DVM Value", gpo, bValue) \
                    \
    TSYNC_X_UNSP(   GO_getMatchEnable ) \
                    \
    TSYNC_X_UNSP(   GO_setMatchEnable ) \
                    \
    TSYNC_X_FUNC(   GO_getSquareWave, GPOSquareWave, ;, \
                    FA_GET, "Get GPO Square Wave", gpo, &pObj) \
                    \
    TSYNC_X_FUNC(   GO_setSquareWave, GPOSquareWave, ;, \
                    FA_SET, "Set GPO Square Wave", gpo, &pObj) \
                    \


#define getReferenceTableOutput \
    int i; \
    char cNone[] = "----"; \
    \
    printf( "\tIndex\t" \
            "Enabl\t" \
            "Prior\t" \
            "Time\t" \
            "PPS\t\n"); \
    for(i = 0; i < TSYNC_TABLE_ENTRY_NUM; i ++) \
    { \
        printf( "\t%u\t" \
                "%u\t" \
                "%u\t" \
                "%s\t" \
                "%s\t\n", \
                i, \
                pObj2.rows[i].enab, \
                pObj2.rows[i].prio, \
                pObj2.rows[i].time[0] != '\0' ? pObj2.rows[i].time : cNone, \
                pObj2.rows[i].pps[0] != '\0' ? pObj2.rows[i].pps : cNone); \
    } \

#define HW_getTsDataOutput \
    int i; \
    int bFoundData; \
    \
    printf( "\tIndex\t" \
            "years\t" \
            "doy\t" \
            "hours\t" \
            "minutes\t" \
            "seconds\t" \
            "ns\t\n"); \
    for(i = 0; i < TSYNC_TIMESTAMP_DATA_NUM; i ++) \
    { \
        if(pObj.data[i].time.doy == 0) continue; \
        bFoundData = 1; \
        printf( "\t%u\t" \
                "%u\t" \
                "%u\t" \
                "%u\t" \
                "%u\t" \
                "%u\t" \
                "%u\t\n", \
                i, \
                pObj.data[i].time.years, \
                pObj.data[i].time.doy, \
                pObj.data[i].time.hours, \
                pObj.data[i].time.minutes, \
                pObj.data[i].time.seconds, \
                pObj.data[i].time.ns); \
    } \
    if( bFoundData != 1) { printf("\tNo Data\n"); } \

#define getCapOutput \
     if(pObj != NULL) \
     { \
        printf("  Got capability: CAI <%u:0x%02x> IID <%u:0x%02x> Access <%u:0x%02x>\n", \
                    pObj->cai, pObj->cai, pObj->iid, \
                    pObj->iid, pObj->access, pObj->access); \
     } \
     else \
     { \
        printf("  Capability doesn't exist: CAI <%u:0x%02x> IID <%u:0x%02x>\n", \
            cai, cai, \
            iid, iid); \
     } \

#define getCapByIndexOutput \
     if(pObj != NULL) \
     { \
        printf("  Got capability: CAI <%u:0x%02x> IID <%u:0x%02x> Access <%u:0x%02x>\n", \
                    pObj->cai, pObj->cai, pObj->iid, \
                    pObj->iid, pObj->access, pObj->access); \
     } \
     else \
     { \
        printf("  Capability doesn't exist: Index <%u>\n", \
            index); \
     } \

#define getReferenceStateTableOutput \
    int i; \
    char cNone[] = "----"; \
     \
        printf( "\tIndex\t" \
                "Src\t" \
                "Time V\t" \
                "PPS V\n"); \
    for(i = 0; i < TSYNC_STATE_TABLE_ENTRY_NUM; i ++) \
    { \
        printf( "\t%u\t" \
                "%s\t" \
                "%u\t" \
                "%u\n", \
                i, \
                pObj.rows[i].source[0] != '\0' ? pObj.rows[i].source : cNone, \
                pObj.rows[i].timeValid, \
                pObj.rows[i].ppsValid); \
    } \

#define getGPSSatDataOutput \
    int i; \
    for(i = 0; i < TSYNC_SAT_INFO_NUM; i ++) \
    { \
        printf( "  GPS Sat Data (%d):\n" \
                "   Channel Number: %u\n" \
                "   SVID: %u\n" \
                "   Signal Strength: %u\n" \
                "   Traim: %u\n" \
                "   Infix: %u\n" \
                "   Bit Flags: 0x%08X\n", \
                i, \
                pObj.info[i].chnum, \
                pObj.info[i].svid, \
                pObj.info[i].str, \
                pObj.info[i].bTraim, \
                pObj.info[i].bInfix, \
                pObj.info[i].flags); \
    } \


#ifdef __cplusplus
}
#endif

#endif  /* _defined_TSYNCTEST_H */
