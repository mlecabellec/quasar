#ifndef _defined_TSYNC_NONKTS_H
#define _defined_TSYNC_NONKTS_H

/*******************************************************************************
**  Module:     tsync_nonkts.h
**  Date:       09/17/09
**  Purpose:    This is the TSYNC/TSAT PCI Card interface file for haedware
**              features that are not part of the KTS.  This file should *only*
**              be included from tsync.h.
**
** (C) Copyright 2009 Spectracom Corporation  All rights reserved.
**
*******************************************************************************/

#ifdef LAFAYETTE
    #include "tsync_nonkts_lafayette.h"
#endif

#endif  /* _defined_TSYNC_NONKTS_H */
