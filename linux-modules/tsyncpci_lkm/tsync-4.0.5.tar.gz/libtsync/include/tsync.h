
#ifndef _defined_TSYNC_H
#define _defined_TSYNC_H

/*******************************************************************************
**  Module:     tsync.h
**  Date:       08/08/07
**  Purpose:    This is the TSYNC/TSAT PCI Card interface file.
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
*******************************************************************************/

#ifdef __cplusplus
extern "C" {
#endif

#include "tsync_platform_mapping.h"

#if (!defined(NIOS) && !defined(COLDFIRE)) || (defined(NIOS) && defined(COLDFIRE))
#error Either NIOS or COLDFIRE must be defined!
#endif

#ifndef DLL_EXPORT
#ifndef WIN32
#define DLL_EXPORT /* */
#else
#define DLL_EXPORT __declspec(dllexport)
#endif
#endif


#ifndef UNUSED_VARIABLE
#define UNUSED_VARIABLE(x) ((void)(x))
#endif


    /*==========================================================================
    SUPPORT CONSTANTS
    ==========================================================================*/

#define SWITCH_FEATURE_OPTION_LEN 8

    /*
    ** Propagation delay min's and max's for CPCI and PCI boards
    */
#define PMC_CPCI_SYNCP_DELAY_MIN        ( -999 )
#define PMC_CPCI_SYNCP_DELAY_MAX        ( 999 )
#define PCI_SYNCP_DELAY_MIN             ( -1000 )
#define PCI_SYNCP_DELAY_MAX             ( 8999 )

    /*
    ** Position conversion constants
    */
#define PI                              ( 3.1415926535898 )
#define RAD_TO_DEG                      ( 180.0 / PI )
#define DEG_TO_RAD                      ( PI / 180.0 )

    /*
    ** Length of firmware rev string
    */
#define TSYNC_FIRMWARE_LENGTH           ( 4 )

    /*
    ** Length of driver version string "XX.YY"
    ** (not including termination)
    */
#define TSYNC_DRV_VERSION_LENGTH        ( 5 )


#include "tsync_error_codes.h"

    /*
    ** Handle to the TSync board obj available to the user
    */
    typedef void* TSYNC_BoardHandle;

    typedef uint8_t CI_CAI;
    typedef uint8_t CI_IID;

#define TSYNC_CAPABILITIES_PER_PAGE     ( 16 )
#define TSYNC_DATA_BLOCK_SIZE           ( 1024 )
/*
 * This next line is a workaround to be able to build libtsync for velasync on default workspace
 * It will be removed once we are able to build kramden-git on master branch and integrate
 * it in the velasync upgrade
 */
#ifdef NIOS
#define TSYNC_TABLE_ENTRY_NUM           ( 31 )
#define TSYNC_STATE_TABLE_ENTRY_NUM     ( 32 )
#else
#define TSYNC_TABLE_ENTRY_NUM           ( 15 )
#define TSYNC_STATE_TABLE_ENTRY_NUM     ( 16 )
#endif
#define TSYNC_REF_PHASE_TABLE_MAX       ( 32 )
#define TSYNC_INIT_RESULT_NUM           ( 16 )
#define TSYNC_SAT_INFO_NUM              ( 32 )
#define TSYNC_IR_SUBFRAME_NUM           ( 10 )
#define TSYNC_IR_CFDATA_NUM             ( 3 )
#define TSYNC_IP_SUBFRAME_NUM           ( 10 )
#define TSYNC_IP_CFDATA_NUM             ( 3 )
#define TSYNC_OSC_MAN_MOD_STRING_SIZE   ( 16 )
#define TSYNC_OSC_DISC_CMD_SIZE         ( 8 )       //TBD!!!
#define TSYNC_OSC_DISC_DATA_SIZE        ( 8 )       //TBD!!!
#define TSYNC_OSC_SER_NUM_STRING_SIZE   ( 32 )
#define TSYNC_PTP_VER_STR_LEN           ( 28 )
#define TSYNC_PTP_DATE_STR_LEN          ( 12 )
#define TSYNC_QUAL_LOG_NUM              ( TSYNC_SAT_INFO_NUM + 1 )
#define TSYNC_PARM_NUM                  ( 4 )
#define TSYNC_GR_AGPS_SIZE              ( 256 )

#define TSYNC_DEFAULT_GPS_INSTANCE      (0)

#define TL_VER_STR_LEN          (8)     // "<0-255>.<0-255>\0"
#define TL_DATE_STR_LEN         (11)    // "<1-12>/<1-31>/<1900-20XX>\0"
#define TL_SERNO_STR_LEN        (17)    // "<0-32767> <0-4294967296>\0"

// Version strings are always null terminated
#define UBX_SW_VER_STR_LEN       (30)    // "<0-255>.<0-255> (XXXXX)\0"
#define UBX_HW_VER_STR_LEN       (10)    // "XXXXXXXXX\0"

#define UBX_HW_VER_STR_NUM       (7)     // Assume N=7 external versions
#define UBX_EX_VER_STR_LEN       (30)    // Receiver Info must be < 256
#define UBX_EX_VER_STR_MAX       (UBX_EX_VER_STR_LEN*UBX_HW_VER_STR_NUM)
                                         // Extended version string is N*30 with
                                         // no limit defined in protocol

// These are the default definitions used to make the SVID field used to
// identify satellites.  The upper 16 bits are the constellation identifier
// and the lower 16 bits are the Satellite index. There is no SV 0, the
// source of these numbers is the UBX SVID values found in the UBX Protocol
// manual in section B Satellite Numbering.

#define GL_CNST_GPS             (0)
#define GL_CNST_SBAS            (1)
#define GL_CNST_GAL             (2)
#define GL_CNST_BDS             (3)
#define GL_CNST_IMES            (4)
#define GL_CNST_QZSS            (5)
#define GL_CNST_GLO             (6)
#define GL_CNST_IRNSS           (7)
#define GL_CNST_GNSS_MAX        (8) // Higher values reserved

#define GL_CNST_CHAR_GPS        'G'
#define GL_CNST_CHAR_SBAS       'S'
#define GL_CNST_CHAR_GAL        'E'
#define GL_CNST_CHAR_BDS        'C'
#define GL_CNST_CHAR_IMES       'M'
#define GL_CNST_CHAR_QZSS       'J'
#define GL_CNST_CHAR_GLO        'R'
#define GL_CNST_CHAR_IRNSS      'I'
#define GL_CNST_CHAR_GNSS_MAX   'U'

#define GL_IDX_GPS_MIN          (1)
#define GL_IDX_GPS_MAX          (32)

#define GL_IDX_SBAS_MIN         (120)
#define GL_IDX_SBAS_MAX         (158)

#define GL_IDX_GAL_MIN          (1)
#define GL_IDX_GAL_MAX          (36)

#define GL_IDX_BDS_MIN          (1)
#define GL_IDX_BDS_MAX          (37)

#define GL_IDX_IMES_MIN         (1)
#define GL_IDX_IMES_MAX         (10)

#define GL_IDX_QZSS_MIN         (1)
#define GL_IDX_QZSS_MAX         (7)

#define GL_IDX_GLO_MIN          (1)
#define GL_IDX_GLO_MAX          (32)
#define GL_IDX_GLO_TRK          (255)

#define GL_IDX_IRNSS_MIN        (1)
#define GL_IDX_IRNSS_MAX        (7)

// SVID definitions based on UBX protocol used by Spectracom

#define GL_SVID_MASK_ID   (0x0000FFFF)
#define GL_SVID_MASK_CNST (0xFFFF0000)

#define GL_SVID_GPS_MIN   ((GL_CNST_GPS   << 16) | GL_IDX_GPS_MIN)
#define GL_SVID_GPS_MAX   ((GL_CNST_GPS   << 16) | GL_IDX_GPS_MAX)

#define GL_SVID_SBAS_MIN  ((GL_CNST_SBAS  << 16) | GL_IDX_SBAS_MIN)
#define GL_SVID_SBAS_MAX  ((GL_CNST_SBAS  << 16) | GL_IDX_SBAS_MAX)

#define GL_SVID_GAL_MIN   ((GL_CNST_GAL   << 16) | GL_IDX_GAL_MIN)
#define GL_SVID_GAL_MAX   ((GL_CNST_GAL   << 16) | GL_IDX_GAL_MAX)

#define GL_SVID_BDS_MIN   ((GL_CNST_BDS   << 16) | GL_IDX_BDS_MIN)
#define GL_SVID_BDS_MAX   ((GL_CNST_BDS   << 16) | GL_IDX_BDS_MAX)

#define GL_SVID_IMES_MIN  ((GL_CNST_IMES  << 16) | GL_IDX_IMES_MIN)
#define GL_SVID_IMES_MAX  ((GL_CNST_IMES  << 16) | GL_IDX_IMES_MAX)

#define GL_SVID_QZSS_MIN  ((GL_CNST_QZSS  << 16) | GL_IDX_QZSS_MIN)
#define GL_SVID_QZSS_MAX  ((GL_CNST_QZSS  << 16) | GL_IDX_QZSS_MAX)

#define GL_SVID_GLO_MIN   ((GL_CNST_GLO   << 16) | GL_IDX_GLO_MIN)
#define GL_SVID_GLO_MAX   ((GL_CNST_GLO   << 16) | GL_IDX_GLO_MAX)
#define GL_SVID_GLO_TRK   ((GL_CNST_GLO   << 16) | GL_IDX_GLO_TRK)

#define GL_SVID_IRNSS_MIN ((GL_CNST_IRNSS << 16) | GL_IDX_IRNSS_MIN)
#define GL_SVID_IRNSS_MAX ((GL_CNST_IRNSS << 16) | GL_IDX_IRNSS_MAX)

 // All values higher are reserved
#define GL_SVID_MAX_RNG   ((GL_CNST_GNSS_MAX << 16) | 0)

// GPS Satellite ID range - DEPRECATED - use new constellation index value
#define TSYNC_SVID_GPS_MIN      (GL_SVID_GPS_MIN)
#define TSYNC_SVID_GPS_MAX      (GL_SVID_GPS_MAX)

#define TSYNC_SVID_GLO_MIN      (65)
#define TSYNC_SVID_GLO_MAX      (96)

#define TSYNC_SVID_BDS_MIN      (200)
#define TSYNC_SVID_BDS_MAX      (236)

#define TSYNC_SVID_QZSS_MIN     (193)
#define TSYNC_SVID_QZSS_MAX     (200)

    /******************************************************
    **     Define Enumerations
    ******************************************************/

    /*** General ***/
    typedef enum
    {
        SIG_CTL_NONE = 0,           // No Signature Control - always ON
        SIG_CTL_SYNC = 1,           // Signature Control based on SYNC status
        SIG_CTL_REF  = 2,           // Signature Control based on Reference
                                    // status
        SIG_CTL_OFF  = 3,           // Ultimate Signature Control - always OFF
        SIG_CTL_NUM

    } SIG_CTL;

    typedef enum
    {                               // TFOM based on Estimated Time Error (ETE)
        TFOM_MIN       = 0,         // Minimum TFOM value
        TFOM_UNDEFINED = 0,         // TFOM is not defined, ETE is unknown
        TFOM_1         = 1,         //             ETE <=   1 nsec
        TFOM_2         = 2,         //    1 nsec < ETE <=  10 nsec
        TFOM_3         = 3,         //   10 nsec < ETE <= 100 nsec
        TFOM_4         = 4,         //  100 nsec < ETE <=   1 usec
        TFOM_5         = 5,         //    1 usec < ETE <=  10 usec
        TFOM_6         = 6,         //   10 usec < ETE <= 100 usec
        TFOM_7         = 7,         //  100 usec < ETE <=   1 msec
        TFOM_8         = 8,         //    1 msec < ETE <=  10 msec
        TFOM_9         = 9,         //   10 msec < ETE <= 100 msec
        TFOM_10        = 10,        //  100 msec < ETE <=   1 sec
        TFOM_11        = 11,        //    1 sec  < ETE <=  10 sec
        TFOM_12        = 12,        //   10 sec  < ETE <=  100 sec
        TFOM_13        = 13,        //  100 sec  < ETE <= 1000 sec
        TFOM_14        = 14,        // 1000 sec  < ETE <= 10000 sec
        TFOM_15        = 15,        //             ETE >  10000 sec
        TFOM_NUM,                   // Number of TFOM values
        TFOM_MAX       = (TFOM_15)

    } TFOM;

    typedef enum
    {
        EDGE_MIN     = 0,
        EDGE_FALLING = 0,
        EDGE_RISING  = 1,
        EDGE_BOTH    = 2,
        EDGE_NUM

    } EDGE;

    typedef enum
    {
        LEVEL_LOW  = 0,
        LEVEL_HIGH = 1

    } LEVEL;

    typedef enum
    {
    OSC_UNKNOWN  = -1,          // Unknown oscillator type

    OSC_TCXO_1   = 0,           //  1ppm
    OSC_TCXO_2   = 1,           //  1ppm

    OSC_OCXO_1   = 2,           // 50ppb
    OSC_OCXO_2   = 3,           //  5ppb
    OSC_OCXO_3   = 4,           //  1ppb
    OSC_OCXO_4   = 5,           //  2ppb

    OSC_RBXO_1   = 6,           // .1ppb
    OSC_RBXO_2   = 7,           // .1ppb
    OSC_RBXO_3   = 8,           // .1ppb

    OSC_RBXO_1_2 = 9,           // .1ppb
    OSC_RBXO_1_3 = 10,          // .1ppb
    OSC_RBXO_1_4 = 11,          // .1ppb

    OSC_CSAC_1   = 12,          // .5ppb

    OSC_MAC_1    = 13,          // .15ppb

    OSC_OCXO_5   = 14,           // 10ppb

    OSC_OCXO_6   = 15,           // 50ppb

    OSC_NUM

    } OSC;

    typedef enum
    {
        ML_START_TIME_SCALES = 0,           // First time scale in list
        ML_TIME_SCALE_UTC    = 0,           // Universal Coordinated Time
        ML_TIME_SCALE_TAI    = 1,           // International Atomic Time
        ML_TIME_SCALE_GPS    = 2,           // Global Positioning System
        ML_TIME_SCALE_LOCAL  = 3,           // UTC w/local rules for time
                                            // zone/DST
        ML_NUM_TIME_SCALES   = 4,           // Number of time scales

        ML_TIME_SCALE_MAX    = 15           // Maximum number of timescales

    } ML_TIME_SCALE;

    typedef enum
    {
        ML_TIME_START_TYPES = 0,            // First time type in the list
        ML_TIME_DOYTIME     = 0,            // Year, Day of Year, Hour, Min,
                                            // Sec, nsec
        ML_TIME_BCDTIME     = 1,            // BCD Year, Day of Year, Hour,
                                            // Min, Sec, ms, us
        ML_TIME_SECONDS     = 2,            // Total number of seconds in
                                            // epoch, nsec
        ML_TIME_NUM_TYPES                   // Number of time types

    } ML_TIME_TYPE;

    typedef enum
    {
        ML_DST_REF_LCL = 0,                 // Reference is local time
        ML_DST_REF_UTC = 1                  // Reference is UTC

    } ML_DST_REF;

    typedef enum
    {
        ML_MONTH_NONE = 0,
        ML_MONTH_JAN  = 1,
        ML_MONTH_FEB  = 2,
        ML_MONTH_MAR  = 3,
        ML_MONTH_APR  = 4,
        ML_MONTH_MAY  = 5,
        ML_MONTH_JUN  = 6,
        ML_MONTH_JUL  = 7,
        ML_MONTH_AUG  = 8,
        ML_MONTH_SEP  = 9,
        ML_MONTH_OCT  = 10,
        ML_MONTH_NOV  = 11,
        ML_MONTH_DEC  = 12

    } ML_MONTH;

    typedef enum
    {
        ML_WOM_NONE   = 0,
        ML_WOM_FIRST  = 1,
        ML_WOM_SECOND = 2,
        ML_WOM_THIRD  = 3,
        ML_WOM_FOURTH = 4,
        ML_WOM_LAST   = 5

    } ML_WOM;

    typedef enum
    {
        ML_DOW_SUN = 0,
        ML_DOW_MON = 1,
        ML_DOW_TUE = 2,
        ML_DOW_WED = 3,
        ML_DOW_THU = 4,
        ML_DOW_FRI = 5,
        ML_DOW_SAT = 6,

    } ML_DOW;

    typedef enum
    {
        ML_HOUR_START_TYPES = 0,            // First hour type in the list
        ML_HOUR_12          = 0,            // 12-hour format
        ML_HOUR_24          = 1,            // 24-hour format
        ML_HOUR_NUM_TYPES                   // Number of hour types

    } ML_HOUR;

    // Number of different message formats that can be sent each second
    #define AL_FMT_MAX              (3)

    typedef enum
    {
        AL_FMT_SPEC_0     = 0x00000000,     // Spectracom format 0
        AL_FMT_SPEC_1     = 0x00000001,     // Spectracom format 1
        AL_FMT_SPEC_2     = 0x00000002,     // Spectracom format 2
        AL_FMT_SPEC_3     = 0x00000003,     // Spectracom format 3
        AL_FMT_SPEC_4     = 0x00000004,     // Spectracom format 4
        AL_FMT_SPEC_5     = 0x00000005,     // Spectracom format 4
        AL_FMT_SPEC_6     = 0x00000006,     // Spectracom format 6
        AL_FMT_SPEC_7     = 0x00000007,     // Spectracom format 7
        AL_FMT_SPEC_8     = 0x00000008,     // Spectracom format 8
        AL_FMT_SPEC_9     = 0x00000009,     // Spectracom format 9
        AL_FMT_NMEA_GGA   = 0x0000000A,     // NMEA GGA message
        AL_FMT_NMEA_RMC   = 0x0000000B,     // NMEA RMC message
        AL_FMT_NMEA_ZDA   = 0x0000000C,     // NMEA ZDA message
        AL_FMT_BBC_01     = 0x0000000D,     // BBC format 1
        AL_FMT_BBC_02     = 0x0000000E,     // BBC format 2
        AL_FMT_BBC_03     = 0x0000000F,     // BBC format 3 PSTN
        AL_FMT_BBC_04     = 0x00000010,     // BBC format 4
        AL_FMT_153C_BB    = 0x00000011,     // ICD-153C 253  Buffer Box
        AL_FMT_153C_TT    = 0x00000012,     // ICD-153C 5101 Time Transfer
        AL_FMT_153C_CS    = 0x00000013,     // ICD-153C 5040 Current Status
        AL_FMT_ER_0       = 0x00000014,     // EndRun Format
        AL_FMT_ER_1       = 0x00000015,     // EndRunX Extended Format
        AL_FMT_EVT_0      = 0x00000016,     // Event Timestamp Format 0
        AL_FMT_EVT_1      = 0x00000017,     // Event Timestamp Format 0
        AL_FMT_BBC_05     = 0x00000018,     // BBC format 5 (RMC)
        AL_FMT_EPS_1      = 0x00000019,     // EPSILON TOD1 Format
        AL_FMT_EPS_3      = 0x0000001A,     // EPSILON TOD3 Format
        AL_FMT_EL_UTC     = 0x0000001B,     // E-LORAN UTC Format
        AL_FMT_EL_LCRSDA  = 0x0000001C,     // E-LORAN LCRSDA Format
        AL_FMT_153C_TM    = 0x0000001D,     // ICD-153C 3 Time Mark Data

        // Add new formats here. Maintain order and values.

        AL_FMT_SPEC_1S    = 0x00000101,     // Format 1S variant
        AL_FMT_SPEC_9S    = 0x00000109,     // Format 9S variant

        AL_FMT_NMEA_GGA_PAD = 0x0000010A,   // NMEA GGA message with padding

        AL_FMT_UNKNOWN    = 0x0000FFFF,     // Unknown (auto)

    } AL_FMT;

    typedef enum
    {
        AL_OMODE_BC = 0,                    // Broadcast
        AL_OMODE_OT = 1,                    // On-Time
        AL_OMODE_IM = 2,                    // Immediate
        AL_OMODE_EV = 3,                    // Event Immediate

    } AL_OUT_MODE;

    // The AL_PPS type defines the source of a 1PPS signal for a ASCII Input
    // port.
    typedef enum
    {
        AL_PPS_OTP = 0,                     // Decoded 1PPS selected
        AL_PPS_SIG = 1,                     // External ATC 1PPS input selected

    } AL_PPS;

    // The AO_SOURCE enumeration describes the different possible
    // sources of an ASCII message
    typedef enum
    {
        AO_SOURCE_SYSTEM = 0, // System Time is output source (normal)
        AO_SOURCE_EVTBUF = 1  // Event Buffer

    } AO_SOURCE;

    typedef enum
    {
        IL_MODE_AUTO   = 0,
        IL_MODE_MANUAL = 1

    } IL_MODE;

    typedef enum
    {
        IL_FMT_IRIG_A     = 0,
        IL_FMT_IRIG_B     = 1,
        IL_FMT_IRIG_G     = 2,
        IL_FMT_NASA_36    = 3,
        IL_FMT_IRIG_E_100 = 4,
        IL_FMT_IRIG_E_1K  = 5,
        IL_FMT_UNKNOWN    = 7,              // Unknown
        IL_FMT_AUTO                         // Auto-detection

    } IL_FMT;

    typedef enum
    {
        IL_MOD_DCLS        = 0,             // IRIG DCLS only
        IL_MOD_AM          = 1,             // IRIG AM only
        IL_MOD_MAN         = 2,             // IRIG Manchester coding
        IL_MOD_UNKNOWN     = 3,             // Unknown
        IL_MOD_AM_AND_DCLS = 4,             // Port generates both AM and DCLS
        IL_MOD_AM_OR_DCLS  = 5              // Port generate AM or DCLS

    } IL_MOD;

    typedef enum
    {
        IL_FRQ_NONE        = 0,             // No Carrier/Index count interval
        IL_FRQ_100HZ       = 1,
        IL_FRQ_1KHZ        = 2,
        IL_FRQ_10KHZ       = 3,
        IL_FRQ_100KHZ      = 4,
        IL_FRQ_1MHZ        = 5,
        IL_FRQ_UNKNOWN     = 6              // Unknown

    } IL_FRQ;

    typedef enum
    {
        IL_CE_BCDT_CF_SBS      = 0,         // BCD TOY, Ctrl Func, Binary
                                            // Seconds
        IL_CE_BCDT_CF          = 1,         // BCD TOY, Ctrl Func
        IL_CE_BCDT             = 2,         // BCD TOY
        IL_CE_BCDT_SBS         = 3,         // BCD TOY, Binary Seconds,
        IL_CE_BCDT_BCDY_CF_SBS = 4,         // BCD TOY/Year, Ctrl Func, Binary
                                            // Seconds
        IL_CE_BCDT_BCDY_CF     = 5,         // BCD TOY/Year, Ctrl Func
        IL_CE_BCDT_BCDY        = 6,         // BCD TOY/Year,
        IL_CE_BCDT_BCDY_SBS    = 7,         // BCD TOY/Year, Binary Seconds
        IL_CE_UNKNOWN          = 8          // Unknown - No fields

    } IL_CE;

    typedef enum
    {
        IL_CF_MIN       = 0,                // Minimum value of CF
        IL_CF_UNKNOWN   = 0,                // Unknown - All bits ignored
        IL_CF_200_04    = 1,                // Fields conform to RCC 200-04
        IL_CF_1344      = 2,                // Fields conform to IEEE
                                            // C37.118-2005
        IL_CF_SPEC      = 3,                // Fields conform to Spectracom
                                            // format
        IL_CF_SPEC_FAA  = 4,                // Fields conform to Spectracom FAA
                                            // format
        IL_CF_NASA      = 5,                // Fields conform to NASA formats
        IL_CF_1344_SPEC = 6,                // Fields conform to IEEE
                                            // C37.118-2005 with extended leap
                                            // second

        IL_CF_NUM                           // Number of CF types

    } IL_CF;

    // The QL_FMT type defines the HaveQuick formats.
    typedef enum
    {
        QL_FMT_HQ_I     = 0,           // STANAG 4246 HaveQuick I
        QL_FMT_HQ_II    = 1,           // STANAG 4246 HaveQuick II
        QL_FMT_HQ_IIA   = 2,           // STANAG 4372 HaveQuick IIA
        QL_FMT_4430_STM = 3,           // STANAG 4430 Standard Time Message
        QL_FMT_4430_XHQ = 4,           // STANAG 4430 Extended HaveQuick
        QL_FMT_GPS_BCD  = 5,           // ICD-GPS-060A Binary Coded Decimal
        QL_FMT_GPS_HQ   = 6,           // ICD-GPS-060A HaveQuick
        QL_FMT_BCD_1399 = 7,           // DOD-STD-1399 Binary Coded Decimal
        QL_FMT_4430_XHQ_ED1 = 8,       // STANAG 4430 Extended HaveQuick Edition 1

        QL_FMT_NUM,                    // Number of formats
        QL_FMT_START    = 0,           // Start of format list

        QL_FMT_UNKNOWN  = -1           // Unknown format

    } QL_FMT;

    // The ESL_FMT type defines the SMPTE/EBU formats.
    typedef enum
    {
        ESL_FMT_LTCBBC   = 0,                // SMPTE/EBU Format LTC BBC
        ESL_FMT_LTC309M  = 1,                // SMPTE/EBU Format LTC 309m

        ESL_FMT_NUM,                         // Number of formats
        ESL_FMT_START    = 0,                // Start of format list

        ESL_FMT_UNKNOWN  = -1                // Unknown format

    } ESL_FMT;

    /*** Flash services ***/
    typedef enum
    {
        UL_IMG_RT_FW        = 0,        // Run-time firmware image
                                        // (upgradeable)
        UL_IMG_RT_FPGA      = 1,        // Run-time FPGA image
                                        // (upgradeable)
        UL_IMG_DEF_FW       = 2,        // Default firmware image
                                        // (read-only)
        UL_IMG_DEF_FPGA     = 3,        // Default FPGA image
                                        // (read-only)
        UL_IMG_BL           = 4,        // Boot Loader
                                        // (read-only)
        UL_IMG_CFPGA        = 5,        // Compressed FPGA image
                                        // (read-only)
        UL_IMG_EE_PATCH     = 6,        // EEPROM Patch image
                                        // (upgradeable)
        UL_IMG_SER_DEF_ADDR = 7,        // Serial flash default addr iamge
                                        // (upgradeable)
        UL_IMG_SER_RT_FPGA  = 8,        // Run-time serial flash FPGA image
                                        // (upgradeable)
        UL_IMG_SER_DEF_FPGA = 9,        // Default serial flash FPGA image
                                        // (upgradeable)
        UL_IMG_PTP_CUR_FW   = 10,       // Run-Time PTP Module Firmware
                                        // (Upgradeable)
        UL_IMG_PTP_DEF_FW   = 11,       // Default PTP Module Firmware
                                        // (Upgradeable)
        UL_IMG_LICENSING    = 12,       // Licensing image file
                                        // (Upgradeable)
        UL_IMG_SER_STREAM   = 13,       // Streaming serial Flash Image
                                        // (Upgradeable)
        UL_IMG_RES_GG_FW    = 14,       // RES-SMT GG image file
                                        // (Upgradeable)
        UL_IMG_RES_UBX_FW   = 15,       // UBLOX image file
                                        // (Upgradeable)
        UL_IMG_NUM_ITEMS,

        UL_IMG_UNDEFINED    = 0xFE,     // Reset Value
        UL_IMG_RSVD_BL      = 0xFF      // Reserved for bootloader use

    } UL_IMG;

    typedef enum
    {
        CI_ACC_NONE = 0,
        CI_ACC_GET  = 1,
        CI_ACC_SET  = 2,
        CI_ACC_BOTH = 3

    } CI_ACCESS;

    /*** Signal Level ***/
    typedef enum
    {
       SL_10V  = 0, // Signal Level 10V
       SL_5V   = 1, // Signal Level 5V
       SL_3_3V = 2  // Signal Level 3.3V
    } SIG_LEVEL;

    /*** Electrical type ***/
    typedef enum
    {
       ET_TTL   = 0,
       ET_RS485 = 1
    } ELEC_TYPE;

    /*** Reference Selection ***/
    typedef enum
    {
       RS_STANDARD = 0,
       RS_EXTENDED = 1,
       RS_NONE     = 2
    } REF_SEL;

    /*** Clock services ***/


    /*** Log service ***/
    typedef enum
    {
        LS_ALARM_SYNC     = 0,              // Not in Sync
        LS_ALARM_HOLDOVER = 1,              // In Holdover
        LS_ALARM_FREQ_ERR = 2,              // Frequency Error
        LS_ALARM_SELF_REF = 3,              // Self Reference only
        LS_ALARM_SW_ERR   = 4,              // Software Error
        LS_ALARM_1PPS     = 5,              // 1PPS is not in specification
        LS_ALARM_REF_CHG  = 6,              // Reference Change
        LS_ALARM_HW_ERR   = 7,              // Hardware Error

        LS_ALARM_NUM                        // Number of alarm types

    } LS_ALARM;


    /*** Oscillator Monitor service ***/
    typedef enum
    {
        XS_CMD_AUTO    = 0,                 // Automatically start a new window
                                            // of measurement when a window
                                            // completes
        XS_CMD_START   = 1,                 // Begin a single window of
                                            // measurement
        XS_CMD_STOP    = 2,                 // Stop measuring immediately
        XS_CMD_FINISH  = 3,                 // Stop after current window
                                            // completes
        XS_CMD_RESTART = 4                  // Restart window measurement (Does
                                            // not change meter state)

    } XS_CMD;

    typedef enum
    {
        XS_STATE_STOPPED = 0,               // Not measuring
        XS_STATE_RUNNING = 1,               // Measuring
        XS_STATE_ENDING  = 2                // Measuring until end of window

    } XS_STATE;

    typedef uint32_t TSYNC_METER_HANDLE;


    /*** Supervisor service ***/
    typedef enum
    {
        SS_EVT_SYNC = 0,                    // In sync / Out of sync
        SS_EVT_REF  = 1                     // Valid ref(s) / No valid ref(s)

    } SS_EVENT;

    typedef enum
    {
        SS_RESET_BRD  = 0,                  // Reset the entire board except
                                            // for FPGA
        SS_RESET_MIC  = 1,                  // Reset the microprocessor &
                                            // peripherals
        SS_RESET_FPGA = 2,                  // Reset the FPGA only
        SS_RESET_NUM

    } SS_RESET;

    typedef enum
    {
        SS_TS_MIN      = 0,                 // Minimum Timestamp index
        SS_TS_TIME_REF = 0,                 // Timestamp on Time Reference
                                            // change
        SS_TS_1PPS_REF = 1,                 // Timestamp on 1PPS Reference
                                            // change
        SS_TS_TFOM     = 2,                 // Timestamp on TFOM value change
        SS_TS_SYNC     = 3,                 // Timestamp on Sync state change
        SS_TS_HOLDOVER = 4,                 // Timestamp on Holdover state
                                            // change
        SS_TS_LOST_REF = 5,                 // Timestamp on entering Holdover

        SS_TS_NUM                           // Number of Timestamps

    } SS_TS_SRC;


    /*** Reference service ***/
    typedef enum
    {
        RS_TT_START_TYPES = 0,
        RS_TT_FACT        = 0,              // Factory default table (built at
                                            // runtime)
        RS_TT_USER        = 1,              // User-default table (stored in
                                            // eeprom)
        RS_TT_CURRENT     = 2,              // Current working table

        RS_TT_NUM_TYPES

    } RS_TABLE_TYPE;

    typedef enum
    {
        RS_THR_MODE_FIXED   = 0,  // User defined fixed phase threshold
        RS_THR_MODE_DYNAMIC = 1,  // Dynamic Phase Threshold calculation

        // Add more here...

        RS_THR_MODE_NUM

    } RS_THRESHOLD_MODE;

    /*** General Purpose services ***/
    typedef enum
    {
        OD_MODE_DIRECT      = 0,            // Direct Output Value
        OD_MODE_MATCH_TIME  = 1,            // Match Time Output
        OD_MODE_SQUARE_WAVE = 2,            // Square Wave
        OD_MODE_RESERVED    = 3

    } OD_MODE;

    /*** Frequency Reference components ***/
    typedef enum
    {
        FR_MODE_SEC      = 0,       // Reference valid as secondary reference:
                                    //   Requires another valid reference
                                    //   to synchronize the system before the
                                    //   frequency reference can be determined
                                    //   to be valid.
        FR_MODE_PRI      = 1,       // Reference valid as primary reference:
                                    //   Can be determined to be valid based
                                    //   solely on its own presence.  The 1PPS
                                    //   of the system should be considered to
                                    //   be at some random point in the second.

        FR_MODE_NUM

    } FR_MODE;

    /*** LED services ***/
    typedef enum
    {
        EC_MODE_SYNC     = 0,               // LED indicates sync status
        EC_MODE_HOLDOVER = 1,               // LED indicates holdover status
        EC_MODE_ALARM    = 2,               // LED indicates alarm status
        EC_MODE_1PPS     = 3,               // LED goes on briefly when 1PPS
                                            // occurs
        EC_MODE_MANUAL   = 4,               // LED manually controlled

        EC_MODE_NUM

    } EC_MODE;

    typedef enum
    {
        EC_STATE_OFF   = 0,                 // LED off solid
        EC_STATE_ON    = 1,                 // LED on solid
        EC_STATE_BLINK = 2,                 // LED blinks on/off (2Hz rate)
        EC_STATE_CODE  = 3,                 // LED blinks a code (2Hz rate,
                                            // 2sec pause)

        EC_STATE_NUM

    } EC_STATE;

    typedef enum
    {
        LE_ALL = -1,

        LE_0   = 0,
        LE_1   = 1,
        LE_2   = 2,
        LE_3   = 3,
        LE_4   = 4,
        LE_5   = 5,

        LE_LEDS_NUM

    } LE_INDEX;

    typedef enum
    {
        EC_BLACKOUT_OFF = 0,
        EC_BLACKOUT_ON  = 1,

        EC_BLACKOUT_NUM

    } EC_BLACKOUT_MODE;

    /*** GPS Reference services ***/
    typedef enum
    {
        GL_DYN_LAND   = 0,
        GL_DYN_SEA    = 1,
        GL_DYN_AIR    = 2,
        GL_DYN_STAT   = 3,
        GL_DYN_AIR_1G = 4,
        GL_DYN_AIR_4G = 5

    } GL_DYN;

    typedef enum
    {
        GL_MODE_1SAT = 0,
        GL_MODE_STND = 1,
        GL_MODE_CONT = 2,
        GL_MODE_AVRG = 3,
        GL_MODE_TIME = 4,
        GL_MODE_STBY = 5,
        GL_MODE_SELF = 6

    } GL_MODE;

    typedef enum
    {
        GL_FIX_DIM_NONE     = 0,
        GL_FIX_DIM_DEAD     = 1,
        GL_FIX_DIM_2D       = 2,
        GL_FIX_DIM_3D       = 3,
        GL_FIX_DIM_GPS_DEAD = 4,
        GL_FIX_DIM_TIME     = 5,
        GL_FIX_DIM_UNKNOWN  = 6

    } GL_FIX_DIM;

    /*** GPS Reset types ***/
    typedef enum
    {
        GL_RESET_COLD = 0,           // Clear data in RAM (like power-cycle)
        GL_RESET_WARM = 1,           // Clear ephemeris and osc. uncertainty
        GL_RESET_HOT  = 2,           // No clear, SW reset, rerun self-test
        GL_RESET_POS  = 3,           // Clear position in receiver flash
        GL_RESET_FACT = 4,           // Cold reset + restore factory settings
        GL_RESET_SAVE = 5,           // Reset GPS + save settings
        GL_RESET_MON  = 6,           // Reset GPS + Monitor Mode
        GL_RESET_ID   = 7,           // Identify Receiver

        GL_RESET_SAASM_ZKEY  = 16,   // SGPS Zeroize Keys
        GL_RESET_SAASM_ZCLR  = 17,   // SGPS Zeroize Clear
        GL_RESET_SAASM_ZEMG  = 18,   // SGPS Emergency Zeroize
        GL_RESET_SAASM_RST   = 19,   // Reset SGPS GSSIP interface
        GL_RESET_SAASM_URST  = 20,   // Reset SGPS ALL GSSIP interfaces

        GL_RESET_NONE        = 0xFF  // No Reset required for Web UI Display

    } GL_RESET;

    // The AGPS_ALMANAC type is used to store the A-GPS almanac information.
    // This information is a set of parameters to the equations that describe a
    // coarse orbit of a GPS SV. The naming is consistent with
    // ICD-GPS-200 Sec 20.3.3.5.1.2.
    typedef struct
    {
        unsigned int   prn;
        unsigned int   svHealth;
        unsigned int   weekNumber;
        float          e;
        unsigned int   toa;
        float          io;          // AKA ksii
        float          omegaDot;
        float          sqrtA;
        float          omega0;
        float          omega;       // AKA "w"
        float          m0;
        float          af0;
        float          af1;

    } GL_ALMANAC;

    // The AGPS_EPHEMERIS type is used to store the A-GPS ephemeris information.
    // This information is a set of parameters to the equations that describe
    // the orbit of a GPS SV, in a finer way than the almanac.
    // The naming is consistent with ICD-GPS-200 Sec 20.3.3.5.1.2.
    typedef struct
    {
        unsigned int   prn;
        unsigned int   svHealth;
        float          tephem;
        unsigned int   weekNumber;
        unsigned int   codeL2;
        unsigned int   L2Pdata;
        unsigned int   uraIdx;  // svAccRaw
        unsigned int   iodc;
        float          tgd;
        float          toc;
        float          af2;
        float          af1;
        float          af0;
        float          svAcc;
        unsigned int   iode;
        unsigned int   fit_interval;
        float          crs;
        float          deltaN;
        double         m0;
        float          cuc;
        double         e;
        float          cus;
        double         sqrtA;
        float          toe;
        float          cic;
        double         omega0;
        float          cis;
        double         io;
        float          crc;
        double         omega;       // AKA "w"
        float          omegaDot;
        float          idot;

    } GL_EPHEMERIS;

    // The AGPS_IONOSPHERE type is used to store the A-GPS ionosphere information.
    // This information is a set of parameters to the equations that describe
    // the orbit of a GPS SV, in a finer way than the ionosphere.
    // The naming is consistent with ICD-GPS-200 Sec 20.3.3.5.1.2.
    typedef struct
    {
    float          alpha0;
    float          alpha1;
    float          alpha2;
    float          alpha3;
    float          beta0;
    float          beta1;
    float          beta2;
        float          beta3;
    } GL_IONOSPHERE;

    // The AGPS_UTC type is used to store the A-GPS UTC information.
    // This information is a set of parameters to the equations that describe
    // the orbit of a GPS SV, in a finer way than the UTC.
    // The naming is consistent with ICD-GPS-200 Sec 20.3.3.5.1.2.
    typedef struct
    {
       double       a0;
       float        a1;
       int          deltaTls;
       float        tot;
       unsigned int wnt;
       unsigned int wnlsf;
       unsigned int dn;
       int          deltaTlsf;
    } GL_UTC;

    /*** GPS Antenna States ***/
    typedef enum
    {
        GL_ANT_OK    = 0,
        GL_ANT_SHORT = 1,
        GL_ANT_OPEN  = 2,
        GL_ANT_UNK   = 3

    } GL_ANT_STATUS;

    /*** GPS Set/Get Parameter Type ***/
    typedef enum
    {
        // UBX Parameters
        GL_PARM_UBX_GPS_WEEK   = 0x00000000,
        GL_PARM_UBX_SURVEY     = 0x00000001,
        GL_PARM_UBX_ACCURACY   = 0x00000002,
        GL_PARM_UBX_ALTITUDE   = 0x00000003,

        // TSIP Parameters
        //GL_PARM_TSIP_TBD     = 0x00010000,

        // GSSIP Parameters
        GL_PARM_GSSIP_KEY_STATE = 0x00020000,
        GL_PARM_GSSIP_COM1_EN   = 0x00020001,
        GL_PARM_GSSIP_COM1_CFG  = 0x00020002,
        GL_PARM_GSSIP_PWR_CTRL  = 0x00020003,

        // NMEA Parameters
        //GL_PARM_NMEA_TBD     = 0x00030000,

        GL_PARM_POS_SERVICE     = 0x00040000,
        // Add more here for other receivers...

    } GL_PARM;

    /*** GSSIP COM1 Usage Type - Mutualy exclusive uses for COM1 ***/
    typedef enum
    {
        GL_GSSIP_COM1_HS_IN    = 0,    // Idle, waiting for HotStart Input
        GL_GSSIP_COM1_HS_OUT   = 1,    // Initiate a HotStart Output
        GL_GSSIP_COM1_HVQK     = 2,    // Output HaveQuick messages
        GL_GSSIP_COM1_PPS      = 3,    // Output 1PPS and 5101 message
      //GL_GSSIP_COM1_NMEA     = 4,    // Output NMEA messages (RESERVED)

    } GL_GSSIP_COM1;

    /*** GSSIP COM1 Power control value ***/
    typedef enum
    {
        GL_GSSIP_PWR_OFF   = 0,
        GL_GSSIP_PWR_ON    = 1,
        GL_GSSIP_PWR_CYCLE = 2,

    } GL_GSSIP_PWR;

    typedef struct
    {
        char serNo       [TL_SERNO_STR_LEN];    // Serial Number
        char serNoDate   [TL_DATE_STR_LEN];     // Serial Number Issue Date
        char appVer      [TL_VER_STR_LEN];      // Appl / Nav Proc SW Version
        char appVerDate  [TL_DATE_STR_LEN];     // Appl / Nav Proc SW Version Date
        char coreVer     [TL_VER_STR_LEN];      // Core / Signal Proc Version
        char coreVerDate [TL_DATE_STR_LEN];     // Core / Signal Version Date

    } TL_RCV_INFO;

    typedef struct
    {
        char swVer[UBX_SW_VER_STR_LEN];
        char hwVer[UBX_HW_VER_STR_LEN];
        char exten[UBX_HW_VER_STR_NUM][UBX_EX_VER_STR_LEN];

    } UBX_RCV_INFO;
    
    /*** Hotswap structures ***/
    typedef struct
    {
        unsigned int fan_en;
        unsigned int fan_pwm;
        unsigned int fan_speed;
               float temp;
               float voltage;
               float current;
    } HS_SLED_STATUS;
    
    typedef struct
    {
        unsigned int fan_en;
        unsigned int fan_pwm;
    } HS_SLED_CTL;

    /*** PTP Reference services ***/
    typedef enum
    {
        PTL_RESET_COLD = 0,
        PTL_RESET_HOT  = 1,
        PTL_RESET_FACT = 2

    } PTL_RESET;

    typedef enum
    {
        PTL_PTP_STATE_INITIALIZING = 0,
        PTL_PTP_STATE_FAULTY       = 1,
        PTL_PTP_STATE_DISABLED     = 2,
        PTL_PTP_STATE_LISTENING    = 3,
        PTL_PTP_STATE_PRE_MASTER   = 4,
        PTL_PTP_STATE_MASTER       = 5,
        PTL_PTP_STATE_PASSIVE      = 6,
        PTL_PTP_STATE_UNCALIBRATED = 7,
        PTL_PTP_STATE_SLAVE        = 8,

        PTL_PTP_STATE_COUNT        = 9

    } PTL_PTP_STATE;

    typedef enum
    {
        PTL_DELAY_MECH_E2E      = 0x01,
        PTL_DELAY_MECH_P2P      = 0x02,
        PTL_DELAY_MECH_DISABLED = 0xFE

    } PTL_DELAY_MECH;

    typedef enum
    {
        PTL_CLK_ACC_MIN            = 0x20,

        PTL_CLK_ACC_WITHIN_25_NS   = 0x20,
        PTL_CLK_ACC_WITHIN_100_NS  = 0x21,
        PTL_CLK_ACC_WITHIN_250_NS  = 0x22,
        PTL_CLK_ACC_WITHIN_1000_NS = 0x23,
        PTL_CLK_ACC_WITHIN_2_5_US  = 0x24,
        PTL_CLK_ACC_WITHIN_10_US   = 0x25,
        PTL_CLK_ACC_WITHIN_25_US   = 0x26,
        PTL_CLK_ACC_WITHIN_100_US  = 0x27,
        PTL_CLK_ACC_WITHIN_250_US  = 0x28,
        PTL_CLK_ACC_WITHIN_1_MS    = 0x29,
        PTL_CLK_ACC_WITHIN_2_5_MS  = 0x2A,
        PTL_CLK_ACC_WITHIN_10_MS   = 0x2B,
        PTL_CLK_ACC_WITHIN_25_MS   = 0x2C,
        PTL_CLK_ACC_WITHIN_100_MS  = 0x2D,
        PTL_CLK_ACC_WITHIN_250_MS  = 0x2E,
        PTL_CLK_ACC_WITHIN_1_S     = 0x2F,
        PTL_CLK_ACC_WITHIN_10_S    = 0x30,
        PTL_CLK_ACC_BEYOND_10_S    = 0x31,

        PTL_CLK_ACC_MAX            = 0x31,

        PTL_CLK_ACC_UNKNOWN        = 0xFE

    } PTL_CLK_ACC;

    typedef enum
    {
        PTL_TIME_SRC_ATOMIC_CLOCK        = 0x10,
        PTL_TIME_SRC_GPS                 = 0x20,
        PTL_TIME_SRC_TERR_RADIO          = 0x30,
        PTL_TIME_SRC_PTP                 = 0x40,
        PTL_TIME_SRC_NTP                 = 0x50,
        PTL_TIME_SRC_HAND_SET            = 0x60,
        PTL_TIME_SRC_OTHER               = 0x90,
        PTL_TIME_SRC_INTERNAL_OSCILLATOR = 0xA0

    } PTL_TIME_SRC;

    typedef enum
    {
        PTL_RESET_CAUSE_LOSS_LOCK        = 0x00,
        PTL_RESET_CAUSE_LOSS_CLOCK       = 0x01,
        PTL_RESET_CAUSE_EXTERNAL         = 0x02,
        PTL_RESET_CAUSE_POWER            = 0x03,
        PTL_RESET_CAUSE_WATCHDOG         = 0x04,
        PTL_RESET_CAUSE_REQUEST          = 0x05

    } PTL_RESET_CAUSE;

    typedef enum
    {
        PTL_TRANS_PROTO_IPV4             = 0x00,
        PTL_TRANS_PROTO_ETH              = 0x01

    } PTL_TRANS_PROTO;


    /*** IRIG Reference services ***/


    /*** Oscillator services ***/
    typedef enum
    {
        XO_MODE_DISC      = 0,               // Disciplining
        XO_MODE_TEST      = 1,               // Testing
        XO_MODE_RESET     = 2,               // Reset
        XO_MODE_RESET_CAL = 3                // Reset Calibration

    } XO_MODE;


    /*** Shared Memory services ***/
    typedef enum
    {
        MS_DI_NMEA_GGA = 0,                 // NMEA messages
        MS_DI_NMEA_GLL = 1,
        MS_DI_NMEA_GSA = 2,
        MS_DI_NMEA_GSV = 3,
        MS_DI_NMEA_RMC = 4,
        MS_DI_NMEA_VTG = 5,
        MS_DI_NMEA_ZDA = 6,

        MS_DI_NUM_ITEMS,                    // Total number of data items

        MS_DI_ALL      = -1                 // Refers to all data items

    } MS_DI_INDEX;

    /*** E1/T1 Output services ***/

    typedef enum
    {
        ETO_OUT_OPT_DIFF   = 0,             // Differential output option
        ETO_OUT_OPT_SINGLE = 1              // Single-ended output option

    } ETO_OUT_OPT;

    typedef enum
    {
        ETO_MODE_T1      = 0,               // T1 output mode
        ETO_MODE_E1      = 1,               // E1 output mode
        ETO_MODE_DISABLE = 2                // Disable output

    } ETO_MODE;

    typedef enum
    {
        ETO_T1_ENC_B8ZS = 0,                // B8ZS T1 encoding
        ETO_T1_ENC_AMI  = 1                 // AMI T1 encoding

    } ETO_T1_ENC;

    typedef enum
    {
        ETO_T1_FRM_D4SF        = 0,         // T1 super frame
        ETO_T1_FRM_ESF_CRC6    = 1,         // T1 extended super frame w/CRC6
        ETO_T1_FRM_ESF_NO_CRC6 = 2,         // T1 extended super frame w/o CRC6
        ETO_T1_FRM_AIS         = 3          // T1 alarm Indication Signal

    } ETO_T1_FRM;

    typedef enum
    {
        ETO_E1_FRM_CRC4    = 0,             // E1 framing w/CRC4
        ETO_E1_FRM_NO_CRC4 = 1,             // E1 framing w/o CRC4
        ETO_E1_FRM_AIS     = 2              // E1 alarm indication signal

    } ETO_E1_FRM;

    typedef enum
    {
        ETO_T1_SSM_PRS  = 0,    // Primary Reference Source
        ETO_T1_SSM_STU  = 1,    // Synchronized - Traceability Unknown
        ETO_T1_SSM_ST2  = 2,    // Stratum 2
        ETO_T1_SSM_TNC  = 3,    // Transit Node Clock
        ETO_T1_SSM_ST3E = 4,    // Stratum 3E
        ETO_T1_SSM_ST3  = 5,    // Stratum 3
        ETO_T1_SSM_SMC  = 6,    // SONET Minimum Clock
        ETO_T1_SSM_ST4  = 7,    // Stratum 4
        ETO_T1_SSM_RES  = 8,    // Reserved for Network Synchronization
        ETO_T1_SSM_DUS  = 9     // Do Not Use for Synchronization

    } ETO_T1_SSM;

    typedef enum
    {
        ETO_E1_SSM_UNK   = 0,   // Synchronized - Traceability Unknown
        ETO_E1_SSM_PRC   = 1,   // Primary Reference Clock (G.811)
        ETO_E1_SSM_SSU_A = 2,   // Synchronization Supply Unit (G.812 Type I)
        ETO_E1_SSM_SSU_B = 3,   // Synchronization Supply Unit (G.812 Type VI)
        ETO_E1_SSM_SEC   = 4,   // Synchronous Equipment Clock (G.813)
        ETO_E1_SSM_DNU   = 5    // Do Not Use

    } ETO_E1_SSM;

    typedef struct
    {
        ETO_OUT_OPT outOpt;                 // Output option board type
        ETO_MODE    mode;                   // Operational mode
        ETO_T1_ENC  t1Encode;               // T1 encoding type
        ETO_T1_FRM  t1Frame;                // T1 framing type
        ETO_E1_FRM  e1Frame;                // E1 framing type
        int         ssmEn;                  // SSM Enable
        ETO_T1_SSM  t1Ssm;                  // T1 SSM value
        ETO_E1_SSM  e1Ssm;                  // E1 SSM value

    } ETO_CFG;

    /*** UART configuration ***/
    typedef enum
    {
        UD_BR_1200   = 1200,
        UD_BR_2400   = 2400,
        UD_BR_4800   = 4800,
        UD_BR_9600   = 9600,
        UD_BR_19200  = 19200,
        UD_BR_38400  = 38400,
        UD_BR_57600  = 57600,
        UD_BR_76800  = 76800,
        UD_BR_115200 = 115200

    } UD_BR;

    typedef enum
    {
        UD_DATA_8 = 0,                  // 8 Data bits
        UD_DATA_7 = 1,                  // 7 Data bits
        UD_DATA_6 = 2,                  // 6 Data bits
        UD_DATA_5 = 3                   // 5 Data bits

    } UD_DATA;

    typedef enum
    {
        UD_STOP_1  = 0,                 // 1 Stop bit
        UD_STOP_15 = 1,                 // 1.5 Stop bits
        UD_STOP_2  = 2                  // 2 Stop bits

    } UD_STOP;

    typedef enum
    {
        UD_PAR_NONE = 0,                // Parity none
        UD_PAR_ODD  = 1,                // Odd parity
        UD_PAR_EVEN = 2                 // Even parity

    } UD_PAR;

    typedef struct
    {
        UD_BR      br;
        UD_DATA    numbits;
        UD_STOP    stopbits;
        UD_PAR     parity;

    } UD_CFG;

    /*** Display services ***/
    typedef enum
    {
        DP_MODE_NORMAL = 0,             // Normal operational mode
        DP_MODE_PHOTO  = 1,             // Photo mode
        DP_MODE_TEST   = 2,             // Display test mode

    } DP_MODE;


    /*** License Type ***/
    typedef enum
    {
        DCS_NONE       = 0,
        DCS_MULTIGNSS  = 1, // Multi GNSS Option
        DCS_SKYLIGHT   = 2, // SkyLight option
        DCS_TIMEKEEPER = 3, // TimeKeeper Option
        DCS_PLLLOCK    = 4, // PLL Lock Option
        DCS_TKPTPV1    = 5, // TimeKeeper PTP V1 Option
        DCS_AGPS       = 6, // AGPS Option
        DCS_PLL2       = 7, // PLL2 Lock Option
        DCS_PD1        = 8, // Peer Daemon Protocol 1 Option
        DCS_SEM        = 9, // ICD-GPS-153 Emulation Option
        DCS_ELORAN1    = 10, // E-Loran v1 Option
        DCS_BSH        = 11, // Talen-X BroadShield Option
        DCS_HQF        = 12, // HaveQuick Output Off on Startup
        DCS_TS1        = 13, // GPI TimeStamper
        DCS_BSL        = 14, // Talen-X BroadShield Pro Option
        DCS_BSD        = 15, // Talen-X BroadShield Debug Option
        DCS_EVENT_TIME_STAMPER = 16,
        DCS_PTP        = 17, // Base Unit PTP
        DCS_MAXIMUM = 17,
        DCS_NOTANOPT = 0xFF // Not an Option type used for the end of list
    } DCS_LICENSE_TYPE;

    /*** Constellation Type ***/
    typedef enum
    {
        GR_NONE_CONST           = 0x00000000, //
        GR_GPS_CONST            = 0x00000001, // GPS Constellation
        GR_GLONASS_CONST        = 0x00000002, // GLONASS Constellation
        GR_BEIDOU_CONST         = 0x00000004, // BeiDou Constellation
        GR_GALILEO_CONST        = 0x00000008, // Galileo Constellation
        GR_SBAS_CONST           = 0x00000010, // SBAS Constellation
        GR_QZSS_CONST           = 0x00000020, // QZSS Constellation

        // Add Constellation type here

    } GR_CONSTELLATION_TYPE;

    /*** Host 1PPS Time Set Mode ***/
    typedef enum
    {
        HR_TS_MODE_SET = 0,             // Set Time
        HR_TS_MODE_DISC = 1,            // Host 1PPS Input Generator Disciplining

    } HR_TS_MODE;

    /*** Hardware services ***/
#include "tsync_hw.h"

    /*=========================================================================
    TSYNC MATCH OBJECT
    ==========================================================================*/

    typedef struct TSYNC_MatchObj
    {
        unsigned char   matchType;      /* start/stop time */
        double          seconds;        /* seconds */
        unsigned char   minutes;        /* minutes */
        unsigned char   hours;          /* hours */
        unsigned short  days;           /* days */
    }
    TSYNC_MatchObj;


    /*==========================================================================
    TSYNC SATINFO OBJECT
    ==========================================================================*/

    typedef struct TSYNC_SatObj
    {
        unsigned char   satsTracked;    /* count of satellites tracked */
        unsigned char   satsView;       /* count satellites in view */
    }
    TSYNC_SatObj;

    /*==========================================================================
    TSYNC HEARTBEAT OBJECT
    ==========================================================================*/

    typedef struct TSYNC_HeartObj
    {
        unsigned char   signalType;     /* square or pulse */
        unsigned char   outputType;     /* jamming option */
        double          frequency;      /* heartbeat freq */
    }
    TSYNC_HeartObj;

    /*==========================================================================
    TSYNC TIME OBJECT
    ==========================================================================*/

    typedef struct TSYNC_TimeObj
    {
        unsigned int years;
        unsigned int doy;
        unsigned int hours;
        unsigned int minutes;
        unsigned int seconds;
        unsigned int ns;
    }
    TSYNC_TimeObj;

    /*==========================================================================
    TSYNC TIME BCD OBJECT
    ==========================================================================*/

    typedef struct TSYNC_TimeBCDObj
    {
        unsigned int years;
        unsigned int doy;
        unsigned int hours;
        unsigned int minutes;
        unsigned int seconds;
        unsigned int ms;
        unsigned int us;
    }
    TSYNC_TimeBCDObj;

    /*==========================================================================
    TSYNC TIME SECONDS OBJECT
    ==========================================================================*/

    typedef struct TSYNC_TimeSecondsObj
    {
        unsigned int seconds;
        unsigned int ns;
    }
    TSYNC_TimeSecondsObj;

    /*==========================================================================
    TSYNC HW TIME OBJECT
    ==========================================================================*/

    typedef struct TSYNC_HWTimeObj
    {
        TSYNC_TimeObj time;
        unsigned int  bSync;
    }
    TSYNC_HWTimeObj;

    /*==========================================================================
    TSYNC HW TIME SECONDS OBJECT
    ==========================================================================*/

    typedef struct TSYNC_HWTimeSecondsObj
    {
        TSYNC_TimeSecondsObj time;
        unsigned int         bSync;
    }
    TSYNC_HWTimeSecondsObj;

    /*==========================================================================
    TSYNC WAIT OBJECT
    ==========================================================================*/

    typedef struct TSYNC_WaitObj
    {
        unsigned int    ticks;          /* num of clock ticks to wait */
        double          seconds;
        unsigned char   minutes;
        unsigned char   hours;
        unsigned short  days;
    }
    TSYNC_WaitObj;

    /*==========================================================================
    TSYNC MEM OBJECT FOR PEEK/POKE
    ==========================================================================*/

    typedef struct TSYNC_MemObj
    {
        unsigned short  offset;         /* offset from base register */
        unsigned int   value;          /* value to use at register location */
    }
    TSYNC_MemObj;

    /*==========================================================================
    TSYNC GET STATUS OBJECT
    ==========================================================================*/

    typedef struct TSYNC_StateObj
    {
        unsigned int image;
        unsigned int step;
        unsigned int complete;
    }
    TSYNC_StateObj;

    /*==========================================================================
    TSYNC IMAGE ID OBJECT
    ==========================================================================*/

    typedef struct
    {
        UL_IMG type;       // Image type
        unsigned int slot; // Image slot
    } TSYNC_ULImageIdObj;

    /*==========================================================================
    TSYNC IMAGE HEADER OBJECT
    ==========================================================================*/

    typedef struct
    {
        unsigned int mark; // Image marker
        UL_IMG type; // Image type
        unsigned int len; // Image length
    } TSYNC_ULImageHeaderObj;

    /*==========================================================================
    TSYNC DATA UPDATE OBJECT
    ==========================================================================*/

    typedef struct
    {
        UL_IMG type; // Image type
        unsigned char data[TSYNC_DATA_BLOCK_SIZE]; // data block
    } TSYNC_UpdateDataObj;

    /*==========================================================================
    TSYNC END UPDATE OBJECT
    ==========================================================================*/

    typedef struct
    {
        UL_IMG type; // Image type
        unsigned char ver[4]; // version
        unsigned int crc; // crc
    } TSYNC_UpdateEndObj;

    /*==========================================================================
    TSYNC Capability OBJECT
    ==========================================================================*/

    typedef struct TSYNC_CapabilityObj
    {
        CI_CAI cai;
        CI_IID iid;
        CI_ACCESS access;
    }
    TSYNC_CapabilityObj;

    /*==========================================================================
    TSYNC Capability Page OBJECT
    ==========================================================================*/

    typedef struct TSYNC_CapabilityPageObj
    {
        unsigned int pageNum;
        int more;
        TSYNC_CapabilityObj caps[TSYNC_CAPABILITIES_PER_PAGE];
    }
    TSYNC_CapabilityPageObj;

    /*==========================================================================
    TSYNC TIME SCALE OBJECT
    ==========================================================================*/

    typedef struct TSYNC_TimeScaleObj
    {
        ML_TIME_SCALE scale;
    }
    TSYNC_TimeScaleObj;

    /*==========================================================================
    TSYNC TIME SCALE OFFSET OBJECT
    ==========================================================================*/

    typedef struct TSYNC_TimeScaleOffsetObj
    {
        ML_TIME_SCALE scale;
        int offset;
    }
    TSYNC_TimeScaleOffsetObj;

    /*==========================================================================
    TSYNC TIME SUBSECOND ADJUSTMENT OBJECT
    ==========================================================================*/

    typedef struct TSYNC_TimeSubsecAdjObj
    {
        int adjust;
    }
    TSYNC_TimeSubsecAdjObj;

    /*==========================================================================
    TSYNC TIME SUBSECOND ADJUSTMENT OBJECT
    ==========================================================================*/

    typedef struct TSYNC_TimeDiscontObj
    {
        TSYNC_TimeObj   newTime;
        TSYNC_TimeObj   effectiveTime;
        int             bActive;
    }
    TSYNC_TimeDiscontObj;

    /*==========================================================================
    TSYNC TIME SUBSECOND ADJUSTMENT OBJECT
    ==========================================================================*/

    typedef struct TSYNC_TimeLeapSecondObj
    {
        int             offset;
        TSYNC_TimeObj   utcDate;
    }
    TSYNC_TimeLeapSecondObj;

    /*==========================================================================
    TSYNC TIME ZONE OFFSET OBJECT
    ==========================================================================*/

    typedef struct TSYNC_TimeZoneOffsetObj
    {
        int             tzOffset;
    }
    TSYNC_TimeZoneOffsetObj;

    /*==========================================================================
    TSYNC TIME DST POINT OBJECT
    ==========================================================================*/

    typedef struct TSYNC_TimeDSTPointObj
    {
        ML_MONTH            month;
        ML_WOM              wom;
        ML_DOW              dow;
        int                 hour;
    }
    TSYNC_TimeDSTPointObj;

    /*==========================================================================
    TSYNC TIME DST RULE OBJECT
    ==========================================================================*/

    typedef struct TSYNC_TimeDSTRuleObj
    {
        ML_DST_REF                ref;
        TSYNC_TimeDSTPointObj     in;
        TSYNC_TimeDSTPointObj     out;
        uint32_t                  offset;
    }
    TSYNC_TimeDSTRuleObj;

    /*==========================================================================
    TSYNC TIME YEAR OBJECT
    ==========================================================================*/

    typedef struct TSYNC_TimeYearObj
    {
        int             year;
    }
    TSYNC_TimeYearObj;

    /*==========================================================================
    TSYNC TIME DST STATE OBJECT
    ==========================================================================*/

    typedef struct TSYNC_TimeDSTStateObj
    {
        int state;
    }
    TSYNC_TimeDSTStateObj;

    /*==========================================================================
    TSYNC UL IMAGE OBJECT
    ==========================================================================*/

    typedef struct TSYNC_ULImageObj
    {
        UL_IMG         image;
    }
    TSYNC_ULImageObj;

    /*==========================================================================
    TSYNC FS CRC OBJECT
    ==========================================================================*/

    typedef struct TSYNC_FSCRCObj
    {
        unsigned int         crc;
    }
    TSYNC_FSCRCObj;

    /*==========================================================================
    TSYNC FS VERSION OBJECT
    ==========================================================================*/

    typedef struct
    {
        char version[4];
    } TSYNC_FSVersionObj;

    /*==========================================================================
    TSYNC ERROR LOG OBJECT
    ==========================================================================*/

    typedef struct
    {
        char message[120];
    } TSYNC_ErrorLogObj;

    /*==========================================================================
    TSYNC ALARM OBJECT
    ==========================================================================*/

    typedef struct
    {
        LS_ALARM index;
    } TSYNC_AlarmObj;

    /*==========================================================================
    TSYNC FLAG OBJECT
    ==========================================================================*/

    typedef struct
    {
        uint32_t flag;
    } TSYNC_FlagObj;

    /*==========================================================================
    TSYNC LS VERSION OBJECT
    ==========================================================================*/

    typedef struct
    {
#if defined(NIOS)         // Need to transmit KTS's revision hash code
        char version[22]; // along with firmware version
#else
        char version[7];
#endif
    } TSYNC_FirmwareVersionObj;

    /*==========================================================================
    TSYNC LS SERIAL NO OBJECT
    ==========================================================================*/

    typedef struct
    {
        char serno[33];
    } TSYNC_SerialNoObj;

    /*==========================================================================
    TSYNC METER HANDLE OBJECT
    ==========================================================================*/

    typedef struct
    {
        TSYNC_METER_HANDLE hnd;
    } TSYNC_MeterHandle;

    /*==========================================================================
    TSYNC METER WIN SIZE OBJECT
    ==========================================================================*/

    typedef struct
    {
        TSYNC_METER_HANDLE  hnd;
        unsigned int        size;
    } TSYNC_MeterWinSizeObj;

    /*==========================================================================
    TSYNC METER DATA OBJECT
    ==========================================================================*/

    typedef struct
    {
        TSYNC_METER_HANDLE  hnd;
        XS_STATE state; // Meter state
        unsigned int size; // Window size
        unsigned int elapsed; // Elapsed duration through the
                                        // window
        float frAccum; // Accumulated frequency error of
                                        // current window
        float frPrev; // Total frequency error of
                                        // previous window
        float phStart; // Starting phase error of current
                                        // window
        float phAccum; // Accumulated phase error of
                                        // current window
        float phPrev; // Total phase error of previous
                                        // window
    } TSYNC_MeterDataObj;

    /*==========================================================================
    TSYNC METER COMMAND OBJECT
    ==========================================================================*/

    typedef struct
    {
        TSYNC_METER_HANDLE  hnd;
        XS_CMD              command;
    } TSYNC_MeterCommandObj;

    /*==========================================================================
    TSYNC SUPERVISOR REFERENCE OBJECT
    ==========================================================================*/

    typedef struct
    {
        char time[5];
        char pps[5];
    } TSYNC_ReferenceObj;

    /*==========================================================================
    TSYNC REFERENCE ID OBJECT
    ==========================================================================*/

    typedef struct
    {
        char refid[5];
    } TSYNC_RefIdObj;

    /*==========================================================================
    TSYNC SUPERVISOR RESET OBJECT
    ==========================================================================*/

    typedef struct
    {
        SS_RESET type;
    } TSYNC_ResetObj;

    /*==========================================================================
    TSYNC REFERENCE MONITOR TABLE TYPE OBJECT
    ==========================================================================*/

    typedef struct
    {
        RS_TABLE_TYPE type;
    } TSYNC_TableTypeObj;

    /*==========================================================================
    TSYNC REFERENCE MONITOR TABLE ENTRY OBJECT
    ==========================================================================*/

    typedef struct
    {
        int enab;
        unsigned int prio;
        char time[5];
        char pps[5];
    } TSYNC_TableEntryObj;

    /*==========================================================================
    TSYNC REFERENCE MONITOR TABLE OBJECT
    ==========================================================================*/

    typedef struct
    {
        TSYNC_TableEntryObj rows[TSYNC_TABLE_ENTRY_NUM];
    } TSYNC_ReferenceTableObj;

    /*==========================================================================
    TSYNC REFERENCE MONITOR TABLE ENTRY STATE OBJECT
    ==========================================================================*/

    typedef struct
    {
        char source[5];
        int timeValid;
        int ppsValid;
    } TSYNC_TableEntryStateObj;

    /*==========================================================================
    TSYNC REFERENCE MONITOR STATE TABLE OBJECT
    ==========================================================================*/

    typedef struct
    {
        TSYNC_TableEntryStateObj rows[TSYNC_STATE_TABLE_ENTRY_NUM];
    } TSYNC_ReferenceStateTableObj;

    /*==========================================================================
        TSYNC REFERENCE MONITOR PHASE ENTRY OBJECT
        ==========================================================================*/

        typedef struct
        {
            unsigned int muxPos;              // Mux Position index
            char source[5];                   // Reference Identifier 4-char string
            unsigned int phaseValid;          // Phase Valid Boolean
            int phase;                        // 20 nsec accurate phase
            double phaseFiltered;             // Filtered Phase value
            double lAvg;                      // Long Phase Average
            double lStdDev;                   // Long Phase Standard Deviation
            double wPhaseErr;                 // Window (60 sec) Phase Error Standard Deviation
            double wFreqErr;                  // Window (60 sec) Frequency Error Standard Deviation
            double threshold;                 // Phase Threshold for Validity
        } TSYNC_ReferencePhaseDataObj;

    /*==========================================================================
        TSYNC REFERENCE MONITOR PHASE Threshold OBJECT
        ==========================================================================*/

        typedef struct
        {
            unsigned int mode;                // Phase Threshold Mode value
            unsigned int n;                   // Std Dev Multiplier
            double minThreshold;              // Min Phase Threshold for Validity
            double maxThreshold;              // Max Phase Threshold for Validity
        } TSYNC_ReferencePhaseThresholdObj;

    /*==========================================================================
    TSYNC REFERENCE MONITOR PHASE TABLE OBJECT
    ==========================================================================*/

    typedef struct
    {
        TSYNC_ReferencePhaseDataObj rows[TSYNC_REF_PHASE_TABLE_MAX];
    } TSYNC_ReferencePhaseTableObj;

    /*==========================================================================
    TSYNC INITIALIZER MODULE RESULT OBJECT
    ==========================================================================*/

    typedef struct
    {
        char module[33];
        TSYNC_ERROR result;
    } TSYNC_InitModuleResult;

    /*==========================================================================
    TSYNC INITIALIZER STATUS OBJECT
    ==========================================================================*/

    typedef struct
    {
        unsigned int pageNum;
        int more;
        TSYNC_InitModuleResult results[TSYNC_INIT_RESULT_NUM];
    } TSYNC_InitStatusResult;

    /*==========================================================================
    TSYNC ASCII EVENT MESSAGE STATUS OBJECT
    ==========================================================================*/

    typedef struct
    {
        char msg[40];

    } TSYNC_AsciiEvtMsg;

    /*==========================================================================
    TSYNC SUPERVISOR TFOM OBJECT
    ==========================================================================*/

    typedef struct
    {
        TFOM tfom;
    } TSYNC_TFOMObj;

    /*==========================================================================
    TSYNC GPS LLA OBJECT
    ==========================================================================*/

    typedef struct
    {
        double lat;
        double lon;
        double alt;
    } TSYNC_LLAObj;

    /*==========================================================================
    TSYNC GPS FIX DATA OBJECT
    ==========================================================================*/

    typedef struct
    {
        int nSats;
        float pdop;
        float hdop;
        float vdop;
        float tdop;
        int fom;
        int tfom;
        int herr;
        int verr;
    } TSYNC_FixDataObj;

    /*==========================================================================
    TSYNC GPS SAT INFO OBJECT
    ==========================================================================*/

    typedef struct
    {
        unsigned int chnum;
        unsigned int svid;
        unsigned int str;
        int bTraim;
        int bInfix;
        unsigned int flags;
    } TSYNC_SatInfoObj;

    /*==========================================================================
    TSYNC GPS SAT DATA OBJECT
    ==========================================================================*/

    typedef struct
    {
        TSYNC_SatInfoObj info[TSYNC_SAT_INFO_NUM];
    } TSYNC_SatDataObj;

    /*==========================================================================
    TSYNC GPS Qualification Log OBJECT
    ==========================================================================*/

    typedef struct
    {
        unsigned int val[TSYNC_QUAL_LOG_NUM];
    } TSYNC_QualLogObj;

    /*==========================================================================
    TSYNC MANUFACTURER MODEL OBJECT
    ==========================================================================*/

    typedef struct
    {
        char mfr[17];
        char mdl[17];
    } TSYNC_ManModObj;

    /*==========================================================================
    TSYNC GPS RECEIVER INFO OBJECT
    ==========================================================================*/

    typedef struct
    {
        unsigned int len;
        char info[257];
    } TSYNC_ReceiverInfoObj;

    /*==========================================================================
    TSYNC GPS CUSTOM MESSAGE OBJECT
    ==========================================================================*/

    typedef struct
    {
        unsigned int len;
        char msg[1000];
    } TSYNC_CustomMessageObj;

    /*==========================================================================
    TSYNC GPS RECEIVER PARM OBJECT
    ==========================================================================*/

    typedef struct
    {
        unsigned int len;
        GL_PARM      parm;
        unsigned int cfg[TSYNC_PARM_NUM];
    } TSYNC_ReceiverParmObj;

    /*==========================================================================
    TSYNC GPS RECEIVER A-GPS ALMANAC OBJECT
    ==========================================================================*/

    typedef struct
    {
        GL_ALMANAC alm;
    } TSYNC_AlmObj;


    /*==========================================================================
    TSYNC GPS RECEIVER A-GPS EPHEMERIS OBJECT
    ==========================================================================*/

    typedef struct
    {
        GL_EPHEMERIS ephm;
    } TSYNC_EphmObj;


    /*==========================================================================
    TSYNC GPS RECEIVER A-GPS SERVER STATE OBJECT
    ==========================================================================*/

    typedef struct
    {
        int state;
    } TSYNC_AgpsServerStateObj;

    /*==========================================================================
    TSYNC GPS RECEIVER A-GPS IONOSPHERE OBJECT
    ==========================================================================*/

    typedef struct
    {
        GL_IONOSPHERE iono;
    } TSYNC_IonoObj;

    /*==========================================================================
    TSYNC GPS RECEIVER A-GPS UTC OBJECT
    ==========================================================================*/

    typedef struct
    {
        GL_UTC utc;
    } TSYNC_UtcObj;

    /*==========================================================================
    PTP MODULE INFO OBJECT
    ==========================================================================*/

    typedef struct
    {
        unsigned int ptpVerisonNumber;
        unsigned int softwareVersion;
        char         hardwareVersion;
        char         filler[3];
        char         softDate[TSYNC_PTP_DATE_STR_LEN];
        char         softTime[9];
    } TSYNC_PTPModuleInfoObj;

    /*==========================================================================
    PTP ETHERNET INTERFACE INFO OBJECT
    ==========================================================================*/

    typedef struct
    {
        int dhcpEnabled;
        unsigned char staticIpAddr[4];
        unsigned char netMask[4];
        unsigned char defaultGateway[4];
    } TSYNC_PTPEthernetItfObj;

    /*==========================================================================
    PTP CLOCK SETTINGS OBJECT
    ==========================================================================*/

    typedef struct
    {
        int ptpClockRunning;
        int usingExternalClock;
    } TSYNC_PTPClkSettingsObj;

    /*==========================================================================
    PTP UNIT SETTINGS OBJECT
    ==========================================================================*/

    typedef struct
    {
        unsigned char clockIdentity[8];
        int oneStepMode;
        int slaveOnly;
        unsigned int domainNumber;
        unsigned int priority1;
        unsigned int priority2;
        int forcedHoldover;
    } TSYNC_PTPUnitSettingsObj;

    /*==========================================================================
    PTP PORT STATE OBJECT
    ==========================================================================*/

    typedef struct
    {
        unsigned int portNumber;
        int portEnabled;
        PTL_PTP_STATE portState;
        int linkConnected;
        int slaveLogAnn;
        int slaveLogSync;
        int slaveLogDelayReq;
        int slaveOneStepMode;
    } TSYNC_PTPPortStateObj;

    /*==========================================================================
    PTP PORT SETTINGS OBJECT
    ==========================================================================*/

    typedef struct
    {
        unsigned int portNumber;
        unsigned int annRcptTimeout;
        int logAnnInterval;
        int logSyncInterval;
        int logDelayReqInterval;
        int logPeerDelayReqInterval;
        PTL_DELAY_MECH  delayMechanism;
    unsigned int syncTimeout;
    unsigned int delayRespTimeout;
    } TSYNC_PTPPortSettingsObj;

    /*==========================================================================
    PTP UNICAST SETTINGS MASTER ADD OBJECT YS
    ==========================================================================*/
typedef struct
    {
         unsigned char  clockIdentity[8];
     unsigned int   portNumber;
     unsigned char  staticIpAddr[4];
     char           logQuerySalveInterval;
     char           filler1;
     unsigned short duationSlaveContracts;
     char           logAnnSlaveInterval;
     char           logSyncMasterInterval;
     char           logDelayReqSlaveInterval;
     char           filler2;
    } TSYNC_PTPUnctMasterAddObj;

    /*==========================================================================
    PTP UNICAST SLAVE PROPERTIES OBJECT YS
    ==========================================================================*/
typedef struct
    {
         int            negoEnabled;
     char           contractAnnState[16];
     unsigned short duationAnnContracts;
     unsigned short delayAnnContracts;
     char           logAnnMsgInterval;
     char           filler1[3];
     char           contractSyncState[16];
     unsigned short duationSyncContracts;
     unsigned short delaySyncContracts;
     char           logSyncMsgInterval;
     char           filler2[3];
     char           contractDelayRespState[16];
     unsigned short duationDelayRespContracts;
     unsigned short delayDelayRespContracts;
     char           logDelayRespMsgInterval;
     char           filler3[3];
    } TSYNC_PTPUnctSlavePropObj;

    /*==========================================================================
    PTP UNICAST MASTER PROPERTIES OBJECT YS
    ==========================================================================*/
typedef struct
    {
         int           negoEnabled;
     unsigned char nbSalveConnected;
     char          filler[3];

    } TSYNC_PTPUnctMasterPropObj;

    /*==========================================================================
    PTP CLOCK QUALITY OBJECT
    ==========================================================================*/

    typedef struct
    {
        unsigned int clockClass;
        PTL_CLK_ACC clockAccuracy;
        unsigned int offsetScaledLogVariance;
    } TSYNC_PTPClkQualityObj;

    /*==========================================================================
    PTP TIME PROPERTIES OBJECT
    ==========================================================================*/

    typedef struct
    {
        int utcOffset;
        int utcOffsetValid;
        int forwardLeap;
        int backwardLeap;
        int timeTraceable;
        int freqTraceable;
        int ptpTimescale;
        PTL_TIME_SRC timeSource;
    } TSYNC_PTPTimePropObj;

    /*==========================================================================
    PTP PARENT PROPERTIES OBJECT
    ==========================================================================*/

    typedef struct
    {
        unsigned char clockIdentity[8];
        unsigned int portNumber;
        int statsCalculated;
        unsigned int observedOSLV;
        unsigned int observedCPCR;
    } TSYNC_PTPParentPropObj;

    /*==========================================================================
    PTP GRANDMASTER PROPERTIES OBJECT
    ==========================================================================*/

    typedef struct
    {
        unsigned char clockIdentity[8];
        TSYNC_PTPClkQualityObj clockQuality;
        unsigned int priority1;
        unsigned int priority2;
    } TSYNC_PTPGrandmasterPropObj;

    /*==========================================================================
    PTP TOD ENABLE OBJECT
    ==========================================================================*/

    typedef struct
    {
        int todEnabled;
        unsigned int timeScale;
    } TSYNC_PTPTODSettingsObj;

    /*==========================================================================
    PTP MAC ADDR OBJECT
    ==========================================================================*/

    typedef struct
    {
        unsigned char macAddress[8];
    } TSYNC_PTPMacAddrObj;

    /*==========================================================================
    PTP MAC ADDR w/ PASSWORD OBJECT
    ==========================================================================*/

    typedef struct
    {
        unsigned char macAddress[8];
        unsigned char pw[12];
    } TSYNC_PTPMacAddrPwObj;

   /*==========================================================================
    PTP USER DESCRIPTION OBJECT
    ==========================================================================*/

    typedef struct
    {
        unsigned char deviceName[16];
        unsigned char deviceLocation[16];
    } TSYNC_PTPUserDescObj;

   /*==========================================================================
    PTP DEBUG OUTPUT OBJECT
    ==========================================================================*/

    typedef struct
    {
        int debugOutput;
        int debugFilterOutput;
    } TSYNC_PTPDebugOutputObj;

   /*==========================================================================
    PTP ETHERNET STATUS OBJECT
    ==========================================================================*/

    typedef struct
    {
        unsigned char ipAddress[4];
        unsigned char netMask[4];
        unsigned char gateway[4];
    } TSYNC_PTPEthernetStatusObj;

   /*==========================================================================
    PTP SYNC-E STATUS OBJECT
    ==========================================================================*/

    typedef struct
    {
        int enableSyncE;
        int xmitSyncEClock;
        int esmcEnable;
        unsigned char ssmCode;
        char filler[3];
    } TSYNC_PTPSyncEStatusObj;

   /*==========================================================================
    PTP ITF OBJECT
    ==========================================================================*/

    typedef struct
    {
        PTL_TRANS_PROTO transProto;
        int             masterUnicast;
        int             slaveUnicast;
        unsigned char   ttl;
        char            filler[3];
        int             mgtPortEna;
    } TSYNC_PTPItfObj;
    /*==========================================================================
    PTP VLAN OBJECT       YS
    ==========================================================================*/

    typedef struct
    {
        int vLanIntEnable;
        unsigned short vLanID;
        unsigned char priorityCodePoint;
        char          filler;
    } TSYNC_PTPVLANObj;

   /*==========================================================================
    PTP FTP ITF OBJECT
    ==========================================================================*/

    typedef struct
    {
        int ftpEnable;
    } TSYNC_PTPFtpItfObj;

   /*==========================================================================
    PTP STATISTICS OBJECT
    ==========================================================================*/

    typedef struct
    {
        int parentStats;
        int clockStats;
    } TSYNC_PTPStatisticsObj;

   /*==========================================================================
    PTP CLOCK PROPERTIES OBJECT
    ==========================================================================*/

    typedef struct
    {
        long long offFromMaster;
        long long meanPathDelay;
        unsigned short stepsRemoved;
    } TSYNC_PTPClockPropertiesObj;

   /*==========================================================================
    TSYNC IRIG MESSAGE OBJECT
    ==========================================================================*/

    typedef struct
    {
        unsigned short subframes[TSYNC_IR_SUBFRAME_NUM];
    } TSYNC_IRIGMessageObj;

    /*==========================================================================
    TSYNC IRIG CONTROL FIELD OBJECT
    ==========================================================================*/

    typedef struct
    {
        unsigned short cfData[TSYNC_IR_CFDATA_NUM];
    } TSYNC_IRIGCfDataObj;

    /*==========================================================================
    TSYNC VARIABLE-FREQUENCY OUTPUT CONFIGURATION OBJECT
    ==========================================================================*/

    typedef struct
    {
        float min;
        float max;
        float step;
    } TSYNC_VPCfgObj;

    /*==========================================================================
    TSYNC TIME LOCAL CLOCK OBJECT
    ==========================================================================*/

    typedef struct
    {
        TSYNC_TimeDSTRuleObj      rule;
        int                       tz;
    }
    TSYNC_LocalClockObj;

    /*==========================================================================
    TSYNC ASCII OUTPUT SUBSECOND OBJECT
    ==========================================================================*/

    typedef struct
    {
        int             bEnabled;
        unsigned int    pos;
        unsigned int    num;
    }
    TSYNC_SubSecondObj;

    /*==========================================================================
    TSYNC OSCILLATOR DISCIPLINING OBJECT
    ==========================================================================*/

    typedef struct
    {
        unsigned char cmd[TSYNC_OSC_DISC_CMD_SIZE];
        unsigned char data[TSYNC_OSC_DISC_DATA_SIZE];
    }
    TSYNC_OscDiscObj;

    /*==========================================================================
    TSYNC OSCILLATOR CUSTOM MESSAGE OBJECT
    ==========================================================================*/

    typedef struct
    {
        unsigned int len;
        char msg[65];
    }
    TSYNC_OscCustomMessageObj;

    /*==========================================================================
    TSYNC SHARED MEMORY OBJECT
    ==========================================================================*/

    typedef struct
    {
        unsigned int    seqNum;
        char            data[256];
    }
    TSYNC_SharedMemoryObj;

    /*==========================================================================
    TSYNC GENERAL PURPOSE SQUARE OBJECT
    ==========================================================================*/

    typedef struct
    {
        int             off;
        unsigned int    per;
        unsigned int    pw;
        EDGE            ae;
    }
    TSYNC_GPOSquareObj;

    /*==========================================================================
    TSYNC TIME DATA OBJECT
    ==========================================================================*/

    typedef struct
    {
        TSYNC_HWTimeObj   data[TSYNC_TIMESTAMP_DATA_NUM];
    }
    TSYNC_HWTimeDataObj;

    /*==========================================================================
    TSYNC OPTION CARD CIS HEADER OBJECT
    ==========================================================================*/

    typedef struct TSYNC_CardInfoStructHdrObj
    {
        unsigned int pldId;
        unsigned int pldVer;
        unsigned int rsv1;
        unsigned int rsv2;
        unsigned int num;
    }
    TSYNC_CardInfoStructHdrObj;

    /*==========================================================================
    TSYNC OPTION CARD HEADER OBJECT
    ==========================================================================*/

    typedef struct TSYNC_OptCardHdrObj
    {
        unsigned int               id;
        unsigned int               ver;
        TSYNC_CardInfoStructHdrObj cish;
    }
    TSYNC_OptCardHdrObj;

    /*==========================================================================
    TSYNC OPTION CARD SLOT/INDEX OBJECT
    ==========================================================================*/

    typedef struct TSYNC_OptCardSlotIdxObj
    {
        int          slot;
        unsigned int idx;
    }
    TSYNC_OptCardSlotIdxObj;

    /*==========================================================================
    TSYNC OPTION CARD SLOT/FEATURE/LOCAL INSTANCE OBJECT
    ==========================================================================*/

    typedef struct TSYNC_OptCardSlotFeatInstObj
    {
        int          slot;
        unsigned int featId;
        unsigned int inst;
    }
    TSYNC_OptCardSlotFeatInstObj;

    /*==========================================================================
    TSYNC OPTION CARD HEADER OBJECT
    ==========================================================================*/

    typedef struct TSYNC_OptCardFeatInstObj
    {
        unsigned int featId;
        unsigned int inst;
        unsigned int version;
    }
    TSYNC_OptCardFeatInstObj;

    /*==========================================================================
    GPL: Clock Identity
    ==========================================================================*/

    typedef struct TSYNC_GprClockId
    {
        unsigned char cid[8];
    }
    TSYNC_GplClockId;

    /*==========================================================================
    GPL: Priority
    ==========================================================================*/

    typedef struct TSYNC_GplPriority
    {
        unsigned char priority1;
        unsigned char priority2;
    }
    TSYNC_GplPriority;

    /*==========================================================================
    GPL: Clock Quality
    ==========================================================================*/

    typedef struct TSYNC_GplClockQual
    {
        unsigned int   clockClass;
        unsigned int   clockAcc;
        unsigned int   oSLV;
    }
    TSYNC_GplClockQual;

    /*==========================================================================
    GPL: Statistics
    ==========================================================================*/

    typedef struct TSYNC_GplStatistics
    {
        int             offFromMaster;
        int             meanPathDelay;
        unsigned short  stepsRemoved;
    }
    TSYNC_GplStatistics;

    /*==========================================================================
    GPL: Parent Data
    ==========================================================================*/

    typedef struct TSYNC_GplParentData
    {
        TSYNC_GplClockId    parentCid;
        unsigned int        parentPortId;
        unsigned int        parentStatsCalc;
        unsigned int        parentObsOSLV;
        unsigned int        parentObsCPCR;
        TSYNC_GplClockQual  gmQual;
        TSYNC_GplClockId    gmCid;
        unsigned char       gmPortid;
        TSYNC_GplPriority   gmpri;
    }
    TSYNC_GplParentData;

    /*==========================================================================
    GPL: Time Properties
    ==========================================================================*/

    typedef struct TSYNC_GplTimeProp
    {
        int             utcOffset;
        unsigned int    utcOffsetValid;
        unsigned int    forwardLeap;
        unsigned int    backwardLeap;
        unsigned int    timeTraceable;
        unsigned int    freqTraceable;
        unsigned int    ptpTimescale;
        unsigned int    timeSource;
    }
    TSYNC_GplTimeProp;

    /*==========================================================================
    GPL: User Description
    ==========================================================================*/

    typedef struct TSYNC_GplUserDesc
    {
        unsigned char deviceName[16];
        unsigned char deviceLocation[16];
    }
    TSYNC_GplUserDesc;

    /*==========================================================================
    GPL: Unicast Master Add Table
    ==========================================================================*/

    typedef struct TSYNC_GplUnctMasterAdd
    {
        unsigned char  masterCid[8];
        unsigned int   masterPid;
        unsigned char  masterIPV4[4];
        unsigned char  logQuerySlaveInterval;
        unsigned short durationSlaveContracts;
        unsigned char  logAnnSlaveInterval;
        unsigned char  logSyncMasterInterval;
        unsigned char  logDelayReqSlaveInterval;
    }
    TSYNC_GplUnctMasterAdd;

    /*==========================================================================
    GPL: Port Identity
    ==========================================================================*/

    typedef struct TSYNC_GplPortId
    {
        unsigned char  cid[8];
        unsigned int   pid;
    }
    TSYNC_GplPortId;

    /*==========================================================================
    GPL: Unicast Slave Properties
    ==========================================================================*/

    typedef struct TSYNC_GplUnctSlaveProp
    {
        unsigned int   negoEnabled;
        unsigned char  contractAnnState[16];
        unsigned short durationAnnContracts;
        unsigned short delayAnnContracts;
        unsigned int   logAnnMsgInterval;
        unsigned char  contractSyncState[16];
        unsigned short durationSyncContracts;
        unsigned short delaySyncContracts;
        unsigned int   logSyncMsgInterval;
        unsigned char  contractDelayRespState[16];
        unsigned short durationDelayRespContracts;
        unsigned short delayDelayRespContracts;
        unsigned int   logDelayRespMsgInterval;
    }
    TSYNC_GplUnctSlaveProp;

    /*==========================================================================
    GPL: Unicast Master Properties
    ==========================================================================*/

    typedef struct TSYNC_GplUnctMasterProp
    {
        unsigned int   negoEnabled;
        unsigned int   nbSlaveConnected;
    }
    TSYNC_GplUnctMasterProp;

    /*==========================================================================
    GPL: Unicast Master Configuration
    ==========================================================================*/

    typedef struct TSYNC_GplUnctMasterCfg
    {
        unsigned short minSyncInt;
        unsigned short maxSyncDur;
        unsigned short minAnnInt;
        unsigned short maxAnnDur;
        unsigned short minDRqInt;
        unsigned short maxDRqDur;
        unsigned short maxSlaves;
    }
    TSYNC_GplUnctMasterCfg;

    /*==========================================================================
    GPL: Message Rates
    ==========================================================================*/

    typedef struct TSYNC_GplMsgRates
    {
        unsigned int logAnnInterval;
        unsigned int logSyncInterval;
        unsigned int logDelayReqInterval;
    }
    TSYNC_GplMsgRates;

    /*==========================================================================
    GPL: Message Timeouts
    ==========================================================================*/

    typedef struct TSYNC_GplMsgTo
    {
        unsigned int annRcptTimeout;
        unsigned int syncTimeout;
        unsigned int delayRespTimeout;
    }
    TSYNC_GplMsgTo;

    /*==========================================================================
    GPL: IPV4 Configuration
    ==========================================================================*/

    typedef struct TSYNC_GplIpV4
    {
        unsigned char ipV4Addr[4];
        unsigned char netmask[4];
        unsigned char gateway[4];
    }
    TSYNC_GplIpV4;

    /*==========================================================================
    GPL: MAC Address
    ==========================================================================*/

    typedef struct TSYNC_GplMacAddr
    {
        unsigned char  macAddr[6];
    }
    TSYNC_GplMacAddr;

    /*==========================================================================
    GPL: Sync Ethernet
    ==========================================================================*/

    typedef struct TSYNC_GplSyncEth
    {
        unsigned int  enableSyncE;
        unsigned int  esmcEnable;
        unsigned int  esmcSigCtl;
        unsigned int  ssmCode;
    }
    TSYNC_GplSyncEth;

    /*==========================================================================
    GPL: VLAN
    ==========================================================================*/

    typedef struct TSYNC_GplVlan
    {
        unsigned int   vLanIntEnable;
        unsigned int   vLanID;
        unsigned int   priorityCodePoint;
    }
    TSYNC_GplVlan;

    /*==========================================================================
    GPL: Module Info
    ==========================================================================*/

    typedef struct
    {
        unsigned int ptpVerisonNumber;
        unsigned int softwareVersion;
        unsigned int hardwareVersion;
        char         softDate[12];
        char         softTime[9];
    }
    TSYNC_GplModuleInfo;

    /*==========================================================================
    GPL: Control
    ==========================================================================*/

    typedef struct TSYNC_GplControl
    {
        unsigned int   networkEn;
        unsigned int   ptpEn;
    }
    TSYNC_GplControl;

    /*==========================================================================
    GPL: Slave Stats
    ==========================================================================*/

    typedef struct TSYNC_GplSlaveStats
    {
        unsigned int   slaveNum;
        unsigned int   ptpEn;
        unsigned char  cid[8];
        unsigned int   pid;
        unsigned char  ipV4Addr[4];
        unsigned char  macAddr[6];
        unsigned short syncPeriod;
        unsigned short annPeriod;
        unsigned short dRqPeriod;
        unsigned short syncDur;
        unsigned short syncRem;
        unsigned short annDur;
        unsigned short annRem;
        unsigned short dRqDur;
        unsigned short dRqRem;

    }
    TSYNC_GplSlaveStats;

    /*==========================================================================
    GPL: Slave Summary
    ==========================================================================*/
    typedef struct TSYNC_GplSlaveSummary
    {
        unsigned int dRqPerSec;
        unsigned int numUniSlaveConn;
    }
    TSYNC_GplSlaveSummary;

    /*==========================================================================
    GPL: BCASt MECH
    ==========================================================================*/

    typedef struct TSYNC_GplBcastMech
    {
        unsigned int   mSync;
        unsigned int   mDelReq;
        unsigned int   uSync;
        unsigned int   uDelReq;
    }
    TSYNC_GplBcastMech;


#define DCS_TYPE_LICENSE_MAX 32
    // The TSYNC_FileOptionObj type is used to store a license option datatypedef struct
    typedef struct TSYNC_FileOptionObj
    {
        unsigned char   length;        // data length
        unsigned char   filler[3];
        unsigned char   type[DCS_TYPE_LICENSE_MAX];     // License option type
    }
    TSYNC_FileOptionObj;

#define FM_LOG_MAX 4
    typedef struct
    {
        float log[FM_LOG_MAX];
    } TSYNC_FmLogObj;

    typedef struct
    {
        uint8_t feature;
        uint8_t type;
        uint8_t io;
        uint8_t instance;
    } TSYNC_IOSwitchObj;

    typedef struct
    {
        char value[SWITCH_FEATURE_OPTION_LEN + 1];
    } TSYNC_SwitchOptionObj;
    typedef struct
    {
       char application[17];
       char system[17];
       char serialnb[17];

    } TSYNC_StrVersionObj;
    
    typedef enum{
       STL_STATIC_KNOWN_POS_MODE,
       STL_STATIC_UNKNOWN_POS_MODE,
       STL_PSEUDO_STATIC_MODE,
       STL_DYNAMIC_MODE,
    } TSYNC_StrGeoModeObj;

    typedef struct
    {
        char         serialnb[17];
        TSYNC_LLAObj pos;
        double       ee_axis;
        double       nn_axis;
        double       uu_axis;
        unsigned int geoMode;
        unsigned int sensLevel;
    } TSYNC_StrConfObj;
    
    typedef struct
    {
        unsigned int rcvBurst;
        unsigned int rcvStrongBurst;
    } TSYNC_StrStatusObj;
    
    typedef struct
    {
        char beginSub[17];
        char endSub[17];
        unsigned int state;
        unsigned int unused;
    } TSYNC_StrSubObj;
    
    typedef struct
    {
        char key[33];
    } TSYNC_StrSubkObj;
    
    /*==========================================================================
    HS : TSync hotswap structs
    ==========================================================================*/
    typedef struct
    {
        unsigned int   statusReg;
        HS_SLED_STATUS sled1;
        HS_SLED_STATUS sled2;
    } TSYNC_HsStatusObj;
    
    typedef struct
    {
        HS_SLED_CTL sled1;
        HS_SLED_CTL sled2;
    } TSYNC_HsCtlObj;

    /*==========================================================================
    PUBLIC ROUTINE PROTOTYPES
    ==========================================================================*/

    /* General ===============================================================*/

    /*
    * Function:    TSYNC_open()
    * Description: Open the TSYNC device.
    *
    * Parameters:
    *   IN: *hw         - Handle
    *       *deviceName - Name of the device.
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_open(
        TSYNC_BoardHandle *hnd,
        const char        *deviceName);

    /*
    * Function:    TSYNC_close()
    * Description: Close the TSYNC device.
    *
    * Parameters:
    *   IN: *hw         - Handle
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_close(
        TSYNC_BoardHandle hnd);
    /*
    * Function:    TSYNC_get()
    * Description: Generic get accessor.
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *        dest              - destination of the call
    *        iid               - item id
    *        inPayload         - transaction specific payload
    *        inLength          - number of bytes in inPayload
    *        maxOutLength      - number bytes allowed in outPayload
    *   OUT: outPayload        - passed back transaction specific data
    *        actualOutLength   - the actual number of bytes passe back
    *                            in outPayload
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_get(
        TSYNC_BoardHandle  handle,
        DEST_ID            dest,
        ITEM_ID            iid,
        void              *inPayload,
        uint32_t           inLength,
        void              *outPayload,
        uint32_t           maxOutLength,
        uint32_t          *actualOutLength);

    /*
    * Function:    TSYNC_set()
    * Description: Generic set accessor.
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *        dest              - destination of the call
    *        iid               - item id
    *        inPayload         - transaction specific payload
    *        inLength          - number of bytes in inPayload
    *        maxOutLength      - number bytes allowed in outPayload
    *   OUT: outPayload        - passed back transaction specific data
    *        actualOutLength   - the actual number of bytes passe back
    *                            in outPayload
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_set(
        TSYNC_BoardHandle  handle,
        DEST_ID            dest,
        ITEM_ID            iid,
        void              *inPayload,
        uint32_t           inLength,
        void              *outPayload,
        uint32_t           maxOutLength,
        uint32_t          *actualOutLength);

    /*
    * Function:    TSYNC_waitFor()
    * Description: Blocking call to wait for specified interrupt.
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *        intType           - the interrupt type to wait for (GPI/GPO are
    *                            indexed)
    *        index             - the index of the interrupt (0 for non-indexed
    *                            interrupts)
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_waitFor(
        TSYNC_BoardHandle handle,
        INT_TYPE          intType,
        uint32_t          index);

    /*
    * Function:    TSYNC_waitForTo()
    * Description: Blocking call to wait for specified interrupt with timeout.
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *        intType           - the interrupt type to wait for (GPI/GPO are
    *                            indexed)
    *        index             - the index of the interrupt (0 for non-indexed
    *                            interrupts)
    *        timeout           - How long it should block before timing out.
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_waitForTo(
        TSYNC_BoardHandle handle,
        INT_TYPE          intType,
        uint32_t          index,
        int32_t           timeout);

    /* Host Agent ============================================================*/

    /*
    * Function:    TSYNC_HA_getCaps()
    * Description: Gets a single page of capability results.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pageNum       - Component Agent Identifier
    *   OUT: *pObj         - Pointer to the page of capability results
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HA_getCaps(
        TSYNC_BoardHandle        hnd,
        unsigned int             pageNum,
        TSYNC_CapabilityPageObj *pObj);

    /* Discovery and Configuration Service ===================================*/

    /*
    * Function:    TSYNC_DCS_getCardInfo()
    * Description: Gets information about an option card in a specified slot.
    *
    * Parameters:
    *   IN:  hnd    - Board handle
    *        nSlot  - Option card slot
    *   OUT: *pObj  - Option card information result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_DCS_getCardInfo(
        TSYNC_BoardHandle    hnd,
        unsigned int         nSlot,
        TSYNC_OptCardHdrObj *pObj);

    /*
    * Function:    TSYNC_DCS_getFeatureByIdx()
    * Description: Gets the feature ID and instance for a specified feature
    *              index on an option card in a specified slot.
    *
    * Parameters:
    *   IN:  hnd      - Board handle
    *        *pInObj  - Slot and index of feature
    *   OUT: *pOutObj - Feature ID and instance result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_DCS_getFeatureByIdx(
        TSYNC_BoardHandle         hnd,
        TSYNC_OptCardSlotIdxObj  *pInObj,
        TSYNC_OptCardFeatInstObj *pOutObj);

    /*
    * Function:    TSYNC_DCS_getInstance()
    * Description: Gets the system instance of a specified local instance of a
    *              specified feature id on an option card in a specified slot.
    *
    * Parameters:
    *   IN:  hnd        - Board handle
    *        *pInObj    - Slot, id, and local instance of feature
    *   OUT: *nInstance - System instance result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_DCS_getInstance(
        TSYNC_BoardHandle             hnd,
        TSYNC_OptCardSlotFeatInstObj *pObj,
        int                          *nInstance);

    /*
    * Function:    TSYNC_DCS_getSlot()
    * Description: Gets the slot number of the option card that contains the
    *              specified system instance of a specified feature id.
    *
    * Parameters:
    *   IN:  hnd    - Board handle
    *        *pObj  - Id and system instance of feature
    *   OUT: *nSlot - Option card slot result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_DCS_getSlot(
        TSYNC_BoardHandle         hnd,
        TSYNC_OptCardFeatInstObj *pObj,
        int                      *nSlot);

/*
    * Function:    TSYNC_DCS_getOptions()
    * Description: Gets access of available licensed options
    *
    * Parameters:
    *   IN:  hnd    - Board handle
    *        *pObj  - Id and system instance of feature
    *   OUT: *fileOption - Option
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_DCS_getOptions(
        TSYNC_BoardHandle         hnd,
        TSYNC_FileOptionObj      *fileOption);

/*
    * Function:    TSYNC_DCS_checkOption()
    * Description: Gets access of the availability of a specified
    *              licensed options
    *
    * Parameters:
    *   IN:  hnd    - Board handle
    *        *pObj  - Id and system instance of feature
             licenseType - Type of license LCS_MULTIGNSS or LCS_SKYLIGHT
    *   OUT: *licenseStatus - License available or not
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_DCS_checkOption(
        TSYNC_BoardHandle         hnd,
        int                      licenseType,
        int                      *licenseStatus);

/*
    * Function:    TSYNC_DCS_deleteOption()
    * Description: Delete specified licensed options
    *
    * Parameters:
    *   IN:  hnd    - Board handle
    *        *pObj  - Id and system instance of feature
             licenseType - Type of license LCS_MULTIGNSS or LCS_SKYLIGHT
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_DCS_deleteOption(
        TSYNC_BoardHandle         hnd,
        int                      licenseType);

    /* Upgrade Service =======================================================*/

    /*
    * Function:    TSYNC_US_getState()
    * Description: Retreive the update status.
    *
    * Parameters:
    *   IN:  *hw           - Handle
    *        *obj          - Pointer to the state result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_US_getState(
        TSYNC_BoardHandle  hnd,
        TSYNC_StateObj    *obj);

    /*
    * Function:    TSYNC_US_start()
    * Description: Begin an image update sequence.
    *
    * Parameters:
    *   IN:  *hw           - Handle
    *        *obj          - Pointer to the update header information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_US_start(
        TSYNC_BoardHandle       hnd,
        TSYNC_ULImageHeaderObj *obj);

    /*
    * Function:    TSYNC_US_startOC()
    * Description: Begin an option card image update sequence.
    *
    * Parameters:
    *   IN:  *hw           - Handle
    *        *obj1         - Pointer to the update image information
    *        *obj2         - Pointer to the update header information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_US_startOC(
        TSYNC_BoardHandle       hnd,
        TSYNC_ULImageIdObj     *obj1,
        TSYNC_ULImageHeaderObj *obj2);

    /*
    * Function:    TSYNC_US_startComp()
    * Description: Begin an component image update sequence.
    *
    * Parameters:
    *   IN:  *hw           - Handle
    *        *obj1         - Pointer to the update image information
    *        *obj2         - Pointer to the update header information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_US_startComp(
        TSYNC_BoardHandle       hnd,
        TSYNC_ULImageIdObj     *obj1,
        TSYNC_ULImageHeaderObj *obj2);

    /*
    * Function:    TSYNC_US_data()
    * Description: Send a single data block in the update sequence.
    *
    * Parameters:
    *   IN:  *hw           - Handle
    *   OUT: *obj          - Pointer to the update data information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_US_data(
        TSYNC_BoardHandle    hnd,
        TSYNC_UpdateDataObj *obj);

    /*
    * Function:    TSYNC_US_data()
    * Description: Finish the update sequence.
    *
    * Parameters:
    *   IN:  *hw           - Handle
    *   OUT: *obj          - Pointer to the update end information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_US_end(
        TSYNC_BoardHandle   hnd,
        TSYNC_UpdateEndObj *obj);

    /*
    * Function:    TSYNC_US_cancel()
    * Description: Cancel the update sequence.
    *
    * Parameters:
    *   IN:  *hw           - Handle
    *   OUT: imageType     - the type of update sequence being cancelled
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_US_cancel(
        TSYNC_BoardHandle hnd,
        UL_IMG            imageType);

    /* Clock Service =========================================================*/

    /*
    * Function:    TSYNC_CS_getTime()
    * Description: Get the DOY time from the firmware.  TSYNC_HW_getTime is
    *              recommended for faster time reads.
    *
    * Parameters:
    *   IN:  *hw         - Handle
    *   OUT: *Timep      - Pointer to the time result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_CS_getTime(
        TSYNC_BoardHandle  hnd,
        TSYNC_TimeObj     *Timep);

    /*
    * Function:    TSYNC_CS_setTime()
    * Description: Set the DOY time.
    *
    * Parameters:
    *   IN:  *hw         - Handle
    *        *Timep      - Pointer to the time information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_CS_setTime(
        TSYNC_BoardHandle  hnd,
        TSYNC_TimeObj     *Timep);

    /*
    * Function:    TSYNC_CS_getNextSec()
    * Description: Get the DOY time for the next second from the firmware.
    *
    * Parameters:
    *   IN:  *hw         - Handle
    *   OUT: *Timep      - Pointer to the time result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_CS_getNextSec(
        TSYNC_BoardHandle  hnd,
        TSYNC_TimeObj     *Timep);

    /*
    * Function:    TSYNC_CS_getTimeScale()
    * Description: Get the board's current time scale.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - Pointer to the time scale result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT TSYNC_ERROR
        TSYNC_CS_getTimeScale(
        TSYNC_BoardHandle   hnd,
        TSYNC_TimeScaleObj *pObj);

    /*
    * Function:    TSYNC_CS_setTimeScale()
    * Description: Set the board's time scale.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pObj          - Pointer to the time scale information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT TSYNC_ERROR
        TSYNC_CS_setTimeScale(
        TSYNC_BoardHandle   hnd,
        TSYNC_TimeScaleObj *pObj);

    /*
    * Function:    TSYNC_CS_getTimeScaleOff()
    * Description: Get the specified time scale's offset from UTC.  Offset is
    *              in seconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - Pointer to the time scale offset result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT TSYNC_ERROR
        TSYNC_CS_getTimeScaleOff(
        TSYNC_BoardHandle         hnd,
        TSYNC_TimeScaleOffsetObj *pObj);

    /*
    * Function:    TSYNC_CS_setTimeScaleOff()
    * Description: Set the specified time scale's offset from UTC.  Offset is in
    *              seconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pObj          - Pointer to the time scale offset information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT TSYNC_ERROR
        TSYNC_CS_setTimeScaleOff(
        TSYNC_BoardHandle         hnd,
        TSYNC_TimeScaleOffsetObj *pObj);

    /*
    * Function:    TSYNC_CS_subsecAdj()
    * Description: Make a one-time adjustment to the 1PPS on-time point.
    *              Adjustment is in nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pObj          - Pointer to the subsecond adjustment information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT TSYNC_ERROR
        TSYNC_CS_subsecAdj(
        TSYNC_BoardHandle       hnd,
        TSYNC_TimeSubsecAdjObj *pObj);

    /*
    * Function:    TSYNC_CS_getTimeDiscont()
    * Description: Get the user time discontinuity.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - Pointer to the time discontinuity result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_CS_getTimeDiscont(
        TSYNC_BoardHandle     hnd,
        TSYNC_TimeDiscontObj *pObj);

    /*
    * Function:    TSYNC_CS_setTimeDiscont()
    * Description: Set the user time discontinuity.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pObj          - Pointer to the time discontinuity information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_CS_setTimeDiscont(
        TSYNC_BoardHandle     hnd,
        TSYNC_TimeDiscontObj *pObj);

    /*
    * Function:    TSYNC_CS_getLeapSec()
    * Description: Get the current leap second information.  Offset is in
    *              seconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pObj          - Pointer to the leap seconds result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_CS_getLeapSec(
        TSYNC_BoardHandle        hnd,
        TSYNC_TimeLeapSecondObj *pObj);

    /*
    * Function:    TSYNC_CS_setLeapSec()
    * Description: Set a new leap second.  Offset is in seconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pObj          - Pointer to the leap seconds information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_CS_setLeapSec(
        TSYNC_BoardHandle        hnd,
        TSYNC_TimeLeapSecondObj *pObj);

    /*
    * Function:    TSYNC_CS_getTimeZoneOff()
    * Description: Get the current time zone offset from UTC.  Offset is in
    *              seconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - Pointer to the time zone offset result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_CS_getTimeZoneOff(
        TSYNC_BoardHandle        hnd,
        TSYNC_TimeZoneOffsetObj *pObj);

    /*
    * Function:    TSYNC_CS_setTimeZoneOff()
    * Description: Set the current time zone offset from UTC.  Offset is in
    *              seconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pObj          - Pointer to the time zone offset information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_CS_setTimeZoneOff(
        TSYNC_BoardHandle        hnd,
        TSYNC_TimeZoneOffsetObj *pObj);

    /*
    * Function:    TSYNC_CS_getDstRule()
    * Description: Get the current DST rule.  DST Offset is in seconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - Pointer to the DST rule result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_CS_getDstRule(
        TSYNC_BoardHandle     hnd,
        TSYNC_TimeDSTRuleObj *pObj);

    /*
    * Function:    TSYNC_CS_setDstRule()
    * Description: Set the DST rule.  DST offset is in seconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pObj          - Pointer to the time zone offset rule information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_CS_setDstRule(
        TSYNC_BoardHandle     hnd,
        TSYNC_TimeDSTRuleObj *pObj);

    /*
    * Function:    TSYNC_CS_getYear()
    * Description: Get the current year.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - Pointer to the year result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_CS_getYear(
        TSYNC_BoardHandle  hnd,
        TSYNC_TimeYearObj *pObj);

    /*
    * Function:    TSYNC_CS_setYear()
    * Description: Set the year.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pObj          - Pointer to the year information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_CS_setYear(
        TSYNC_BoardHandle  hnd,
        TSYNC_TimeYearObj *pObj);

    /*
    * Function:    TSYNC_CS_getDstState()
    * Description: Get the current DST state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pObj          - Pointer to the DST state information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_CS_getDstState(
        TSYNC_BoardHandle      hnd,
        TSYNC_TimeDSTStateObj *pObj);

    /*
    * Function:    TSYNC_CS_setDstState()
    * Description: Set the DST state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pObj          - Pointer to the DST state information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_CS_setDstState(
        TSYNC_BoardHandle      hnd,
        TSYNC_TimeDSTStateObj *pObj);

    /*
    * Function:    TSYNC_CS_getTimeSec()
    * Description: Get the time in seconds and nanoseconds format.
    *              TSYNC_HW_getTimeSec is recommended for faster time reads.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: nSeconds      - The seconds result
    *        nNanos        - The nanoseconds result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_CS_getTimeSec(
        TSYNC_BoardHandle  hnd,
        unsigned int      *nSeconds,
        unsigned int      *nNanos);

    /*
    * Function:    TSYNC_CS_setTimeSec()
    * Description: Set the time in seconds and nanoseconds format.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nSeconds      - The seconds information
    *        nNanos        - The nanoseconds information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_CS_setTimeSec(
        TSYNC_BoardHandle hnd,
        unsigned int      nSeconds,
        unsigned int      nNanos);

    /*
    * Function:    TSYNC_CS_getTimeBcd()
    * Description: Get the time in BCD format.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - Pointer to the time result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_CS_getTimeBcd(
        TSYNC_BoardHandle  hnd,
        TSYNC_TimeBCDObj  *pObj);

    /*
    * Function:    TSYNC_CS_setTimeBcd()
    * Description: Set the time in BCD format.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pObj          - Pointer to the time information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_CS_setTimeBcd(
        TSYNC_BoardHandle  hnd,
        TSYNC_TimeBCDObj  *pObj);

    /* Flash Manager Service =================================================*/

    /*
    * Function:    TSYNC_FS_getCrc()
    * Description: Get the CRC for a particular flash image.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pObj          - Pointer to the image information
    *   OUT: pObj2         - Pointer to the crc result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FS_getCrc(
        TSYNC_BoardHandle  hnd,
        TSYNC_ULImageObj  *pObj,
        TSYNC_FSCRCObj    *pObj2);

    /*
    * Function:    TSYNC_FS_calcCrc()
    * Description: Calculate the CRC for a particular flash image.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pObj          - Pointer to the image information
    *   OUT: pObj2         - Pointer to the crc result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FS_calcCrc(
        TSYNC_BoardHandle  hnd,
        TSYNC_ULImageObj  *pObj,
        TSYNC_FSCRCObj    *pObj2);

    /*
    * Function:    TSYNC_FS_getHeader()
    * Description: Get the image header for a particular flash image.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pObj          - Pointer to the image information
    *   OUT: pObj2         - Pointer to the image header result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FS_getHeader(
        TSYNC_BoardHandle       hnd,
        TSYNC_ULImageObj       *pObj,
        TSYNC_ULImageHeaderObj *pObj2);

    /*
    * Function:    TSYNC_FS_getVersion()
    * Description: Get the image version for a particular flash image.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pObj          - Pointer to the image information
    *   OUT: pObj2         - Pointer to the image version result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FS_getVersion(
        TSYNC_BoardHandle   hnd,
        TSYNC_ULImageObj   *pObj,
        TSYNC_FSVersionObj *pObj2);

    /* Log Service ===========================================================*/

    /*
    * Function:    TSYNC_LS_getErrorLog()
    * Description: Get the error log.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - Pointer to the error log result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_LS_getErrorLog(
        TSYNC_BoardHandle  hnd,
        TSYNC_ErrorLogObj *pObj);

    /*
    * Function:    TSYNC_LS_getAlarm()
    * Description: Get the alarm state for the specified alarm.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pObj          - Pointer to the alarm index information
    *   OUT: pObj2         - Pointer to the alarm flag result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_LS_getAlarm(
        TSYNC_BoardHandle  hnd,
        TSYNC_AlarmObj    *pObj,
        TSYNC_FlagObj     *pObj2);

    /*
    * Function:    TSYNC_LS_setAlarm()
    * Description: Clear the specified alarm.  (Set 0 to clear)
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pObj          - Pointer to the alarm index information
    *        pObj2         - Pointer to the alarm flag result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_LS_setAlarm(
        TSYNC_BoardHandle  hnd,
        TSYNC_AlarmObj    *pObj,
        TSYNC_FlagObj     *pObj2);

    /*
    * Function:    TSYNC_LS_getVersion()
    * Description: Get the firmware version string.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - Pointer to the firmware version result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_LS_getVersion(
        TSYNC_BoardHandle         hnd,
        TSYNC_FirmwareVersionObj *pObj);

    /*
    * Function:    TSYNC_LS_getSerialNo()
    * Description: Get the serial number string.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - Pointer to the serial number result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_LS_getSerialNo(
        TSYNC_BoardHandle  hnd,
        TSYNC_SerialNoObj *pObj);

    /* Oscillator Monitor Service ============================================*/

    /*
    * Function:    TSYNC_XS_register()
    * Description: Reserve a meter.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - Pointer to the meter handle result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_XS_register(
        TSYNC_BoardHandle  hnd,
        TSYNC_MeterHandle *pObj);

    /*
    * Function:    TSYNC_XS_unregister()
    * Description: Free the specified meter.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pObj          - Pointer to the meter handle information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_XS_unregister(
        TSYNC_BoardHandle  hnd,
        TSYNC_MeterHandle *pObj);

    /*
    * Function:    TSYNC_XS_getWindowSize()
    * Description: Get the specified meter's error data.  Error data is in
    *              nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - Pointer to the window size result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_XS_getWindowSize (
        TSYNC_BoardHandle      hnd,
        TSYNC_MeterWinSizeObj *pObj);

    /*
    * Function:    TSYNC_XS_setWindowSize()
    * Description: Set the specified meter's window size.  Size is in seconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pObj          - Pointer to the window size information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_XS_setWindowSize(
        TSYNC_BoardHandle      hnd,
        TSYNC_MeterWinSizeObj *pObj);

    /*
    * Function:    TSYNC_XS_getMeterData()
    * Description: Get the meter data.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - Pointer to the meter data result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_XS_getMeterData(
        TSYNC_BoardHandle   hnd,
        TSYNC_MeterDataObj *pObj);

    /*
    * Function:    TSYNC_XS_meterCmd()
    * Description: Send a command to a meter.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pObj          - Pointer to the meter command information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_XS_meterCmd(
        TSYNC_BoardHandle      hnd,
        TSYNC_MeterCommandObj *pObj);

    /* Superviser Service ====================================================*/

    /*
    * Function:    TSYNC_SS_reset()
    * Description: Reset the TSYNC board.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pObj          - Pointer to the reset type information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_SS_reset(
        TSYNC_BoardHandle  hnd,
        TSYNC_ResetObj    *pObj);

    /*
    * Function:    TSYNC_SS_getRef()
    * Description: Get currently selected time and 1PPS reference.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - Pointer to the reference result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_SS_getRef(
        TSYNC_BoardHandle   hnd,
        TSYNC_ReferenceObj *pObj);

    /*
    * Function:    TSYNC_SS_getMaxTfom()
    * Description: Get the maximum TFOM.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: tfom          - Pointer to the maximum TFOM result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_SS_getMaxTfom(
        TSYNC_BoardHandle  hnd,
        TFOM              *tfom);

    /*
    * Function:    TSYNC_SS_setMaxTfom()
    * Description: Set the maximum TFOM.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        tfom          - Pointer to the maximum TFOM information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_SS_setMaxTfom(
        TSYNC_BoardHandle hnd,
        TFOM              tfom);

    /*
    * Function:    TSYNC_SS_getTfom()
    * Description: Get the current TFOM.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: tfom          - Pointer to the current TFOM result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_SS_getTfom(
        TSYNC_BoardHandle  hnd,
        TFOM              *tfom);

    /*
    * Function:    TSYNC_SS_getSync()
    * Description: Get the current sync state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: bSync         - Pointer to the current sync state result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_SS_getSync(
        TSYNC_BoardHandle  hnd,
        int               *bSync);

    /*
    * Function:    TSYNC_SS_getHoldover()
    * Description: Get the current holdover state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: bHoldover     - Pointer to the current holdover state result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_SS_getHoldover(
        TSYNC_BoardHandle  hnd,
        int               *bHoldover);

    /*
    * Function:    TSYNC_SS_getHoldoverTO()
    * Description: Get the current holdover timeout.
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *   OUT: nHoldoverTimeout  - Pointer to the current timeout state result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_SS_getHoldoverTO(
        TSYNC_BoardHandle  hnd,
        unsigned int      *nHoldoverTimeout);

    /*
    * Function:    TSYNC_SS_setHoldoverTO()
    * Description: Set the current holdover timeout.
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *        nHoldoverTimeout  - Pointer to the current timeout state
    *                            information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_SS_setHoldoverTO(
        TSYNC_BoardHandle hnd,
        unsigned int      nHoldoverTimeout);

    /*
    * Function:    TSYNC_SS_getTimestamp()
    * Description: Get the specified state change timestamp.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        src           - The timestamp source
    *   OUT: pObj          - Pointer to the time result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_SS_getTimestamp(
        TSYNC_BoardHandle  hnd,
        SS_TS_SRC          src,
        TSYNC_TimeObj     *pObj);

    /*
    * Function:    TSYNC_SS_getTimestampBcd()
    * Description: Get the specified state change timestamp in BCD format.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        src           - The timestamp source
    *   OUT: pObj          - Pointer to the time result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_SS_getTimestampBcd(
        TSYNC_BoardHandle  hnd,
        SS_TS_SRC          src,
        TSYNC_TimeBCDObj  *pObj);

    /*
    * Function:    TSYNC_SS_getTimestampSec()
    * Description: Get the specified state change timestamp in seconds format.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        src           - The timestamp source
    *   OUT: nSeconds      - Pointer to the seconds time result
    *        nNanos        - Pointer to the nanoseconds time result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_SS_getTimestampSec(
        TSYNC_BoardHandle  hnd,
        SS_TS_SRC          src,
        unsigned int      *nSeconds,
        unsigned int      *nNanos);

    /*
    * Function:    TSYNC_SS_getUptime()
    * Description: Get the board's total uptime in minutes.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: nUptime       - Pointer to the uptime result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_SS_getUptime(
        TSYNC_BoardHandle  hnd,
        unsigned int      *nUptime);

    /*
    * Function:    TSYNC_SS_getFreeRun()
    * Description: Get the current freerun state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: bFreerun      - The freerun result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_SS_getFreeRun(
        TSYNC_BoardHandle  hnd,
        int               *bFreerun);

    /* Reference Monitor Service =============================================*/

    /*
    * Function:    TSYNC_RS_getTable()
    * Description: Get specified reference priority table.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pObj          - Pointer to the table type information
    *   OUT: pObj2         - Pointer to the reference result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_RS_getTable(
        TSYNC_BoardHandle        hnd,
        TSYNC_TableTypeObj      *pObj,
        TSYNC_ReferenceTableObj *pObj2);

    /*
    * Function:    TSYNC_RS_getBestRef()
    * Description: Get current best working priority table entry.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - Pointer to the table entry result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_RS_getBestRef(
        TSYNC_BoardHandle    hnd,
        TSYNC_TableEntryObj *pObj);

    /*
    * Function:    TSYNC_RS_getEntry()
    * Description: Get working priority table entry by index.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        index         - Table entry index
    *   OUT: pObj          - Pointer to the table entry result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_RS_getEntry(
        TSYNC_BoardHandle    hnd,
        int                  index,
        TSYNC_TableEntryObj *pObj);

    /*
    * Function:    TSYNC_RS_addEntry()
    * Description: Add an entry to the working priority table.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pObj          - Pointer to the table entry information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_RS_addEntry(
        TSYNC_BoardHandle    hnd,
        TSYNC_TableEntryObj *pObj);

    /*
    * Function:    TSYNC_RS_setFactDef()
    * Description: Reset the working priority table to the factory priority
    *              table.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_RS_setFactDef(
        TSYNC_BoardHandle hnd);

    /*
    * Function:    TSYNC_RS_setUserDef()
    * Description: Reset the reference table to the user default settings, if
    *              saved user priority table exists.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_RS_setUserDef(
        TSYNC_BoardHandle hnd);

    /*
    * Function:    TSYNC_RS_saveUserDef()
    * Description: Save the working priority table to the user priority table.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_RS_saveUserDef(
        TSYNC_BoardHandle hnd);

    /*
    * Function:    TSYNC_RS_deleteEntry()
    * Description: Delete a working priority table entry by index.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        index         - Index of table entry to delete
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_RS_deleteEntry(
        TSYNC_BoardHandle hnd,
        unsigned int      index);

    /*
    * Function:    TSYNC_RS_getPriority()
    * Description: Get specified working priority table entry's priority.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        index         - Table entry index
    *   OUT: priority      - Pointer to the priority result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_RS_getPriority(
        TSYNC_BoardHandle  hnd,
        unsigned int       index,
        unsigned int      *priority);

    /*
    * Function:    TSYNC_RS_setPriority()
    * Description: Set specified working priority table entry's priority.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        index         - Table entry index
    *        priority      - Pointer to the priority information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_RS_setPriority(
        TSYNC_BoardHandle hnd,
        unsigned int      index,
        unsigned int      priority);

    /*
    * Function:    TSYNC_RS_getEnable()
    * Description: Get specified working priority table entry's enable state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        index         - Table entry index
    *   OUT: enabled       - Pointer to the enabled result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_RS_getEnable(
        TSYNC_BoardHandle  hnd,
        unsigned int       index,
        unsigned int      *enabled);

    /*
    * Function:    TSYNC_RS_setEnable()
    * Description: Set specified working priority table entry's enable state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        index         - Table entry index
    *        enabled       - Pointer to the enabled information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_RS_setEnable(
        TSYNC_BoardHandle hnd,
        unsigned int      index,
        unsigned int      enabled);

    /*
    * Function:    TSYNC_RS_getStateTable()
    * Description: Get the reference validity state table.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - Pointer to the reference state table result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_RS_getStateTable(
        TSYNC_BoardHandle             hnd,
        TSYNC_ReferenceStateTableObj *pObj);


    /*
    * Function:    TSYNC_RS_getReferencePhaseData()
    * Description: Get the reference phase table entry
    *              specified by 4-char reference id
    *              string.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pRef          - The reference id string
    *   OUT: pObj          - Pointer to the reference phase entry result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_RS_getReferencePhaseData(
        TSYNC_BoardHandle             hnd,
        char                         *pRef,
        TSYNC_ReferencePhaseDataObj  *pObj);

    /*
    * Function:    TSYNC_RS_setPhaseThreshold()
    * Description: Set the reference phase threshold value.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pRef          - The reference id string
    *        threshold     - The reference phase threshold value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_RS_setPhaseThreshold(
        TSYNC_BoardHandle                 hnd,
        char                             *pRef,
        TSYNC_ReferencePhaseThresholdObj *pObj);

    /*
    * Function:    TSYNC_RS_getPhaseThreshold()
    * Description: Get the reference phase threshold value.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pRef          - The reference id string
    *   OUT: pThreshold    - Pointer to the reference phase threshold value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_RS_getPhaseThreshold(
        TSYNC_BoardHandle                 hnd,
        char                             *pRef,
        TSYNC_ReferencePhaseThresholdObj *pObj);

    /* Initializer Service ===================================================*/

    /*
    * Function:    TSYNC_IN_getStatus()
    * Description: Get the board's initialization results.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pageNum       - Table entry index
    *   OUT: pObj          - Pointer to the initialization status result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IN_getStatus(
        TSYNC_BoardHandle       hnd,
        unsigned int            pageNum,
        TSYNC_InitStatusResult *pObj);

    /* General-Purpose Input Component =======================================*/

    /*
    * Function:    TSYNC_GI_getValue()
    * Description: Get the specified GPI's current input value.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        index         - The input index
    *   OUT: bEnabled      - The value result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GI_getValue(
        TSYNC_BoardHandle  hnd,
        ID_PIN             index,
        int               *bEnabled);

    /*
    * Function:    TSYNC_GI_getEdge()
    * Description: Get the GPI's trigger edge used when detecting
    *              input changes.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        index         - The input index
    *   OUT: edge          - The edge result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GI_getEdge(
        TSYNC_BoardHandle  hnd,
        ID_PIN             index,
        EDGE              *edge);

    /*
    * Function:    TSYNC_GI_setEdge()
    * Description: Set the GPI's trigger edge used when detecting
    *              input changes.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        index         - The input index
    *        edge          - The edge information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GI_setEdge(
        TSYNC_BoardHandle hnd,
        ID_PIN            index,
        EDGE              edge);

    /*
    * Function:    TSYNC_GI_getTsEnable()
    * Description: Get the GPI's timestamp enable state
    *              used when time stamping input changes.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        index         - The input index
    *   OUT: bEnable       - The enabled result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GI_getTsEnable(
        TSYNC_BoardHandle  hnd,
        ID_PIN             index,
        int               *bEnable);

    /*
    * Function:    TSYNC_GI_setTsEnable()
    * Description: Set the GPI's timestamp enable state
    *              used when time stamping input changes.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        index         - The input index
    *        bEnable       - The enabled information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GI_setTsEnable(
        TSYNC_BoardHandle hnd,
        ID_PIN            index,
        int               bEnable);

    /*
    * Function:    TSYNC_GI_getNumInst()
    * Description: Get number of GPIO Inputs present in the system.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: nInstances    - The number of instances result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GI_getNumInst(
        TSYNC_BoardHandle  hnd,
        unsigned int      *nInstances);

    /*
    * Function:    TSYNC_GI_getTsType()
    * Description: Get Timestamp Type of a specified GI instance.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        index         - The input index
    *   OUT: bType         - The timestamp type
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GI_getTsType(
        TSYNC_BoardHandle hnd,
        ID_PIN index,
        int *bType);

    /*
    * Function:    TSYNC_GI_getAsciiTs()
    * Description: Get the latest ASCII Timestamp.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        index         - The input index
    *   OUT: pObj          - The latest ASCII timestamp
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GI_getAsciiTs(
        TSYNC_BoardHandle hnd,
        ID_PIN index,
        TSYNC_AsciiEvtMsg *pObj);

    /*
    * Function:    TSYNC_GI_tsClear()
    * Description: Clears the ASCII TImestamp buffer.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        index         - The input index
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GI_tsClear(
        TSYNC_BoardHandle hnd,
        ID_PIN index);


    /* Host Reference Component ==============================================*/

    /*
    * Function:    TSYNC_HR_getValidity()
    * Description: Get the reference validity from the Host.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: bTimeValid    - The time reference result
    *        bPpsValid     - The pps reference result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HR_getValidity(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *bTimeValid,
        int               *bPpsValid);

    /*
    * Function:    TSYNC_HR_setValidity()
    * Description: Set the reference validity of the Host.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        bTimeValid    - The time reference information
    *        bPpsValid     - The pps reference information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HR_setValidity(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int               bTimeValid,
        int               bPpsValid);

    /*
    * Function:    TSYNC_HR_setTime()
    * Description: Set the time from the Host.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        TSYNC_TimeObj - The time information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HR_setTime(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        TSYNC_TimeObj     *pObj);

    /*
    * Function:    TSYNC_HR_getLocal()
    * Description: Get the ASCII reference's local time zone and DST rule.
    *              Timezone and DST offsets are in seconds.
    *
    * Parameters:
    *   IN:  hnd                 - Board handle
    *        nInstance           - The instance number
    *   OUT: TSYNC_LocalClockObj - The local clock result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HR_getLocal(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_LocalClockObj *pObj);

    /*
    * Function:    TSYNC_HR_setLocal()
    * Description: Set the ASCII reference's local time zone and DST rule.
    *              Timezone and DST offsets are in seconds.
    *
    * Parameters:
    *   IN:  hnd                 - Board handle
    *        nInstance           - The instance number
    *        TSYNC_LocalClockObj - The local clock information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HR_setLocal(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_LocalClockObj *pObj);

    /*
    * Function:    TSYNC_HR_getTimeScale()
    * Description: Get the Host reference's time scale.
    *
    * Parameters:
    *   IN:  hnd                 - Board handle
    *        nInstance           - The instance number
    *   OUT: TSYNC_LocalClockObj - The time scale result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HR_getTimeScale(
        TSYNC_BoardHandle   hnd,
        unsigned int        nInstance,
        TSYNC_TimeScaleObj *pObj);

    /*
    * Function:    TSYNC_HR_setTimeScale()
    * Description: Set the Host reference's time scale.
    *
    * Parameters:
    *   IN:  hnd                 - Board handle
    *        nInstance           - The instance number
    *        TSYNC_LocalClockObj - The time scale information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HR_setTimeScale(
        TSYNC_BoardHandle   hnd,
        unsigned int        nInstance,
        TSYNC_TimeScaleObj *pObj);

    /*
    * Function:    TSYNC_HR_getRefId()
    * Description: Get reference identifier for a Host reference instance.
    *
    * Parameters:
    *   IN:  hnd            - Board handle
    *   OUT: TSYNC_RefIdObj - The reference identifier result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HR_getRefId(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        TSYNC_RefIdObj    *pObj);

    /*
    * Function:    TSYNC_HR_getNumInst()
    * Description: Get number of Host reference instances present in the system.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: nInstances    - The number of instances result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HR_getNumInst(
        TSYNC_BoardHandle  hnd,
        unsigned int      *nInstances);

    /*
    * Function:    TSYNC_HR_getOffset()
    * Description: Get the Host 1PPS reference's input offset.  Offset is in
    *              nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: nOffset       - The offset result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HR_getOffset(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *nOffset);

    /*
    * Function:    TSYNC_HR_setOffset()
    * Description: Get the Host 1PPS reference's 1PPS input offset.  Offset is in
    *              nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        nOffset       - The offset
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HR_setOffset(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int               nOffset);

    /*
    * Function:    TSYNC_HR_getMode()
    * Description: Get the Host 1PPS reference's input time set mode.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: mode          - The Set Time Mode
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HR_getMode(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        HR_TS_MODE         *mode);

    /*
    * Function:    TSYNC_HR_setMode()
    * Description: Set the Host 1PPS reference's 1PPS input time set mode.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        mode          - The Set Time Mode
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HR_setMode(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        HR_TS_MODE        mode);

    /* 1PPS Reference Component ==============================================*/

    /*
    * Function:    TSYNC_PR_getOffset()
    * Description: Get the 1PPS reference's input offset.  Offset is in
    *              nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: nOffset       - The offset result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PR_getOffset(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *nOffset);

    /*
    * Function:    TSYNC_PR_setOffset()
    * Description: Get the 1PPS reference's 1PPS input offset.  Offset is in
    *              nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        nOffset       - The offset
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PR_setOffset(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int               nOffset);

    /*
    * Function:    TSYNC_PR_getEdge()
    * Description: Get the 1PPS reference's active edge setting.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: edge          - The edge result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PR_getEdge(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        EDGE              *edge);

    /*
    * Function:    TSYNC_PR_setEdge()
    * Description: Set the 1PPS reference's active edge setting.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        edge          - The edge information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PR_setEdge(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        EDGE              edge);

    /*
    * Function:    TSYNC_PR_getValidity()
    * Description: Get the 1PPS validity structure.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: bTimeValid    - The time reference result
    *        bPpsValid     - The pps reference result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PR_getValidity(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *bTimeValid,
        int               *bPpsValid);

    /*
    * Function:    TSYNC_PR_getNumInst()
    * Description: Get number of PPS reference instances present in the system.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: nInstances    - The number of instances result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PR_getNumInst(
        TSYNC_BoardHandle  hnd,
        unsigned int      *nInstances);

    /*
    * Function:    TSYNC_PR_getRefId()
    * Description: Get reference identifier for a PPS reference instance.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PR_getRefId(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        TSYNC_RefIdObj    *pObj);

    /* LED Control Component =================================================*/

    /*
    * Function:    TSYNC_EC_getMode()
    * Description: Get the LED usage mode state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        index         - The LED index
    *   OUT: mode          - The usage mode
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_EC_getMode(
        TSYNC_BoardHandle  hnd,
        LE_INDEX           index,
        EC_MODE            *mode);

    /*
    * Function:    TSYNC_EC_setMode()
    * Description: Set the LED usage mode state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        index         - The LED index
    *        mode          - The usage mode
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_EC_setMode(
        TSYNC_BoardHandle hnd,
        LE_INDEX          index,
        EC_MODE           mode);

    /*
    * Function:    TSYNC_EC_getState()
    * Description: Get the LED display state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        index         - The LED index
    *   OUT: state         - The display state
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_EC_getState(
        TSYNC_BoardHandle  hnd,
        LE_INDEX           index,
        EC_STATE          *state);

    /*
    * Function:    TSYNC_EC_setState()
    * Description: Set the LED display state.  Settable only in manual LED mode.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        index         - The LED index
    *        state         - The display state
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_EC_setState(
        TSYNC_BoardHandle hnd,
        LE_INDEX          index,
        EC_STATE          state);

    /*
     *
     *
     *
     */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_EC_getBlackoutMode(
        TSYNC_BoardHandle  hnd,
        EC_BLACKOUT_MODE  *mode);

    /*
     *
     *
     *
     */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_EC_setBlackoutMode(
        TSYNC_BoardHandle  hdn,
        EC_BLACKOUT_MODE   mode);

    /* ASCII Reference Component =============================================*/

    /*
    * Function:    TSYNC_AR_getOffset()
    * Description: Get the ASCII reference's input offset.  Offset is in
    *              nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: nOffset       - The offset result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AR_getOffset(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *nOffset);

    /*
    * Function:    TSYNC_AR_setOffset()
    * Description: Get the ASCII reference's 1PPS input offset.  Offset is in
    *              nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        nOffset       - The offset
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AR_setOffset(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int               nOffset);

    /*
    * Function:    TSYNC_AR_getValidity()
    * Description: Get the ASCII reference validity structure.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: bTimeValid    - The time reference result
    *        bPpsValid     - The pps reference result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AR_getValidity(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *bTimeValid,
        int               *bPpsValid);

    /*
    * Function:    TSYNC_AR_getUartCfg()
    * Description: Get the ASCII reference UART configuration.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pCfg          - The UART configuration
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AR_getUartCfg(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        UD_CFG            *pCfg);

    /*
    * Function:    TSYNC_AR_setUartCfg()
    * Description: Set the ASCII reference UART configuration.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pCfg          - The UART configuration
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AR_setUartCfg(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        UD_CFG            *pCfg);

    /*
    * Function:    TSYNC_AR_getLeapFlag()
    * Description: Get the ASCII reference leap pending flag.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: bLeap         - The leap pending flag
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AR_getLeapFlag(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        unsigned int      *bLeap);

    /*
    * Function:    TSYNC_AR_getLocal()
    * Description: Get the ASCII reference's local time zone and DST rule.
    *              Timezone and DST offsets are in seconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the Local Clock result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AR_getLocal(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_LocalClockObj *pObj);

    /*
    * Function:    TSYNC_AR_setLocal()
    * Description: Set the ASCII reference's local time zone and DST rule.
    *              Timezone and DST offsets are in seconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the Local Clock information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AR_setLocal(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_LocalClockObj *pObj);

    /*
    * Function:    TSYNC_AR_getTimeScale()
    * Description: Get the ASCII reference's time scale.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the time scale result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AR_getTimeScale(
        TSYNC_BoardHandle   hnd,
        unsigned int        nInstance,
        TSYNC_TimeScaleObj *pObj);

    /*
    * Function:    TSYNC_AR_setTimeScale()
    * Description: Set the ASCII reference's time scale.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the time scale information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AR_setTimeScale(
        TSYNC_BoardHandle   hnd,
        unsigned int        nInstance,
        TSYNC_TimeScaleObj *pObj);

    /*
    * Function:    TSYNC_AR_getRefId()
    * Description: Get reference identifier for an ASCII reference instance.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AR_getRefId(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        TSYNC_RefIdObj    *pObj);

    /*
    * Function:    TSYNC_AR_getFormat()
    * Description: Get the ASCII time code format.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: format        - The format result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AR_getFormat(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        AL_FMT            *format);

    /*
    * Function:    TSYNC_AR_setFormat()
    * Description: Set the ASCII time code format.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        format        - The format information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AR_setFormat(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        AL_FMT            format);

    /*
    * Function:    TSYNC_AR_getNumInst()
    * Description: Get number of ASCII reference instances present in the
    *              system.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: nInstances    - The number of instances result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AR_getNumInst(
        TSYNC_BoardHandle  hnd,
        unsigned int      *nInstances);

    /*
    * Function:    TSYNC_AR_getPpsSrc()
    * Description: Get the ASCII PPS Source.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: AL_SRC        - The 1PPS Source
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AR_getPpsSrc(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        AL_PPS            *pps);

    /*
    * Function:    TSYNC_AR_setPpsSrc()
    * Description: Set the ASCII PPS Source.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        format        - The 1PPS Source
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AR_setPpsSrc(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        AL_PPS            pps);

   /*
    * Function:    TSYNC_STR_getNumInst()
    * Description: Get number of STL reference instances present in the
    *              system.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: nInstances    - The number of instances result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_STR_getNumInst(
        TSYNC_BoardHandle  hnd,
        unsigned int      *nInstances);

    /*
    * Function:    TSYNC_STR_getValidity()
    * Description: Get the STL reference validity structure.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: bTimeValid    - The time reference result
    *        bPpsValid     - The pps reference result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_STR_getValidity(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *bTimeValid,
        int               *bPpsValid);

   /*
    * Function:    TSYNC_STR_getRefId()
    * Description: Get reference identifier for an STL reference instance.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_STR_getRefId(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        TSYNC_RefIdObj    *pObj);

    /*
    * Function:    TSYNC_STR_getVersion()
    * Description: Get the Satelles version.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the version result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT TSYNC_ERROR
    TSYNC_STR_getVersion(
        TSYNC_BoardHandle hnd,
        unsigned int nInstance,
        TSYNC_StrVersionObj *pObj);

   /*
    * Function:    TSYNC_STR_getSubscription()
    * Description: Get the end of Satelles Subscription
    *
    * Parameters:
    *   IN:  *hw         - Handle
    *   OUT: *Timep      - Pointer to the time result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT TSYNC_ERROR
    TSYNC_STR_getSubscription(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        TSYNC_StrSubObj *Sub);

    DLL_EXPORT TSYNC_ERROR
    TSYNC_STR_getActFeat(
        TSYNC_BoardHandle hnd,
        unsigned int nInstance,
        int *nActFeat);

    DLL_EXPORT TSYNC_ERROR
    TSYNC_STR_setConf(
       TSYNC_BoardHandle hnd,
       unsigned int nInstance,
       TSYNC_StrConfObj conf);

    DLL_EXPORT TSYNC_ERROR
        TSYNC_STR_getConf(
        TSYNC_BoardHandle hnd,
        unsigned int nInstance,
        TSYNC_StrConfObj *pConf);
   /*
    * Function:    TSYNC_STR_getIpAddr()
    * Description: Get the STL IP Addr
    *
    * Parameters:
    *   IN:  *hw         - Handle
    *   OUT: *IpAddr      - Pointer to the IP address result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT TSYNC_ERROR
    TSYNC_STR_getIpAddr(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        char * IpAddr);

   /*
    * Function:    TSYNC_STR_getStat()
    * Description: Get the STL Status
    *
    * Parameters:
    *   IN:  *hw         - Handle
    *   OUT: *IpAddr      - Pointer to the IP address result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT TSYNC_ERROR
    TSYNC_STR_getStat(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        TSYNC_StrStatusObj * status);

    DLL_EXPORT TSYNC_ERROR
    TSYNC_STR_getSubk(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        TSYNC_StrSubkObj * subk);

    DLL_EXPORT TSYNC_ERROR
    TSYNC_STR_setSubk(
       TSYNC_BoardHandle hnd,
       unsigned int      nInstance,
       TSYNC_StrSubkObj  subk);

    /* Frequency Reference Component =========================================*/

    /*
    * Function:    TSYNC_FR_getValidity()
    * Description: Get the frequency validity structure.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: bTimeValid    - The time reference result
    *        bPpsValid     - The pps reference result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FR_getValidity(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *bTimeValid,
        int               *bPpsValid);

    /*
    * Function:    TSYNC_FR_getFreq()
    * Description: Get the frequency of a frequency reference.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: freq          - The frequency result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FR_getFreq(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        unsigned int      *freq);

    /*
    * Function:    TSYNC_FR_setFreq()
    * Description: Set the frequency of a frequency reference.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        freq          - The frequency information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FR_setFreq(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      freq);

    /*
    * Function:    TSYNC_FR_getMode()
    * Description: Get the reference mode of a frequency reference.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: mode          - The reference mode result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FR_getMode(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        FR_MODE           *mode);

    /*
    * Function:    TSYNC_FR_setMode()
    * Description: Set the reference mode of a frequency reference.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        mode          - The reference mode information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FR_setMode(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        FR_MODE           mode);

    /*
    * Function:    TSYNC_FR_getNumInst()
    * Description: Get number of frequency reference instances present in the
    *              system.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: nInstances    - The number of instances result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FR_getNumInst(
        TSYNC_BoardHandle  hnd,
        unsigned int      *nInstances);

    /*
    * Function:    TSYNC_FR_getRefId()
    * Description: Get reference identifier for a frequency reference instance.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FR_getRefId(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        TSYNC_RefIdObj    *pObj);


    /*
    * Function:    TSYNC_GER_getRefId()
    * Description: Get reference identifier for a PTS reference instance.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GER_getRefId(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        TSYNC_RefIdObj    *pObj);


    /* Generic Reference Component ===========================================*/
    /*
    * Function:    TSYNC_GER_getNumInst()
    * Description: Get number of Generic references instances present in the system.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: nInstances    - The number of instances result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GER_getNumInst(
        TSYNC_BoardHandle  hnd,
        unsigned int      *nInstances);

    /*
    * Function:    TSYNC_GER_getType()
    * Description: Get type of Generic references instances present in the system.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: *nType        - The Type of the given Instance    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GER_getType(
        TSYNC_BoardHandle  hnd,
        unsigned int nInstance,
        unsigned int      *nType);

    /*
    * Function:    TSYNC_GER_getValidity()
    * Description: Get the GER validity structure.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: bTimeValid    - The time reference result
    *        bPpsValid     - The pps reference result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GER_getValidity(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *bTimeValid,
        int               *bPpsValid);



    /*
    * Function:    TSYNC_GER_getCustom()
    * Description: Get the last unhandled GPS message.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the custom message result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GER_getCustom(
        TSYNC_BoardHandle       hnd,
        unsigned int            nInstance,
        TSYNC_CustomMessageObj *pObj);

    /*
    * Function:    TSYNC_GR_setCustom()
    * Description: Send a custom message to the GPS.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the custom message result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GER_setCustom(
        TSYNC_BoardHandle       hnd,
        unsigned int            nInstance,
        TSYNC_CustomMessageObj *pObj);

    /*
    * Function:    TSYNC_GER_getOffset()
    * Description: Get the Generic reference's 1PPS input offset.  Offset is in
    *              nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: nOffset       - The offset result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GER_getOffset(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *nOffset);

    /*
    * Function:    TSYNC_GER_setOffset()
    * Description: Set the Generic reference's 1PPS input offset.  Offset is in
    *              nanoseconds from -500 msec to +500 msec.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        nOffset       - The offset information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GER_setOffset(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int               nOffset);


    /* GPS Reference Component ===============================================*/

    /*
    * Function:    TSYNC_GR_getOffset()
    * Description: Get the GPS reference's 1PPS input offset.  Offset is in
    *              nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: nOffset       - The offset result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_getOffset(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *nOffset);

    /*
    * Function:    TSYNC_GR_setOffset()
    * Description: Set the GPS reference's 1PPS input offset.  Offset is in
    *              nanoseconds from -500 msec to +500 msec.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        nOffset       - The offset information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_setOffset(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int               nOffset);

    /*
    * Function:    TSYNC_GR_getValidity()
    * Description: Get the GPS validity structure.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: bTimeValid    - The time reference result
    *        bPpsValid     - The pps reference result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_getValidity(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *bTimeValid,
        int               *bPpsValid);

    /*
    * Function:    TSYNC_GR_setValidity()
    * Description: Set the GPS validity structure.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: bTimeValid    - The time reference result
    *        bPpsValid     - The pps reference result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_setValidity(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int                bTimeValid,
        int                bPpsValid);

    /*
    * Function:    TSYNC_GR_getPosition()

    * Description: Get the GPS position.  Latitude and longitude are in radians.
    *              Altitude is in meters.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the position result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_getPosition(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        TSYNC_LLAObj      *pObj);

    /*
    * Function:    TSYNC_GR_setPosition()
    * Description: Set the GPS position.  Latitude and longitude are in radians.
    *              Altitude is in meters.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the position information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_setPosition(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        TSYNC_LLAObj      *pObj);

    /*
    * Function:    TSYNC_GR_getMode()
    * Description: Get the GPS receiver mode.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: mode          - The receiver mode result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_getMode(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        GL_MODE           *mode,
        GL_DYN            *dyn);

    /*
    * Function:    TSYNC_GR_setMode()
    * Description: Set the GPS receiver mode.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        mode          - The receiver mode information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_setMode(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        GL_MODE           mode,
        GL_DYN            dyn);

    /*
    * Function:    TSYNC_GR_getDynamics()
    * Description: Get the GPS dynamics mode.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: mode          - The dynamics mode result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_getDynamics(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        GL_DYN            *mode);

    /*
    * Function:    TSYNC_GR_setDynamics()
    * Description: Set the GPS dynamics mode.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        mode          - The dynamics mode information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_setDynamics(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        GL_DYN            mode);

    /*
    * Function:    TSYNC_GR_getFixData()
    * Description: Get the GPS position fix data.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the position fix data result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_getFixData(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        TSYNC_FixDataObj  *pObj);

    /*
    * Function:    TSYNC_GR_svidToString()
    * Description: Convert SVID to string format.
    *
    * Parameters:
    *   IN:  svid          - The svid number
    *   OUT: pObj          - Pointer to the satellite id string
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    void TSYNC_GR_svidToString(
        char*              pSvidStr,
        unsigned int       svid);

    /*
    * Function:    TSYNC_GR_getSatData()
    * Description: Get the GPS satellite data.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the satellite data result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_getSatData(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        TSYNC_SatDataObj  *pObj);

    /*
    * Function:    TSYNC_GR_getSurveyProg()
    * Description: Get the GPS survey progress.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: nProgress     - The survey progress result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_getSurveyProg(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        unsigned int      *nProgress);

    /*
    * Function:    TSYNC_GR_getMfrMdl()
    * Description: Get the GPS receiver manufacturer and model.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the manufacturer and model result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_getMfrMdl(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        TSYNC_ManModObj   *pObj);

    /*
    * Function:    TSYNC_GR_getRcvInfo()
    * Description: Get the GPS receiver info.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the receiver info result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_getRcvInfo(
        TSYNC_BoardHandle      hnd,
        unsigned int           nInstance,
        TSYNC_ReceiverInfoObj *pObj);

    /*
    * Function:    TSYNC_GR_GetUbxVersion()
    * Description: Helper function to convert Receiver Info Object to return version strings for UBX receiver.
    *
    * Parameters:
    *   IN:  pRI           - Pointer to the receiver info result
    *   OUT: pSwVer        - Pointer to char array for Software version
    *        pTimVer       - Pointer to char array for Timing Software version
    *        pProtocol     - Pointer to char array for Protocol version
    * Returns:  Success returns version strings, error returns 0.0 version for ones not found
    */
    DLL_EXPORT
    void TSYNC_GR_getUbxVersion(
            TSYNC_ReceiverInfoObj *pRI,
            char* pSwVer,
            char* pTimVer,
            char* pProtocol,
            char* pHwVer);

    /*
    * Function:    TSYNC_GR_getCustom()
    * Description: Get the last unhandled GPS message.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the custom message result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_getCustom(
        TSYNC_BoardHandle       hnd,
        unsigned int            nInstance,
        TSYNC_CustomMessageObj *pObj);

    /*
    * Function:    TSYNC_GR_setCustom()
    * Description: Send a custom message to the GPS.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the custom message result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_setCustom(
        TSYNC_BoardHandle       hnd,
        unsigned int            nInstance,
        TSYNC_CustomMessageObj *pObj);

    /*
    * Function:    TSYNC_GR_getNumInst()
    * Description: Get number of GPS references instances present in the system.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: nInstances    - The number of instances result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_getNumInst(
        TSYNC_BoardHandle  hnd,
        unsigned int      *nInstances);

    /*
    * Function:    TSYNC_GR_delPos()
    * Description: Clear any position information that is stored in persistent
    *              memory inside the GPS receiver.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_delPos(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance);

    /*
    * Function:    TSYNC_GR_getRefId()
    * Description: Get reference identifier for a GPS reference instance.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_getRefId(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        TSYNC_RefIdObj    *pObj);

    /*
    * Function:    TSYNC_GR_Reset()
    * Description: Reset the GPS receiver.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        reset         - The reset type
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_reset(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        GL_RESET          reset);

    /*
    * Function:    TSYNC_GR_getAntenna()
    * Description: Get the GPS receiver antenna status.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        status        - Pointer to the status result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_getAntenna(
        TSYNC_BoardHandle hnd,
        unsigned int nInstance,
        GL_ANT_STATUS *status);
/*
    * Function:    TSYNC_GR_getConstSel()
    * Description: Get the Constellation selection.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the Constellation selection
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_getConstSel(
        TSYNC_BoardHandle       hnd,
        unsigned int            nInstance,
        unsigned int            *constellation);

    /*
    * Function:    TSYNC_GR_setConstSel()
    * Description: Send the Constellation selection.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the Constellation selection
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_setConstSel(
        TSYNC_BoardHandle       hnd,
        unsigned int            nInstance,
        unsigned int            constellation);
    /*
    * Function:    TSYNC_GR_getParameter()
    * Description: Get a GPS Receiver specific parameter or control response.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the GPS specific message
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_getParameter(
        TSYNC_BoardHandle       hnd,
        unsigned int            nInstance,
        TSYNC_ReceiverParmObj   *pObj);

    /*
    * Function:    TSYNC_GR_setParameter()
    * Description: Send a GPS Receiver specific parameter or control message.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the GPS specific message
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_setParameter(
        TSYNC_BoardHandle       hnd,
        unsigned int            nInstance,
        TSYNC_ReceiverParmObj   *pObj);

    /*
    * Function:    TSYNC_GR_getQualLog()
    * Description: Get the GPS satellite Qualification Log for the last hour.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the qualification log data result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_getQualLog(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        TSYNC_QualLogObj  *pObj);

    /*
    * Function:    TSYNC_GR_getAlm()
    * Description: Get the almanac
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the returned almanac
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_getAlm(
        TSYNC_BoardHandle      hnd,
        unsigned int           nInstance,
        TSYNC_AlmObj          *pObj);

    /*
    * Function:    TSYNC_GR_setAlm()
    * Description: Set the almanac
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the almanac to be sent
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_setAlm(
        TSYNC_BoardHandle      hnd,
        unsigned int           nInstance,
        TSYNC_AlmObj          *pObj);

    /*
    * Function:    TSYNC_GR_getEphm()
    * Description: Get the ephemeris
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the returned ephemeris
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_getEphm(
        TSYNC_BoardHandle      hnd,
        unsigned int           nInstance,
        TSYNC_EphmObj          *pObj);

    /*
    * Function:    TSYNC_GR_setEphm()
    * Description: Set the ephemeris
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the ephemeris to be sent
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_setEphm(
        TSYNC_BoardHandle      hnd,
        unsigned int           nInstance,
        TSYNC_EphmObj          *pObj);

    /*
    * Function:    TSYNC_GR_setAgpsTime()
    * Description: Apply the current time in the timing system to the GPS
    *              receiver.  Coarsly accurate time, together with position,
    *              allows the receiver to use A-GPS almanac and ephemeris data.
    *              The timing system time can be set by NTP or by hand.  The
    *              UTC-GPS offset also needs to be set before setting time.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_setAgpsTime(
        TSYNC_BoardHandle      hnd,
        unsigned int           nInstance);

    /*
    * Function:    TSYNC_GR_getAgpsServerState()
    * Description: Get whether the GPS component is collecting A-GPS data
    *              or not.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the returned A-GPS server state
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_getAgpsServerState(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_AgpsServerStateObj *pObj);

    /*
    * Function:    TSYNC_GR_setAgpsServerState()
    * Description: Set the GPS component to collect A-GPS data or not.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the A-GPS server state to be sent
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_setAgpsServerState(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_AgpsServerStateObj *pObj);

   /*
    * Function:    TSYNC_GR_getIono()
    * Description: Get the ionosphere
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the returned ionosphere
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_getIono(
        TSYNC_BoardHandle      hnd,
        unsigned int           nInstance,
        TSYNC_IonoObj          *pObj);

   /*
    * Function:    TSYNC_GR_getUtc()
    * Description: Get the UTC (time correction)
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the returned ionosphere
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GR_getUtc(
        TSYNC_BoardHandle      hnd,
        unsigned int           nInstance,
        TSYNC_UtcObj          *pObj);

    /* IRIG Reference Component ==============================================*/

    /*
    * Function:    TSYNC_IR_getOffset()
    * Description: Get the IRIG reference's 1PPS input offset.  Offset is in
    *              nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: nOffset       - The offset information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IR_getOffset(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *nOffset);

    /*
    * Function:    TSYNC_IR_setOffset()
    * Description: Set the IRIG reference's 1PPS input offset.  Offset is in
    *              nanoseconds from -500 msec to +500 msec.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        nOffset       - The offset information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IR_setOffset(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int               nOffset);

    /*
    * Function:    TSYNC_IR_getValidity()
    * Description: Get the IRIG validity structure.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: bTimeValid    - The time reference result
    *        bPpsValid     - The pps reference result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IR_getValidity(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *bTimeValid,
        int               *bPpsValid);

    /*
    * Function:    TSYNC_IR_getMode()
    * Description: Get the IRIG mode.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: mode          - The receiver mode result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IR_getMode(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        IL_MODE           *mode);

    /*
    * Function:    TSYNC_IR_setMode()
    * Description: Set the IRIG mode.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        mode          - The receiver mode information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IR_setMode(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        IL_MODE           mode);

    /*
    * Function:    TSYNC_IR_getFormat()
    * Description: Get the IRIG format.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: format        - The format result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IR_getFormat(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        IL_FMT            *format);

    /*
    * Function:    TSYNC_IR_setFormat()
    * Description: Set the IRIG format.  Settable only when in manual mode.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        format        - The format information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IR_setFormat(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        IL_FMT            format);

    /*
    * Function:    TSYNC_IR_getMod()
    * Description: Get the IRIG modulation.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: mod           - The modulation result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IR_getMod(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        IL_MOD            *mod);

    /*
    * Function:    TSYNC_IR_setMod()
    * Description: Set the IRIG modulation.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        mod           - The modulation
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IR_setMod(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        IL_MOD            mod);

    /*
    * Function:    TSYNC_IR_getFreq()
    * Description: Get the IRIG carrier frequency.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: freq          - The frequency result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IR_getFreq(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        IL_FRQ            *freq);

    /*
    * Function:    TSYNC_IR_setFreq()
    * Description: Set the IRIG carrier frequency.  Settable only when in
    *              manual mode.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        freq          - The frequency information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IR_setFreq(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        IL_FRQ            freq);

    /*
    * Function:    TSYNC_IR_getCodedExpr()
    * Description: Get the IRIG Coded Expression.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: ce            - The Coded Expression result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IR_getCodedExpr(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        IL_CE             *ce);

    /*
    * Function:    TSYNC_IR_setCodedExpr()
    * Description: Set the IRIG Coded Expression.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        ce            - The Coded Expression information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IR_setCodedExpr(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        IL_CE             ce);

    /*
    * Function:    TSYNC_IR_getCtrlField()
    * Description: Get the IRIG Control Field.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: cf            - The Control Field result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IR_getCtrlField(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        IL_CF             *cf);

    /*
    * Function:    TSYNC_IR_setCtrlField()
    * Description: Set the IRIG Control Field.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        cf            - The Control Field information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IR_setCtrlField(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        IL_CF             cf);

    /*
    * Function:    TSYNC_IR_getMessage()
    * Description: Get the latest IRIG input message.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the message result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IR_getMessage(
        TSYNC_BoardHandle     hnd,
        unsigned int          nInstance,
        TSYNC_IRIGMessageObj *pObj);

    /*
    * Function:    TSYNC_IR_setMessage()
    * Description: Set the latest IRIG input message.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the message information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IR_setMessage(
        TSYNC_BoardHandle     hnd,
        unsigned int          nInstance,
        TSYNC_IRIGMessageObj *pObj);

    /*
    * Function:    TSYNC_IR_getNumInst()
    * Description: Get number of IRIG references instances present in the
    *              system.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: nInstances    - The number of instances result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IR_getNumInst(
        TSYNC_BoardHandle  hnd,
        unsigned int      *nInstances);

    /*
    * Function:    TSYNC_IR_getCfData()
    * Description: Get the latest IRIG Control Field data received.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the control field information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IR_getCfData(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_IRIGCfDataObj *pObj);

    /*
    * Function:    TSYNC_IR_getLocal()
    * Description: Get the IRIG reference's local time zone and DST rule.
    *              Timezone and DST offsets are in seconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the Local Clock result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IR_getLocal(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_LocalClockObj *pObj);

    /*
    * Function:    TSYNC_IR_setLocal()
    * Description: Set the IRIG reference's local time zone and DST rule.
    *              Timezone and DST offsets are in seconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the Local Clock information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IR_setLocal(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_LocalClockObj *pObj);

    /*
    * Function:    TSYNC_IR_getTimeScale()
    * Description: Get the IRIG reference's time scale.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the time scale result
    *
    * Returns: (TSYNC_SUCCESS) Success

    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IR_getTimeScale(
        TSYNC_BoardHandle   hnd,
        unsigned int        nInstance,
        TSYNC_TimeScaleObj *pObj);

    /*
    * Function:    TSYNC_IR_setTimeScale()
    * Description: Set the IRIG reference's time scale.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the time scale information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IR_setTimeScale(
        TSYNC_BoardHandle   hnd,
        unsigned int        nInstance,
        TSYNC_TimeScaleObj *pObj);

    /*
    * Function:    TSYNC_IR_getRefId()
    * Description: Get reference identifier for an IRIG reference instance.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IR_getRefId(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        TSYNC_RefIdObj    *pObj);

    /*
    * Function:    TSYNC_IR_getType()
    * Description: Get the IRIG reference's type.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the time scale information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IR_getType(
        TSYNC_BoardHandle hnd,
        unsigned int nInstance,
        IL_MOD *type);

    /* STANAG/HaveQuick Reference Component ==================================*/

    /*
    * Function:    TSYNC_QR_getOffset()
    * Description: Get the STANAG/HaveQuick reference's 1PPS input offset.
    *              Offset is in nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: nOffset       - The offset information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_getOffset(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *nOffset);

    /*
    * Function:    TSYNC_QR_setOffset()
    * Description: Set the STANAG/HaveQuick reference's 1PPS input offset.
    *              Offset is in nanoseconds from -500 msec to +500 msec.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        nOffset       - The offset information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_setOffset(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int               nOffset);

    /*
    * Function:    TSYNC_QR_getExtOffset()
    * Description: Get the STANAG/HaveQuick extended reference's 1PPS input offset.
    *              Offset is in nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: nOffset       - The offset information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_getExtOffset(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *nOffset);

    /*
    * Function:    TSYNC_QR_setExtOffset()
    * Description: Set the STANAG/HaveQuick extended reference's 1PPS input offset.
    *              Offset is in nanoseconds from -500 msec to +500 msec.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        nOffset       - The offset information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_setExtOffset(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int               nOffset);

    /*
    * Function:    TSYNC_QR_getValidity()
    * Description: Get the STANAG/HaveQuick validity structure.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: bTimeValid    - The time reference result
    *        bPpsValid     - The pps reference result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_getValidity(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *bTimeValid,
        int               *bPpsValid);

    /*
    * Function:    TSYNC_QR_getFormat()
    * Description: Get the STANAG/HaveQuick format.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: format        - The format result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_getFormat(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        QL_FMT            *format);

    /*
    * Function:    TSYNC_QR_setFormat()
    * Description: Set the STANAG/HaveQuick format.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        format        - The format information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_setFormat(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        QL_FMT            format);

   /*
    * Function:    TSYNC_QR_getExtFormat()
    * Description: Get the STANAG/HaveQuick format.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: format        - The format result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_getExtFormat(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        QL_FMT            *format);

    /*
    * Function:    TSYNC_QR_setExtFormat()
    * Description: Set the STANAG/HaveQuick format.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        format        - The format information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_setExtFormat(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        QL_FMT            format);

    /*
    * Function:    TSYNC_QR_getLocal()
    * Description: Get the STANAG/HaveQuick reference's local time zone and DST
    *              rule.  Timezone and DST offsets are in seconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the Local Clock result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_getLocal(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_LocalClockObj *pObj);

    /*
    * Function:    TSYNC_QR_setLocal()
    * Description: Set the STANAG/HaveQuick reference's local time zone and DST
    *              rule.  Timezone and DST offsets are in seconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the Local Clock information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_setLocal(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_LocalClockObj *pObj);

    /*
    * Function:    TSYNC_QR_getTimeScale()
    * Description: Get the STANAG/HaveQuick reference's time scale.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the time scale result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_getTimeScale(
        TSYNC_BoardHandle   hnd,
        unsigned int        nInstance,
        TSYNC_TimeScaleObj *pObj);

    /*
    * Function:    TSYNC_QR_setTimeScale()
    * Description: Set the STANAG/HaveQuick reference's time scale.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the time scale information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_setTimeScale(
        TSYNC_BoardHandle   hnd,
        unsigned int        nInstance,
        TSYNC_TimeScaleObj *pObj);

 /*
    * Function:    TSYNC_QR_getExtTimeScale()
    * Description: Get the STANAG/HaveQuick Extended reference's time scale.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the time scale result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_getExtTimeScale(
        TSYNC_BoardHandle   hnd,
        unsigned int        nInstance,
        TSYNC_TimeScaleObj *pObj);

    /*
    * Function:    TSYNC_QR_setExtTimeScale()
    * Description: Set the STANAG/HaveQuick Extended reference's time scale.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the time scale information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_setExtTimeScale(
        TSYNC_BoardHandle   hnd,
        unsigned int        nInstance,
        TSYNC_TimeScaleObj *pObj);

    /*
    * Function:    TSYNC_QR_getRefId()
    * Description: Get reference identifier for a STANAG/HaveQuick reference
    *              instance.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_getRefId(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        TSYNC_RefIdObj    *pObj);

    /*
    * Function:    TSYNC_QR_getNumInst()
    * Description: Get number of STANAG/HaveQuick reference instances present
    *              in the system.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: nInstances    - The number of instances result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_getNumInst(
        TSYNC_BoardHandle  hnd,
        unsigned int      *nInstances);

    /*
    * Function:    TSYNC_QR_getTfd()
    * Description: Set the STANAG/HaveQuick reference's time fault discrete.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: tfd           - The time fault discrete information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_getTfd(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int     *tfd);

    /*
    * Function:    TSYNC_QR_setTfd()
    * Description: Set the STANAG/HaveQuick reference's time fault discrete.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        tfd           - The time fault discrete result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_setTfd(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      tfd);

    /*
    * Function:    TSYNC_QR_getTfdState()
    * Description: Set the STANAG/HaveQuick reference's time fault discrete state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: tfd           - The time fault discrete state information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_getTfdState(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int     *tfd);

    /*
    * Function:    TSYNC_QR_setTfdState()
    * Description: Set the STANAG/HaveQuick reference's time fault discrete state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        tfd           - The time fault discrete state result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_setTfdState(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      tfd);

    /*
    * Function:    TSYNC_QR_getBs()
    * Description: Set the STANAG/HaveQuick reference's Bit synchnonization.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: bs            - The Bit synchnonization information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_getBs(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int     *bs);

    /*
    * Function:    TSYNC_QR_setRefSelection()
    * Description: Set the STANAG/HaveQuick reference's Ref Selection.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        refsel        - The Reference selection result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_setRefSelection(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      refsel);
    /*
    * Function:    TSYNC_QR_getRefSelection()
    * Description: Set the STANAG/HaveQuick reference's Ref Selection.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: refsel        - The Reference Selection information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_getRefSelection(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int     *refsel);

    /*
    * Function:    TSYNC_QR_getSelectedRef()
    * Description: Set the STANAG/HaveQuick reference's Selected Ref.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: refsel        - The Reference Selection information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_getSelectedRef(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int     *refsel);

    /*
    * Function:    TSYNC_QR_setBs()
    * Description: Set the STANAG/HaveQuick reference's Bit synchnonization.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        bs            - The Bit synchnonization result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_setBs(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      bs);

    /*
    * Function:    TSYNC_QR_getTfom()
    * Description: Get the STANAG/HaveQuick reference's TFOM.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: tfom          - The TFOM result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_getTfom(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int     *tfom);
    /*
    * Function:    TSYNC_QR_getExtTfom()
    * Description: Get the STANAG/HaveQuick extended reference's TFOM.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: tfom          - The TFOM result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_getExtTfom(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int     *tfom);

   /*
    * Function:    TSYNC_QR_getElecType()
    * Description: Get the reference's electrical type.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstances    - The instance number
    *   OUT: et            - The electrical type result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_getElecType(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstances,
        ELEC_TYPE         *et);

    /*
    * Function:    TSYNC_QR_setElecType()
    * Description: Set the reference's electrical type.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstances    - The instance number
    *        et            - The electrical type information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_setElecType (
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstances,
        ELEC_TYPE          et);

   /*
    * Function:    TSYNC_QR_getExtElecType()
    * Description: Get the extended reference's electrical type.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstances    - The instance number
    *   OUT: et            - The electrical type result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_getExtElecType(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstances,
        ELEC_TYPE         *et);

    /*
    * Function:    TSYNC_QR_setExtElecType()
    * Description: Set the extended reference's electrical type.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstances    - The instance number
    *        et            - The electrical type information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_setExtElecType (
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstances,
        ELEC_TYPE          et);


    /*
    * Function:    TSYNC_QR_getPpsElecType()
    * Description: Get the 1PPS reference's electrical type.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstances    - The instance number
    *   OUT: et            - The electrical type result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_getPpsElecType(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstances,
        ELEC_TYPE         *et);

    /*
    * Function:    TSYNC_QR_setPpsElecType()
    * Description: Set the 1PPS reference's electrical type.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstances    - The instance number
    *        et            - The electrical type information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_setPpsElecType (
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstances,
        ELEC_TYPE          et);

 /*
    * Function:    TSYNC_QR_getPpsOffset()
    * Description: Get the 1PPS reference's input offset.  Offset is in
    *              nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: nOffset       - The offset result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_getPpsOffset(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *nOffset);

    /*
    * Function:    TSYNC_QR_setPpsOffset()
    * Description: Get the 1PPS reference's 1PPS input offset.  Offset is in
    *              nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        nOffset       - The offset
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_setPpsOffset(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int               nOffset);

    /*
    * Function:    TSYNC_QR_getPpsEdge()
    * Description: Get the 1PPS reference's active edge setting.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: edge          - The edge result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_getPpsEdge(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        EDGE              *edge);

    /*
    * Function:    TSYNC_QR_setPpsEdge()
    * Description: Set the 1PPS reference's active edge setting.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        edge          - The edge information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_setPpsEdge(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        EDGE              edge);

    /*
    * Function:    TSYNC_QR_getTfomThreshold()
    * Description: Get the STANAG/HaveQuick reference's TFOM threshold.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: tfom          - The TFOM result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_getTfomThreshold(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int     *tfom);

    /*
    * Function:    TSYNC_QR_setTfomThreshold()
    * Description: Set the TFOM threshold setting.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        tfom          - The tfom threshold information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_setTfomThreshold(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      tfom);

    /*
    * Function:    TSYNC_QR_getExtTfomThreshold()
    * Description: Get the STANAG/HaveQuick reference's TFOM threshold.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: tfom          - The TFOM result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_getExtTfomThreshold(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int     *tfom);

    /*
    * Function:    TSYNC_QR_setExtTfomThreshold()
    * Description: Set the TFOM threshold setting.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        tfom          - The tfom threshold information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QR_setExtTfomThreshold(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      tfom);

    /* ASCII Output Component ================================================*/

    /*
    * Function:    TSYNC_AP_getSigCtrl()
    * Description: Get the ASCII output's signature control state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: sig           - The signature control result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AP_getSigCtrl(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        SIG_CTL           *sig);

    /*
    * Function:    TSYNC_AP_setSigCtrl()
    * Description: Set the ASCII output's signature control state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        sig           - The signature control information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AP_setSigCtrl(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        SIG_CTL           sig);

    /*
    * Function:    TSYNC_AP_getLocal()
    * Description: Get the ASCII output's local time zone and DST rule.
    *              Timezone and DST offsets are in seconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the Local Clock result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AP_getLocal(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_LocalClockObj *pObj);


    /*
    * Function:    TSYNC_AP_setLocal()
    * Description: Set the ASCII output's local time zone and DST rule.
    *              Timezone and DST offsets are in seconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the Local Clock information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AP_setLocal(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_LocalClockObj *pObj);

    /*
    * Function:    TSYNC_AP_getTimeScale()
    * Description: Get the ASCII output's time scale.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the time scale result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AP_getTimeScale(
        TSYNC_BoardHandle   hnd,
        unsigned int        nInstance,
        TSYNC_TimeScaleObj *pObj);

    /*
    * Function:    TSYNC_AP_setTimeScale()
    * Description: Set the ASCII output's time scale.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the time scale information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AP_setTimeScale(
        TSYNC_BoardHandle   hnd,
        unsigned int        nInstance,
        TSYNC_TimeScaleObj *pObj);

    /*
    * Function:    TSYNC_AP_getFormat()
    * Description: Get the ASCII output time code format.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: format        - The format result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AP_getFormat(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        AL_FMT            *format);

    /*
    * Function:    TSYNC_AP_setFormat()
    * Description: Set the ASCII output time code format.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        format        - The format information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AP_setFormat(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        AL_FMT            *format);

    /*
    * Function:    TSYNC_AP_getMode()
    * Description: Get the ASCII output mode.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: mode          - The mode
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AP_getMode(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        AL_OUT_MODE       *mode);

    /*
    * Function:    TSYNC_AP_setMode()
    * Description: Set the ASCII output mode.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        mode          - The mode information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AP_setMode(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        AL_OUT_MODE        mode);

    /*
    * Function:    TSYNC_AP_getReqChar()
    * Description: Get the ASCII output request character.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        req           - The request character result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AP_getReqChar(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        char              *req);

    /*
    * Function:    TSYNC_AP_setReqChar()
    * Description: Set the ASCII output request character.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        req           - The request character information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AP_setReqChar(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        char               req);

    /*
    * Function:    TSYNC_AP_getUartCfg()
    * Description: Get the ASCII output UART configuration.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pCfg          - The UART configuration
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AP_getUartCfg(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        UD_CFG            *pCfg);

    /*
    * Function:    TSYNC_AP_setUartCfg()
    * Description: Set the ASCII output UART configuration.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pCfg          - The UART configuration
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AP_setUartCfg(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        UD_CFG            *pCfg);

    /*
    * Function:    TSYNC_AP_getNumInst()
    * Description: Get number of ASCII output instances present in the system.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: nInstances    - The number of instances result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AP_getNumInst(
        TSYNC_BoardHandle  hnd,
        unsigned int      *nInstances);

    /*
    * Function:    TSYNC_AP_getSource()
    * Description: Get the ASCII output's Message Source.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: source        - The Message Source result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AP_getSource(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        AO_SOURCE         *source);

    /*
    * Function:    TSYNC_AP_getOffset()
    * Description: Get the ASCII output's offset.  Offset is in nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: nOffset       - The offset result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AP_getOffset(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *nOffset);

    /*
    * Function:    TSYNC_AP_setOffset()
    * Description: Set the ASCCI output's offset.  Offset is in nanoseconds from
    *              -500 msec to +500 msec.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        nOffset       - The offset information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_AP_setOffset(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int               nOffset);
		
    /* IRIG Output Component =================================================*/

    /*
    * Function:    TSYNC_IP_getSigCtrl()
    * Description: Get the IRIG output's signature control state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: sig           - The signature control result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_getSigCtrl(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        SIG_CTL           *sig);

    /*
    * Function:    TSYNC_IP_setSigCtrl()
    * Description: Set the IRIG output's signature control state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        sig           - The signature control information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_setSigCtrl(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        SIG_CTL           sig);

    /*
    * Function:    TSYNC_IP_getOffset()
    * Description: Get the IRIG output's offset.  Offset is in nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: nOffset       - The offset result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_getOffset(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *nOffset);

    /*
    * Function:    TSYNC_IP_setOffset()
    * Description: Set the IRIG output's offset.  Offset is in nanoseconds from
    *              -500 msec to +500 msec.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        nOffset       - The offset information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_setOffset(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int               nOffset);

    /*
    * Function:    TSYNC_IP_getLocal()
    * Description: Get the IRIG output's local time zone and DST rule.
    *              Timezone and DST offsets are in seconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the Local Clock result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_getLocal(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_LocalClockObj *pObj);

    /*
    * Function:    TSYNC_IP_setLocal()
    * Description: Set the IRIG output's local time zone and DST rule.
    *              Timezone and DST offsets are in seconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the Local Clock information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_setLocal(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_LocalClockObj *pObj);

    /*
    * Function:    TSYNC_IP_getFormat()
    * Description: Get the IRIG output format.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: format        - The format result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_getFormat(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        IL_FMT            *format);

    /*
    * Function:    TSYNC_IP_setFormat()
    * Description: Set the IRIG output format.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        format        - The format information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_setFormat(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        IL_FMT            format);

    /*
    * Function:    TSYNC_IP_getAmplitude()
    * Description: Get the IRIG output amplitude.
    *              Amplitude is in range of 3 - 255.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: amp           - The amplitude result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_getAmplitude(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        unsigned int      *amp);

    /*
    * Function:    TSYNC_IP_setAmplitude()
    * Description: Set the IRIG output amplitude.
    *              Amplitude is in range of 3 - 255.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        amp           - The amplitude information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_setAmplitude(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      amp);

    /*
    * Function:    TSYNC_IP_getMod()
    * Description: Get the IRIG outputmodulation.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: mod           - The modulation result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_getMod(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        IL_MOD            *mod);

    /*
    * Function:    TSYNC_IP_setMod()
    * Description: Set the IRIG outputmodulation.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        mod           - The modulation
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_setMod(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        IL_MOD            mod);

    /*
    * Function:    TSYNC_IP_getFreq()
    * Description: Get the IRIG outputfrequency.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: freq          - The frequency result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_getFreq(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        IL_FRQ            *freq);

    /*
    * Function:    TSYNC_IP_setFreq()
    * Description: Set the IRIG outputfrequency.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        freq          - The frequency information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_setFreq(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        IL_FRQ            freq);

    /*
    * Function:    TSYNC_IP_getCodedExpr()
    * Description: Get the IRIG output Coded Expression.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: ce            - The Coded Expression result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_getCodedExpr(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        IL_CE             *ce);

    /*
    * Function:    TSYNC_IP_setCodedExpr()
    * Description: Set the IRIG output Coded Expression.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        ce            - The Coded Expression information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_setCodedExpr(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        IL_CE             ce);

    /*
    * Function:    TSYNC_IP_getCtrlField()
    * Description: Get the IRIG output Control Field.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: cf            - The Control Field result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_getCtrlField(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        IL_CF             *cf);

    /*
    * Function:    TSYNC_IP_setCtrlField()
    * Description: Set the IRIG output Control Field.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        cf            - The Control Field information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_setCtrlField(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        IL_CF             cf);

    /*
    * Function:    TSYNC_IP_getMessage()
    * Description: Get the latest IRIG output message.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the message information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_getMessage(
        TSYNC_BoardHandle     hnd,
        unsigned int          nInstance,
        TSYNC_IRIGMessageObj *pObj);

    /*
    * Function:    TSYNC_IP_setMessage()
    * Description: Set the IRIG output message.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the message information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_setMessage(
        TSYNC_BoardHandle     hnd,
        unsigned int          nInstance,
        TSYNC_IRIGMessageObj *pObj);

    /*
    * Function:    TSYNC_IP_getCfData()
    * Description: Get the latest IRIG output control field data.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the control field information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_getCfData(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_IRIGCfDataObj *pObj);

    /*
    * Function:    TSYNC_IP_setCfData()
    * Description: Set the IRIG output control field data manually.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the control field information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_setCfData(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_IRIGCfDataObj *pObj);

    /*
    * Function:    TSYNC_IP_getNumInst()
    * Description: Get number of IRIG output instances present in the system.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: nInstances    - The number of instances result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_getNumInst(
        TSYNC_BoardHandle  hnd,
        unsigned int      *nInstances);

    /*
    * Function:    TSYNC_IP_getPhase()
    * Description: Get the IRIG output's current phase adjustment.  This
    *              feature is only available to Spectracom for testing.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: phase         - The phase adjustment result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_getPhase(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        unsigned int      *phase);

    /*
    * Function:    TSYNC_IP_setPhase()
    * Description: Set the IRIG output's phase adjustment.  This feature is
    *              only available to Spectracom for testing.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        sig           - The signature control information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_setPhase(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      phase);

    /*
    * Function:    TSYNC_IP_getPhaseErr()
    * Description: Get the IRIG output's current phase error.  This feature is
    *              only available to Spectracom for testing.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: phErr         - The phase error result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_getPhaseErr(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *phErr);

    /*
    * Function:    TSYNC_IP_getTimeScale()
    * Description: Get the IRIG output's time scale.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the time scale result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_getTimeScale(
        TSYNC_BoardHandle   hnd,
        unsigned int        nInstance,
        TSYNC_TimeScaleObj *pObj);

    /*
    * Function:    TSYNC_IP_setTimeScale()
    * Description: Set the IRIG output's time scale.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the time scale information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_setTimeScale(
        TSYNC_BoardHandle   hnd,
        unsigned int        nInstance,
        TSYNC_TimeScaleObj *pObj);

    /*
    * Function:    TSYNC_IP_getType()
    * Description: Get the IRIG output's type.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the time scale information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_IP_getType(
        TSYNC_BoardHandle hnd,
        unsigned int nInstance,
        IL_MOD *type);

    /* PTP Reference Component ===============================================*/

    /*
    * Function:    TSYNC_PTR_getModuleInfo()
    * Description: Gets the PTP module's version and build date.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - The module's version and build date
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getModuleInfo(
        TSYNC_BoardHandle       hnd,
        unsigned int            nInstance,
        TSYNC_PTPModuleInfoObj *pObj);

    /*
    * Function:    TSYNC_PTR_getEthernetItf()
    * Description: Gets Ethernet settings for the PTP module.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - The module's Ethernet interface settings
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getEthernetItf(
        TSYNC_BoardHandle        hnd,
        unsigned int             nInstance,
        TSYNC_PTPEthernetItfObj *pObj);

    /*
    * Function:    TSYNC_PTR_setEthernetItf()
    * Description: Sets Ethernet settings for the PTP module.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - The module's new Ethernet interface settings
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_setEthernetItf(
        TSYNC_BoardHandle        hnd,
        unsigned int             nInstance,
        TSYNC_PTPEthernetItfObj *pObj);


// ----------------------------YS ---------------------------------------------------------
/*
    * Function:    TSYNC_PTR_getSyncEthItf()
    * Description: Gets Ethernet settings for the PTP module.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - The module's Sync Ethernet interface settings
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getSyncEthItf(
        TSYNC_BoardHandle        hnd,
        unsigned int             nInstance,
        TSYNC_PTPSyncEStatusObj *pObj);

    /*
    * Function:    TSYNC_PTR_setSyncEthItf()
    * Description: Sets sync Ethernet settings for the PTP module.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - The module's new Sync Ethernet interface settings
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_setSyncEthItf(
        TSYNC_BoardHandle        hnd,
        unsigned int             nInstance,
        TSYNC_PTPSyncEStatusObj *pObj);



//-----------------------------------------------------------------------------------------
    /*
    * Function:    TSYNC_PTR_getClockSettings()
    * Description: Gets the module's clock settings.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - The module's new clock settings
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getClockSettings(
        TSYNC_BoardHandle        hnd,
        unsigned int             nInstance,
        TSYNC_PTPClkSettingsObj *pObj);

    /*
    * Function:    TSYNC_PTR_setClockSettings()
    * Description: Sets the module's clock settings.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - The module's clock settings
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_setClockSettings(
        TSYNC_BoardHandle        hnd,
        unsigned int             nInstance,
        TSYNC_PTPClkSettingsObj *pObj);


    /*
    * Function:    TSYNC_PTR_getUnitSettings()
    * Description: Gets general PTP settings for the module.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - The module's general PTP settings
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getUnitSettings(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_PTPUnitSettingsObj *pObj);

    /*
    * Function:    TSYNC_PTR_setUnitSettings()
    * Description: Sets general PTP settings for the module.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - The module's new general PTP settings
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_setUnitSettings(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_PTPUnitSettingsObj *pObj);

    /*
    * Function:    TSYNC_PTR_getPortState()
    * Description: Gets the state of a port on the module.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - The state of a port on the module
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getPortState(
        TSYNC_BoardHandle      hnd,
        unsigned int           nInstance,
        TSYNC_PTPPortStateObj *pObj);

    /*
    * Function:    TSYNC_PTR_setPortState()
    * Description: Gets the state of a port on the module.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - The state of a port on the module
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_setPortState(
        TSYNC_BoardHandle      hnd,
        unsigned int           nInstance,
        TSYNC_PTPPortStateObj *pObj);


    /*
    * Function:    TSYNC_PTR_getPortSettings()
    * Description: Gets various settings of a port on the module.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Various settings of a port on the module
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getPortSettings(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_PTPPortSettingsObj *pObj);

    /*
    * Function:    TSYNC_PTR_setPortSettings()
    * Description: Sets various settings of a port on the module.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Various settings of a port on the module
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_setPortSettings(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_PTPPortSettingsObj *pObj);


//------------------------------------YS------------------------------------
/*
    * Function:    TSYNC_PTR_setVLAN()
    * Description: Sets the VLAN interface settings.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Various settings of a port on the module
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_setVLAN(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_PTPVLANObj *pObj);
    /*
    * Function:    TSYNC_PTR_getVLAN()
    * Description: Gets the VLAN interface settings.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - The Master clock's properties.
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getVLAN(
        TSYNC_BoardHandle       hnd,
        unsigned int            nInstance,
        TSYNC_PTPVLANObj *pObj);

    /*
    * Function:    TSYNC_PTR_setUnctMasterAdd()
    * Description: Sets the unicast parameters provided by the clock and adds a master cmocl to the list of master clocks.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Various settings of a port on the module
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_setUnctMasterAdd(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_PTPUnctMasterAddObj *pObj);
   /*
    * Function:    TSYNC_PTR_getUnctMasterAdd()
    * Description: Gets the Master clock's propertirs  .
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - The Master clock's properties.
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getUnctMasterAdd(
        TSYNC_BoardHandle       hnd,
        unsigned int            nInstance,
        TSYNC_PTPUnctMasterAddObj *pObj);

    /*
    * Function:    TSYNC_PTR_getUnctSlaveProp()
    * Description: Gets the unicast mode properties of a Slave-Only unit  .
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - The unicast mode properties of a Slave-Only unit.
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getUnctSlaveProp(
        TSYNC_BoardHandle       hnd,
        unsigned int            nInstance,
         TSYNC_PTPUnctSlavePropObj *pObj);

    /*
    * Function:    TSYNC_PTR_getUnctMasterProp()
    * Description: Gets the unicast mode properties of a Master-Only unit  .
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - The unicast mode properties of a Master-Only unit.
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getUnctMasterProp(
        TSYNC_BoardHandle       hnd,
        unsigned int            nInstance,
         TSYNC_PTPUnctMasterPropObj *pObj);


    /*
    * Function:    TSYNC_PTR_getClkQuality()
    * Description: Gets the module's reported clock quality information.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - The module's reported clock quality information.
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getClkQuality(
        TSYNC_BoardHandle       hnd,
        unsigned int            nInstance,
        TSYNC_PTPClkQualityObj *pObj);

    /*
    * Function:    TSYNC_PTR_getTimeProperties()
    * Description: Gets the module's reported time properties.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - The module's reported time properties
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getTimeProperties(
        TSYNC_BoardHandle     hnd,
        unsigned int          nInstance,
        TSYNC_PTPTimePropObj *pObj);

    /*
    * Function:    TSYNC_PTR_getParentProperties()
    * Description: Gets the module's parent properties dataset.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - The module's parent properties dataset
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getParentProperties(
        TSYNC_BoardHandle       hnd,
        unsigned int            nInstance,
        TSYNC_PTPParentPropObj *pObj);

    /*
    * Function:    TSYNC_PTR_getGrandmasterProperties()
    * Description: Gets the module's grandmaster properties dataset.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - The module's grandmaster properties dataset
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getGrandmasterProperties(
        TSYNC_BoardHandle            hnd,
        unsigned int                 nInstance,
        TSYNC_PTPGrandmasterPropObj *pObj);

    /*
    * Function:    TSYNC_PTR_getTODEnabled()
    * Description: Gets whether the module outputs a TOD.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: bTodEnabled   - Whether the module outputs a TOD
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getTODSettings(
        TSYNC_BoardHandle      hnd,
        unsigned int           nInstance,
        TSYNC_PTPTODSettingsObj *pObj);

    /*
    * Function:    TSYNC_PTR_setTODEnabled()
    * Description: Sets whether the module outputs a TOD.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        bTodEnabled   - Whether the module outputs a TOD
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_setTODSettings(
        TSYNC_BoardHandle      hnd,
        unsigned int           nInstance,
        TSYNC_PTPTODSettingsObj *pObj);

    /*
    * Function:    TSYNC_PTR_getPPSEnabled()
    * Description: Gets whether the module outputs a PPS when it's a slave.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: bPpsEnabled   - Whether the module outputs a PPS when it's a slave
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getPPSEnabled(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int              *bPpsEnabled);

    /*
    * Function:    TSYNC_PTR_setPPSEnabled()
    * Description: Sets whether the module outputs a PPS when it's a slave.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        bPpsEnabled   - Whether the module outputs a PPS when it's a slave
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_setPPSEnabled(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int               bPpsEnabled);

    /*
    * Function:    TSYNC_PTR_getPPSRisingEdge()
    * Description: Gets if the module's output PPS is rising-edge or not.
    *
    * Parameters:
    *   IN:  hnd            - Board handle
    *        nInstance      - The instance number
    *   OUT: bPpsRisingEdge - Whether the module's PPS is risin-edge or not
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getPPSRisingEdge(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int              *bPpsRisingEdge);

    /*
    * Function:    TSYNC_PTR_setPPSRisingEdge()
    * Description: Sets if the module's output PPS is rising-edge or not.
    *
    * Parameters:
    *   IN:  hnd            - Board handle
    *        nInstance      - The instance number
    *        bPpsRisingEdge - Whether the module's PPS is risin-edge or not
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_setPPSRisingEdge(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int               bPpsRisingEdge);

    /*
    * Function:    TSYNC_PTR_saveSettingsToROM()
    * Description: Saves any settings that have been changed in the PTP module
    *              to the module's ROM.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_saveSettingsToROM(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance);

    /*
    * Function:    TSYNC_PTR_resetModule()
    * Description: Resets the PTP module, based on the type of reset requested.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - PTP instance requested
    *        resetType     - The type of reset requested.
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_resetModule(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        PTL_RESET         resetType);

    /*
    * Function:    TSYNC_PTR_getNumInst()
    * Description: Gets the number of PTP modules present in the system.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: nInstances    - The number of PTP modules present in the system
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getNumInst(
        TSYNC_BoardHandle hnd,
        unsigned int     *nInstances);

    /*
    * Function:    TSYNC_PTR_reinitModule()
    * Description: Reinitializes PTP Module.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_reinitModule(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance);

   /*
    * Function:    TSYNC_PTR_getValidity()
    * Description: Get the PTR validity structure.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: bTimeValid    - The time reference result
    *        bPpsValid     - The pps reference result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getValidity(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *bTimeValid,
        int               *bPpsValid);

   /*
    * Function:    TSYNC_PTR_getMode()
    * Description: Gets the module's current operational mode.
    *
    * Parameters:
    *   IN:  hnd            - Board handle
    *        nInstance      - The instance number
    *   OUT: bMode          - Current Operational Mode
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getMode(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int              *bMode);

    /*
    * Function:    TSYNC_PTR_setMode()
    * Description: Sets the module's current operational mode.
    *
    * Parameters:
    *   IN:  hnd            - Board handle
    *        nInstance      - The instance number
    *        bMode          - New Operational Mode
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_setMode(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int               bMode);


    /*
    * Function:    TSYNC_PTR_getMacAddr()
    * Description: Sets the module's current MAC Address.
    *
    * Parameters:
    *   IN:  hnd            - Board handle
    *        nInstance      - The instance number
    *        pObj           - MAC Address object
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getMacAddr(
        TSYNC_BoardHandle     hnd,
        unsigned int          nInstance,
        TSYNC_PTPMacAddrObj  *pObj);


    /*
    * Function:    TSYNC_PTR_setMacAddr()
    * Description: Sets the module's current MAC Address.
    *
    * Parameters:
    *   IN:  hnd            - Board handle
    *        nInstance      - The instance number
    *        pObj           - MAC Address object
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_setMacAddr(
        TSYNC_BoardHandle        hnd,
        unsigned int             nInstance,
        TSYNC_PTPMacAddrPwObj   *pObj);

    /*
    * Function:    TSYNC_PTR_getMasterActive()
    * Description: Gets the Master Active state.
    *
    * Parameters:
    *   IN:  hnd            - Board handle
    *        nInstance      - The instance number
    *        pObj           - MAC Address object
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getMasterActive(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int              *bMasterActive);

    /*
    * Function:    TSYNC_PTR_getModuleStatus()
    * Description: Gets the Module Status
    *
    * Parameters:
    *   IN:  hnd            - Board handle
    *        nInstance      - The instance number
    *        bModuleStatus  - Module Status (Reset Cause)
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getModuleStatus(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int              *bModuleStatus);

    /*
    * Function:    TSYNC_PTR_getUserDesc()
    * Description: Gets the User Description strings
    *
    * Parameters:
    *   IN:  hnd            - Board handle
    *        nInstance      - The instance number
    *        pObj           - User Description object
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getUserDesc(
        TSYNC_BoardHandle        hnd,
        unsigned int             nInstance,
        TSYNC_PTPUserDescObj    *pObj);

    /*
    * Function:    TSYNC_PTR_setUserDesc()
    * Description: Sets the User Description strings
    *
    * Parameters:
    *   IN:  hnd            - Board handle
    *        nInstance      - The instance number
    *        pObj           - User Description object
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_setUserDesc(
        TSYNC_BoardHandle        hnd,
        unsigned int             nInstance,
        TSYNC_PTPUserDescObj    *pObj);

    /*
    * Function:    TSYNC_PTR_getRefId()
    * Description: Get reference identifier for a PTP reference instance.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getRefId(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        TSYNC_RefIdObj    *pObj);

    /*
    * Function:    TSYNC_PTR_getDebugOutput()
    * Description: Gets Debug Output information.
    *
    * Parameters:
    *   IN:  hnd            - Board handle
    *        nInstance      - The instance number
    *
    *  OUT:  pObj           - Debug Output object
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getDebugOutput(
        TSYNC_BoardHandle        hnd,
        unsigned int             nInstance,
        TSYNC_PTPDebugOutputObj *pObj);

    /*
    * Function:    TSYNC_PTR_setDebugOutput()
    * Description: Sets Debug Output information.
    *
    * Parameters:
    *   IN:  hnd            - Board handle
    *        nInstance      - The instance number
    *        pObj           - Debug Output object
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_setDebugOutput(
        TSYNC_BoardHandle      hnd,
        unsigned int           nInstance,
        TSYNC_PTPDebugOutputObj *pObj);

    /*
    * Function:    TSYNC_PTR_getEthernetStatus()
    * Description: Gets current Ethernet Status.
    *
    * Parameters:
    *   IN:  hnd            - Board handle
    *        nInstance      - The instance number
    *
    *  OUT:  pObj           - Ethernet Status object
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getEthernetStatus(
        TSYNC_BoardHandle           hnd,
        unsigned int                nInstance,
        TSYNC_PTPEthernetStatusObj *pObj);

    /*
    * Function:    TSYNC_PTR_getSyncEItf()
    * Description: Gets Sync-E Interface information.
    *
    * Parameters:
    *   IN:  hnd            - Board handle
    *        nInstance      - The instance number
    *
    *  OUT:  pObj           - Sync-E Interface object
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getSyncEItf(
        TSYNC_BoardHandle        hnd,
        unsigned int             nInstance,
        TSYNC_PTPSyncEStatusObj *pObj);

    /*
    * Function:    TSYNC_PTR_setSyncEItf()
    * Description: Sets Sync-E Interface information.
    *
    * Parameters:
    *   IN:  hnd            - Board handle
    *        nInstance      - The instance number
    *        pObj           - Sync-E Interface object
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_setSyncEItf(
        TSYNC_BoardHandle        hnd,
        unsigned int             nInstance,
        TSYNC_PTPSyncEStatusObj *pObj);

    /*
    * Function:    TSYNC_PTR_getPTPItf()
    * Description: Gets PTP Protocol information
    *
    * Parameters:
    *   IN:  hnd            - Board handle
    *        nInstance      - The instance number
    *
    *  OUT:  pObj           - PTP Interface object
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getPTPItf(
        TSYNC_BoardHandle   hnd,
        unsigned int        nInstance,
        TSYNC_PTPItfObj    *pObj);

    /*
    * Function:    TSYNC_PTR_setPTPItf()
    * Description: Sets PTP Protocol information
    *
    * Parameters:
    *   IN:  hnd            - Board handle
    *        nInstance      - The instance number
    *        pObj           - PTP Interface object
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_setPTPItf(
        TSYNC_BoardHandle   hnd,
        unsigned int        nInstance,
        TSYNC_PTPItfObj    *pObj);

    /*
    * Function:    TSYNC_PTR_getFTPItf()
    * Description: Gets FTP Protocol information
    *
    * Parameters:
    *   IN:  hnd            - Board handle
    *        nInstance      - The instance number
    *
    *  OUT:  pObj           - FTP Interface object
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getFTPItf(
        TSYNC_BoardHandle      hnd,
        unsigned int           nInstance,
        TSYNC_PTPFtpItfObj    *pObj);

    /*
    * Function:    TSYNC_PTR_setFTPItf()
    * Description: Sets FTP Protocol information
    *
    * Parameters:
    *   IN:  hnd            - Board handle
    *        nInstance      - The instance number
    *        pObj           - FTP Interface object
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_setFTPItf(
        TSYNC_BoardHandle      hnd,
        unsigned int           nInstance,
        TSYNC_PTPFtpItfObj    *pObj);

    /*
    * Function:    TSYNC_PTR_getPTPStatistics()
    * Description: Gets PTP Statistics Control information
    *
    * Parameters:
    *   IN:  hnd            - Board handle
    *        nInstance      - The instance number
    *
    *  OUT:  pObj           - PTP Statistics object
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getPTPStatistics(
        TSYNC_BoardHandle        hnd,
        unsigned int             nInstance,
        TSYNC_PTPStatisticsObj  *pObj);

    /*
    * Function:    TSYNC_PTR_setPTPStatistics()
    * Description: Sets PTP Statistics Control information
    *
    * Parameters:
    *   IN:  hnd            - Board handle
    *        nInstance      - The instance number
    *        pObj           - PTP Statistics object
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_setPTPStatistics(
        TSYNC_BoardHandle        hnd,
        unsigned int             nInstance,
        TSYNC_PTPStatisticsObj  *pObj);

   /*
    * Function:    TSYNC_PTR_getClockProperties()
    * Description: Gets PTP Clock Properties information
    *
    * Parameters:
    *   IN:  hnd            - Board handle
    *        nInstance      - The instance number
    *        pObj           - PTP Clock Properties object
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getClockProperties(
        TSYNC_BoardHandle            hnd,
        unsigned int                 nInstance,
        TSYNC_PTPClockPropertiesObj *pObj);

    /*
    * Function:    TSYNC_PTR_getState()
    * Description: Retreive the PTR update status.
    *
    * Parameters:
    *   IN:  *hw           - Handle
    *        *obj          - Pointer to the state result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getState(
        TSYNC_BoardHandle  hnd,
        TSYNC_StateObj    *obj);

    /*
    * Function:    TSYNC_PTR_start()
    * Description: Begin a PTR update sequence.
    *
    * Parameters:
    *   IN:  *hw           - Handle
    *        *obj1         - Pointer to the update image information
    *        *obj2         - Pointer to the update header information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_start(
        TSYNC_BoardHandle       hnd,
        TSYNC_ULImageIdObj     *obj1,
        TSYNC_ULImageHeaderObj *obj2);

    /*
    * Function:    TSYNC_PTR_data()
    * Description: Send a single data block in the update sequence.
    *
    * Parameters:
    *   IN:  *hw           - Handle
    *   OUT: *obj          - Pointer to the update data information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_data(
        TSYNC_BoardHandle    hnd,
        TSYNC_UpdateDataObj *obj);

    /*
    * Function:    TSYNC_PTR_end()
    * Description: Finish the update sequence.
    *
    * Parameters:
    *   IN:  *hw           - Handle
    *   OUT: *obj          - Pointer to the update end information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_end(
        TSYNC_BoardHandle   hnd,
        TSYNC_UpdateEndObj *obj);

    /*
    * Function:    TSYNC_PTR_cancel()
    * Description: Cancel the update sequence.
    *
    * Parameters:
    *   IN:  *hw           - Handle
    *   OUT: imageType     - the type of update sequence being cancelled
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_cancel(
        TSYNC_BoardHandle hnd,
        UL_IMG            imageType);

    /*
    * Function:    TSYNC_PTR_getBootImg()
    * Description: Gets the image that the module will boot into on a Module Reset.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: bBootImg      - Whether the module outputs a PPS when it's a slave
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_getBootImg(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int              *bBootImg);

    /*
    * Function:    TSYNC_PTR_setBootImg()
    * Description: Sets the image that the module will boot into on a Module Reset.
    *
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        bBootImg      - Whether the module outputs a PPS when it's a slave
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PTR_setBootImg(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int               bBootImg);


    /* STANAG/HaveQuick Output Component =====================================*/

    /*
    * Function:    TSYNC_QP_getSigCtrl()
    * Description: Get the HaveQuick output's signature control state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: sig           - The signature control result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_getSigCtrl(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        SIG_CTL           *sig);

    /*
    * Function:    TSYNC_QP_setSigCtrl()
    * Description: Set the HaveQuick output's signature control state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        sig           - The signature control information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_setSigCtrl(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        SIG_CTL           sig);

/*
    * Function:    TSYNC_QP_getExtSigCtrl()
    * Description: Get the HaveQuick extended output's signature control state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: sig           - The signature control result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_getExtSigCtrl(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        SIG_CTL           *sig);

    /*
    * Function:    TSYNC_QP_setExtSigCtrl()
    * Description: Set the HaveQuick extended output's signature control state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        sig           - The signature control information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_setExtSigCtrl(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        SIG_CTL           sig);

    /*
    * Function:    TSYNC_QP_getOffset()
    * Description: Get the HaveQuick output's offset.  Offset is in nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: nOffset       - The offset result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_getOffset(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *nOffset);

    /*
    * Function:    TSYNC_QP_setOffset()
    * Description: Set the HaveQuick output's offset.  Offset is in nanoseconds
    *              from -500 msec to +500 msec.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        nOffset       - The offset information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_setOffset(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int               nOffset);
/*
    * Function:    TSYNC_QP_getExtOffset()
    * Description: Get the HaveQuick Extended output's offset.  Offset is in nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: nOffset       - The offset result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_getExtOffset(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *nOffset);

    /*
    * Function:    TSYNC_QP_setExtOffset()
    * Description: Set the HaveQuick Extended output's offset.  Offset is in nanoseconds
    *              from -500 msec to +500 msec.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        nOffset       - The offset information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_setExtOffset(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int               nOffset);

    /*
    * Function:    TSYNC_QP_getLocal()
    * Description: Get the HaveQuick output's local time zone and DST rule.
    *              Timezone and DST offsets are in seconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the Local Clock result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_getLocal(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_LocalClockObj *pObj);

    /*
    * Function:    TSYNC_QP_setLocal()
    * Description: Set the HaveQuick output's local time zone and DST rule.
    *              Timezone and DST offsets are in seconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the Local Clock information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_setLocal(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_LocalClockObj *pObj);

    /*
    * Function:    TSYNC_QP_getBs()
    * Description: Get the HaveQuick output Bit Synchronization.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: bs            - The Bit Synchronization result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_getBs(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        unsigned int       *bs);

    /*
    * Function:    TSYNC_QP_setBs()
    * Description: Set the HaveQuick output Bit Synchronization.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        bs            - The Bit Synchronization information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_setBs(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      bs);

    /*
    * Function:    TSYNC_QP_getFormat()
    * Description: Get the HaveQuick output format.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: format        - The format result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_getFormat(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        QL_FMT            *format);

    /*
    * Function:    TSYNC_QP_setFormat()
    * Description: Set the HaveQuick output format.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number

    *        format        - The format information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_setFormat(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        QL_FMT            format);

   /*
    * Function:    TSYNC_QP_getExtFormat()
    * Description: Get the Extended HaveQuick output format.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: format        - The format result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_getExtFormat(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        QL_FMT            *format);

    /*
    * Function:    TSYNC_QP_setExtFormat()
    * Description: Set the HaveQuick Extended output format.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        format        - The format information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_setExtFormat(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        QL_FMT            format);

    /*
    * Function:    TSYNC_QP_getTimeScale()
    * Description: Get the HaveQuick output's time scale.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the time scale result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_getTimeScale(
        TSYNC_BoardHandle   hnd,
        unsigned int        nInstance,
        TSYNC_TimeScaleObj *pObj);

    /*
    * Function:    TSYNC_QP_setTimeScale()
    * Description: Set the HaveQuick output's time scale.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the time scale information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_setTimeScale(
        TSYNC_BoardHandle   hnd,
        unsigned int        nInstance,
        TSYNC_TimeScaleObj *pObj);

   /*
    * Function:    TSYNC_QP_getExtTimeScale()
    * Description: Get the HaveQuick extended output's time scale.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the time scale result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_getExtTimeScale(
        TSYNC_BoardHandle   hnd,
        unsigned int        nInstance,
        TSYNC_TimeScaleObj *pObj);

    /*
    * Function:    TSYNC_QP_setExtTimeScale()
    * Description: Set the HaveQuick extended output's time scale.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the time scale information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_setExtTimeScale(
        TSYNC_BoardHandle   hnd,
        unsigned int        nInstance,
        TSYNC_TimeScaleObj *pObj);

    /*
    * Function:    TSYNC_QP_getNumInst()
    * Description: Get number of HaveQuick output instances present in the
    *              system.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: nInstances    - The number of instances result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_getNumInst(
        TSYNC_BoardHandle  hnd,
        unsigned int      *nInstances);
    /*
    * Function:    TSYNC_QP_getTfd()
    * Description: Get the HaveQuick output's time fault discrete.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstances    - The number of instances result
    *   OUT  tfd           - Pointer to the time fault discrete result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_getTfd(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstances,
        unsigned int      *tfd);
    /*
    * Function:    TSYNC_QP_setTfd()
    * Description: Set the HaveQuick output time fault discrete.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        tfd            - The time fault discrete information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_setTfd(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      tfd);

    /*
    * Function:    TSYNC_QP_getTfdState()
    * Description: Get the HaveQuick output's time fault discrete state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstances    - The number of instances result
    *   OUT  tfd           - Pointer to the time fault discrete result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_getTfdState(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstances,
        unsigned int      *tfd);
    /*
    * Function:    TSYNC_QP_setTfdState()
    * Description: Set the HaveQuick output time fault discrete state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        tfd            - The time fault discrete information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_setTfdState(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      tfd);

    /*
    * Function:    TSYNC_QP_getTfom()
    * Description: Get the HaveQuick output's TFOM.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstances    - The number of instances result
    *        tfd           - Pointer to the TFOM result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_getTfom(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstances,
        unsigned int      *tfom);

  /*
    * Function:    TSYNC_QP_getRequiredTfom()
    * Description: Get the HaveQuick output's required TFOM.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstances    - The number of instances result
    *        tfd           - Pointer to the TFOM result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_getRequiredTfom(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstances,
        unsigned int      *tfom);

   /*
    * Function:    TSYNC_QP_setRequiredTfom()
    * Description: Set the HaveQuick output required tfom.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        tfom          - The required tfom information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_setRequiredTfom(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      tfom);

   /*
    * Function:    TSYNC_QP_getExtTfom()
    * Description: Get the HaveQuick extended output's TFOM.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstances    - The number of instances result
    *        tfd           - Pointer to the TFOM result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_getExtTfom(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstances,
        unsigned int      *tfom);

    /*
    * Function:    TSYNC_QP_getLevel()
    * Description: Get the output's level.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstances    - The instance number
    *   OUT: sl            - The signal level result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_getLevel(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstances,
        SIG_LEVEL         *sl);

    /*
    * Function:    TSYNC_QP_setLevel()
    * Description: Set the output's level.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstances    - The instance number
    *        pw            - The signal level information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_setLevel(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstances,
        SIG_LEVEL          sl);

    /*
    * Function:    TSYNC_QP_getElecType()
    * Description: Get the output's electrical type.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstances    - The instance number
    *   OUT: et            - The electrical type result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_getElecType(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstances,
        ELEC_TYPE         *et);

    /*
    * Function:    TSYNC_QP_setElecType()
    * Description: Set the output's electrical type.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstances    - The instance number
    *        et            - The electrical type result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_setElecType (
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstances,
        ELEC_TYPE          et);

   /*
    * Function:    TSYNC_QP_getExtElecType()
    * Description: Get the extended output's electrical type.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstances    - The instance number

    *   OUT: et            - The electrical type result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_getExtElecType(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstances,
        ELEC_TYPE         *et);

    /*
    * Function:    TSYNC_QP_setExtElecType()
    * Description: Set the extended output's electrical type.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstances    - The instance number
    *        et            - The electrical type result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_setExtElecType (
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstances,
        ELEC_TYPE          et);
    /*
    * Function:    TSYNC_QP_getPpsSigCtrl()
    * Description: Get the PPS output's signature control state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: sig           - The signature control result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_getPpsSigCtrl(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        SIG_CTL           *sig);

    /*
    * Function:    TSYNC_QP_setPpsSigCtrl()
    * Description: Set the PPS output's signature control state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        sig           - The signature control information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_setPpsSigCtrl(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        SIG_CTL           sig);

    /*
    * Function:    TSYNC_QP_getPpsElecType()
    * Description: Get the PPS output's electrical type.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstances    - The instance number
    *   OUT: et            - The electrical type result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_getPpsElecType(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstances,
        ELEC_TYPE         *et);

    /*
    * Function:    TSYNC_QP_setPpsElecType()
    * Description: Set the PPS output's electrical type.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstances    - The instance number
    *        et            - The electrical type result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_setPpsElecType (
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstances,
        ELEC_TYPE          et);

    /*
    * Function:    TSYNC_QP_getPpsOffset()
    * Description: Get the PPS output's offset.  Offset is in nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: nOffset       - The offset result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_getPpsOffset(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *nOffset);

    /*
    * Function:    TSYNC_QP_setPpsOffset()
    * Description: Get the PPS output's offset.  Offset is in nanoseconds from
    *              -500 msec to +500 msec.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        nOffset       - The offset information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_setPpsOffset(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int               nOffset);

    /*
    * Function:    TSYNC_QP_getPpsEdge()
    * Description: Get the PPS output's edge.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: edge          - The edge result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_getPpsEdge(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        EDGE              *edge);

    /*
    * Function:    TSYNC_QP_setPpsEdge()
    * Description: Set the PPS output's edge.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        edge          - The edge information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_setPpsEdge(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        EDGE              edge);

    /*
    * Function:    TSYNC_QP_getPpsPw()
    * Description: Get the PPS output's pulse width.  Pulse width is in
    *              nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pw            - The pulse width result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_getPpsPw(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        unsigned int      *pw);

    /*
    * Function:    TSYNC_QP_setPpsPw()
    * Description: Set the PPS output's pulse width.  Pulse width is in
    *              nanoseconds from 10 nsec to 999,999,990 nsec.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pw            - The pulse width information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_QP_setPpsPw(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      pw);


    /* SMPTE/EBU Output Component =====================================*/

    /*
    * Function:    TSYNC_EP_getSigCtrl()
    * Description: Get the SMPTE/EBU output's signature control state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: sig           - The signature control result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_EP_getSigCtrl(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        SIG_CTL           *sig);

    /*
    * Function:    TSYNC_EP_setSigCtrl()
    * Description: Set the SMPTE/EBU output's signature control state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        sig           - The signature control information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_EP_setSigCtrl(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        SIG_CTL           sig);

    /*
    * Function:    TSYNC_EP_getOffset()
    * Description: Get the SMPTE/EBU output's offset.  Offset is in nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: nOffset       - The offset result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_EP_getOffset(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *nOffset);

    /*
    * Function:    TSYNC_EP_setOffset()
    * Description: Set the SMPTE/EBU output's offset.  Offset is in nanoseconds
    *              from -500 msec to +500 msec.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        nOffset       - The offset information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_EP_setOffset(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int               nOffset);

    /*
    * Function:    TSYNC_EP_getLocal()
    * Description: Get the SMPTE/EBU output's local time zone and DST rule.
    *              Timezone and DST offsets are in seconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the Local Clock result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_EP_getLocal(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_LocalClockObj *pObj);

    /*
    * Function:    TSYNC_EP_setLocal()
    * Description: Set the SMPTE/EBU output's local time zone and DST rule.
    *              Timezone and DST offsets are in seconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the Local Clock information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_EP_setLocal(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_LocalClockObj *pObj);

    /*
    * Function:    TSYNC_EP_getFormat()
    * Description: Get the SMPTE/EBU output format.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: format        - The format result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_EP_getFormat(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        ESL_FMT           *format);

    /*
    * Function:    TSYNC_EP_setFormat()
    * Description: Set the SMPTE/EBU output format.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        format        - The format information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_EP_setFormat(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        ESL_FMT           format);

    /*
    * Function:    TSYNC_EP_getTimeScale()
    * Description: Get the SMPTE/EBU output's time scale.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the time scale result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_EP_getTimeScale(
        TSYNC_BoardHandle   hnd,
        unsigned int        nInstance,
        TSYNC_TimeScaleObj *pObj);

    /*
    * Function:    TSYNC_EP_setTimeScale()
    * Description: Set the SMPTE/EBU output's time scale.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the time scale information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_EP_setTimeScale(
        TSYNC_BoardHandle   hnd,
        unsigned int        nInstance,
        TSYNC_TimeScaleObj *pObj);

    /*
    * Function:    TSYNC_EP_getAmplitude()
    * Description: Get the SMPTE/EBU output's amplitude.
    *              Amplitude is in range of 0 - 255.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: amp           - The amplitude result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_EP_getAmplitude(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        unsigned int      *amp);

    /*
    * Function:    TSYNC_EP_setAmplitude()
    * Description: Set the SMPTE/EBU output's amplitude.
    *              Amplitude is in range of 0 - 255.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        amp           - The amplitude information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_EP_setAmplitude(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      amp);

    /*
    * Function:    TSYNC_EP_getNumInst()
    * Description: Get number of SMPTE/EBU output instances present in the
    *              system.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: nInstances    - The number of instances result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_EP_getNumInst(
        TSYNC_BoardHandle  hnd,
        unsigned int      *nInstances);

    /* Display Output Component ==============================================*/

    /*
    * Function:    TSYNC_DP_getLocal()
    * Description: Get the display output's local time zone and DST rule.
    *              Timezone and DST offsets are in seconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the Local Clock result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_DP_getLocal(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_LocalClockObj *pObj);

    /*
    * Function:    TSYNC_DP_setLocal()
    * Description: Set the display output's local time zone and DST rule.
    *              Timezone and DST offsets are in seconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the Local Clock information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_DP_setLocal(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_LocalClockObj *pObj);

    /*
    * Function:    TSYNC_DP_getFormat()
    * Description: Get the display output format.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: format        - The format result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_DP_getFormat(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        ML_HOUR           *format);

    /*
    * Function:    TSYNC_DP_setFormat()
    * Description: Set the display output format.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        format        - The format information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_DP_setFormat(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        ML_HOUR           format);

    /*
    * Function:    TSYNC_DP_getTimeScale()
    * Description: Get the display output's time scale.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the time scale result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_DP_getTimeScale(
        TSYNC_BoardHandle   hnd,
        unsigned int        nInstance,
        TSYNC_TimeScaleObj *pObj);

    /*
    * Function:    TSYNC_DP_setTimeScale()
    * Description: Set the display output's time scale.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pObj          - Pointer to the time scale information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_DP_setTimeScale(
        TSYNC_BoardHandle   hnd,
        unsigned int        nInstance,
        TSYNC_TimeScaleObj *pObj);

    /*
    * Function:    TSYNC_DP_getNumInst()
    * Description: Get number of display output instances present in the
    *              system.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: nInstances    - The number of instances result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_DP_getNumInst(
        TSYNC_BoardHandle  hnd,
        unsigned int      *nInstances);

    /*
    * Function:    TSYNC_DP_getMode()
    * Description: Get the display mode.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: mode          - The mode result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_DP_getMode(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        DP_MODE           *mode);

    /*
    * Function:    TSYNC_DP_setMode()
    * Description: Set the display mode.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        format        - The format information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_DP_setMode(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        DP_MODE           mode);

    /* 1PPS Output Component =================================================*/

    /*
    * Function:    TSYNC_PP_getSigCtrl()
    * Description: Get the PPS output's signature control state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: sig           - The signature control result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PP_getSigCtrl(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        SIG_CTL           *sig);

    /*
    * Function:    TSYNC_PP_setSigCtrl()
    * Description: Set the PPS output's signature control state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        sig           - The signature control information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PP_setSigCtrl(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        SIG_CTL           sig);

    /*
    * Function:    TSYNC_PP_getFreq()
    * Description: Get the PPS output's frequency.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: freq          - The frequency result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PP_getFreq(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        float             *freq);

    /*
    * Function:    TSYNC_PP_getOffset()
    * Description: Get the PPS output's offset.  Offset is in nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: nOffset       - The offset result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PP_getOffset(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *nOffset);

    /*
    * Function:    TSYNC_PP_setOffset()
    * Description: Get the PPS output's offset.  Offset is in nanoseconds from
    *              -500 msec to +500 msec.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        nOffset       - The offset information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PP_setOffset(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int               nOffset);

    /*
    * Function:    TSYNC_PP_getEdge()
    * Description: Get the PPS output's edge.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: edge          - The edge result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PP_getEdge(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        EDGE              *edge);

    /*
    * Function:    TSYNC_PP_setEdge()
    * Description: Set the PPS output's edge.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        edge          - The edge information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PP_setEdge(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        EDGE              edge);

    /*
    * Function:    TSYNC_PP_getPulseWidth()
    * Description: Get the PPS output's pulse width.  Pulse width is in
    *              nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pw            - The pulse width result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PP_getPulseWidth(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        unsigned int      *pw);

    /*
    * Function:    TSYNC_PP_setPulseWidth()
    * Description: Set the PPS output's pulse width.  Pulse width is in
    *              nanoseconds from 10 nsec to 999,999,990 nsec.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        pw            - The pulse width information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PP_setPulseWidth(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      pw);

    /*
    * Function:    TSYNC_PP_getNumInst()
    * Description: Get number of PPS output instances present in the system.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: nInstances    - The number of instances result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_PP_getNumInst(
        TSYNC_BoardHandle  hnd,
        unsigned int      *nInstances);

    /* Variable-Frequency Output Component ===================================*/

    /*
    * Function:    TSYNC_VP_getSigCtrl()
    * Description: Get the Variable-Frequency output's signature control state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: sig           - The signature control result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_VP_getSigCtrl(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        SIG_CTL           *sig);

    /*
    * Function:    TSYNC_VP_setSigCtrl()
    * Description: Set the Variable-Frequency output's signature control state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        sig           - The signature control information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_VP_setSigCtrl(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        SIG_CTL           sig);

    /*
    * Function:    TSYNC_VP_getFreq()
    * Description: Get the Variable-Frequency output frequency.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: freq          - The frequency result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_VP_getFreq(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        double            *freq);

    /*
    * Function:    TSYNC_VP_setFreq()
    * Description: Set the Variable-Frequency output frequency.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        freq          - The frequency information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_VP_setFreq(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        double            freq);

    /*
    * Function:    TSYNC_VP_getPhase()
    * Description: Get the Variable-Phase output frequency.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: phase         - The phase result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_VP_getPhase(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        float            *phase);

    /*
    * Function:    TSYNC_VP_setPhase()
    * Description: Set the Variable-Frequency output phase.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        phase         - The phase information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_VP_setPhase(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        float                phase);

    /*
    * Function:    TSYNC_VP_getCfg()
    * Description: Get the Variable-Frequency output configuration.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: cfg           - The configuration result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_VP_getCfg(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        TSYNC_VPCfgObj   *pObj);

    /*
    * Function:    TSYNC_VP_getNumInst()
    * Description: Get number of Variable-Frequency output instances present in
    *              the system.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: nInstances    - The number of instances result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_VP_getNumInst(
        TSYNC_BoardHandle  hnd,
        unsigned int      *nInstances);

    /*
    * Function:    TSYNC_VP_getLock()
    * Description: Get number of Variable-Frequency output instances present in
    *              the system.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: lock          - PLL lock enabled/disabled
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_VP_getLock(
        TSYNC_BoardHandle  hnd,
    unsigned int       nInstance,
        int      *lock);

    /* E1/T1 Output Component ================================================*/

    /*
    * Function:    TSYNC_ETP_getSigCtrl()
    * Description: Get the E1/T1 output's signature control state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: sig           - The signature control result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_ETP_getSigCtrl(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        SIG_CTL           *sig);

    /*
    * Function:    TSYNC_ETP_setSigCtrl()
    * Description: Set the E1/T1 output's signature control state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        sig           - The signature control information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_ETP_setSigCtrl(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        SIG_CTL           sig);

    /*
    * Function:    TSYNC_ETP_getCfg()
    * Description: Get the E1/T1 output configuration parameters.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pCfg          - Pointer to the configuration parameter structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_ETP_getCfg(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        ETO_CFG           *pCfg);

    /*
    * Function:    TSYNC_ETP_setMode()
    * Description: Set the E1/T1 output configuration parameters.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pCfg          - Pointer to the configuration parameter structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_ETP_setCfg(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        ETO_CFG           *pCfg);

    /*
    * Function:    TSYNC_ETP_getNumInst()
    * Description: Get number of E1/T1 output set instances in the system.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: nInstances    - The number of instances result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_ETP_getNumInst(
        TSYNC_BoardHandle  hnd,
        unsigned int      *nInstances);

    /* Oscillator Component ==================================================*/

    /*
    * Function:    TSYNC_XO_getDiscState()
    * Description: Get the external oscillator's disciplining state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: disc          - The disciplining state result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_XO_getDiscState(
        TSYNC_BoardHandle  hnd,
        int               *disc);

    /*
    * Function:    TSYNC_XO_getMode()
    * Description: Get the external oscillator's mode used when
    *              disciplining or testing.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: mode          - The mode result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_XO_getMode(
        TSYNC_BoardHandle  hnd,
        XO_MODE           *mode);

    /*
    * Function:    TSYNC_XO_setMode()
    * Description: Set the external oscillator's mode used when
    *              disciplining or testing.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        mode          - The mode information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_XO_setMode(
        TSYNC_BoardHandle hnd,
        XO_MODE           mode);

    /*
    * Function:    TSYNC_XO_getDac()
    * Description: Get the external oscillator's DAC setting for testing.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: dac           - The DAC result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_XO_getDac(
        TSYNC_BoardHandle  hnd,
        unsigned short    *dac);

    /*
    * Function:    TSYNC_XO_setDac()
    * Description: Set the external oscillator's DACsetting for testing.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        dac           - The DAC information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_XO_setDac(
        TSYNC_BoardHandle hnd,
        unsigned short    dac);

    /*
    * Function:    TSYNC_XO_getAlarm()
    * Description: Get the external oscillator's alarm state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: alarm         - The alarm result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_XO_getAlarm(
        TSYNC_BoardHandle  hnd,
        unsigned int      *alarm);

    /*
    * Function:    TSYNC_XO_getSerNum()
    * Description: Get the external oscillator's serial number.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: sernum        - The serial number result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_XO_getSerNum(
        TSYNC_BoardHandle  hnd,
        TSYNC_SerialNoObj *sernum);

    /*
    * Function:    TSYNC_XO_getMfrMdl()
    * Description: Get the external oscillator's manufacturer and model.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - Pointer to the man/mod result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_XO_getMfrMdl(
        TSYNC_BoardHandle  hnd,
        TSYNC_ManModObj   *pObj);

    /*
    * Function:    TSYNC_XO_setMessage()
    * Description: Send a Custom Message to the external oscillator.  Result is
    *              passed back in same buffer.  Valid only when in test mode.
    *
    * Parameters:
    *   IN:    hnd         - Board handle
    *   INOUT: pObj        - Pointer to the message information and result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_XO_setMessage(
        TSYNC_BoardHandle       hnd,
        TSYNC_OscCustomMessageObj *pObj);

    /*
    * Function:    TSYNC_XO_getCmd()
    * Description: Get a disciplining dataset from the external oscillator.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - Pointer to the dataset result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_XO_getCmd(
        TSYNC_BoardHandle  hnd,
        TSYNC_OscDiscObj  *pObj);

    /*
    * Function:    TSYNC_XO_setCmd()
    * Description: Send a disciplining command and dataset to the
    *              external oscillator.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        pObj          - Pointer to the command information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_XO_setCmd(
        TSYNC_BoardHandle  hnd,
        TSYNC_OscDiscObj  *pObj);

    /*
    * Function:    TSYNC_XO_getPhaseErr()
    * Description: Get the estimated phase error of the external oscillator.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        error         - Phase error result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_XO_getPhaseErr(
        TSYNC_BoardHandle  hnd,
        int               *error);

    /*
    * Function:    TSYNC_XO_getPhaseErrLim()
    * Description: Get the phase error limit of the external oscillator.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        error         - Phase error limit result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_XO_getPhaseErrLim(
        TSYNC_BoardHandle  hnd,
        unsigned int      *error);

    /*
    * Function:    TSYNC_XO_setPhaseErrLim()
    * Description: Set the phase error limit of the external oscillator.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        error         - Phase error limit value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_XO_setPhaseErrLim(
        TSYNC_BoardHandle    hnd,
        unsigned int         error);

    /*
    * Function:    TSYNC_XO_getFreqErr()
    * Description: Get the frequency phase error of the external oscillator.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        error         - Frequency error result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_XO_getFreqErr(
        TSYNC_BoardHandle  hnd,
        float             *error);

    /*
    * Function:    TSYNC_XO_getCalVal()
    * Description: Get the calibration value of the external oscillator.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        cal           - calibration value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_XO_getCalVal(
        TSYNC_BoardHandle  hnd,
        float             *cal);

    /*
    * Function:    TSYNC_XO_getOscType()
    * Description: Get the system oscillator type.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        err           - Oscillator type
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_XO_getOscType(
        TSYNC_BoardHandle hnd,
        OSC *oscType);


    /* Fixed-Frequency Output Component ======================================*/

    /*
    * Function:    TSYNC_FP_getSigCtrl()
    * Description: Get the Fixed Frequency output's signature control state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: sig           - The signature control result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FP_getSigCtrl(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        SIG_CTL           *sig);

    /*
    * Function:    TSYNC_FP_setSigCtrl()
    * Description: Set the Fixed Frequency output's signature control state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        sig           - The signature control information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FP_setSigCtrl(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        SIG_CTL           sig);

    /*
    * Function:    TSYNC_FP_getFreq()
    * Description: Get the Fixed Frequency output's frequency.  Frequency is in
    *              Hertz.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: freq          - The frequency result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FP_getFreq(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        float             *freq);

    /*
    * Function:    TSYNC_FP_getNumInst()
    * Description: Get number of fixed-freq output instances present in the
    *              system.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: nInstances    - The number of instances result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FP_getNumInst(
        TSYNC_BoardHandle  hnd,
        unsigned int      *nInstances);

    /*
    * Function:    TSYNC_FP_getPllLock()
    * Description: Get the Fixed Frequency output's PLL Lock status.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pllLock       - The PLL lock result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FP_getPllLock(
        TSYNC_BoardHandle hnd,
        unsigned int nInstance,
        unsigned int *pllLock);

    /* Shared-Memory Service =================================================*/

    /*
    * Function:    TSYNC_MS_reset()
    * Description: Reset a shared memory data set item.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        index         - Index of the shared memory set
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_MS_reset(
        TSYNC_BoardHandle hnd,
        MS_DI_INDEX       index);

    /*
    * Function:    TSYNC_MS_getData()
    * Description: Get a shared memory data set item.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        index         - Index of the shared memory set
    *   OUT: pObj          - Pointer to the shared memory dataset result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_MS_getData(
        TSYNC_BoardHandle      hnd,
        MS_DI_INDEX            index,
        TSYNC_SharedMemoryObj *pObj);

    /*
    * Function:    TSYNC_MS_setData()
    * Description: Set a shared memory data set item.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        index         - Index of the shared memory set
    *        pObj          - Pointer to the shared memory dataset information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_MS_setData(
        TSYNC_BoardHandle      hnd,
        MS_DI_INDEX            index,
        TSYNC_SharedMemoryObj *pObj);

    /* General-Purpose Output Component ======================================*/

    /*
    * Function:    TSYNC_GO_getSigCtrl()
    * Description: Get the GPO's signature control state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *   OUT: sig           - The signature control result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_getSigCtrl(
        TSYNC_BoardHandle  hnd,
        OD_PIN             gpo,
        SIG_CTL           *sig);

    /*
    * Function:    TSYNC_GO_setSigCtrl()
    * Description: Set the GPO's signature control state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *        sig           - The signature control information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_setSigCtrl(
        TSYNC_BoardHandle hnd,
        OD_PIN            gpo,
        SIG_CTL           sig);

    /*
    * Function:    TSYNC_GO_getEnable()
    * Description: Get the GPO's enable state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *   OUT: bEnable       - The output enable result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_getEnable(
        TSYNC_BoardHandle  hnd,
        OD_PIN             gpo,
        int               *bEnable);

    /*
    * Function:    TSYNC_GO_setEnable()
    * Description: Set the GPO's enable state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *        bEnable       - The output enable information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_setEnable(
        TSYNC_BoardHandle hnd,
        OD_PIN            gpo,
        int               bEnable);

    /*
    * Function:    TSYNC_GO_getValue()
    * Description: Get the GPO's current output value.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *   OUT: bValue        - The value result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_getValue(
        TSYNC_BoardHandle  hnd,
        OD_PIN             gpo,
        int               *bValue);

    /*
    * Function:    TSYNC_GO_getMode()
    * Description: Get the GPO's mode state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *   OUT: mode          - The mode result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_getMode(
        TSYNC_BoardHandle  hnd,
        OD_PIN             gpo,
        OD_MODE           *mode);

    /*
    * Function:    TSYNC_GO_setMode()
    * Description: Set the GPO's mode state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *        mode          - The mode information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_setMode(
        TSYNC_BoardHandle hnd,
        OD_PIN            gpo,
        OD_MODE           mode);

    /*
    * Function:    TSYNC_GO_getDvmValue()
    * Description: Get the GPO's Direct Value Mode (DVM) value state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *   OUT: bValue        - The DVM result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_getDvmValue(
        TSYNC_BoardHandle  hnd,
        OD_PIN             gpo,
        int               *bValue);

    /*
    * Function:    TSYNC_GO_setDvmValue()
    * Description: Set the GPO's Direct Value Mode (DVM) value state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *        bValue        - The DVM information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_setDvmValue(
        TSYNC_BoardHandle hnd,
        OD_PIN            gpo,
        int               bValue);

    /*
    * Function:    TSYNC_GO_getMatchEnable()
    * Description: Get the GPO's match enable state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *        lvl           - Low or High Match Time
    *   OUT: bEnable       - Match enable
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_getMatchEnable(
        TSYNC_BoardHandle  hnd,
        OD_PIN             gpo,
        LEVEL              lvl,
        int               *bEnable);

    /*
    * Function:    TSYNC_GO_setMatchEnable()
    * Description: Set the GPO's match enable state.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *        lvl           - Low or High Match Time
    *        bEnable       - Match enable
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_setMatchEnable(
        TSYNC_BoardHandle hnd,
        OD_PIN            gpo,
        LEVEL             lvl,
        int               bEnable);

    /*
    * Function:    TSYNC_GO_getSquareWave()
    * Description: Get the GPO's square wave output configuration structure.
    *              Offset, period, and pulse width are in nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *   OUT: pObj          - Pointer to the configuration result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_getSquareWave(
        TSYNC_BoardHandle   hnd,
        OD_PIN              gpo,
        TSYNC_GPOSquareObj *pObj);

    /*
    * Function:    TSYNC_GO_setSquareWave()
    * Description: Get the GPO's square wave output configuration structure.
    *              Offset and pulse width are in nanoseconds.  Period is in
    *              nanoseconds or microseconds depending on scale bit (msb).
    *              Offset is from -500 msec to +500 msec. Period is from 100
    *              nsec to 20 sec in nanosecond scale, and from 100 usec to
    *              20,000 sec in microsecond scale.  Pulse width is from 10
    *              nsec to 999,999,990 nsec.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *        pObj          - Pointer to the configuration information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_setSquareWave(
        TSYNC_BoardHandle   hnd,
        OD_PIN              gpo,
        TSYNC_GPOSquareObj *pObj);

    /*
    * Function:    TSYNC_GO_getSWOffset()
    * Description: Get the GPO's square wave offset.  Offset is in nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *        off           - Pointer to the square wave offset
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_getSWOffset(
        TSYNC_BoardHandle  hnd,
        OD_PIN             gpo,
        int               *off);

    /*
    * Function:    TSYNC_GO_setSWOffset()
    * Description: Set the GPO's square wave offset.  Offset is in nanoseconds
    *              from -500 msec to +500 msec.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *        off           - Square wave offset
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_setSWOffset(
        TSYNC_BoardHandle hnd,
        OD_PIN            gpo,
        int               off);

    /*
    * Function:    TSYNC_GO_getSWPeriod()
    * Description: Get the GPO's square wave period.  Period is in nanoseconds
    *              or microseconds depending on scale bit (msb).
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *   OUT: per           - Pointer to the square wave period
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_getSWPeriod(
        TSYNC_BoardHandle  hnd,
        OD_PIN             gpo,
        unsigned int      *per);

    /*
    * Function:    TSYNC_GO_setSWPeriod()
    * Description: Set the GPO's square wave period.  Period is in nanoseconds
    *              or microseconds depending on scale bit (msb).  Period is
    *              from 100 nsec to 20 sec in nanosecond scale, and from 100
    *              usec to 20,000 sec in microsecond scale.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *   OUT: per           - Square wave period
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_setSWPeriod(
        TSYNC_BoardHandle hnd,
        OD_PIN            gpo,
        unsigned int      per);

    /*
    * Function:    TSYNC_GO_getSWPW()
    * Description: Get the GPO's square wave pulse width.  Pulse width is in
    *              nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *        pw            - Pointer to the square wave pulse width
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_getSWPW(
        TSYNC_BoardHandle  hnd,
        OD_PIN             gpo,
        unsigned int      *pw);

    /*
    * Function:    TSYNC_GO_setSWPW()
    * Description: Set the GPO's square wave pulse width.  Pulse width is in
    *              nanoseconds from 20 nsec to 900,000,000 nsec.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *        pw            - Square wave pulse width
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_setSWPW(
        TSYNC_BoardHandle hnd,
        OD_PIN            gpo,
        unsigned int      pw);

    /*
    * Function:    TSYNC_GO_getSWEdge()
    * Description: Get the GPO's square wave active edge.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *        edge          - Pointer to the square wave active edge
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_getSWEdge(
        TSYNC_BoardHandle  hnd,
        OD_PIN             gpo,
        EDGE              *edge);

    /*
    * Function:    TSYNC_GO_setSWEdge()
    * Description: Set the GPO's square wave active edge.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *        edge          - Square wave active edge
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_setSWEdge(
        TSYNC_BoardHandle hnd,
        OD_PIN            gpo,
        EDGE              edge);

    /*
    * Function:    TSYNC_GO_getSWPerCorr()
    * Description: Get the GPO's square wave period correction.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *        num           - Pointer to the square wave period correction
    *                        numerator
    *        den           - Pointer to the square wave period correction
    *                        denominator
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_getSWPerCorr(
        TSYNC_BoardHandle  hnd,
        OD_PIN             gpo,
        unsigned int      *num,
        unsigned int      *den);

    /*
    * Function:    TSYNC_GO_setSWPerCorr()
    * Description: Set the GPO's square wave period correction.  The numerator
    *              and denominator are in the range of 0 to 255, where the
    *              numerator must be less than the denominator, and a
    *              numerator of 0 indicating no period correction.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *        num           - Square wave period correction numerator
    *        den           - Square wave period correction denominator
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_setSWPerCorr(
        TSYNC_BoardHandle hnd,
        OD_PIN            gpo,
        unsigned int      num,
        unsigned int      den);

    /*
    * Function:    TSYNC_GO_getSWAlignCnt()
    * Description: Get the GPO's square wave alignment count.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *        cnt           - Pointer to the square wave alignment count
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_getSWAlignCnt(
        TSYNC_BoardHandle  hnd,
        OD_PIN             gpo,
        unsigned int      *cnt);

    /*
    * Function:    TSYNC_GO_setSWAlignCnt()
    * Description: Set the GPO's square wave alignment count.  The alginment
    *              count is in seconds from 0 secs to 1 minute, where 0
    *              disables PPS alignment beyond the initial alignment.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *        cnt           - Square wave alignment count
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_setSWAlignCnt(
        TSYNC_BoardHandle hnd,
        OD_PIN            gpo,
        unsigned int      cnt);

    /*
    * Function:    TSYNC_GO_getSWTmAlgnEn()
    * Description: Get the GPO's square wave time alignment enable.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *        bEnable       - Pointer to the square wave time alignment enable
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_getSWTmAlgnEn(
        TSYNC_BoardHandle  hnd,
        OD_PIN             gpo,
        int               *bEnable);

    /*
    * Function:    TSYNC_GO_setSWTmAlgnEn()
    * Description: Set the GPO's square wave time alignment enable.  The time
    *              alignment enable changes the function of the alignment
    *              counter to align the square wave whenever the current time's
    *              seconds value is a multiple of the alignment count.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *        bEnable       - Square wave time alignment enable
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_setSWTmAlgnEn(
        TSYNC_BoardHandle hnd,
        OD_PIN            gpo,
        int               bEnable);

    /*
    * Function:    TSYNC_GO_setSWInit()
    * Description: Set the GPO's square wave initialization.  This will
    *              initialize, align, and restart the square wave on the next
    *              PPS.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_setSWInit(
        TSYNC_BoardHandle hnd,
        OD_PIN            gpo);

    /*
    * Function:    TSYNC_GO_getNumInst()
    * Description: Get number of GPIO Outputs present in the system.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: nInstances    - The number of instances result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_getNumInst(
        TSYNC_BoardHandle  hnd,
        unsigned int      *nInstances);

    /*
    * Function:    TSYNC_GO_getSWOtpPW()
    * Description: Get the GPO's square wave OTP pulse width.  Pulse width is
    *              in nanoseconds.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *        pw            - Pointer to the square wave pulse width
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_getSWOtpPW(
        TSYNC_BoardHandle  hnd,
        OD_PIN             gpo,
        unsigned int      *pw);

    /*
    * Function:    TSYNC_GO_setSWOtpPW()
    * Description: Get the GPO's square wave OTP pulse width.  Pulse width is
    *              in nanoseconds from 20 nsec to 900,000,000 nsec.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        gpo           - GPO index
    *        pw            - Square wave pulse width
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GO_setSWOtpPW(
        TSYNC_BoardHandle hnd,
        OD_PIN            gpo,
        unsigned int      pw);

    /* GPR Generic PTP Reference =============================================*/
    /*
    * Function:    TSYNC_GPR_getNumInst()
    * Description: Gets the number of PTP modules present in the system.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: nInstances    - The number of PTP modules present in the system
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getNumInst(
        TSYNC_BoardHandle hnd,
        unsigned int     *nInstances);

    /*
    * Function:    TSYNC_GPR_getClockIdentity()
    * Description: Gets the Clock Identity of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the Clock Identity
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getClockIdentity(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        TSYNC_GplClockId  *pObj);

    /*
    * Function:    TSYNC_GPR_setClockIdentity()
    * Description: Sets the Clock Identity of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   IN:  pObj          - pointer to the Clock Identity
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setClockIdentity(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        TSYNC_GplClockId  *pObj);

    /*
    * Function:    TSYNC_GPR_getPriority()
    * Description: Gets the Priority of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the Priority structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getPriority(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        TSYNC_GplPriority *pObj);

    /*
    * Function:    TSYNC_GPR_setPriority()
    * Description: Sets the Priority of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   IN:  pObj          - pointer to the Priority structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setPriority(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        TSYNC_GplPriority *pObj);

    /*
    * Function:    TSYNC_GPR_getDomain()
    * Description: Gets the Domain of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to the Domain value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getDomain(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      *pVal);

    /*
    * Function:    TSYNC_GPR_setDomain()
    * Description: Sets the domain of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   IN:  pVal          - pointer to the Domain value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setDomain(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      *pVal);

    /*
    * Function:    TSYNC_GPR_getClockMode()
    * Description: Gets the Clock Mode of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to the Clock Mode value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getClockMode(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      *pVal);

    /*
    * Function:    TSYNC_GPR_setClockMode()
    * Description: Sets the Clock Mode of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   IN:  pVal          - pointer to the Clock Mode value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setClockMode(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      *pVal);

    /*
    * Function:    TSYNC_GPR_getClockSteps()
    * Description: Gets the Clock Steps of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to the Clock Steps value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getClockSteps(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      *pVal);

    /*
    * Function:    TSYNC_GPR_setClockSteps()
    * Description: Gets the Clock Steps of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   IN:  pVal          - pointer to the Clock Steps value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setClockSteps(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      *pVal);

    /*
    * Function:    TSYNC_GPR_getClockPorts()
    * Description: Gets the number of clock Ports in the module.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to the Clock Ports value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getClockPorts(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      *pVal);

    /*
    * Function:    TSYNC_GPR_getClockQual()
    * Description: Gets the Clock Quality structure.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the Clock Quality structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getClockQual(
        TSYNC_BoardHandle   hnd,
        unsigned int        nInstance,
        TSYNC_GplClockQual *pObj);

    /*
    * Function:    TSYNC_GPR_getStatistics()
    * Description: Gets the Statistics structure.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the Statistics structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getStatistics(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_GplStatistics *pObj);

    /*
    * Function:    TSYNC_GPR_getParentData()
    * Description: Gets the Parent Data structure.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the Parent Data structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getParentData(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_GplParentData *pObj);

    /*
    * Function:    TSYNC_GPR_getTimeProp()
    * Description: Gets the Time Properties structure.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the Time Properties structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getTimeProp(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_GplTimeProp    *pObj);


    /*
    * Function:    TSYNC_GPR_getUserDesc()
    * Description: Gets the User Description structure.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the User Description structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getUserDesc(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_GplUserDesc    *pObj);

    /*
    * Function:    TSYNC_GPR_setUserDesc()
    * Description: Sets the User Description structure.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the User Description structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setUserDesc(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_GplUserDesc    *pObj);

    /*
    * Function:    TSYNC_GPR_getUnctMasterAdd()
    * Description: Gets the current Unicast Master.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the Unicast Master Add structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getUnctMasterAdd(
        TSYNC_BoardHandle          hnd,
        unsigned int              nInstance,
        TSYNC_GplUnctMasterAdd    *pObj);

    /*
    * Function:    TSYNC_GPR_setUnctMasterAdd()
    * Description: Sets the current Unicast Master.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the Unicast Master Add structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setUnctMasterAdd(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_GplUnctMasterAdd    *pObj);


    /*
    * Function:    TSYNC_GPR_setUnctMasterDel()
    * Description: Deletes a Unicast Master.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the Master's Port Identity
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setUnctMasterDel(
        TSYNC_BoardHandle    hnd,
        unsigned int         nInstance,
        TSYNC_GplPortId      *pObj);

    /*
    * Function:    TSYNC_GPR_getUnctSlaveProp()
    * Description: Gets properties when acting as a Unicast Slave.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the Unicast Slave Prop structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getUnctSlaveProp(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_GplUnctSlaveProp    *pObj);


    /*
    * Function:    TSYNC_GPR_getUnctMasterProp()
    * Description: Gets properties when acting as a Unicast Master.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the Unicast Master Prop structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getUnctMasterProp(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_GplUnctMasterProp   *pObj);


    /*
    * Function:    TSYNC_GPR_getUnctMasterCfg()
    * Description: Gets configuration when acting as a Unicast Master.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the Unicast Master Cfg structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getUnctMasterCfg(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_GplUnctMasterCfg    *pObj);


    /*
    * Function:    TSYNC_GPR_setUnctMasterCfg()
    * Description: Sets configuration when acting as a Unicast Master.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the Unicast Master Cfg structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setUnctMasterCfg(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_GplUnctMasterCfg    *pObj);


    /*
    * Function:    TSYNC_GPR_getPortState()
    * Description: Gets the Port State.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to the Port State value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getPortState(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        unsigned int              *pVal);


    /*
    * Function:    TSYNC_GPR_getMsgRates()
    * Description: Gets message rates.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the Message Rates structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getMsgRates(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_GplMsgRates    *pObj);


    /*
    * Function:    TSYNC_GPR_setMsgRates()
    * Description: Sets message rates.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the Message Rates structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setMsgRates(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_GplMsgRates        *pObj);

    /*
    * Function:    TSYNC_GPR_getMsgTo()
    * Description: Gets message Timeouts.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the Message Timeouts structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getMsgTo(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_GplMsgTo            *pObj);


    /*
    * Function:    TSYNC_GPR_setMsgTo()
    * Description: Sets message Timeouts.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the Message Timeouts structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setMsgTo(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_GplMsgTo            *pObj);


    /*
    * Function:    TSYNC_GPR_getDelayMech()
    * Description: Gets the Delay Mechanism.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to the Delay Mechanism value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getDelayMech(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        unsigned int              *pVal);


    /*
    * Function:    TSYNC_GPR_setDelayMech()
    * Description: Sets the Delay Mechanism.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to the Port State value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setDelayMech(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        unsigned int              *pVal);


    /*
    * Function:    TSYNC_GPR_getBcastMech()
    * Description: Gets the Broadcast Mechanism.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to the Broadcast Mechanism value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getBcastMech(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_GplBcastMech       *pObj);


    /*
    * Function:    TSYNC_GPR_setBcastMech()
    * Description: Sets the Broadcast Mechanism
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to the Port State value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setBcastMech(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_GplBcastMech       *pObj);


    /*
    * Function:    TSYNC_GPR_getStaticIPV4()
    * Description: Gets Static IP Configurations.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the IPV4 structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getStaticIPV4(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_GplIpV4             *pObj);

    /*
    * Function:    TSYNC_GPR_setStaticIPV4()
    * Description: Sets Static IP Configurations.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the IPV4 structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setStaticIPV4(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_GplIpV4             *pObj);

    /*
    * Function:    TSYNC_GPR_getCurrentIPV4()
    * Description: Gets current IP Configuration.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the IPV4 structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getCurrentIPV4(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_GplIpV4             *pObj);

    /*
    * Function:    TSYNC_GPR_getDHCPEn()
    * Description: Gets the DHCP Enable value.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to the DHCP Enable value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getDHCPEn(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        unsigned int              *pVal);


    /*
    * Function:    TSYNC_GPR_setDHCPEn()
    * Description: Sets the DHCP Enable value
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to the DHCP Enable value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setDHCPEn(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        unsigned int              *pVal);


    /*
    * Function:    TSYNC_GPR_getMacAddr()
    * Description: Gets MAC Address.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the MAC Address structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getMacAddr(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_GplMacAddr          *pObj);

    /*
    * Function:    TSYNC_GPR_setMacAddr()
    * Description: Sets MAC Address
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the MAC Address structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setMacAddr(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_GplMacAddr          *pObj);



    /*
    * Function:    TSYNC_GPR_getTTL()
    * Description: Gets the TTL value.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to the TTL value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getTTL(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        unsigned int              *pVal);


    /*
    * Function:    TSYNC_GPR_setTTL()
    * Description: Sets the TTL value
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to the TTL value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setTTL(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        unsigned int              *pVal);

    /*
    * Function:    TSYNC_GPR_getEthTrans()
    * Description: Gets the Ethernet Transport value.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to the Ethernet Transport value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getEthTrans(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        unsigned int              *pVal);


    /*
    * Function:    TSYNC_GPR_setEthTrans()
    * Description: Sets the DHCP Enable value
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to the Ethernet Transport value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setEthTrans(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        unsigned int              *pVal);


    /*
    * Function:    TSYNC_GPR_getSyncEth()
    * Description: Gets the Sync-E Configuration.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the Sync-E structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getSyncEth(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_GplSyncEth          *pObj);

    /*
    * Function:    TSYNC_GPR_setSyncEth()
    * Description: Sets the Sync-E Configuration
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the Sync-E structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setSyncEth(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_GplSyncEth          *pObj);

    /*
    * Function:    TSYNC_GPR_getVLAN()
    * Description: Gets the VLAN Configuration.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the VLAN structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getVLAN(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_GplVlan             *pObj);

    /*
    * Function:    TSYNC_GPR_setVLAN()
    * Description: Sets the VLAN configuration
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the VLAN structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setVLAN(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_GplVlan             *pObj);

    /*
    * Function:    TSYNC_GPR_getClassCfg()
    * Description: Gets the Clock Class configuration.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to the ClassCfg Value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getClassCfg(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      *pVal);

    /*
    * Function:    TSYNC_GPR_setClassCfg()
    * Description: Sets the Clock Class configuration
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to the ClassCfg structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setClassCfg(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      *pVal);


    /*
    * Function:    TSYNC_GPR_getModuleInfo()
    * Description: Gets the Module Info.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the Module Info structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getModuleInfo(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_GplModuleInfo       *pObj);


    /*
    * Function:    TSYNC_GPR_getControl()
    * Description: Gets the Control information of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the Control structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getControl(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        TSYNC_GplControl *pObj);

    /*
    * Function:    TSYNC_GPR_setControl()
    * Description: Sets the Control information of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   IN:  pObj          - pointer to the Control structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setControl(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        TSYNC_GplControl *pObj);

    /*
    * Function:    TSYNC_GPR_getPortSpeed()
    * Description: Gets the Port Speed information of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to Port Speed
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getPortSpeed(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      *pVal);

    /*
    * Function:    TSYNC_GPR_setPortSpeed()
    * Description: Sets the Port Speed information of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   IN:  pVal          - pointer to Port Speed value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setPortSpeed(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      *pVal);

    /*
    * Function:    TSYNC_GPR_getSlaveStats()
    * Description: Gets the Slave Stats information of the given module
    *              Must use GPR_getSlaveSummary and GPR_setSlaveStats first.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the Slave Stats structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getSlaveStats(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        TSYNC_GplSlaveStats  *pObj);


    /*
    * Function:    TSYNC_GPR_setSlaveStats()
    * Description: Sets the Slave number to get Stats for.
    *              Must use GP_getSummary first.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   IN:  pVal          - pointer to Slave Number
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setSlaveStats(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      *pVal);

    /*
    * Function:    TSYNC_GPR_getSlaveSummary()
    * Description: Gets the Slave Summary information of the given module
    *              Also latches data for setSlaveStats.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pObj          - pointer to the Slave Stats structure
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getSlaveSummary(
        TSYNC_BoardHandle      hnd,
        unsigned int           nInstance,
        TSYNC_GplSlaveSummary *pObj);


    /*
    * Function:    TSYNC_GPR_getDebug()
    * Description: Gets the debug information of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to Debug
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getDebug(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        unsigned int              *pVal);


    /*
    * Function:    TSYNC_GPR_setDebug()
    * Description: Sets the Debug information of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   IN:  pVal          - pointer to Debug value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setDebug(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        unsigned int              *pVal);


   /*
    * Function:    TSYNC_GPR_getProfile()
    * Description: Gets the profile information of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to Profile
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_getProfile(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        unsigned int              *pVal);


    /*
    * Function:    TSYNC_GPR_setProfile()
    * Description: Sets the Profile information of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   IN:  pVal          - pointer to Profile value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_GPR_setProfile(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        unsigned int              *pVal);

    /*
     * Function:    TSYNC_GPR_getPPSOffset()
     * Description: Gets the profile information of the given module
     *
     * Parameters:
     *   IN:  hnd           - Board handle
     *   OUT: pVal          - pointer to PPS Offset value
     *
     * Returns: (TSYNC_SUCCESS) Success
     */
     DLL_EXPORT
     TSYNC_ERROR TSYNC_GPR_getPPSOffset(
         TSYNC_BoardHandle         hnd,
         unsigned int              nInstance,
         unsigned int              *pVal);


     /*
     * Function:    TSYNC_GPR_setPPSOffset()
     * Description: Sets the Profile information of the given module
     *
     * Parameters:
     *   IN:  hnd           - Board handle
     *   IN:  pVal          - pointer to PPS Offset Value
     *
     * Returns: (TSYNC_SUCCESS) Success
     */
     DLL_EXPORT
     TSYNC_ERROR TSYNC_GPR_setPPSOffset(
         TSYNC_BoardHandle         hnd,
         unsigned int              nInstance,
         unsigned int              *pVal);


/*
    * Function:    TSYNC_FM_getNumInst()
    * Description: Get number of Frequency Mon present in the system.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to Profile
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FM_getNumInst(
        TSYNC_BoardHandle         hnd,
        unsigned int              *pVal);

/*
    * Function:    TSYNC_FM_getRefFrequency()
    * Description: Gets the ref freq information of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to Profile
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FM_getRefFrequency(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        float              *pVal);

    /*
    * Function:    TSYNC_FM_setRefFrequency()
    * Description: Sets the ref freq information of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   IN:  pVal          - pointer to Profile value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FM_setRefFrequency(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        float                    pVal);

/*
    * Function:    TSYNC_FM_getMinAccuracy()
    * Description: Gets the min accuracy information of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to Profile
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FM_getMinAccuracy(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        float                   *pVal);

    /*
    * Function:    TSYNC_FM_setMinAccuracy()
    * Description: Sets the min accuracy information of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   IN:  pVal          - pointer to Profile value
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FM_setMinAccuracy(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        float                    pVal);

   /*
    * Function:    TSYNC_FM_getFrequency()
    * Description: Gets the freq information of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to Profile
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FM_getFrequency(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        float                    *pVal);

/*
    * Function:    TSYNC_FM_getAccuracy()
    * Description: Gets the accuracy information of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to Profile
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FM_getLogAccuracy(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_FmLogObj            *pVal);

   /*
    * Function:    TSYNC_FM_getFrequency()
    * Description: Gets the freq information of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to Profile
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FM_getLogFrequency(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        TSYNC_FmLogObj            *pVal);

/*
    * Function:    TSYNC_FM_getAccuracy()
    * Description: Gets the accuracy information of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to Profile
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FM_getAccuracy(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        float                   *pVal);

/*
    * Function:    TSYNC_FM_getAccurate()
    * Description: Gets the accurate information of the given module
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: pVal          - pointer to Profile
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_FM_getAccurate(
        TSYNC_BoardHandle         hnd,
        unsigned int              nInstance,
        unsigned int              *pVal);

    /* Hardware Interface ==============================
     *
     * ======================*/

    /*
    * Function:    TSYNC_HW_getTime()
    * Description: Get the current system time from the hardware.
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *   OUT: pObj              - Pointer to the time result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HW_getTime(
        TSYNC_BoardHandle  handle,
        TSYNC_HWTimeObj    *pObj);

    /*
    * Function:    TSYNC_HW_getTimeSec()
    * Description: Get the current system time from the hardware in
    *              seconds format.
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *   OUT: pObj              - Pointer to the time result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HW_getTimeSec(
        TSYNC_BoardHandle       handle,
        TSYNC_HWTimeSecondsObj *pObj);

    /*
    * Function:    TSYNC_HW_getTsEnable()
    * Description: Get the current enable/disable state of timestamps.
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *   OUT: bEnable           - The enable result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HW_getTsEnable(
        TSYNC_BoardHandle  handle,
        int               *bEnable);

    /*
    * Function:    TSYNC_HW_setTsEnable()
    * Description: Set the current enable/disable state of timestamps.
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *        bEnable           - The enable information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HW_setTsEnable(
        TSYNC_BoardHandle handle,
        int               bEnable);

    /*
    * Function:    TSYNC_HW_setTsReq()
    * Description: Manually generate a hardware timestamp.
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HW_setTsReq(
        TSYNC_BoardHandle handle);

    /*
    * Function:    TSYNC_HW_setTsClear()
    * Description: Clear all collected timestamps from the specified source.
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *        source            - Timestamp source
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HW_setTsClear(
        TSYNC_BoardHandle handle,
        TMSTMP_SRC        source);

    /*
    * Function:    TSYNC_HW_getTsCount()
    * Description: Get the number of collected timestamps for the specified
    *              source.
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *        source            - The timestamp source information
    *   OUT: nCount            - The count result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HW_getTsCount(
        TSYNC_BoardHandle  handle,
        TMSTMP_SRC         source,
        unsigned int      *nCount);

    /*
    * Function:    TSYNC_HW_getTsData()
    * Description: Get all collected timestamps for the specified source.
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *        source            - The timestamp source information
    *   OUT: pObj              - Pointer to the timestamp data result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HW_getTsData(
        TSYNC_BoardHandle    handle,
        TMSTMP_SRC           source,
        TSYNC_HWTimeDataObj *pObj);

    /*
    * Function:    TSYNC_HW_getMatchTimeHi()
    * Description: Get the match time value when the specified general purpose
    *              output will transition to an active high state.
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *        index             - GPO index information
    *   OUT: pObj              - Pointer to the time result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HW_getMatchTimeHi(
        TSYNC_BoardHandle  handle,
        OD_PIN             index,
        TSYNC_TimeObj     *pObj);

    /*
    * Function:    TSYNC_HW_setMatchTimeHi()
    * Description: Set the match time value when the specified general purpose
    *              output will transition to an active high state.
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *        index             - GPO index information
    *        pObj              - Pointer to the time information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HW_setMatchTimeHi(
        TSYNC_BoardHandle  handle,
        OD_PIN             index,
        TSYNC_TimeObj     *pObj);

    /*
    * Function:    TSYNC_HW_getMatchTimeLo()
    * Description: Get the match time value when the specified general purpose
    *              output will transition to an active low state.
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *        index             - GPO index information
    *   OUT: pObj              - Pointer to the time result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HW_getMatchTimeLo(
        TSYNC_BoardHandle  handle,
        OD_PIN             index,
        TSYNC_TimeObj     *pObj);

    /*
    * Function:    TSYNC_HW_setMatchTimeLo()
    * Description: Set the match time value when the specified general purpose
    *              output will transition to an active low state.
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *        index             - GPO index information
    *        pObj              - Pointer to the time information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HW_setMatchTimeLo(
        TSYNC_BoardHandle  handle,
        OD_PIN             index,
        TSYNC_TimeObj     *pObj);

    /*
    * Function:    TSYNC_HW_getFpgaInfo()
    * Description: Get the the FPGA ID and version information.
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *   OUT: id                - The ID result
    *        rev               - The version result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HW_getFpgaInfo(
        TSYNC_BoardHandle  handle,
        unsigned short    *id,
        unsigned short    *rev);

    /*
    * Function:    TSYNC_HW_getIntMask()
    * Description: Get the hardware interrupt masking enabled state
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *        intType           - The interrupt type information
    *        index             - The interrupt index information
    *   OUT: bEnable           - The enable result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HW_getIntMask(
        TSYNC_BoardHandle  handle,
        INT_TYPE           intType,
        unsigned int       index,
        int               *bEnable);

    /*
    * Function:    TSYNC_HW_setIntMask()
    * Description: Set the hardware interrupt masking enabled state
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *        intType           - The interrupt type information
    *        index             - The interrupt index information
    *        bEnable           - The enable information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HW_setIntMask(
        TSYNC_BoardHandle handle,
        INT_TYPE          intType,
        unsigned int      index,
        int               bEnable);

    /*
    * Function:    TSYNC_HW_getTsSingle()
    * Description: Get a single collected timestamp for a given source.
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *        source            - The timestamp source information
    *   OUT: pObj              - Pointer to the time result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HW_getTsSingle(
        TSYNC_BoardHandle  handle,
        TMSTMP_SRC         source,
        TSYNC_HWTimeObj   *pObj);

    /*
    * Function:    TSYNC_HW_getIntCnt()
    * Description: Get the interrupt counter
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *        intType           - The interrupt type information
    *        index             - The interrupt index information
    *   OUT: nIntCount         - The interrupt counter result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HW_getIntCnt(
        TSYNC_BoardHandle  handle,
        INT_TYPE           intType,
        unsigned int       index,
        unsigned int      *nIntCount);

    /*
    * Function:    TSYNC_HW_getIntTs()
    * Description: Get the interrupt timestamp
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *        intType           - The interrupt type information
    *        index             - The interrupt index information
    *   OUT: pObj              - Pointer to the interrupt timestamp result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HW_getIntTs(
        TSYNC_BoardHandle     handle,
        INT_TYPE              intType,
        unsigned int          index,
        TSYNC_TimeSecondsObj *pObj);


    /*
    * Function:    TSYNC_HW_clrIntCnt()
    * Description: Clear the interrupt counter
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *        intType           - The interrupt type information
    *        index             - The interrupt index information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HW_clrIntCnt(
        TSYNC_BoardHandle  handle,
        INT_TYPE           intType,
        unsigned int       index);

   /*
    * Function:    TSYNC_HW_getTemperature()
    * Description: Read the current board temperature in counts.
    *
    *    To convert to degrees C
    *    freq = 1/(pTemp*.00000002) // convert counts to freq
    *    temperature = (freq/4)-273.15 // convert freq to Temp
    *
    * Parameters:
    *   IN:  handle           - Board handle
    *
    *   OUT: pTemp           - Pointer to contents of temperature
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HW_getTemperature(
        TSYNC_BoardHandle handle,
        unsigned short *pTemp);

   /*
    * Function:    TSYNC_HW_getTemperature_ss()
    * Description: Read the current board temperature in counts.
    *
    *   To convert to degrees C
    *    freq = 1/(pTemp*.00000002) // convert counts to freq
    *    temperature = (freq/4)-273.15 // convert freq to Temp
    *
    * Parameters:
    *   IN:  handle           - Board handle
    *
    *   OUT: pTemp            - Pointer to contents of temperature
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HW_getTemperature_ss(
        TSYNC_BoardHandle handle,
        unsigned short *pTemp);

    DLL_EXPORT
    TSYNC_ERROR TSYNC_SW_getIOSwitch(
        TSYNC_BoardHandle pHandle,
        TSYNC_IOSwitchObj *sw,
        uint32_t io);

    DLL_EXPORT
    TSYNC_ERROR TSYNC_SW_setIOSwitch(
        TSYNC_BoardHandle pHandle,
        uint8_t feature,
        uint8_t type,
        uint8_t inst,
        uint8_t io);

    DLL_EXPORT
    TSYNC_ERROR TSYNC_SW_getSwitchOptionsAmount(
        TSYNC_BoardHandle pHandle,
        uint32_t* optionsAmount);

    DLL_EXPORT
    TSYNC_ERROR TSYNC_SW_getSwitchOption(
        TSYNC_BoardHandle pHandle,
        TSYNC_SwitchOptionObj* sw,
        uint32_t index);

    DLL_EXPORT
    TSYNC_ERROR TSYNC_SW_getSwitchIoNum(
        TSYNC_BoardHandle pHandle,
        uint32_t* ioNum);

    /* Mac Reference Component ==============================================*/

    /*
    * Function:    TSYNC_MR_getValidity()
    * Description: Get the reference validity from the MR.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: bTimeValid    - The time reference result
    *        bPpsValid     - The pps reference result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_MR_getValidity(
        TSYNC_BoardHandle  hnd,
        unsigned int       nInstance,
        int               *bTimeValid,
        int               *bPpsValid);

    /*
    * Function:    TSYNC_MR_setValidity()
    * Description: Set the reference validity of the MR.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        bTimeValid    - The time reference validity
    *        bPpsValid     - The pps reference validity
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_MR_setValidity(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int               bTimeValid,
        int               bPpsValid);


    /*
    * Function:    TSYNC_MR_getTime()
    * Description: Get the current time of the MR.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the time result (doyTime)
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_MR_getTime(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        TSYNC_TimeObj     *pObj);

    /*
    * Function:    TSYNC_MR_getRefId()
    * Description: Get the references Ids of the MR.
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: pObj          - Pointer to the RefId Object
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_MR_getRefId(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        TSYNC_RefIdObj    *pObj);

    /*
    * Function:    TSYNC_MR_getUTCOffset()
    * Description: Get the references Ids
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: utcOff        - Pointer to current custom UTC offset
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_MR_getUTCOffset(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int               *utcOff);

    /*
    * Function:    TSYNC_MR_setUTCOffset()
    * Description: Get the current custom UTC offset value
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_MR_setUTCOffset(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int               utcOff);

    /*
    * Function:    TSYNC_MR_useCSOff()
    * Description: Tells the MR instance whether it should
                   use CS or custom UTC offset
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *        useCsOff      - use CS offset ?
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_MR_useCSOff(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        unsigned int      useCsOff);

    /*
    * Function:    TSYNC_MR_getUseCSOff()
    * Description: Returns whether the MR instance is currently using
    *              CS offset or custom UTC offset
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *        nInstance     - The instance number
    *   OUT: CSOffUsed     - MR instance currently using CS ?
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_MR_getUseCSOff(
        TSYNC_BoardHandle hnd,
        unsigned int      nInstance,
        int               *CSOffUsed);

    /*
    * Function:    TSYNC_MR_getNumInst()
    * Description: Returns the number of MR instances
    *
    * Parameters:
    *   IN:  hnd           - Board handle
    *   OUT: nInstance     - The number of instances
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR
    TSYNC_MR_getNumInst(
        TSYNC_BoardHandle hnd,
        unsigned int *nInstances);


/* Include prototypes for non-KTS functionality */
#include "tsync_nonkts.h"

#ifdef __cplusplus
}
#endif

#endif  /* _defined_TSYNC_H */
