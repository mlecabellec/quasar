#ifndef __TSYNC_EXAMPLE_H__
#define __TSYNC_EXAMPLE_H__ 1

#define DEVICE_ROOT         "/dev/"
#define DEFAULT_DEV         "tsyncpci"
#define DEFAULT_DEV_NUM     0

#endif
