///////////////////////////////////////////////////////////////////////////////
//
// Name:        spec_ktsal_en.h
// Date:        08/03/09
// Author:      Pat McDermott
// Purpose:     This module holds constants that are to be used by the
//              tsync example get access programs.
//
// Description: Holds common constants for the tsync example get access
//              programs.
//
//              To use define the environment variable in the shell of the
//              caller of an access program.  For example for a single
//              command do the following:
//
//              shell> SPEC_KTSAL_EN=true ./IP_GetAmp 0 0 
//
//
// (c) Copyright 2009 Spectracom Corporation, All Rights Reserved
///////////////////////////////////////////////////////////////////////////////
#ifndef _SPEC_KTSAL_EN_H
#define _SPEC_KTSAL_EN_H

const char*     ENV_TRUE       = "true";
const char*     SPEC_KTSAL_EN  = "SPEC_KTSAL_EN";
const char*     SPEC_KTSAL_ENV = "SPEC_KTSAL_EN=true";

#endif // _SPEC_KTSAL_EN_H
