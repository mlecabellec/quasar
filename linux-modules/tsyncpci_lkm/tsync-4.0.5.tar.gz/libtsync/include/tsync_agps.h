#ifndef __tsync_agps_h__
#define __tsync_agps_h__ 1

#ifdef __cplusplus
extern "C" {
#endif

// The AGPS_ALMANAC type is used to store the A-GPS almanac information.
// This information is a set of parameters to the equations that describe the
// coarse orbit of a GPS SV.  This is the set of almanac data provided by a
// SUPL server. The naming is consistent with ICD-GPS-200 Sec 20.3.3.5.1.2.
typedef struct
{
    unsigned int   prn;
    unsigned int   svHealth;
    unsigned int   weekNumber;
    float          e;
    unsigned int   toa;
    float          io;          // AKA ksii
    float          omegaDot;
    float          sqrtA;
    float          omega0;
    float          omega;       // AKA "w"
    float          m0; 
    float          af0;
    float          af1;

} AGPS_ALMANAC;

// The AGPS_EPHEMERIS type is used to store the A-GPS ephemeris information.
// This information is a set of parameters to the equations that describe
// the orbit of a GPS SV, in a finer way than the almanac.  This is the set of 
// ephemeris data provided by a SUPL server.    
// The naming is consistent with ICD-GPS-200 Sec 20.3.3.5.1.2.
typedef struct
{
    unsigned int   prn;
    unsigned int   svHealth;
    float          tephem;
    unsigned int   weekNumber;
    unsigned int   codeL2;
    unsigned int   L2Pdata;
    unsigned int   uraIdx;  // svAccRaw
    unsigned int   iodc;
    float          tgd;
    float          toc;
    float          af2;
    float          af1;
    float          af0;
    float          svAcc;
    unsigned int   iode;
    unsigned int   fit_interval;
    float          crs;
    float          deltaN;
    double         m0;
    float          cuc;
    double         e;
    float          cus;
    double         sqrtA;
    float          toe;
    float          cic;
    double         omega0;
    float          cis;
    double         io;
    float          crc;
    double         omega;       // AKA "w"
    float          omegaDot;
    float          idot;

} AGPS_EPHEMERIS;

#ifdef __cplusplus
}
#endif

#endif
