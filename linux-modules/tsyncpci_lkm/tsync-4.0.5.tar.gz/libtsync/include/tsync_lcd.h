#ifndef __TSYNC_LCD_H__
#define __TSYNC_LCD_H__ 1

/* LCD status register bits (not the CSL status register) */
#define LCD_STAT_RESET  (0x10)   /* Driver chip in reset if 1 */
#define LCD_STAT_ONOFF  (0x20)   /* 0 = display on, 1 = display off */
#define LCD_STAT_ADC    (0x40)   /* 0 = reverse, 1 = forward */
#define LCD_STAT_BUSY   (0x80)   /* Driver chip is busy if 1 */

/* CSL status register bits */
#define LCD_READ_BUSY   (0x0100) /* Valid read data not ready until this is 0 */
#define LCD_WRITE_BUSY  (0x0200) /* Cannot write anything until this is 0 */

/* CSL command register bits */
#define LCD_A0          (0x100)  /* 0 = command/status, 1 = data */
#define LCD_RW          (0x200)  /* 0 = write, 1 = read */

/* CSL command register bus cycle types using the bits defined above */
#define LCD_WRITE_CMD   (0              )   /* R/W = 0, A0 = 0 */
#define LCD_WRITE_DATA  (         LCD_A0)   /* R/W = 0, A0 = 1 */
#define LCD_READ_STAT   (LCD_RW         )   /* R/W = 1, A0 = 0 */
#define LCD_READ_DATA   (LCD_RW | LCD_A0)   /* R/W = 1, A0 = 1 */

/* LCD dimensions */
#define LCD_NUM_PAGES_V (4)   /* Number of pages vertically (all in one chip) */
#define LCD_PAGE_HEIGHT (8)   /* Page height in pixels */
#define LCD_NUM_PAGES_H (2)   /* One display = 2 side-by-side (2 chips) */
#define LCD_PAGE_WIDTH  (61)  /* Page width in pixels */
#define LCD_ROW_LENGTH  (LCD_ROW_MAX + 1)
#define LCD_COL_LENGTH  (LCD_COL_MAX + 1)

/* Maximum row and column ranges.
 * These do not represent the dimensions of the display being used but are
 * intended for static uses.  There is an Ioctl function that can be used to
 * get the actual size of the display being used.
 */
#define LCD_ROW_MIN (0)
#define LCD_ROW_MAX (31)
#define LCD_COL_MIN (0)
#define LCD_COL_MAX (121)

/* LCD commands - write to set status of certain features
 *
 * The values here describe the upper bits of the 8-bit command sent to the LCD
 * controller.  These bits determine what command is being issued.
 * The lower bits are arguments to the commands.
 */
#define LCD_CMD_ONOFF   (0xAE)  /* Bits 7-1 fixed, Bit 0: 1=LCD on, 0=LCD off */
#define LCD_CMD_START   (0xC0)  /* Bits 7-5 fixed, Bits 4-0: start line address */
#define LCD_CMD_PAGE    (0xB8)  /* Bits 7-2 fixed, Bits 1-0: page number */
#define LCD_CMD_COLUMN  (0x00)  /* Bit 7 fixed,    Bits 6-0: column number */
#define LCD_CMD_ADC     (0xA0)  /* Bits 7-1 fixed, Bit 0: 1=reverse, 0=forward */
#define LCD_CMD_STATIC  (0xA4)  /* Bits 7-1 fixed, Bit 0: 1=static, 0=normal */
#define LCD_CMD_DUTY    (0xA8)  /* Bits 7-1 fixed, Bit 0: 1=1/32 duty, 0=1/16 */
#define LCD_CMD_RMW     (0xE0)  /* Enable Read-Modify-Write(RMW) mode */
#define LCD_CMD_END     (0xEE)  /* End Read-Modify-Write mode */
#define LCD_CMD_RESET   (0xE2)  /* Software reset command */

/*******************************************************************************
 * Typedefs
 ******************************************************************************/

/* Select the first, second, or both chips in a targeted display */
typedef enum {
    LCD_CHIP_ONE  = 0x1000,
    LCD_CHIP_TWO  = 0x2000,
    LCD_CHIP_BOTH = 0x3000
} LCD_CHIP;

/* Draw modes: used to control the type of data transfer to and from LCD. */
typedef enum {
    LCD_DRAW_MODE_OVER = 0,
    LCD_DRAW_MODE_OR,
    LCD_DRAW_MODE_AND,
    LCD_DRAW_MODE_XOR,
    LCD_DRAW_MODE_READ
} LCD_DRAW_MODE;

/* Image data type.  This is used for transfers with an LCD.  Holds the
 * coordinate of the upper left corner, the size of the display (in rows by
 * columns), and a pointer to an array describing the dots.
 */
typedef struct {
    uint32_t       upperLeftCol;
    uint32_t       upperLeftRow;
    uint32_t       colSize;
    uint32_t       rowSize;
    uint8_t const *dots;
    LCD_DRAW_MODE  mode;        /* Draw mode, only used for writes */
} LCD_IMAGE;

#endif
