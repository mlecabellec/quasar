#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>

#include "tsync.h"
#include "tsync_driver_interface.h"
#include "tsync_macros.h"
#include "tsync_trans.h"
#include "ddtsync.h"
#include "ddtpro.h"

TSYNC_ERROR TSYNC_openImpl(TSYNC_BoardHandle* hnd, const char *deviceName)
{
  TSYNC_BoardObj *Board;

  /**
  ***  allocate board object
  **/
  Board = (TSYNC_BoardObj *) malloc (sizeof (TSYNC_BoardObj));
  if ( Board == NULL) {
    return (TSYNC_OBJECT_ERR);
  }


  /**
  ***  open device
  **/

  Board->file_descriptor = open (deviceName, O_RDWR);
  if (Board->file_descriptor < 0) {
      printf("Unable to open %s: %s\n", deviceName, strerror(errno));

        /*
         * free resource on failure
         */
        free( Board );
        Board = NULL ;

      return (TSYNC_HANDLE_ERR);
  }


  /**
  *** create open I/O control
  **/

  if (ioctl (Board->file_descriptor, IOCTL_TPRO_OPEN, Board) < 0) {
    return (TSYNC_COMM_ERR);
  }

#if 0
  /**
  ***  get firmware
  **/

  if (ioctl (Board->file_descriptor, IOCTL_TSYNC_GET_FIRMWARE, Board->firmware) < 0) {
    return (TSYNC_COMM_ERR);
  }


  /**
  ***  get fpga version
  **/

  if ( (Board->options == 0x7000) || (Board->options == 0x7100) ) {

    if (ioctl (Board->file_descriptor, IOCTL_TSYNC_GET_FPGA, Board->FPGA) < 0) {
      return (TSYNC_COMM_ERR);
    }
  }
#endif

  /**
  ***  set user context pointer
  **/

  *((TSYNC_BoardObj**)hnd) =  Board;

  return (TSYNC_SUCCESS);
}

TSYNC_ERROR TSYNC_closeImpl(TSYNC_BoardHandle hnd) {
    TSYNC_ERROR         rc;
    TSYNC_ERROR   ret = TSYNC_DEVICE_NOT_OPEN_ERR;
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

#if 1
    /*
     * if board not present, and if there is no file descriptor,
     * then return that the device associated with the board
     * has not been opened.
     */
    if ( handle != NULL )
    {
        if ( handle->file_descriptor >= 0 )
        {
            /*
             * close the opened device
             */
            errno = 0;
            ret = TSYNC_CLOSE_HANDLE_ERR;

            if ( (rc = close( handle->file_descriptor )) == 0 )
            {
                ret = TSYNC_SUCCESS;
            }
#ifdef DEBUG
            else
            {
                printf("Close() failed: rc <%d> errno <%d>\n",
                        rc, errno );
            }
#endif
        }

        /*
         * free resources
         */
        free( handle );
        handle = NULL;
    }

#endif
    ret = TSYNC_SUCCESS;

    /*
     * return results
     */
    return ( ret );
}

TSYNC_ERROR TSYNC_ioctl(TSYNC_BoardHandle hnd,
                        TSYNC_IOCTL_ID id,
                        void* data,
                        unsigned int dataLength) {
    int ioctlStatus;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*) hnd;

    const unsigned int invalidID = 0xdead;
    unsigned int actualID = invalidID;

    UNUSED_VARIABLE(dataLength);

    switch (id) {
    case TSYNC_GET:
        actualID = IOCTL_TSYNC_GET;
        break;

    case TSYNC_SET:
        actualID = IOCTL_TSYNC_SET;
        break;

    case TSYNC_WAIT:
        actualID = IOCTL_TSYNC_WAIT;
        break;

    case TSYNC_WAIT_TO:
        actualID = IOCTL_TSYNC_WAIT_TO;
        break;
    }

    if (actualID == invalidID) {
        return TSYNC_INVALID_INPUT;
    }

    ioctlStatus = ioctl(handle->file_descriptor, actualID, data);

    if (ioctlStatus != 0) {
        printf("ioctl returned %d (%s:%u)\n", ioctlStatus, __FILE__, __LINE__);
        return TSYNC_COMM_ERR;
    }


    return TSYNC_SUCCESS;
}
