
#ifndef _defined_TSYNC_SR_SERVICES_H
#define _defined_TSYNC_SR_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_sr_services.h
**
**  Date:       04/21/10
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2010 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              04/21/2010 Added Reference ID
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_SR                     0x43

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#endif  /* _defined_TSYNC_SR_SERVICES_H */
