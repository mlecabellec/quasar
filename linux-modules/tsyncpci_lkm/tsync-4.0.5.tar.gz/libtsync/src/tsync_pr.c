#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_pr_services.h"
#include "tsync_misc_services.h"

extern uint8_t PR_VALUE_RECIPE[];
extern uint8_t PR_OFFSET_SET_CMD_RECIPE[];
extern uint8_t PR_EDGE_SET_CMD_RECIPE[];
extern uint8_t EL_VALIDITY_RECIPE[];
extern uint8_t EL_REF_ID_RECIPE[];

TSYNC_ERROR
TSYNC_PR_getOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *nOffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nOffset);

        struct PR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PR_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PR,
            TSYNC_ID_PR_CA_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PR_VALUE_RECIPE,
            PR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PR_VALUE* outPayload =
            (PR_VALUE*)GetPayload(result);
            
        *nOffset = outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_PR_setOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int nOffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct PR_OFFSET_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.offset = nOffset;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PR_OFFSET_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_PR,
            TSYNC_ID_PR_CA_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PR_OFFSET_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_PR_getEdge(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    EDGE *edge)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(edge);

        struct PR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PR_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PR,
            TSYNC_ID_PR_CA_EDGE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PR_VALUE_RECIPE,
            PR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PR_VALUE* outPayload =
            (PR_VALUE*)GetPayload(result);
            
        *edge = (EDGE)outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_PR_setEdge(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    EDGE edge)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct PR_EDGE_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.edge = edge;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PR_EDGE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_PR,
            TSYNC_ID_PR_CA_EDGE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PR_EDGE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_PR_getValidity(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *bTimeValid,
    int *bPpsValid)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(bTimeValid);
        CHECK_NOT_NULL(bPpsValid);

        struct PR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(EL_VALIDITY_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PR,
            TSYNC_ID_PR_CA_VALIDITY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PR_VALUE_RECIPE,
            EL_VALIDITY_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct EL_VALIDITY* outPayload =
            (EL_VALIDITY*)GetPayload(result);
            
        *bTimeValid = outPayload->timeValid;
        *bPpsValid = outPayload->ppsValid;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_PR_getNumInst(
    TSYNC_BoardHandle hnd,
    unsigned int *nInstances)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nInstances);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PR_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PR,
            TSYNC_ID_PR_CA_NUM_INST,
            ctl,
            pyldLen,
            NULL,
            NULL,
            PR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PR_VALUE* outPayload =
            (PR_VALUE*)GetPayload(result);
            
        *nInstances = outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_PR_getRefId(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_RefIdObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(EL_REF_ID_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PR,
            TSYNC_ID_PR_CA_REF_ID,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PR_VALUE_RECIPE,
            EL_REF_ID_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct EL_REF_ID* outPayload =
            (EL_REF_ID*)GetPayload(result);
            
        memset(pObj->refid, '\0', sizeof(pObj->refid));
        memcpy(pObj->refid, outPayload->ref, sizeof(outPayload->ref));
        
    return ( err );
}

