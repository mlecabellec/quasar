
/***************************************************************************
**  Module:     tsync_gpr_services_recipes.c
**
**  Date:       03/06/2013
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2013 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              03/06/2015 Creation DPR
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_gpr_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(GPR_VALUE)
RECIPE(GPR_VALUE_SET_CMD)
RECIPE(GPL_CLOCK_ID)
RECIPE(GPL_CLOCK_ID_SET)
RECIPE(GPL_PRIORITY)
RECIPE(GPL_PRIORITY_SET)
RECIPE(GPL_CLOCK_QUAL)
RECIPE(GPL_STATISTICS)
RECIPE(GPL_PARENT_DATA)
RECIPE(GPL_TIME_PROP)
RECIPE(GPL_USER_DESC)
RECIPE(GPL_USER_DESC_SET)
RECIPE(GPL_UNCT_MASTER_ADD)
RECIPE(GPL_UNCT_MASTER_ADD_SET)
RECIPE(GPL_PORT_IDENTITY)
RECIPE(GPL_PORT_IDENTITY_SET)
RECIPE(GPL_UNCT_SLAVE_PROP)
RECIPE(GPL_UNCT_MASTER_PROP)
RECIPE(GPL_UNCT_MASTER_CFG)
RECIPE(GPL_UNCT_MASTER_CFG_SET)
RECIPE(GPL_MSG_RATES)
RECIPE(GPL_MSG_RATES_SET)
RECIPE(GPL_MSG_TO)
RECIPE(GPL_MSG_TO_SET)
RECIPE(GPL_IPV4)
RECIPE(GPL_IPV4_SET)
RECIPE(GPL_MAC_ADDR)
RECIPE(GPL_MAC_ADDR_SET)
RECIPE(GPL_SYNC_ETH_ITF)
RECIPE(GPL_SYNC_ETH_ITF_SET)
RECIPE(GPL_VLAN)
RECIPE(GPL_VLAN_SET)
RECIPE(GPL_MODULE_INFO)
RECIPE(GPL_CONTROL)
RECIPE(GPL_CONTROL_SET)
RECIPE(GPL_BCAST_MECH)
RECIPE(GPL_BCAST_MECH_SET)
RECIPE(GPL_SLAVE_STATS)
RECIPE(GPL_SLAVE_SUMMARY)



#include "tsync_recipe_undef.h"
