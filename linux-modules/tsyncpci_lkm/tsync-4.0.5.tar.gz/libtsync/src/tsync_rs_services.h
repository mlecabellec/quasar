
#ifndef _defined_TSYNC_RS_SERVICES_H
#define _defined_TSYNC_RS_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_rs_services.h
**
**  Date:       07/25/08
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/25/2008 Creation
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_RS                             0x24
#define TSYNC_ID_RS_CA_FACT_DEFAULT             0x00
#define TSYNC_ID_RS_CA_USER_DEFAULT             0x01
#define TSYNC_ID_RS_CA_SAVE_USER_DEFAULT        0x02
#define TSYNC_ID_RS_CA_BEST_REFERENCE           0x03
#define TSYNC_ID_RS_CA_TABLE                    0x04
#define TSYNC_ID_RS_CA_TABLE_ENTRY              0x05
#define TSYNC_ID_RS_CA_TABLE_ENTRY_ADD          0x06
#define TSYNC_ID_RS_CA_TABLE_ENTRY_DEL          0x07
#define TSYNC_ID_RS_CA_PRIORITY                 0x08
#define TSYNC_ID_RS_CA_ENABLE                   0x09
#define TSYNC_ID_RS_CA_REF_STATE_TABLE          0x0A
#define TSYNC_ID_RS_CA_REF_PHASE_DATA           0x0B
#define TSYNC_ID_RS_CA_REF_PHASE_THRESHOLD      0x0C

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define RS_TABLE_TYPE_OBJ_FIELDS                    \
    TSYNC_X(        RS_TABLE_TYPE,   type)
    
#define RS_TABLE_ENTRY_FIELDS                    \
    TSYNC_X(        uint32_t,   enab)                    \
    TSYNC_X(        uint32_t,   prio)                    \
    TSYNC_X_BUFFER( int8_t,     time,    4)    \
    TSYNC_X_BUFFER( int8_t,     pps,    4)

#define RS_REF_TABLE_FIELDS                    \
    TSYNC_X_ARRAY(  RS_TABLE_ENTRY,   rows, TSYNC_TABLE_ENTRY_NUM)
    
#define RS_TABLE_INDEX_OBJ_FIELDS                    \
    TSYNC_X(        uint32_t,   index)
    
#define RS_TABLE_INDEX_VALUE_FIELDS                   \
    TSYNC_X(        uint32_t,   index)          \
    TSYNC_X(        uint32_t,   value)
    
#define RS_TABLE_VALUE_FIELDS                   \
    TSYNC_X(        uint32_t,   value)
    
#define RS_REF_STATE_ENTRY_FIELDS                       \
    TSYNC_X_BUFFER( int8_t,     src,        4)          \
    TSYNC_X(        uint32_t,   timeValid)              \
    TSYNC_X(        uint32_t,   ppsValid)
    
#define RS_STATE_TABLE_FIELDS                    \
    TSYNC_X_ARRAY(  RS_REF_STATE_ENTRY,   rows, TSYNC_STATE_TABLE_ENTRY_NUM)

#define RS_REF_PHASE_INDEX_OBJ_FIELDS                   \
    TSYNC_X_BUFFER( int8_t,     ref,        4)

#define RS_REF_PHASE_DATA_FIELDS                       \
    TSYNC_X(        uint32_t,   muxPos)                 \
    TSYNC_X_BUFFER( int8_t,     src,        4)          \
    TSYNC_X(        uint32_t,   phaseValid)             \
    TSYNC_X(        int32_t,    phase)                  \
    TSYNC_X(        double,     phaseFiltered)          \
    TSYNC_X(        double,     lAvg)                   \
    TSYNC_X(        double,     lStdDev)                \
    TSYNC_X(        double,     wPhaseErr)              \
    TSYNC_X(        double,     wFreqErr)               \
    TSYNC_X(        double,     threshold)

#define RS_REF_PHASE_INDEX_THRESHOLD_FIELDS             \
    TSYNC_X_BUFFER( int8_t,     ref,        4)          \
    TSYNC_X(        uint32_t,   mode)                   \
    TSYNC_X(        uint32_t,   n)                      \
    TSYNC_X(        double,     minThreshold)           \
    TSYNC_X(        double,     maxThreshold)

#define RS_REF_PHASE_THRESHOLD_FIELDS                   \
    TSYNC_X(        uint32_t,   mode)                   \
    TSYNC_X(        uint32_t,   n)                      \
    TSYNC_X(        double,     minThreshold)           \
    TSYNC_X(        double,     maxThreshold)

#include "tsync_struct_define.h"

GEN_STRUCT(RS_TABLE_TYPE_OBJ)
GEN_STRUCT(RS_TABLE_ENTRY)
GEN_STRUCT(RS_REF_TABLE)
GEN_STRUCT(RS_TABLE_INDEX_OBJ)
GEN_STRUCT(RS_TABLE_INDEX_VALUE)
GEN_STRUCT(RS_TABLE_VALUE)
GEN_STRUCT(RS_REF_STATE_ENTRY)
GEN_STRUCT(RS_STATE_TABLE)
GEN_STRUCT(RS_REF_PHASE_INDEX_OBJ)
GEN_STRUCT(RS_REF_PHASE_DATA)
GEN_STRUCT(RS_REF_PHASE_INDEX_THRESHOLD)
GEN_STRUCT(RS_REF_PHASE_THRESHOLD)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_RS_SERVICES_H */
