
/***************************************************************************
**  Module:     tsync_gi_services_recipes.c
**
**  Date:       07/29/08
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/29/2008 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_gi_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(GI_VALUE)
RECIPE(GI_EDGE_SET_CMD)
RECIPE(GI_TIMESTAMP_ENABLE_SET_CMD)
RECIPE(GI_ASCII_TIMESTAMP)

#include "tsync_recipe_undef.h"
