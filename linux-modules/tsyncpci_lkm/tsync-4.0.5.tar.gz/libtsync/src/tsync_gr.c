#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_gr_services.h"
#include "tsync_misc_services.h"

extern uint8_t GR_VALUE_RECIPE[];
extern uint8_t EL_VALIDITY_RECIPE[];
extern uint8_t GR_VALIDITY_SET_CMD_RECIPE[];
extern uint8_t GR_POS_LLA_RECIPE[];
extern uint8_t GR_FIX_DATA_RECIPE[];
extern uint8_t GL_SAT_INFO_RECIPE[];
extern uint8_t GR_SAT_DATA_RECIPE[];
extern uint8_t GR_MFR_MDL_RECIPE[];
extern uint8_t GR_RCVR_INFO_RECIPE[];
extern uint8_t GR_CUSTOM_MSG_RECIPE[];
extern uint8_t GR_RCVR_PARM_GET_RECIPE[];
extern uint8_t GR_RCVR_PARM_RECIPE[];
extern uint8_t GR_RCVR_PARM_SET_RECIPE[];
extern uint8_t GR_OFFSET_SET_CMD_RECIPE[];
extern uint8_t GR_POS_LLA_SET_CMD_RECIPE[];
extern uint8_t GR_RECMODE_SET_CMD_RECIPE[];
extern uint8_t GR_RECMODE_GET_CMD_RECIPE[];
extern uint8_t GR_DYNMODE_SET_CMD_RECIPE[];
extern uint8_t GR_CUSTOM_MSG_SET_CMD_RECIPE[];
extern uint8_t GR_RESET_CMD_RECIPE[];
extern uint8_t GR_QUAL_LOG_RECIPE[];
extern uint8_t EL_REF_ID_RECIPE[];
extern uint8_t GR_CNST_SET_CMD_RECIPE[];
extern uint8_t GR_ALM_GET_RECIPE[];
extern uint8_t GR_ALM_RECIPE[];
extern uint8_t GR_ALM_SET_RECIPE[];
extern uint8_t GR_EPHM_GET_RECIPE[];
extern uint8_t GR_EPHM_RECIPE[];
extern uint8_t GR_EPHM_SET_RECIPE[];
extern uint8_t GR_AGPS_SERVER_STATE_GET_RECIPE[];
extern uint8_t GR_AGPS_SERVER_STATE_RECIPE[];
extern uint8_t GR_AGPS_SERVER_STATE_SET_RECIPE[];
extern uint8_t GR_IONO_RECIPE[];
extern uint8_t GR_UTC_RECIPE[];

static int FindLine(char* pLine, char* pMatchStr, UBX_RCV_INFO* pRec);
static int FindDigitString(char* pStr, char* pLine);

TSYNC_ERROR
TSYNC_GR_getOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *nOffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nOffset);

        struct GR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GR_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_VALUE_RECIPE,
            GR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct GR_VALUE* outPayload =
            (GR_VALUE*)GetPayload(result);
            
        *nOffset = outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_setOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int nOffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GR_OFFSET_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.nOffset = nOffset;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_OFFSET_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_OFFSET_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}



TSYNC_ERROR
TSYNC_GR_getConstSel(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int *constellation)
{ 
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(constellation);

        struct GR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GR_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_CNST,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_VALUE_RECIPE,
            GR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct GR_VALUE* outPayload =
            (GR_VALUE*)GetPayload(result);
            
        *constellation = outPayload->value;
        
    return ( err );
}


TSYNC_ERROR
TSYNC_GR_setConstSel(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int constellation)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GR_CNST_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.constellation = constellation;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_CNST_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_CNST,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_CNST_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_getValidity(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *bTimeValid,
    int *bPpsValid)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(bTimeValid);
        CHECK_NOT_NULL(bPpsValid);

        struct GR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(EL_VALIDITY_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_VALIDITY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_VALUE_RECIPE,
            EL_VALIDITY_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct EL_VALIDITY* outPayload =
            (EL_VALIDITY*)GetPayload(result);
            
        *bTimeValid = outPayload->timeValid;
        *bPpsValid = outPayload->ppsValid;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_setValidity(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int bTimeValid,
    int bPpsValid)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);

    struct GR_VALIDITY_SET_CMD inPayload;
    inPayload.nInstance = nInstance;
    inPayload.timeValid = bTimeValid;
    inPayload.ppsValid  = bPpsValid;

    uint16_t ctl = 0x02;
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(GR_VALIDITY_SET_CMD_RECIPE, &pos);

    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(0));

    err = BaseTransaction(
        TSYNC_ID_GR,
        TSYNC_ID_GR_CA_VALIDITY,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        GR_VALIDITY_SET_CMD_RECIPE,
        NULL,
        result,
        handle);

    CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_GR_getPosition(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_LLAObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GR_POS_LLA_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_POSITION,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_VALUE_RECIPE,
            GR_POS_LLA_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct GR_POS_LLA* outPayload =
            (GR_POS_LLA*)GetPayload(result);
            
        pObj->lat = outPayload->lat;
        pObj->lon = outPayload->lon;
        pObj->alt = outPayload->alt;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_setPosition(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_LLAObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GR_POS_LLA_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.lat = pObj->lat;
        inPayload.lon = pObj->lon;
        inPayload.alt = pObj->alt;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_POS_LLA_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_POSITION,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_POS_LLA_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_getMode(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    GL_MODE *mode,
    GL_DYN  *dyn)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(mode);

        struct GR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GR_RECMODE_GET_CMD_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_RCVR_MODE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_VALUE_RECIPE,
            GR_RECMODE_GET_CMD_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct GR_RECMODE_GET_CMD* outPayload =
            (GR_RECMODE_GET_CMD*)GetPayload(result);
            
        *mode = outPayload->mode;
        *dyn  = outPayload->dyn;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_setMode(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    GL_MODE mode,
    GL_DYN  dyn)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GR_RECMODE_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.mode = mode;
        inPayload.dyn  = dyn;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_RECMODE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_RCVR_MODE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_RECMODE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_getDynamics(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    GL_DYN *mode)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(mode);

        struct GR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GR_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_DYNAMICS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_VALUE_RECIPE,
            GR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct GR_VALUE* outPayload =
            (GR_VALUE*)GetPayload(result);
            
        *mode = (GL_DYN)outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_setDynamics(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    GL_DYN mode)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GR_DYNMODE_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.mode = mode;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_DYNMODE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_DYNAMICS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_DYNMODE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_getFixData(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_FixDataObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GR_FIX_DATA_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_FIX_DATA,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_VALUE_RECIPE,
            GR_FIX_DATA_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct GR_FIX_DATA* outPayload =
            (GR_FIX_DATA*)GetPayload(result);
            
        pObj->nSats = outPayload->nSats;
        pObj->pdop = outPayload->pdop;
        pObj->hdop = outPayload->hdop;
        pObj->vdop = outPayload->vdop;
        pObj->tdop = outPayload->tdop;
        pObj->fom = outPayload->fom;
        pObj->tfom = outPayload->tfom;
        pObj->herr = outPayload->herr;
        pObj->verr = outPayload->verr;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_getSatData(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_SatDataObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GR_SAT_DATA_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_SAT_DATA,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_VALUE_RECIPE,
            GR_SAT_DATA_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct GR_SAT_DATA* outPayload =
            (GR_SAT_DATA*)GetPayload(result);
            
        int i;
        for(i = 0; i < TSYNC_SAT_INFO_NUM; i++)
        {
            pObj->info[i].chnum = outPayload->info[i].chnum;
            pObj->info[i].svid = outPayload->info[i].svid;
            pObj->info[i].str = outPayload->info[i].str;
            pObj->info[i].bTraim = outPayload->info[i].traim;
            pObj->info[i].bInfix = outPayload->info[i].infix;
            pObj->info[i].flags = outPayload->info[i].flags;
        }
        
    return ( err );
}

void 
TSYNC_GR_svidToString(
    char*              pSvidStr,
    unsigned int       svid)
{
    char svIdChar = 'X';
    
    if ((svid >= GL_SVID_GPS_MIN) && (svid <= GL_SVID_GPS_MAX))
    {
        svIdChar = GL_CNST_CHAR_GPS;
    }
    else if ((svid >= GL_SVID_SBAS_MIN) && (svid <= GL_SVID_SBAS_MAX))
    {
        svIdChar = GL_CNST_CHAR_SBAS;
    }
    else if ((svid >= GL_SVID_GAL_MIN) && (svid <= GL_SVID_GAL_MAX))
    {
        svIdChar = GL_CNST_CHAR_GAL;
    }
    else if (((svid >= GL_SVID_BDS_MIN) && (svid <= GL_SVID_BDS_MAX)) ||
             ((svid >= TSYNC_SVID_BDS_MIN) && (svid <= TSYNC_SVID_BDS_MAX)))
    {
        svIdChar = GL_CNST_CHAR_BDS;
    }
    else if ((svid >= GL_SVID_IMES_MIN) && (svid <= GL_SVID_IMES_MAX))
    {
        svIdChar = GL_CNST_CHAR_IMES;
    }
    else if (((svid >= GL_SVID_QZSS_MIN) && (svid <= GL_SVID_QZSS_MAX)) ||
             ((svid >= TSYNC_SVID_QZSS_MIN) && (svid <= TSYNC_SVID_QZSS_MAX)))
    {
        svIdChar = GL_CNST_CHAR_QZSS;
    }
    else if ((((svid >= GL_SVID_GLO_MIN) && (svid <= GL_SVID_GLO_MAX)) || (svid == GL_SVID_GLO_TRK)) ||
             ((svid >= TSYNC_SVID_GLO_MIN) && (svid <= TSYNC_SVID_GLO_MAX)))
    {
        svIdChar = GL_CNST_CHAR_GLO;
    }
    else if ((svid >= GL_SVID_IRNSS_MIN) && (svid <= GL_SVID_IRNSS_MAX))
    {
        svIdChar = GL_CNST_CHAR_IRNSS;
    }
    else // Unknown   
    {
        svIdChar = GL_CNST_CHAR_GNSS_MAX;
    }

    if ((svid & GL_SVID_MASK_ID) <= 99)
    {
        sprintf(pSvidStr, "%c%02d ", svIdChar, (svid & GL_SVID_MASK_ID));
    }
    else
    {
        sprintf(pSvidStr, "%c%3d", svIdChar, (svid & GL_SVID_MASK_ID));
    }
}

TSYNC_ERROR
TSYNC_GR_getSurveyProg(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int *nProgress)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nProgress);

        struct GR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GR_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_SURVEY_PROG,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_VALUE_RECIPE,
            GR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct GR_VALUE* outPayload =
            (GR_VALUE*)GetPayload(result);
            
        *nProgress = outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_getMfrMdl(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_ManModObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GR_MFR_MDL_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_MFR_MDL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_VALUE_RECIPE,
            GR_MFR_MDL_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct GR_MFR_MDL* outPayload =
            (GR_MFR_MDL*)GetPayload(result);
            
        memset(pObj->mfr, '\0', sizeof(pObj->mfr));
        memset(pObj->mdl, '\0', sizeof(pObj->mdl));
        
        memcpy(pObj->mfr, outPayload->mfr, sizeof(outPayload->mfr));
        memcpy(pObj->mdl, outPayload->mdl, sizeof(outPayload->mdl));
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_getRcvInfo(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_ReceiverInfoObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GR_RCVR_INFO_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_RCVR_INFO,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_VALUE_RECIPE,
            GR_RCVR_INFO_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct GR_RCVR_INFO* outPayload =
            (GR_RCVR_INFO*)GetPayload(result);
            
        pObj->len = outPayload->len;    
            
        memset(pObj->info, '\0', sizeof(pObj->info));
        
        memcpy(pObj->info, outPayload->info, sizeof(outPayload->info));
        
    return ( err );
}

void
TSYNC_GR_getUbxVersion(
        TSYNC_ReceiverInfoObj *pRI,
        char* pSwVer,
        char* pTimVer,
        char* pProtocol,
        char* pHwVer)
{
    int  ret;
    char line[UBX_EX_VER_STR_LEN+10] = {0};
    UBX_RCV_INFO* pRec = (UBX_RCV_INFO*)&pRI->info;

    // Initialize to defaults
    strcpy(pSwVer, "0.0");
    strcpy(pTimVer, "0.0");
    strcpy(pProtocol, "0.0");
    strncpy(pHwVer, pRec->hwVer, UBX_HW_VER_STR_LEN);

    FindDigitString(pSwVer, pRec->swVer);

    ret = FindLine(line, "TIM", pRec);

    if (ret == 0)
    {
       FindDigitString(pTimVer, line);
    }

    ret = FindLine(line, "PROT", pRec);

    if (ret == 0)
    {
        FindDigitString(pProtocol, line);
    }
}

static int FindLine(char* pLine, char* pMatchStr, UBX_RCV_INFO* pRec)
{
    int  ret = -1; // Not Found
    int  i;
    char lbuf[UBX_EX_VER_STR_LEN+1] = {0};

    for (i = 0; i < UBX_HW_VER_STR_NUM; i++)
    {
        strncpy(lbuf, pRec->exten[i], UBX_EX_VER_STR_LEN);

        if (strstr(lbuf, pMatchStr) != NULL)
        {
            strcpy(pLine, lbuf);
            ret = 0;
            break;
        }
    }

    return (ret);

} /* End - FindLine() */


static int FindDigitString(char* pStr, char* pLine)
{
    int ret = -1; // Not Found
    unsigned int i;

    for (i = 0; i < strlen(pLine); i++)
    {
        if (isdigit(pLine[i]))
        {
            char* pStart = &pLine[i];
            sscanf(pStart, "%s %*s", pStr);
            ret = 0;
            break;
        }
    }

    return (ret);

} /* End - FindDigitString() */


TSYNC_ERROR
TSYNC_GR_getCustom(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_CustomMessageObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GR_CUSTOM_MSG_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_CUSTOM_MSG,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_VALUE_RECIPE,
            GR_CUSTOM_MSG_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct GR_CUSTOM_MSG* outPayload =
            (GR_CUSTOM_MSG*)GetPayload(result);
        
        pObj->len = outPayload->len;
        
        memset(pObj->msg, '\0', sizeof(pObj->msg));
        memcpy(pObj->msg, outPayload->msg, sizeof(outPayload->msg));
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_setCustom(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_CustomMessageObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GR_CUSTOM_MSG_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.len = pObj->len;
        memcpy(inPayload.msg, pObj->msg, sizeof(inPayload.msg));
        
        uint16_t ctl = 0x02;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_CUSTOM_MSG_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_CUSTOM_MSG,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_CUSTOM_MSG_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_getNumInst(
    TSYNC_BoardHandle hnd,
    unsigned int *nInstances)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nInstances);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GR_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_NUM_INST,
            ctl,
            pyldLen,
            NULL,
            NULL,
            GR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct GR_VALUE* outPayload =
            (GR_VALUE*)GetPayload(result);
            
        *nInstances = outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_delPos(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_VALUE_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_DEL_POS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_VALUE_RECIPE,
            NULL,
            result,
            handle);

    return ( err );
}

TSYNC_ERROR
TSYNC_GR_getRefId(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_RefIdObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(EL_REF_ID_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_REF_ID,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_VALUE_RECIPE,
            EL_REF_ID_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct EL_REF_ID* outPayload =
            (EL_REF_ID*)GetPayload(result);
            
        memset(pObj->refid, '\0', sizeof(pObj->refid));
        memcpy(pObj->refid, outPayload->ref, sizeof(outPayload->ref));
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_reset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    GL_RESET reset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GR_RESET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.reset = reset;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_RESET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_RESET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_RESET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_getAntenna(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    GL_ANT_STATUS *status)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(status);

        struct GR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GR_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_ANTENNA,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_VALUE_RECIPE,
            GR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct GR_VALUE* outPayload =
            (GR_VALUE*)GetPayload(result);
            
        *status = (GL_ANT_STATUS)outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_getParameter(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_ReceiverParmObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GR_RCVR_PARM_GET inPayload;
        inPayload.nInstance = nInstance;
        inPayload.len  = pObj->len;
        inPayload.parm = pObj->parm;
        memcpy(inPayload.cfg, pObj->cfg, sizeof(inPayload.cfg));
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_RCVR_PARM_GET_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GR_RCVR_PARM_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_PARAMETER,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_RCVR_PARM_GET_RECIPE,
            GR_RCVR_PARM_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct GR_RCVR_PARM* outPayload =
            (GR_RCVR_PARM*)GetPayload(result);
        
        pObj->len = outPayload->len;
        pObj->parm = outPayload->parm;
        
        memset(pObj->cfg, '\0', sizeof(pObj->cfg));
        memcpy(pObj->cfg, outPayload->cfg, sizeof(outPayload->cfg));
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_setParameter(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_ReceiverParmObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GR_RCVR_PARM_SET inPayload;
        inPayload.nInstance = nInstance;
        inPayload.len = pObj->len;
        inPayload.parm = pObj->parm;
        memcpy(inPayload.cfg, pObj->cfg, sizeof(inPayload.cfg));
        
        uint16_t ctl = 0x02;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_RCVR_PARM_SET_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_PARAMETER,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_RCVR_PARM_SET_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_getQualLog(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_QualLogObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GR_QUAL_LOG_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_QUAL_LOG,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_VALUE_RECIPE,
            GR_QUAL_LOG_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GR_QUAL_LOG* outPayload =
            (GR_QUAL_LOG*)GetPayload(result);
            
        int i;
        for(i = 0; i < TSYNC_QUAL_LOG_NUM; i++)
        {
            pObj->val[i] = outPayload->ql[i].value;
        }
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_getAlm(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_AlmObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GR_ALM_GET inPayload;
        inPayload.nInstance = nInstance;
        inPayload.prn = pObj->alm.prn;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_ALM_GET_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GR_ALM_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_ALM,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_ALM_GET_RECIPE,
            GR_ALM_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct GR_ALM* outPayload =
            (GR_ALM*)GetPayload(result);
            
        pObj->alm.prn        = outPayload->prn        ;
        pObj->alm.svHealth   = outPayload->svHealth   ;
        pObj->alm.weekNumber = outPayload->weekNumber ;
        pObj->alm.e          = outPayload->e          ;
        pObj->alm.toa        = outPayload->toa        ;
        pObj->alm.io         = outPayload->io         ;
        pObj->alm.omegaDot   = outPayload->omegaDot   ;
        pObj->alm.sqrtA      = outPayload->sqrtA      ;
        pObj->alm.omega0     = outPayload->omega0     ;
        pObj->alm.omega      = outPayload->omega      ;
        pObj->alm.m0         = outPayload->m0         ;
        pObj->alm.af0        = outPayload->af0        ;
        pObj->alm.af1        = outPayload->af1        ;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_setAlm(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_AlmObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GR_ALM_SET inPayload;
        inPayload.nInstance = nInstance;
        
        inPayload.prn        = pObj->alm.prn        ;
        inPayload.svHealth   = pObj->alm.svHealth   ;
        inPayload.weekNumber = pObj->alm.weekNumber ;
        inPayload.e          = pObj->alm.e          ;
        inPayload.toa        = pObj->alm.toa        ;
        inPayload.io         = pObj->alm.io         ;
        inPayload.omegaDot   = pObj->alm.omegaDot   ;
        inPayload.sqrtA      = pObj->alm.sqrtA      ;
        inPayload.omega0     = pObj->alm.omega0     ;
        inPayload.omega      = pObj->alm.omega      ;
        inPayload.m0         = pObj->alm.m0         ;
        inPayload.af0        = pObj->alm.af0        ;
        inPayload.af1        = pObj->alm.af1        ;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_ALM_SET_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_ALM,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_ALM_SET_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_getEphm(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_EphmObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GR_EPHM_GET inPayload;
        inPayload.nInstance = nInstance;
        inPayload.prn = pObj->ephm.prn;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_EPHM_GET_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GR_EPHM_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_EPHM,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_EPHM_GET_RECIPE,
            GR_EPHM_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct GR_EPHM* outPayload =
            (GR_EPHM*)GetPayload(result);
            
        pObj->ephm.prn          = outPayload->prn          ;
        pObj->ephm.svHealth     = outPayload->svHealth     ;
        pObj->ephm.tephem       = outPayload->tephem       ;
        pObj->ephm.weekNumber   = outPayload->weekNumber   ;
        pObj->ephm.codeL2       = outPayload->codeL2       ;
        pObj->ephm.L2Pdata      = outPayload->L2Pdata      ;
        pObj->ephm.uraIdx       = outPayload->uraIdx       ;
        pObj->ephm.iodc         = outPayload->iodc         ;
        pObj->ephm.tgd          = outPayload->tgd          ;
        pObj->ephm.toc          = outPayload->toc          ;
        pObj->ephm.af2          = outPayload->af2          ;
        pObj->ephm.af1          = outPayload->af1          ;
        pObj->ephm.af0          = outPayload->af0          ;
        pObj->ephm.svAcc        = outPayload->svAcc        ;
        pObj->ephm.iode         = outPayload->iode         ;
        pObj->ephm.fit_interval = outPayload->fit_interval ;
        pObj->ephm.crs          = outPayload->crs          ;
        pObj->ephm.deltaN       = outPayload->deltaN       ;
        pObj->ephm.m0           = outPayload->m0           ;
        pObj->ephm.cuc          = outPayload->cuc          ;
        pObj->ephm.e            = outPayload->e            ;
        pObj->ephm.cus          = outPayload->cus          ;
        pObj->ephm.sqrtA        = outPayload->sqrtA        ;
        pObj->ephm.toe          = outPayload->toe          ;
        pObj->ephm.cic          = outPayload->cic          ;
        pObj->ephm.omega0       = outPayload->omega0       ;
        pObj->ephm.cis          = outPayload->cis          ;
        pObj->ephm.io           = outPayload->io           ;
        pObj->ephm.crc          = outPayload->crc          ;
        pObj->ephm.omega        = outPayload->omega        ;
        pObj->ephm.omegaDot     = outPayload->omegaDot     ;
        pObj->ephm.idot         = outPayload->idot         ;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_setEphm(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_EphmObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GR_EPHM_SET inPayload;
        inPayload.nInstance = nInstance;
 
        inPayload.prn          = pObj->ephm.prn          ;
        inPayload.svHealth     = pObj->ephm.svHealth     ;
        inPayload.tephem       = pObj->ephm.tephem       ;
        inPayload.weekNumber   = pObj->ephm.weekNumber   ;
        inPayload.codeL2       = pObj->ephm.codeL2       ;
        inPayload.L2Pdata      = pObj->ephm.L2Pdata      ;
        inPayload.uraIdx       = pObj->ephm.uraIdx       ;
        inPayload.iodc         = pObj->ephm.iodc         ;
        inPayload.tgd          = pObj->ephm.tgd          ;
        inPayload.toc          = pObj->ephm.toc          ;
        inPayload.af2          = pObj->ephm.af2          ;
        inPayload.af1          = pObj->ephm.af1          ;
        inPayload.af0          = pObj->ephm.af0          ;
        inPayload.svAcc        = pObj->ephm.svAcc        ;
        inPayload.iode         = pObj->ephm.iode         ;
        inPayload.fit_interval = pObj->ephm.fit_interval ;
        inPayload.crs          = pObj->ephm.crs          ;
        inPayload.deltaN       = pObj->ephm.deltaN       ;
        inPayload.m0           = pObj->ephm.m0           ;
        inPayload.cuc          = pObj->ephm.cuc          ;
        inPayload.e            = pObj->ephm.e            ;
        inPayload.cus          = pObj->ephm.cus          ;
        inPayload.sqrtA        = pObj->ephm.sqrtA        ;
        inPayload.toe          = pObj->ephm.toe          ;
        inPayload.cic          = pObj->ephm.cic          ;
        inPayload.omega0       = pObj->ephm.omega0       ;
        inPayload.cis          = pObj->ephm.cis          ;
        inPayload.io           = pObj->ephm.io           ;
        inPayload.crc          = pObj->ephm.crc          ;
        inPayload.omega        = pObj->ephm.omega        ;
        inPayload.omegaDot     = pObj->ephm.omegaDot     ;
        inPayload.idot         = pObj->ephm.idot         ;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_EPHM_SET_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_EPHM,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_EPHM_SET_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_setAgpsTime(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_VALUE_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_AGPS_TIME,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_VALUE_RECIPE,
            NULL,
            result,
            handle);

    return ( err );
}

TSYNC_ERROR
TSYNC_GR_getAgpsServerState(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_AgpsServerStateObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GR_AGPS_SERVER_STATE_GET inPayload;
        inPayload.nInstance = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_AGPS_SERVER_STATE_GET_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GR_AGPS_SERVER_STATE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_AGPS_SERVER_STATE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_AGPS_SERVER_STATE_GET_RECIPE,
            GR_AGPS_SERVER_STATE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct GR_AGPS_SERVER_STATE* outPayload =
            (GR_AGPS_SERVER_STATE*)GetPayload(result);
            
        pObj->state = outPayload->bState;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_setAgpsServerState(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_AgpsServerStateObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GR_AGPS_SERVER_STATE_SET inPayload;
        inPayload.nInstance = nInstance;
        inPayload.bState     = pObj->state;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_AGPS_SERVER_STATE_SET_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_AGPS_SERVER_STATE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_AGPS_SERVER_STATE_SET_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_getIono(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_IonoObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GR_IONO_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_IONO,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_VALUE_RECIPE,
            GR_IONO_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct GR_IONO* outPayload =
            (GR_IONO*)GetPayload(result);
            
		pObj->iono.alpha0 = outPayload->alpha0;
		pObj->iono.alpha1 = outPayload->alpha1;
		pObj->iono.alpha2 = outPayload->alpha2;
		pObj->iono.alpha3 = outPayload->alpha3;
		pObj->iono.beta0  = outPayload->beta0;
		pObj->iono.beta1  = outPayload->beta1;
        pObj->iono.beta2  = outPayload->beta2;
        pObj->iono.beta3  = outPayload->beta3;
    return ( err );
}

TSYNC_ERROR
TSYNC_GR_getUtc(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_UtcObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GR_UTC_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GR,
            TSYNC_ID_GR_CA_UTC,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GR_VALUE_RECIPE,
            GR_UTC_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct GR_UTC* outPayload =
            (GR_UTC*)GetPayload(result);
			
		pObj->utc.a0        = outPayload->a0;
		pObj->utc.a1        = outPayload->a1;
		pObj->utc.deltaTls  = outPayload->deltaTls;
		pObj->utc.tot       = outPayload->tot;
		pObj->utc.wnt	    = outPayload->wnt;
		pObj->utc.wnlsf     = outPayload->wnlsf;
        pObj->utc.dn        = outPayload->dn;
        pObj->utc.deltaTlsf = outPayload->deltaTlsf;
    return ( err );
}
