#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "ddtsync.h"
#include "tsync_macros.h"

TSYNC_ERROR
TSYNC_HW_getTime(
    TSYNC_BoardHandle handle,
    TSYNC_HWTimeObj *pObj)
{
    CHECK_NOT_NULL(pObj);

    //create the objects the accessor call will reference
    DEST_ID dest;
    ITEM_ID iid;
    struct TSYNCD_HWTimeObj outPayload;
    uint32_t actualOutLength;
    
    //set some values
    dest = DEST_ID_HW;
    iid.hid = HW_SYS_TIME;
    
    //call the generic get
    TSYNC_ERROR err = TSYNC_get(
        handle,
        dest,
        iid,
        NULL,
        0,
        (void*) &outPayload,
        sizeof(outPayload),
        &actualOutLength);
          
    //return the error if not success
    CHECK_SUCCESS(err)
    
    //fill in the output object
    pObj->time.years = outPayload.time.years;
    pObj->time.doy = outPayload.time.doy;
    pObj->time.hours = outPayload.time.hours;
    pObj->time.minutes = outPayload.time.minutes;
    pObj->time.seconds = outPayload.time.seconds;
    pObj->time.ns = outPayload.time.ns;
    pObj->bSync = outPayload.bSync;
    
    return ( TSYNC_SUCCESS );
}

TSYNC_ERROR
TSYNC_HW_getTimeSec(
    TSYNC_BoardHandle       handle,
    TSYNC_HWTimeSecondsObj *pObj)
{
    CHECK_NOT_NULL(pObj);

    //create the objects the accessor call will reference
    DEST_ID dest;
    ITEM_ID iid;
    struct TSYNCD_HWTimeSecondsObj outPayload;
    uint32_t actualOutLength;
    
    //set some values
    dest = DEST_ID_HW;
    iid.hid = HW_SEC_TIME;
    
    //call the generic accessor
    TSYNC_ERROR err = TSYNC_get(
        handle,
        dest,
        iid,
        NULL,
        0,
        (void*) &outPayload,
        sizeof(outPayload),
        &actualOutLength);
          
    //return the error if not success
    CHECK_SUCCESS(err)
    
    //fill in the output object
    pObj->time.seconds = outPayload.time.seconds;
    pObj->time.ns      = outPayload.time.ns;
    pObj->bSync        = outPayload.bSync;
    
    return ( TSYNC_SUCCESS );
}

TSYNC_ERROR
TSYNC_HW_getTsEnable(
    TSYNC_BoardHandle handle,
    int* bEnable)
{
    CHECK_NOT_NULL(bEnable);

    //create the objects the accessor call will reference
    DEST_ID dest;
    ITEM_ID iid;
    TSYNCD_Boolean outPayload;
    uint32_t actualOutLength;
    
    //set some values
    dest = DEST_ID_HW;
    iid.hid = HW_TMSTMP_EN;
    
    //call the generic accessor
    TSYNC_ERROR err = TSYNC_get(
        handle,
        dest,
        iid,
        NULL,
        0,
        (void*) &outPayload,
        sizeof(outPayload),
        &actualOutLength);
          
    //return the error if not success
    CHECK_SUCCESS(err)
    
    //fill in the output object
    *bEnable = outPayload == TDB_TRUE ? 1 : 0;
    
    return ( TSYNC_SUCCESS );
}

TSYNC_ERROR
TSYNC_HW_setTsEnable(
    TSYNC_BoardHandle handle,
    int bEnable)
{
    //create the objects the accessor call will reference
    DEST_ID dest;
    ITEM_ID iid;
    TSYNCD_Boolean inPayload;
    uint32_t actualOutLength;
    
    //set some values
    dest = DEST_ID_HW;
    iid.hid = HW_TMSTMP_EN;
    inPayload = bEnable ? TDB_TRUE : TDB_FALSE;
    
    //call the generic accessor
    TSYNC_ERROR err = TSYNC_set(
        handle,
        dest,
        iid,
        (void*) &inPayload,
        sizeof(inPayload),
        NULL,
        0,
        &actualOutLength);
    
    return ( err );
}

TSYNC_ERROR
TSYNC_HW_setTsReq(
    TSYNC_BoardHandle handle)
{
    //create the objects the accessor call will reference
    DEST_ID dest;
    ITEM_ID iid;
    uint32_t actualOutLength;
    
    //set some values
    dest = DEST_ID_HW;
    iid.hid = HW_TMSTMP_REQ;
    
    //call the generic accessor
    TSYNC_ERROR err = TSYNC_set(
        handle,
        dest,
        iid,
        NULL,
        0,
        NULL,
        0,
        &actualOutLength);
    
    return ( err );
}

TSYNC_ERROR
TSYNC_HW_setTsClear(
    TSYNC_BoardHandle handle,
    TMSTMP_SRC source)
{
    //create the objects the accessor call will reference
    DEST_ID dest;
    ITEM_ID iid;
    uint32_t actualOutLength;
    
    //set some values
    dest = DEST_ID_HW;
    iid.hid = HW_TMSTMP_CLR;
    
    //call the generic accessor
    TSYNC_ERROR err = TSYNC_set(
        handle,
        dest,
        iid,
        (void*) &source,
        sizeof(source),
        NULL,
        0,
        &actualOutLength);
    
    return ( err );
}

TSYNC_ERROR
TSYNC_HW_getTsCount(
    TSYNC_BoardHandle handle,
    TMSTMP_SRC source,
    unsigned int* nCount)
{
    CHECK_NOT_NULL(nCount);

    //create the objects the accessor call will reference
    DEST_ID dest;
    ITEM_ID iid;
    uint32_t outPayload;
    uint32_t actualOutLength;
    
    //set some values
    dest = DEST_ID_HW;
    iid.hid = HW_TMSTMP_CNT;
    
    //call the generic accessor
    TSYNC_ERROR err = TSYNC_get(
        handle,
        dest,
        iid,
        (void*) &source,
        sizeof(source),
        (void*) &outPayload,
        sizeof(outPayload),
        &actualOutLength);
          
    //return the error if not success
    CHECK_SUCCESS(err)
    
    //fill in the output object
    *nCount = outPayload;
    
    return ( TSYNC_SUCCESS );
}

TSYNC_ERROR
TSYNC_HW_getTsData(
    TSYNC_BoardHandle handle,
    TMSTMP_SRC source,
    TSYNC_HWTimeDataObj *pObj)
{
    CHECK_NOT_NULL(pObj);

    //create the objects the accessor call will reference
    DEST_ID dest;
    ITEM_ID iid;
    struct TSYNCD_HWTimeDataObj outPayload;
    uint32_t actualOutLength;
    
    //set some values
    dest = DEST_ID_HW;
    iid.hid = HW_TMSTMP_DATA;
    
    //call the generic get
    TSYNC_ERROR err = TSYNC_get(
        handle,
        dest,
        iid,
        (void*) &source,
        sizeof(source),
        (void*) &outPayload,
        sizeof(outPayload),
        &actualOutLength);
          
    //return the error if not success
    CHECK_SUCCESS(err)
    
    //fill in the output object
    int i;
    for(i = 0; i < TSYNC_TIMESTAMP_DATA_NUM; i ++)
    {
        pObj->data[i].time.years = outPayload.data[i].time.years;
        pObj->data[i].time.doy = outPayload.data[i].time.doy;
        pObj->data[i].time.hours = outPayload.data[i].time.hours;
        pObj->data[i].time.minutes = outPayload.data[i].time.minutes;
        pObj->data[i].time.seconds = outPayload.data[i].time.seconds;
        pObj->data[i].time.ns = outPayload.data[i].time.ns;
        pObj->data[i].bSync = outPayload.data[i].bSync;
    }
    
    return ( TSYNC_SUCCESS );
}

TSYNC_ERROR
TSYNC_HW_getMatchTimeHi(
    TSYNC_BoardHandle handle,
    OD_PIN index,
    TSYNC_TimeObj *pObj)
{
    CHECK_NOT_NULL(pObj);

    //create the objects the accessor call will reference
    DEST_ID dest;
    ITEM_ID iid;
    struct TSYNCD_TimeObj outPayload;
    uint32_t actualOutLength;
    
    //set some values
    dest = DEST_ID_HW;
    iid.hid = HW_GPO_MTCH_HI;
    
    //call the generic get
    TSYNC_ERROR err = TSYNC_get(
        handle,
        dest,
        iid,
        (void*) &index,
        sizeof(index),
        (void*) &outPayload,
        sizeof(outPayload),
        &actualOutLength);
          
    //return the error if not success
    CHECK_SUCCESS(err)
    
    //fill in the output object
    pObj->years = outPayload.years;
    pObj->doy = outPayload.doy;
    pObj->hours = outPayload.hours;
    pObj->minutes = outPayload.minutes;
    pObj->seconds = outPayload.seconds;
    pObj->ns = outPayload.ns;
    
    return ( TSYNC_SUCCESS );
}

TSYNC_ERROR
TSYNC_HW_setMatchTimeHi(
    TSYNC_BoardHandle handle,
    OD_PIN index,
    TSYNC_TimeObj *pObj)
{
    CHECK_NOT_NULL(pObj);

    //create the objects the accessor call will reference
    DEST_ID dest;
    ITEM_ID iid;
    struct TSYNCD_MatchTimeObj inPayload;
    uint32_t actualOutLength;
    
    //set some values
    dest = DEST_ID_HW;
    iid.hid = HW_GPO_MTCH_HI;
    
    inPayload.index = index;
    inPayload.time.years = pObj->years;
    inPayload.time.doy = pObj->doy;
    inPayload.time.hours = pObj->hours;
    inPayload.time.minutes = pObj->minutes;
    inPayload.time.seconds = pObj->seconds;
    inPayload.time.ns = pObj->ns;
    
    //call the generic accessor
    TSYNC_ERROR err = TSYNC_set(
        handle,
        dest,
        iid,
        (void*) &inPayload,
        sizeof(inPayload),
        NULL,
        0,
        &actualOutLength);
          
    return ( err );
}

TSYNC_ERROR
TSYNC_HW_getMatchTimeLo(
    TSYNC_BoardHandle handle,
    OD_PIN index,
    TSYNC_TimeObj *pObj)
{
    CHECK_NOT_NULL(pObj);

    //create the objects the accessor call will reference
    DEST_ID dest;
    ITEM_ID iid;
    struct TSYNCD_TimeObj outPayload;
    uint32_t actualOutLength;
    
    //set some values
    dest = DEST_ID_HW;
    iid.hid = HW_GPO_MTCH_LO;
    
    //call the generic get
    TSYNC_ERROR err = TSYNC_get(
        handle,
        dest,
        iid,
        (void*) &index,
        sizeof(index),
        (void*) &outPayload,
        sizeof(outPayload),
        &actualOutLength);
          
    //return the error if not success
    CHECK_SUCCESS(err)
    
    //fill in the output object
    pObj->years = outPayload.years;
    pObj->doy = outPayload.doy;
    pObj->hours = outPayload.hours;
    pObj->minutes = outPayload.minutes;
    pObj->seconds = outPayload.seconds;
    pObj->ns = outPayload.ns;
    
    return ( TSYNC_SUCCESS );
}

TSYNC_ERROR
TSYNC_HW_setMatchTimeLo(
    TSYNC_BoardHandle handle,
    OD_PIN index,
    TSYNC_TimeObj *pObj)
{
    CHECK_NOT_NULL(pObj);

    //create the objects the accessor call will reference
    DEST_ID dest;
    ITEM_ID iid;
    struct TSYNCD_MatchTimeObj inPayload;
    uint32_t actualOutLength;
    
    //set some values
    dest = DEST_ID_HW;
    iid.hid = HW_GPO_MTCH_LO;
    
    inPayload.index = index;
    inPayload.time.years = pObj->years;
    inPayload.time.doy = pObj->doy;
    inPayload.time.hours = pObj->hours;
    inPayload.time.minutes = pObj->minutes;
    inPayload.time.seconds = pObj->seconds;
    inPayload.time.ns = pObj->ns;
    
    //call the generic accessor
    TSYNC_ERROR err = TSYNC_set(
        handle,
        dest,
        iid,
        (void*) &inPayload,
        sizeof(inPayload),
        NULL,
        0,
        &actualOutLength);
          
    return ( err );
}

TSYNC_ERROR
TSYNC_HW_getFpgaInfo(
    TSYNC_BoardHandle handle,
    unsigned short* id,
    unsigned short* rev)
{
    CHECK_NOT_NULL(id);
    CHECK_NOT_NULL(rev);

    //create the objects the accessor call will reference
    DEST_ID dest;
    ITEM_ID iid;
    struct TSYNCD_FPGAInfoObj outPayload;
    uint32_t actualOutLength;
    
    //set some values
    dest = DEST_ID_HW;
    iid.hid = HW_FPGA_ID;
    
    //call the generic accessor
    TSYNC_ERROR err = TSYNC_get(
        handle,
        dest,
        iid,
        NULL,
        0,
        (void*) &outPayload,
        sizeof(outPayload),
        &actualOutLength);
          
    //return the error if not success
    CHECK_SUCCESS(err)
    
    //fill in the output object
    *id = outPayload.id;
    *rev = outPayload.rev;
    
    return ( TSYNC_SUCCESS );
}

TSYNC_ERROR
TSYNC_HW_getIntMask(
    TSYNC_BoardHandle handle,
    INT_TYPE intType,
    unsigned int index,
    int* bEnable)
{
    CHECK_NOT_NULL(bEnable);

    //create the objects the accessor call will reference
    DEST_ID dest;
    ITEM_ID iid;
    TSYNCD_InterruptMaskGetObj inPayload;
    TSYNCD_Boolean outPayload;
    uint32_t actualOutLength;
    
    //set some values
    dest = DEST_ID_HW;
    iid.hid = HW_INT_MASK;
    
    inPayload.intType = intType;
    inPayload.index = index;
    
    //call the generic accessor
    TSYNC_ERROR err = TSYNC_get(
        handle,
        dest,
        iid,
        (void*) &inPayload,
        sizeof(inPayload),
        (void*) &outPayload,
        sizeof(outPayload),
        &actualOutLength);
          
    //return the error if not success
    CHECK_SUCCESS(err)
    
    //fill in the output object
    *bEnable = outPayload == TDB_TRUE ? 1 : 0;
    
    return ( TSYNC_SUCCESS );
}

TSYNC_ERROR
TSYNC_HW_setIntMask(
    TSYNC_BoardHandle handle,
    INT_TYPE intType,
    unsigned int index,
    int bEnable)
{
    //create the objects the accessor call will reference
    DEST_ID dest;
    ITEM_ID iid;
    TSYNCD_InterruptMaskSetObj inPayload;
    uint32_t actualOutLength;
    
    //set some values
    dest = DEST_ID_HW;
    iid.hid = HW_INT_MASK;
    
    inPayload.intType = intType;
    inPayload.index = index;
    inPayload.bEnable = bEnable ? TDB_TRUE : TDB_FALSE;
    
    //call the generic accessor
    TSYNC_ERROR err = TSYNC_set(
        handle,
        dest,
        iid,
        (void*) &inPayload,
        sizeof(inPayload),
        NULL,
        0,
        &actualOutLength);
          
    return ( err );
}

TSYNC_ERROR
TSYNC_HW_getTsSingle(
    TSYNC_BoardHandle handle,
    TMSTMP_SRC source,
    TSYNC_HWTimeObj *pObj)
{
    CHECK_NOT_NULL(pObj);

    //create the objects the accessor call will reference
    DEST_ID dest;
    ITEM_ID iid;
    struct TSYNCD_HWTimeObj outPayload;
    uint32_t actualOutLength;
    
    //set some values
    dest = DEST_ID_HW;
    iid.hid = HW_TMSTMP_SINGLE;
    
    //call the generic get
    TSYNC_ERROR err = TSYNC_get(
        handle,
        dest,
        iid,
        (void*) &source,
        sizeof(source),
        (void*) &outPayload,
        sizeof(outPayload),
        &actualOutLength);
          
    //return the error if not success
    CHECK_SUCCESS(err)
    
    //fill in the output object
    pObj->time.years = outPayload.time.years;
    pObj->time.doy = outPayload.time.doy;
    pObj->time.hours = outPayload.time.hours;
    pObj->time.minutes = outPayload.time.minutes;
    pObj->time.seconds = outPayload.time.seconds;
    pObj->time.ns = outPayload.time.ns;
    pObj->bSync = outPayload.bSync;
    
    return ( TSYNC_SUCCESS );
}

TSYNC_ERROR
TSYNC_HW_getIntCnt(
    TSYNC_BoardHandle handle,
    INT_TYPE intType,
    unsigned int index,
    unsigned int* nIntCount)
{
    CHECK_NOT_NULL(nIntCount);

    //create the objects the accessor call will reference
    DEST_ID dest;
    ITEM_ID iid;
    TSYNCD_InterruptMaskGetObj inPayload;
    uint32_t    actualOutLength;
    uint32_t    outPayload;
    
    //set some values
    dest = DEST_ID_HW;
    iid.hid = HW_INT_CNT;
    
    inPayload.intType = intType;
    inPayload.index = index;
    
    //call the generic accessor
    TSYNC_ERROR err = TSYNC_get(
        handle,
        dest,
        iid,
        (void*) &inPayload,
        sizeof(inPayload),
        (void*)&outPayload,
        sizeof(outPayload),
        &actualOutLength);
          

    //return the error if not success
    CHECK_SUCCESS(err)
    
    //fill in the output object
    *nIntCount = outPayload ;
    
    return ( TSYNC_SUCCESS );
}

TSYNC_ERROR
TSYNC_HW_getIntTs(
    TSYNC_BoardHandle handle,
    INT_TYPE intType,
    unsigned int index,
    TSYNC_TimeSecondsObj *pObj)
{
    CHECK_NOT_NULL(pObj);

    //create the objects the accessor call will reference
    DEST_ID                    dest;
    ITEM_ID                    iid;
    TSYNCD_InterruptMaskGetObj inPayload;
    uint32_t                   actualOutLength;
    TSYNCD_TimeSecondsObj      outPayload;
    
    //set some values
    dest    = DEST_ID_HW;
    iid.hid = HW_INT_TS;
    
    inPayload.intType = intType;
    inPayload.index   = index;
    
    //call the generic accessor
    TSYNC_ERROR err = TSYNC_get(
        handle,
        dest,
        iid,
        (void*) &inPayload,
        sizeof(inPayload),
        (void*)&outPayload,
        sizeof(outPayload),
        &actualOutLength);
          

    //return the error if not success
    CHECK_SUCCESS(err)
    
    //fill in the output object
    pObj->seconds = outPayload.seconds;
    pObj->ns      = outPayload.ns;
    
    return ( TSYNC_SUCCESS );
}

TSYNC_ERROR
TSYNC_HW_clrIntCnt(
    TSYNC_BoardHandle handle,
    INT_TYPE intType,
    unsigned int index)
{

    //create the objects the accessor call will reference
    DEST_ID dest;
    ITEM_ID iid;
    TSYNCD_InterruptMaskGetObj inPayload;
    uint32_t    actualOutLength;

    
    //set some values
    dest = DEST_ID_HW;
    iid.hid = HW_INT_CNT_CLR;
    
    inPayload.intType = intType;
    inPayload.index = index;
    
    //call the generic accessor
    TSYNC_ERROR err = TSYNC_set(
        handle,
        dest,
        iid,
        (void*) &inPayload,
        sizeof(inPayload),
        NULL,
        0,
        &actualOutLength);
          

    //return the error if not success
    CHECK_SUCCESS(err)
    
    
    return ( TSYNC_SUCCESS );
}


TSYNC_ERROR TSYNC_HW_getTemperature(TSYNC_BoardHandle handle,
                                     unsigned short* pTemp) {
    /* Create the objects the accessor call will reference */
    DEST_ID     dest;
    ITEM_ID     iid;
    uint32_t    actualOutLength;
    uint32_t    outPayload;

    // return right away if on NIOS,
    // since NIOS products don't have this register
#ifdef NIOS
    return (TSYNC_DRV_NOT_IMPLEMENTED);
#endif

    //set some values
    dest = DEST_ID_HW;
    iid.hid = HW_KTS_TEMPERATURE;
    
    CHECK_NOT_NULL(pTemp);
    
    
    /* Call the generic accessor */
    TSYNC_ERROR err = TSYNC_get(handle,
                    dest,
                    iid,
                    NULL,
                    0,
                    (void*)&outPayload,
                    sizeof(outPayload),
                    &actualOutLength);
    
    // return the error if not success
    CHECK_SUCCESS(err);
    
    // fill in the output object
    *pTemp = outPayload ;
    
    return (TSYNC_SUCCESS);
    
} /* End TSYNC_HW_getTemperature */


TSYNC_ERROR TSYNC_HW_getTemperature_ss(TSYNC_BoardHandle handle,
                                     unsigned short* pTemp) {

    /* Create the objects the accessor call will reference */
    DEST_ID     dest;
    ITEM_ID     iid;
    uint32_t    actualOutLength;
    uint32_t    outPayload;

    // return right away if on NIOS,
    // since NIOS products don't have this register
#ifdef NIOS
    return (TSYNC_DRV_NOT_IMPLEMENTED);
#endif

    //set some values
    dest = DEST_ID_HW;
    iid.hid = HW_KTS_TEMPERATURE_SS;
    
    CHECK_NOT_NULL(pTemp);
    
    
    /* Call the generic accessor */
    TSYNC_ERROR err = TSYNC_get(handle,
                    dest,
                    iid,
                    NULL,
                    0,
                    (void*)&outPayload,
                    sizeof(outPayload),
                    &actualOutLength);
    
    // return the error if not success
    CHECK_SUCCESS(err);
    
    // fill in the output object
    *pTemp = outPayload;
    
    return (TSYNC_SUCCESS);
    
} /* End TSYNC_HW_getTemperature_ss */
