
/***************************************************************************
**  Module:     tsync_cs_services_recipes.c
**
**  Date:       07/10/08
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/10/2008 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_cs_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(ML_DOYTIME)
RECIPE(ML_DOYTIME_GET_RESP)
RECIPE(ML_DOYTIME_SET_CMD)
RECIPE(ML_NEXTSEC_GET_RESP)
RECIPE(ML_TIME_GET)
RECIPE(ML_TIME_SCALE_OBJ)
RECIPE(ML_TIME_SCALE_OFFSET_GET_CMD)
RECIPE(ML_TIME_SCALE_OFFSET_GET_RESP)
RECIPE(ML_TIME_SCALE_OFFSET_SET_CMD)
RECIPE(ML_SUBSEC_ADJUST)
RECIPE(CS_TIME_DISCONT)
RECIPE(ML_LEAP_SEC)
RECIPE(ML_TIMEZONE_OFFSET)
RECIPE(ML_DST_POINT)
RECIPE(ML_DST_RULE)
RECIPE(ML_YEAR)
RECIPE(ML_SECTIME)
RECIPE(ML_SECTIME_GET_RESP)
RECIPE(ML_SECTIME_SET_CMD)
RECIPE(ML_BCDTIME_GET_RESP)
RECIPE(ML_BCDTIME_SET_CMD)
RECIPE(ML_BCDTIME)
RECIPE(ML_CLK_LOCAL)
RECIPE(CS_DST_STATE)

uintptr_t ML_TIME_RECIPE[] = {
    3,  // Number of members
    (uintptr_t)ML_SECTIME_RECIPE,
    (uintptr_t)ML_DOYTIME_RECIPE,
    (uintptr_t)ML_BCDTIME_RECIPE,
};

uintptr_t ML_TIME_UNION_GET_RESP_RECIPE[] = {
    3,  // Number of members
    (uintptr_t)ML_SECTIME_GET_RESP_RECIPE,
    (uintptr_t)ML_DOYTIME_GET_RESP_RECIPE,
    (uintptr_t)ML_BCDTIME_GET_RESP_RECIPE,
};

uintptr_t ML_TIME_UNION_SET_CMD_RECIPE[] = {
    3,  // Number of members
    (uintptr_t)ML_SECTIME_SET_CMD_RECIPE,
    (uintptr_t)ML_DOYTIME_SET_CMD_RECIPE,
    (uintptr_t)ML_BCDTIME_SET_CMD_RECIPE,
};

#include "tsync_recipe_undef.h"
