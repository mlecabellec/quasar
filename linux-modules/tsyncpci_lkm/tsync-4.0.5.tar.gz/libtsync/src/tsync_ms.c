#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_ms_services.h"

extern uint8_t MS_VALUE_RECIPE[];
extern uint8_t MS_SHARE_ITEM_RECIPE[];
extern uint8_t MS_DATA_SET_CMD_RECIPE[];

TSYNC_ERROR
TSYNC_MS_reset(
    TSYNC_BoardHandle hnd,
    MS_DI_INDEX index)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct MS_VALUE inPayload;
        inPayload.value = index;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(MS_VALUE_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_MS,
            TSYNC_ID_MS_CA_RESET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            MS_VALUE_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}
  
TSYNC_ERROR
TSYNC_MS_getData(
    TSYNC_BoardHandle hnd,
    MS_DI_INDEX index,
    TSYNC_SharedMemoryObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct MS_VALUE inPayload;
        inPayload.value = index;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(MS_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(MS_SHARE_ITEM_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_MS,
            TSYNC_ID_MS_CA_DATA,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            MS_VALUE_RECIPE,
            MS_SHARE_ITEM_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct MS_SHARE_ITEM* outPayload =
            (MS_SHARE_ITEM*)GetPayload(result);
        
        pObj->seqNum = outPayload->seqNum;
        
        memset(pObj->data, '\0', sizeof(pObj->data));
        memcpy(pObj->data, outPayload->data, sizeof(outPayload->data));
        
    return ( err );
}

TSYNC_ERROR
TSYNC_MS_setData(
    TSYNC_BoardHandle hnd,
    MS_DI_INDEX index,
    TSYNC_SharedMemoryObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct MS_DATA_SET_CMD inPayload;
        inPayload.index = index;
        inPayload.seqNum = pObj->seqNum;
        memcpy(inPayload.data, pObj->data, sizeof(inPayload.data));
        
        uint16_t ctl = 0x02;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(MS_DATA_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_MS,
            TSYNC_ID_MS_CA_DATA,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            MS_DATA_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}
    

