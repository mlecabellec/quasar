#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_ir_services.h"
#include "tsync_cs_services.h"
#include "tsync_misc_services.h"

extern uint8_t IR_VALUE_RECIPE[];
extern uint8_t IR_OFFSET_SET_CMD_RECIPE[];
extern uint8_t EL_VALIDITY_RECIPE[];
extern uint8_t IR_MODE_SET_CMD_RECIPE[];
extern uint8_t IR_FORMAT_SET_CMD_RECIPE[];
extern uint8_t IR_MOD_SET_CMD_RECIPE[];
extern uint8_t IR_FREQ_SET_CMD_RECIPE[];
extern uint8_t IR_CE_SET_CMD_RECIPE[];
extern uint8_t IR_CF_SET_CMD_RECIPE[];
extern uint8_t IR_MSG_RECIPE[];
extern uint8_t IR_MSG_SET_CMD_RECIPE[];
extern uint8_t IR_CFDATA_RECIPE[];
extern uint8_t ML_CLK_LOCAL_RECIPE[];
extern uint8_t IR_LOCAL_SET_CMD_RECIPE[];
extern uint8_t ML_TIME_SCALE_OBJ_RECIPE[];
extern uint8_t IR_TIME_SCALE_SET_CMD_RECIPE[];
extern uint8_t EL_REF_ID_RECIPE[];

TSYNC_ERROR
TSYNC_IR_getOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *nOffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nOffset);

        struct IR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IR,
            TSYNC_ID_IR_CA_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IR_VALUE_RECIPE,
            IR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IR_VALUE* outPayload =
            (IR_VALUE*)GetPayload(result);

        *nOffset = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_IR_setOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int nOffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct IR_OFFSET_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.offset = nOffset;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IR_OFFSET_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_IR,
            TSYNC_ID_IR_CA_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IR_OFFSET_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_IR_getValidity(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *bTimeValid,
    int *bPpsValid)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(bTimeValid);
        CHECK_NOT_NULL(bPpsValid);

        struct IR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(EL_VALIDITY_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IR,
            TSYNC_ID_IR_CA_VALIDITY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IR_VALUE_RECIPE,
            EL_VALIDITY_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct EL_VALIDITY* outPayload =
            (EL_VALIDITY*)GetPayload(result);

        *bTimeValid = outPayload->timeValid;
        *bPpsValid = outPayload->ppsValid;

    return ( err );
}

TSYNC_ERROR
TSYNC_IR_getMode(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    IL_MODE *mode)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(mode);

        struct IR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IR,
            TSYNC_ID_IR_CA_MODE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IR_VALUE_RECIPE,
            IR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IR_VALUE* outPayload =
            (IR_VALUE*)GetPayload(result);

        *mode = (IL_MODE)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_IR_setMode(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    IL_MODE mode)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct IR_MODE_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.mode = mode;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IR_MODE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_IR,
            TSYNC_ID_IR_CA_MODE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IR_MODE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_IR_getFormat(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    IL_FMT *format)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(format);

        struct IR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IR,
            TSYNC_ID_IR_CA_FORMAT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IR_VALUE_RECIPE,
            IR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IR_VALUE* outPayload =
            (IR_VALUE*)GetPayload(result);

        *format = (IL_FMT)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_IR_setFormat(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    IL_FMT format)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct IR_FORMAT_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.format = format;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IR_FORMAT_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_IR,
            TSYNC_ID_IR_CA_FORMAT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IR_FORMAT_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_IR_getMod(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    IL_MOD *mod)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(mod);

        struct IR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IR,
            TSYNC_ID_IR_CA_MOD,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IR_VALUE_RECIPE,
            IR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IR_VALUE* outPayload =
            (IR_VALUE*)GetPayload(result);

        *mod = (IL_MOD)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_IR_setMod(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    IL_MOD mod)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct IR_MOD_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.mod  = mod;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IR_MOD_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_IR,
            TSYNC_ID_IR_CA_MOD,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IR_MOD_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_IR_getFreq(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    IL_FRQ *freq)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(freq);

        struct IR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IR,
            TSYNC_ID_IR_CA_FRQ,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IR_VALUE_RECIPE,
            IR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IR_VALUE* outPayload =
            (IR_VALUE*)GetPayload(result);

        *freq = (IL_FRQ)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_IR_setFreq(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    IL_FRQ freq)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct IR_FREQ_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.freq = freq;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IR_FREQ_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_IR,
            TSYNC_ID_IR_CA_FRQ,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IR_FREQ_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_IR_getCodedExpr(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    IL_CE *ce)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(ce);

        struct IR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IR,
            TSYNC_ID_IR_CA_CODED_EXP,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IR_VALUE_RECIPE,
            IR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IR_VALUE* outPayload =
            (IR_VALUE*)GetPayload(result);

        *ce = (IL_CE)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_IR_setCodedExpr(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    IL_CE ce)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct IR_CE_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.ce = ce;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IR_CE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_IR,
            TSYNC_ID_IR_CA_CODED_EXP,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IR_CE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_IR_getCtrlField(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    IL_CF *cf)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(cf);

        struct IR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IR,
            TSYNC_ID_IR_CA_CTRL_FLD,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IR_VALUE_RECIPE,
            IR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IR_VALUE* outPayload =
            (IR_VALUE*)GetPayload(result);

        *cf = (IL_CF)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_IR_setCtrlField(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    IL_CF cf)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct IR_CF_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.cf = cf;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IR_CF_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_IR,
            TSYNC_ID_IR_CA_CTRL_FLD,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IR_CF_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_IR_getMessage(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_IRIGMessageObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct IR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IR_MSG_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IR,
            TSYNC_ID_IR_CA_MESSAGE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IR_VALUE_RECIPE,
            IR_MSG_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IR_MSG* outPayload =
            (IR_MSG*)GetPayload(result);

        int i;
        for(i = 0; i < TSYNC_IR_SUBFRAME_NUM; i++)
        {
            pObj->subframes[i] = outPayload->subframes[i].value;
        }

    return ( err );
}

TSYNC_ERROR
TSYNC_IR_setMessage(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_IRIGMessageObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct IR_MSG_SET_CMD inPayload;
        inPayload.inst = nInstance;
        int i;
        for(i = 0; i < TSYNC_IR_SUBFRAME_NUM; i++)
        {
            inPayload.subframes[i].value = pObj->subframes[i];
        }


        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IR_MSG_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_IR,
            TSYNC_ID_IR_CA_MESSAGE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IR_MSG_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_IR_getNumInst(
    TSYNC_BoardHandle hnd,
    unsigned int *nInstances)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nInstances);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IR,
            TSYNC_ID_IR_CA_NUM_INST,
            ctl,
            pyldLen,
            NULL,
            NULL,
            IR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IR_VALUE* outPayload =
            (IR_VALUE*)GetPayload(result);

        *nInstances = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_IR_getCfData(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_IRIGCfDataObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct IR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IR_CFDATA_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IR,
            TSYNC_ID_IR_CA_CFDATA,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IR_VALUE_RECIPE,
            IR_CFDATA_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IR_CFDATA* outPayload =
            (IR_CFDATA*)GetPayload(result);

        int i;
        for(i = 0; i < TSYNC_IR_CFDATA_NUM; i++)
        {
            pObj->cfData[i] = outPayload->cfData[i].value;
        }

    return ( err );
}

TSYNC_ERROR
TSYNC_IR_getLocal(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_LocalClockObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct IR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(ML_CLK_LOCAL_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IR,
            TSYNC_ID_IR_CA_LOCAL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IR_VALUE_RECIPE,
            ML_CLK_LOCAL_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct ML_CLK_LOCAL* outPayload =
            (ML_CLK_LOCAL*)GetPayload(result);

        pObj->rule.ref = outPayload->ref;
        pObj->rule.in.month = outPayload->in.month;
        pObj->rule.in.wom = outPayload->in.wom;
        pObj->rule.in.dow = outPayload->in.dow;
        pObj->rule.in.hour = outPayload->in.hour;
        pObj->rule.out.month = outPayload->out.month;
        pObj->rule.out.wom = outPayload->out.wom;
        pObj->rule.out.dow = outPayload->out.dow;
        pObj->rule.out.hour = outPayload->out.hour;
        pObj->rule.offset = outPayload->offset;
        pObj->tz = outPayload->tz;

    return ( err );
}

TSYNC_ERROR
TSYNC_IR_setLocal(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_LocalClockObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct IR_LOCAL_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.ref = pObj->rule.ref;
        inPayload.in.month = pObj->rule.in.month;
        inPayload.in.wom = pObj->rule.in.wom;
        inPayload.in.dow = pObj->rule.in.dow;
        inPayload.in.hour = pObj->rule.in.hour;
        inPayload.out.month = pObj->rule.out.month;
        inPayload.out.wom = pObj->rule.out.wom;
        inPayload.out.dow = pObj->rule.out.dow;
        inPayload.out.hour = pObj->rule.out.hour;
        inPayload.offset = pObj->rule.offset;
        inPayload.tz = pObj->tz;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IR_LOCAL_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_IR,
            TSYNC_ID_IR_CA_LOCAL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IR_LOCAL_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_IR_getTimeScale(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_TimeScaleObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    struct IR_VALUE inPayload;
    inPayload.value = nInstance;

    uint16_t ctl = 0x00;//get
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(IR_VALUE_RECIPE, &pos);

    pos = 0;
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(ML_TIME_SCALE_OBJ_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_IR,
        TSYNC_ID_IR_CA_TIME_SCALE,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        IR_VALUE_RECIPE,
        ML_TIME_SCALE_OBJ_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    struct ML_TIME_SCALE_OBJ* outPayload =
        (ML_TIME_SCALE_OBJ*)GetPayload(result);

    pObj->scale = outPayload->scale;

    return ( err );
}

TSYNC_ERROR TSYNC_IR_setTimeScale (
    TSYNC_BoardHandle   hnd,
    unsigned int nInstance,
    TSYNC_TimeScaleObj *pObj)
{
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    struct IR_TIME_SCALE_SET_CMD inPayload;
    inPayload.inst = nInstance;
    inPayload.scale.scale = pObj->scale;

    uint16_t ctl = 0x02;//set
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(IR_TIME_SCALE_SET_CMD_RECIPE, &pos);

    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(0));

    TSYNC_ERROR err = BaseTransaction(
        TSYNC_ID_IR,
        TSYNC_ID_IR_CA_TIME_SCALE,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        IR_TIME_SCALE_SET_CMD_RECIPE,
        NULL,
        result,
        handle);

    return ( err );
}

TSYNC_ERROR
TSYNC_IR_getRefId(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_RefIdObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct IR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(EL_REF_ID_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_IR,
            TSYNC_ID_IR_CA_REF_ID,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IR_VALUE_RECIPE,
            EL_REF_ID_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct EL_REF_ID* outPayload =
            (EL_REF_ID*)GetPayload(result);
            
        memset(pObj->refid, '\0', sizeof(pObj->refid));
        memcpy(pObj->refid, outPayload->ref, sizeof(outPayload->ref));
        
    return ( err );
}

TSYNC_ERROR
TSYNC_IR_getType(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    IL_MOD *type)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(type);

        struct IR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IR,
            TSYNC_ID_IR_CA_TYPE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IR_VALUE_RECIPE,
            IR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IR_VALUE* outPayload =
            (IR_VALUE*)GetPayload(result);

        *type = (IL_MOD)outPayload->value;

    return ( err );
}
