
#ifndef _defined_TSYNC_PP_SERVICES_H
#define _defined_TSYNC_PP_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_pp_services.h
**
**  Date:       08/05/08
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              08/05/2008 Creation
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_PP                     0x35
#define TSYNC_ID_PP_CA_SIG_CTL          0x00
#define TSYNC_ID_PP_CA_FREQ             0x01
#define TSYNC_ID_PP_CA_OFFSET           0x02
#define TSYNC_ID_PP_CA_EDGE             0x03
#define TSYNC_ID_PP_CA_PW               0x04
#define TSYNC_ID_PP_CA_NUM_INST         0x05

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define PP_SET_CMD_FIELDS                 \
    TSYNC_X(        uint32_t,   inst)     \
    TSYNC_X(        uint32_t,   value)
#define PP_INT_SET_CMD_FIELDS             \
    TSYNC_X(        uint32_t,   inst)     \
    TSYNC_X(        int32_t,    value)
#define PP_VALUE_FIELDS                   \
    TSYNC_X(        uint32_t,   value)
#define PP_INT_VALUE_FIELDS               \
    TSYNC_X(        int32_t,    value)
#define PP_FREQ_FIELDS                    \
    TSYNC_X(        float,      freq)
    
#include "tsync_struct_define.h"

GEN_STRUCT(PP_SET_CMD)
GEN_STRUCT(PP_INT_SET_CMD)
GEN_STRUCT(PP_VALUE)
GEN_STRUCT(PP_INT_VALUE)
GEN_STRUCT(PP_FREQ)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_PP_SERVICES_H */
