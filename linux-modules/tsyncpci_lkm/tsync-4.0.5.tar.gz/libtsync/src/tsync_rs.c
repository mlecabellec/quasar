#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_rs_services.h"

extern uint8_t RS_TABLE_TYPE_OBJ_RECIPE[];
extern uint8_t RS_REF_TABLE_RECIPE[];
extern uint8_t RS_TABLE_ENTRY_RECIPE[];
extern uint8_t RS_TABLE_INDEX_OBJ_RECIPE[];
extern uint8_t RS_TABLE_INDEX_VALUE_RECIPE[];
extern uint8_t RS_TABLE_VALUE_RECIPE[];
extern uint8_t RS_REF_STATE_ENTRY_RECIPE[];
extern uint8_t RS_STATE_TABLE_RECIPE[];
extern uint8_t RS_REF_PHASE_INDEX_OBJ_RECIPE[];
extern uint8_t RS_REF_PHASE_DATA_RECIPE[];
extern uint8_t RS_REF_PHASE_INDEX_THRESHOLD_RECIPE[];
extern uint8_t RS_REF_PHASE_THRESHOLD_RECIPE[];

TSYNC_ERROR
TSYNC_RS_getTable(
    TSYNC_BoardHandle hnd,
    TSYNC_TableTypeObj *pObj,
    TSYNC_ReferenceTableObj *pObj2)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);
        CHECK_NOT_NULL(pObj2);

        struct RS_TABLE_TYPE_OBJ inPayload;
        inPayload.type = pObj->type;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(RS_TABLE_TYPE_OBJ_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(RS_REF_TABLE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_RS,
            TSYNC_ID_RS_CA_TABLE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            RS_TABLE_TYPE_OBJ_RECIPE,
            RS_REF_TABLE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct RS_REF_TABLE* outPayload =
            (RS_REF_TABLE*)GetPayload(result);
        
        int i;
        for(i = 0; i < TSYNC_TABLE_ENTRY_NUM; i++)
        {
            pObj2->rows[i].enab = outPayload->rows[i].enab;
            pObj2->rows[i].prio = outPayload->rows[i].prio;
            
            memset(pObj2->rows[i].time, '\0', sizeof(pObj2->rows[i].time));
            memset(pObj2->rows[i].pps, '\0', sizeof(pObj2->rows[i].pps));
            
            memcpy(pObj2->rows[i].time, outPayload->rows[i].time, sizeof(outPayload->rows[i].time));
            memcpy(pObj2->rows[i].pps, outPayload->rows[i].pps, sizeof(outPayload->rows[i].pps));
        }
        
    return ( err );
}

TSYNC_ERROR
TSYNC_RS_getBestRef(
    TSYNC_BoardHandle hnd,
    TSYNC_TableEntryObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(RS_TABLE_ENTRY_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_RS,
            TSYNC_ID_RS_CA_BEST_REFERENCE,
            ctl,
            pyldLen,
            NULL,
            NULL,
            RS_TABLE_ENTRY_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct RS_TABLE_ENTRY* outPayload =
            (RS_TABLE_ENTRY*)GetPayload(result);
        
        pObj->enab = outPayload->enab;
        pObj->prio = outPayload->prio;
        
        memset(pObj->time, '\0', sizeof(pObj->time));
        memset(pObj->pps, '\0', sizeof(pObj->pps));
        
        memcpy(pObj->time, outPayload->time, sizeof(outPayload->time));
        memcpy(pObj->pps, outPayload->pps, sizeof(outPayload->pps));
        
    return ( err );
}

TSYNC_ERROR
TSYNC_RS_getEntry(
    TSYNC_BoardHandle hnd,
    int index,
    TSYNC_TableEntryObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct RS_TABLE_INDEX_OBJ inPayload;
        inPayload.index = index;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(RS_TABLE_INDEX_OBJ_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(RS_TABLE_ENTRY_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_RS,
            TSYNC_ID_RS_CA_TABLE_ENTRY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            RS_TABLE_INDEX_OBJ_RECIPE,
            RS_TABLE_ENTRY_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct RS_TABLE_ENTRY* outPayload =
            (RS_TABLE_ENTRY*)GetPayload(result);
        
        pObj->enab = outPayload->enab;
        pObj->prio = outPayload->prio;
        
        memset(pObj->time, '\0', sizeof(pObj->time));
        memset(pObj->pps, '\0', sizeof(pObj->pps));
        
        memcpy(pObj->time, outPayload->time, sizeof(outPayload->time));
        memcpy(pObj->pps, outPayload->pps, sizeof(outPayload->pps));
        
    return ( err );
}

TSYNC_ERROR
TSYNC_RS_addEntry(
    TSYNC_BoardHandle hnd,
    TSYNC_TableEntryObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct RS_TABLE_ENTRY inPayload;
        inPayload.enab = pObj->enab;
        inPayload.prio = pObj->prio;
        memcpy(inPayload.time, pObj->time, sizeof(inPayload.time));
        memcpy(inPayload.pps, pObj->pps, sizeof(inPayload.pps));
        
        uint16_t ctl = 0x02;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(RS_TABLE_ENTRY_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_RS,
            TSYNC_ID_RS_CA_TABLE_ENTRY_ADD,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            RS_TABLE_ENTRY_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_RS_setFactDef(
    TSYNC_BoardHandle hnd)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        uint16_t ctl = 0x02;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_RS,
            TSYNC_ID_RS_CA_FACT_DEFAULT,
            ctl,
            pyldLen,
            NULL,
            NULL,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_RS_setUserDef(
    TSYNC_BoardHandle hnd)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        uint16_t ctl = 0x02;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_RS,
            TSYNC_ID_RS_CA_USER_DEFAULT,
            ctl,
            pyldLen,
            NULL,
            NULL,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_RS_saveUserDef(
    TSYNC_BoardHandle hnd)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        uint16_t ctl = 0x02;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
            
        err = BaseTransaction(
            TSYNC_ID_RS,
            TSYNC_ID_RS_CA_SAVE_USER_DEFAULT,
            ctl,
            pyldLen,
            NULL,
            NULL,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_RS_deleteEntry(
    TSYNC_BoardHandle hnd, unsigned int index)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct RS_TABLE_INDEX_OBJ inPayload;
        inPayload.index = index;
        
        uint16_t ctl = 0x02;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(RS_TABLE_INDEX_OBJ_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_RS,
            TSYNC_ID_RS_CA_TABLE_ENTRY_DEL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            RS_TABLE_INDEX_OBJ_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_RS_getPriority(
    TSYNC_BoardHandle hnd, unsigned int index, unsigned int* priority)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct RS_TABLE_INDEX_OBJ inPayload;
        inPayload.index = index;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(RS_TABLE_INDEX_OBJ_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(RS_TABLE_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_RS,
            TSYNC_ID_RS_CA_PRIORITY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            RS_TABLE_INDEX_OBJ_RECIPE,
            RS_TABLE_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct RS_TABLE_VALUE* outPayload =
            (RS_TABLE_VALUE*)GetPayload(result);
        
        *priority = outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_RS_setPriority(
    TSYNC_BoardHandle hnd, unsigned int index, unsigned int priority)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct RS_TABLE_INDEX_VALUE inPayload;
        inPayload.index = index;
        inPayload.value = priority;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(RS_TABLE_INDEX_VALUE_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_RS,
            TSYNC_ID_RS_CA_PRIORITY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            RS_TABLE_INDEX_VALUE_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_RS_getEnable(
    TSYNC_BoardHandle hnd, unsigned int index, unsigned int* enabled)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct RS_TABLE_INDEX_OBJ inPayload;
        inPayload.index = index;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(RS_TABLE_INDEX_OBJ_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(RS_TABLE_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_RS,
            TSYNC_ID_RS_CA_ENABLE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            RS_TABLE_INDEX_OBJ_RECIPE,
            RS_TABLE_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct RS_TABLE_VALUE* outPayload =
            (RS_TABLE_VALUE*)GetPayload(result);
        
        *enabled = outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_RS_setEnable(
    TSYNC_BoardHandle hnd, unsigned int index, unsigned int enabled)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct RS_TABLE_INDEX_VALUE inPayload;
        inPayload.index = index;
        inPayload.value = enabled;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(RS_TABLE_INDEX_VALUE_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_RS,
            TSYNC_ID_RS_CA_ENABLE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            RS_TABLE_INDEX_VALUE_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_RS_getStateTable(
    TSYNC_BoardHandle hnd,
    TSYNC_ReferenceStateTableObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(RS_STATE_TABLE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_RS,
            TSYNC_ID_RS_CA_REF_STATE_TABLE,
            ctl,
            pyldLen,
            NULL,
            NULL,
            RS_STATE_TABLE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct RS_STATE_TABLE* outPayload =
            (RS_STATE_TABLE*)GetPayload(result);
        
        int i;
        for(i = 0; i < TSYNC_STATE_TABLE_ENTRY_NUM; i++)
        {
            pObj->rows[i].timeValid = outPayload->rows[i].timeValid;
            pObj->rows[i].ppsValid = outPayload->rows[i].ppsValid;
            
            memset(pObj->rows[i].source, '\0', sizeof(pObj->rows[i].source));
            memcpy(pObj->rows[i].source, outPayload->rows[i].src, sizeof(outPayload->rows[i].src));
        }
        
    return ( err );
}

TSYNC_ERROR
TSYNC_RS_getReferencePhaseData(
    TSYNC_BoardHandle hnd, char* pRef, TSYNC_ReferencePhaseDataObj* pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct RS_REF_PHASE_INDEX_OBJ inPayload;

        memcpy(inPayload.ref, pRef, sizeof(inPayload.ref));

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(RS_REF_PHASE_INDEX_OBJ_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(RS_REF_PHASE_DATA_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_RS,
            TSYNC_ID_RS_CA_REF_PHASE_DATA,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            RS_REF_PHASE_INDEX_OBJ_RECIPE,
            RS_REF_PHASE_DATA_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct RS_REF_PHASE_DATA* outPayload =
            (RS_REF_PHASE_DATA*)GetPayload(result);

        pObj->muxPos = outPayload->muxPos;

        memset(pObj->source, '\0', sizeof(pObj->source));
        memcpy(pObj->source, outPayload->src, sizeof(outPayload->src));

        pObj->phaseValid = outPayload->phaseValid;

        pObj->phase = outPayload->phase;

        pObj->phaseFiltered = outPayload->phaseFiltered;

        pObj->lAvg = outPayload->lAvg;

        pObj->lStdDev = outPayload->lStdDev;

        pObj->wPhaseErr = outPayload->wPhaseErr;

        pObj->wFreqErr = outPayload->wFreqErr;

        pObj->threshold = outPayload->threshold;

    return ( err );
}


TSYNC_ERROR
TSYNC_RS_setPhaseThreshold(
    TSYNC_BoardHandle                 hnd,
    char                             *pRef,
    TSYNC_ReferencePhaseThresholdObj *pObj)
{    TSYNC_ERROR err = TSYNC_SUCCESS;

TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);

    struct RS_REF_PHASE_INDEX_THRESHOLD inPayload;

    memcpy(inPayload.ref, pRef, sizeof(inPayload.ref));

    inPayload.mode        = pObj->mode;
    inPayload.n            = pObj->n;
    inPayload.minThreshold = pObj->minThreshold;
    inPayload.maxThreshold = pObj->maxThreshold;

    uint16_t ctl = 0x02;
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(RS_REF_PHASE_INDEX_THRESHOLD_RECIPE, &pos);

    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(0));

    err = BaseTransaction(
        TSYNC_ID_RS,
        TSYNC_ID_RS_CA_REF_PHASE_THRESHOLD,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        RS_REF_PHASE_INDEX_THRESHOLD_RECIPE,
        NULL,
        result,
        handle);

    CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_RS_getPhaseThreshold(
    TSYNC_BoardHandle                 hnd,
    char                             *pRef,
    TSYNC_ReferencePhaseThresholdObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct RS_REF_PHASE_INDEX_OBJ inPayload;

        memcpy(inPayload.ref, pRef, sizeof(inPayload.ref));

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(RS_REF_PHASE_INDEX_OBJ_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(RS_REF_PHASE_THRESHOLD_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_RS,
            TSYNC_ID_RS_CA_REF_PHASE_THRESHOLD,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            RS_REF_PHASE_INDEX_OBJ_RECIPE,
            RS_REF_PHASE_THRESHOLD_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct RS_REF_PHASE_THRESHOLD* outPayload =
            (RS_REF_PHASE_THRESHOLD*)GetPayload(result);

        pObj->mode         = outPayload->mode;
        pObj->n            = outPayload->n;
        pObj->minThreshold = outPayload->minThreshold;
        pObj->maxThreshold = outPayload->maxThreshold;

    return ( err );
}

