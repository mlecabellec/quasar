#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_xo_services.h"
#include "tsync_misc_services.h"

extern uint8_t XO_VALUE_RECIPE[];
extern uint8_t XO_DAC_RECIPE[];
extern uint8_t XO_SERIAL_NUM_RECIPE[];
extern uint8_t XO_MFR_MDL_RECIPE[];
extern uint8_t XO_CUSTOM_MSG_RECIPE[];
extern uint8_t XO_DISC_GET_CMD_RECIPE[];
extern uint8_t XO_DISC_GET_RESP_RECIPE[];
extern uint8_t XO_DISC_SET_CMD_RECIPE[];
extern uint8_t XO_INT_VALUE_RECIPE[];
extern uint8_t XO_FLOAT_VALUE_RECIPE[];

TSYNC_ERROR
TSYNC_XO_getDiscState(
    TSYNC_BoardHandle hnd,
    int *disc)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(disc);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(XO_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_XO,
            TSYNC_ID_XO_CA_DISC_STATE,
            ctl,
            pyldLen,
            NULL,
            NULL,
            XO_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct XO_VALUE* outPayload =
            (XO_VALUE*)GetPayload(result);

        *disc = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_XO_getMode(
    TSYNC_BoardHandle hnd,
    XO_MODE *mode)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(mode);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(XO_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_XO,
            TSYNC_ID_XO_CA_MODE,
            ctl,
            pyldLen,
            NULL,
            NULL,
            XO_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct XO_VALUE* outPayload =
            (XO_VALUE*)GetPayload(result);

        *mode = (XO_MODE)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_XO_setMode(
    TSYNC_BoardHandle hnd,
    XO_MODE mode)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct XO_VALUE inPayload;
        inPayload.value = mode;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(XO_VALUE_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_XO,
            TSYNC_ID_XO_CA_MODE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            XO_VALUE_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_XO_getDac(
    TSYNC_BoardHandle hnd,
    unsigned short *dac)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(dac);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(XO_DAC_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_XO,
            TSYNC_ID_XO_CA_DAC,
            ctl,
            pyldLen,
            NULL,
            NULL,
            XO_DAC_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct XO_DAC* outPayload =
            (XO_DAC*)GetPayload(result);

        *dac = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_XO_setDac(
    TSYNC_BoardHandle hnd,
    unsigned short dac)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct XO_DAC inPayload;
        inPayload.value = dac;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(XO_DAC_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_XO,
            TSYNC_ID_XO_CA_DAC,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            XO_DAC_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_XO_getAlarm(
    TSYNC_BoardHandle hnd,
    unsigned int *alarm)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(alarm);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(XO_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_XO,
            TSYNC_ID_XO_CA_ALARM,
            ctl,
            pyldLen,
            NULL,
            NULL,
            XO_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct XO_VALUE* outPayload =
            (XO_VALUE*)GetPayload(result);

        *alarm = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_XO_getSerNum(
    TSYNC_BoardHandle hnd,
    TSYNC_SerialNoObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(XO_SERIAL_NUM_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_XO,
            TSYNC_ID_XO_CA_SERIAL_NUM,
            ctl,
            pyldLen,
            NULL,
            NULL,
            XO_SERIAL_NUM_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct XO_SERIAL_NUM* outPayload =
            (XO_SERIAL_NUM*)GetPayload(result);

        memset(pObj->serno, '\0', sizeof(pObj->serno));
        memcpy(pObj->serno, outPayload->ser, sizeof(outPayload->ser));

    return ( err );
}

TSYNC_ERROR
TSYNC_XO_getMfrMdl(
    TSYNC_BoardHandle hnd,
    TSYNC_ManModObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(XO_MFR_MDL_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_XO,
            TSYNC_ID_XO_CA_MFR_MDL,
            ctl,
            pyldLen,
            NULL,
            NULL,
            XO_MFR_MDL_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct XO_MFR_MDL* outPayload =
            (XO_MFR_MDL*)GetPayload(result);

        memset(pObj->mfr, '\0', sizeof(pObj->mfr));
        memset(pObj->mdl, '\0', sizeof(pObj->mdl));

        memcpy(pObj->mfr, outPayload->mfr, sizeof(outPayload->mfr));
        memcpy(pObj->mdl, outPayload->mdl, sizeof(outPayload->mdl));

    return ( err );
}

TSYNC_ERROR
TSYNC_XO_setMessage(
    TSYNC_BoardHandle hnd,
    TSYNC_OscCustomMessageObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct XO_CUSTOM_MSG inPayload;
        inPayload.len = pObj->len;
        memcpy(inPayload.msg, pObj->msg, sizeof(inPayload.msg));

        uint16_t ctl = 0x02;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(XO_CUSTOM_MSG_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(XO_CUSTOM_MSG_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_XO,
            TSYNC_ID_XO_CA_CUSTOM_MSG,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            XO_CUSTOM_MSG_RECIPE,
            XO_CUSTOM_MSG_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct XO_CUSTOM_MSG* outPayload =
            (XO_CUSTOM_MSG*)GetPayload(result);

        pObj->len = outPayload->len;

        memset(pObj->msg, '\0', sizeof(pObj->msg));
        memcpy(pObj->msg, outPayload->msg, sizeof(outPayload->msg));

    return ( err );
}

TSYNC_ERROR
TSYNC_XO_getCmd(
    TSYNC_BoardHandle hnd,
    TSYNC_OscDiscObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct XO_DISC_GET_CMD inPayload;
        memcpy(inPayload.cmd, pObj->cmd, TSYNC_OSC_DISC_CMD_SIZE);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(XO_DISC_GET_CMD_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(XO_DISC_GET_RESP_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_XO,
            TSYNC_ID_XO_CA_DISC,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            XO_DISC_GET_CMD_RECIPE,
            XO_DISC_GET_RESP_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct XO_DISC_GET_RESP* outPayload =
            (XO_DISC_GET_RESP*)GetPayload(result);

        memcpy(pObj->data, outPayload->data, TSYNC_OSC_DISC_DATA_SIZE);

    return ( err );
}

TSYNC_ERROR
TSYNC_XO_setCmd(
    TSYNC_BoardHandle hnd,
    TSYNC_OscDiscObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct XO_DISC_SET_CMD inPayload;
        memcpy(inPayload.cmd, pObj->cmd, TSYNC_OSC_DISC_CMD_SIZE);
        memcpy(inPayload.data, pObj->data, TSYNC_OSC_DISC_DATA_SIZE);

        uint16_t ctl = 0x02;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(XO_DISC_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_XO,
            TSYNC_ID_XO_CA_DISC,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            XO_DISC_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_XO_getPhaseErr(
    TSYNC_BoardHandle hnd,
    int *error)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(error);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(XO_INT_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_XO,
            TSYNC_ID_XO_CA_PHASE_ERR,
            ctl,
            pyldLen,
            NULL,
            NULL,
            XO_INT_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct XO_INT_VALUE* outPayload =
            (XO_INT_VALUE*)GetPayload(result);

        *error = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_XO_getPhaseErrLim(
    TSYNC_BoardHandle hnd,
    unsigned int *error)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(error);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(XO_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_XO,
            TSYNC_ID_XO_CA_PHASE_ERR_LIM,
            ctl,
            pyldLen,
            NULL,
            NULL,
            XO_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct XO_VALUE* outPayload =
            (XO_VALUE*)GetPayload(result);

        *error = outPayload->value;

    return ( err );
}


TSYNC_ERROR
TSYNC_XO_setPhaseErrLim(
    TSYNC_BoardHandle hnd,
    unsigned int pel)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct XO_VALUE inPayload;
        inPayload.value = pel;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(XO_VALUE_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_XO,
            TSYNC_ID_XO_CA_PHASE_ERR_LIM,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            XO_VALUE_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_XO_getFreqErr(
    TSYNC_BoardHandle hnd,
    float *error)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(error);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(XO_FLOAT_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_XO,
            TSYNC_ID_XO_CA_FREQ_ERR,
            ctl,
            pyldLen,
            NULL,
            NULL,
            XO_FLOAT_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct XO_FLOAT_VALUE* outPayload =
            (XO_FLOAT_VALUE*)GetPayload(result);

        *error = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_XO_getCalVal(
    TSYNC_BoardHandle hnd,
    float *cal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(cal);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(XO_FLOAT_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_XO,
            TSYNC_ID_XO_CA_CAL_VAL,
            ctl,
            pyldLen,
            NULL,
            NULL,
            XO_FLOAT_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct XO_FLOAT_VALUE* outPayload =
            (XO_FLOAT_VALUE*)GetPayload(result);

        *cal = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_XO_getOscType(
    TSYNC_BoardHandle hnd,
    OSC *oscType)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(oscType);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(XO_INT_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_XO,
            TSYNC_ID_XO_CA_OSC_TYPE,
            ctl,
            pyldLen,
            NULL,
            NULL,
            XO_INT_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct XO_INT_VALUE* outPayload =
            (XO_INT_VALUE*)GetPayload(result);

        *oscType = (OSC)outPayload->value;

    return ( err );
}
