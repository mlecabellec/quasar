#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"
#include "tsync_ger_services.h"
#include "tsync_misc_services.h"

extern uint8_t GER_VALUE_RECIPE[];
extern uint8_t EL_VALIDITY_RECIPE[];
extern uint8_t GER_CUSTOM_MSG_RECIPE[];
extern uint8_t GER_CUSTOM_MSG_SET_CMD_RECIPE[];
extern uint8_t GER_OFFSET_SET_CMD_RECIPE[];
extern uint8_t EL_REF_ID_RECIPE[];



TSYNC_ERROR
TSYNC_GER_getRefId(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_RefIdObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GER_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GER_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(EL_REF_ID_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GER,
            TSYNC_ID_GER_CA_REF_ID,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GER_VALUE_RECIPE,
            EL_REF_ID_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct EL_REF_ID* outPayload =
            (EL_REF_ID*)GetPayload(result);

        memset(pObj->refid, '\0', sizeof(pObj->refid));
        memcpy(pObj->refid, outPayload->ref, sizeof(outPayload->ref));
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GER_getNumInst(
    TSYNC_BoardHandle hnd,
    unsigned int *nInstances)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nInstances);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GER_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GER,
            TSYNC_ID_GER_CA_NUM_INST,
            ctl,
            pyldLen,
            NULL,
            NULL,
            GER_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GER_VALUE* outPayload =
            (GER_VALUE*)GetPayload(result);

        *nInstances = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_GER_getType(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int *nType)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nType);

        struct GER_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GER_VALUE_RECIPE, &pos);;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GER_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GER,
            TSYNC_ID_GER_CA_TYPE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GER_VALUE_RECIPE,
            GER_VALUE_RECIPE,
            result,
            handle);


        CHECK_SUCCESS(err)

        struct GER_VALUE* outPayload =
            (GER_VALUE*)GetPayload(result);

        *nType = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_GER_getValidity(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *bTimeValid,
    int *bPpsValid)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(bTimeValid);
        CHECK_NOT_NULL(bPpsValid);

        struct GER_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GER_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(EL_VALIDITY_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GER,
            TSYNC_ID_GER_CA_VALIDITY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GER_VALUE_RECIPE,
            EL_VALIDITY_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct EL_VALIDITY* outPayload =
            (EL_VALIDITY*)GetPayload(result);

        *bTimeValid = outPayload->timeValid;
        *bPpsValid = outPayload->ppsValid;

    return ( err );
}

TSYNC_ERROR
TSYNC_GER_getCustom(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_CustomMessageObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GER_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GER_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GER_CUSTOM_MSG_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GER,
            TSYNC_ID_GER_CA_CUSTOM_MSG,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GER_VALUE_RECIPE,
            GER_CUSTOM_MSG_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GER_CUSTOM_MSG* outPayload =
            (GER_CUSTOM_MSG*)GetPayload(result);

        pObj->len = outPayload->len;

        memset(pObj->msg, '\0', sizeof(pObj->msg));
        memcpy(pObj->msg, outPayload->msg, sizeof(outPayload->msg));

    return ( err );
}

TSYNC_ERROR
TSYNC_GER_setCustom(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_CustomMessageObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GER_CUSTOM_MSG_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.len = pObj->len;
        memcpy(inPayload.msg, pObj->msg, sizeof(inPayload.msg));

        uint16_t ctl = 0x02;//set
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GER_CUSTOM_MSG_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GER,
            TSYNC_ID_GER_CA_CUSTOM_MSG,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GER_CUSTOM_MSG_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}



TSYNC_ERROR
TSYNC_GER_getOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *nOffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nOffset);

        struct GER_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GER_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GER_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GER,
            TSYNC_ID_GER_CA_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GER_VALUE_RECIPE,
            GER_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GER_VALUE* outPayload =
            (GER_VALUE*)GetPayload(result);

        *nOffset = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_GER_setOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int nOffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GER_OFFSET_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.nOffset = nOffset;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GER_OFFSET_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GER,
            TSYNC_ID_GER_CA_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GER_OFFSET_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

