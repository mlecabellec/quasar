
/***************************************************************************
**  Module:     tsync_fs_services_recipes.c
**
**  Date:       07/10/08
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/10/2008 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_fs_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(UL_IMG_HDR)
RECIPE(UL_IMG_TRL)
RECIPE(UL_IMG_OBJ)
RECIPE(FS_CRC_OBJ)
RECIPE(FS_VERS_OBJ)

#include "tsync_recipe_undef.h"
