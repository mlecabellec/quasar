
#ifndef _defined_TSYNC_GI_SERVICES_H
#define _defined_TSYNC_GI_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_gi_services.h
**
**  Date:       07/29/08
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/29/2008 Creation
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_GI                     0x38
#define TSYNC_ID_GI_CA_VALUE            0x00
#define TSYNC_ID_GI_CA_EDGE             0x01
#define TSYNC_ID_GI_CA_TIMESTAMP_EN     0x02
#define TSYNC_ID_GI_CA_NUM_INST         0x03
#define TSYNC_ID_GI_CA_TS_TYPE          0x04
#define TSYNC_ID_GI_CA_TS_ASCII         0x05
#define TSYNC_ID_GI_CA_TS_CLEAR         0x06

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define GI_VALUE_FIELDS                         \
    TSYNC_X( uint32_t,      value)

#define GI_EDGE_SET_CMD_FIELDS                  \
    TSYNC_X( ID_PIN,        index)              \
    TSYNC_X( EDGE,          edge)

#define GI_TIMESTAMP_ENABLE_SET_CMD_FIELDS      \
    TSYNC_X( ID_PIN,        index)              \
    TSYNC_X( uint32_t,      enable)

#define GI_ASCII_TIMESTAMP_FIELDS               \
    TSYNC_X_BUFFER( int8_t,   msg,        40)  \


#include "tsync_struct_define.h"

GEN_STRUCT(GI_VALUE)
GEN_STRUCT(GI_EDGE_SET_CMD)
GEN_STRUCT(GI_TIMESTAMP_ENABLE_SET_CMD)
GEN_STRUCT(GI_ASCII_TIMESTAMP)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_GI_SERVICES_H */
