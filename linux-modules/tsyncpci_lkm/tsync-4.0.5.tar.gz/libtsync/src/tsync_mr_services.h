
#ifndef _defined_TSYNC_MR_SERVICES_H
#define _defined_TSYNC_MR_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_mr_services.h
**
**  Date:       02/20/20
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2020 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              02/20/2020 Creation
**
****************************************************************************/

#include "tsync_cs_services.h"

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_MR                     0x50
#define TSYNC_ID_MR_CA_VALIDITY         0x00
#define TSYNC_ID_MR_CA_TIME             0x01
#define TSYNC_ID_MR_CA_UTC_OFF          0x02
#define TSYNC_ID_MR_CA_USE_CS_OFF       0x03
#define TSYNC_ID_MR_CA_REF_ID           0x04
#define TSYNC_ID_MR_CA_NUM_INST         0x05

/******************************************************
**     Define Structures
******************************************************/

#define MR_VALUE_FIELDS                            \
    TSYNC_X(        uint32_t,           value)

#define MR_SVALUE_FIELDS                           \
    TSYNC_X(        int32_t,            value)

#define MR_VALIDITY_SET_CMD_FIELDS                 \
    TSYNC_X(        uint32_t,           nInstance) \
    TSYNC_X(        uint32_t,           timeValid) \
    TSYNC_X(        uint32_t,           ppsValid)

#define MR_UTC_OFF_SET_CMD_FIELDS                  \
    TSYNC_X(        uint32_t,           nInstance) \
    TSYNC_X(        int32_t,            utcOff)

#define MR_USE_CS_OFF_SET_CMD_FIELDS               \
    TSYNC_X(        uint32_t,           nInstance) \
    TSYNC_X(        uint32_t,           useCSOff)

#include "tsync_struct_define.h"

GEN_STRUCT(MR_VALUE)
GEN_STRUCT(MR_SVALUE)
GEN_STRUCT(MR_VALIDITY_SET_CMD)
GEN_STRUCT(MR_UTC_OFF_SET_CMD)
GEN_STRUCT(MR_USE_CS_OFF_SET_CMD)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_MR_SERVICES_H */
