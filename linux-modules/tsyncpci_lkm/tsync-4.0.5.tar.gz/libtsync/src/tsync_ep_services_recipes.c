
/***************************************************************************
**  Module:     tsync_ep_services_recipes.c
**
**  Date:       07/19/10
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2010 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/19/2010 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_ep_services.h"
#include "tsync_cs_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(EP_VALUE)
RECIPE(EP_SET_CMD)
RECIPE(EP_INT_VALUE)
RECIPE(EP_INT_SET_CMD)
RECIPE(EP_LOCAL_SET_CMD)
RECIPE(EP_TIME_SCALE_SET_CMD)

#include "tsync_recipe_undef.h"
