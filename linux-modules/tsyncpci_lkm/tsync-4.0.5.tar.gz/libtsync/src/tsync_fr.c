#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_fr_services.h"
#include "tsync_misc_services.h"

extern uint8_t FR_VALUE_RECIPE[];
extern uint8_t FR_OFFSET_SET_CMD_RECIPE[];
extern uint8_t FR_FREQ_SET_CMD_RECIPE[];
extern uint8_t FR_MODE_GET_RESP_RECIPE[];
extern uint8_t FR_MODE_SET_CMD_RECIPE[];
extern uint8_t EL_VALIDITY_RECIPE[];
extern uint8_t EL_REF_ID_RECIPE[];

TSYNC_ERROR
TSYNC_FR_getValidity(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *bTimeValid,
    int *bPpsValid)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(bTimeValid);
        CHECK_NOT_NULL(bPpsValid);

        struct FR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(FR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(EL_VALIDITY_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_FR,
            TSYNC_ID_FR_CA_VALIDITY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            FR_VALUE_RECIPE,
            EL_VALIDITY_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct EL_VALIDITY* outPayload =
            (EL_VALIDITY*)GetPayload(result);
            
        *bTimeValid = outPayload->timeValid;
        *bPpsValid = outPayload->ppsValid;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_FR_getFreq(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int *freq)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(freq);

        struct FR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(FR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(FR_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_FR,
            TSYNC_ID_FR_CA_FREQUENCY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            FR_VALUE_RECIPE,
            FR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct FR_VALUE* outPayload =
            (FR_VALUE*)GetPayload(result);
            
        *freq = outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_FR_setFreq(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int freq)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct FR_FREQ_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.freq = freq;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(FR_FREQ_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_FR,
            TSYNC_ID_FR_CA_FREQUENCY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            FR_FREQ_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_FR_getMode(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    FR_MODE *mode)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(mode);

        struct FR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(FR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(FR_MODE_GET_RESP_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_FR,
            TSYNC_ID_FR_CA_REF_MODE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            FR_VALUE_RECIPE,
            FR_MODE_GET_RESP_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct FR_MODE_GET_RESP* outPayload =
            (FR_MODE_GET_RESP*)GetPayload(result);
            
        *mode = outPayload->mode;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_FR_setMode(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    FR_MODE mode)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct FR_MODE_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.mode = mode;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(FR_MODE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_FR,
            TSYNC_ID_FR_CA_REF_MODE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            FR_MODE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_FR_getNumInst(
    TSYNC_BoardHandle hnd,
    unsigned int *nInstances)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nInstances);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(FR_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_FR,
            TSYNC_ID_FR_CA_NUM_INST,
            ctl,
            pyldLen,
            NULL,
            NULL,
            FR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct FR_VALUE* outPayload =
            (FR_VALUE*)GetPayload(result);
            
        *nInstances = outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_FR_getRefId(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_RefIdObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct FR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(FR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(EL_REF_ID_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_FR,
            TSYNC_ID_FR_CA_REF_ID,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            FR_VALUE_RECIPE,
            EL_REF_ID_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct EL_REF_ID* outPayload =
            (EL_REF_ID*)GetPayload(result);
            
        memset(pObj->refid, '\0', sizeof(pObj->refid));
        memcpy(pObj->refid, outPayload->ref, sizeof(outPayload->ref));
        
    return ( err );
}

