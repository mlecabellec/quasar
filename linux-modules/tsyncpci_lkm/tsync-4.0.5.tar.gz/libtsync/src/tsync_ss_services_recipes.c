
/***************************************************************************
**  Module:     tsync_ss_services_recipes.c
**
**  Date:       07/25/08
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/25/2008 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_ss_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(SS_RESET_OBJ)
RECIPE(SS_REF_OBJ)
RECIPE(SS_VALUE)
RECIPE(SS_TS_REQ)

#include "tsync_recipe_undef.h"
