
#ifndef _defined_TSYNC_LS_SERVICES_H
#define _defined_TSYNC_LS_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_ls_services.h
**
**  Date:       07/10/08
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/10/2008 Creation
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_LS                     0x40
#define TSYNC_ID_LS_CA_ERROR_LOG        0x00
#define TSYNC_ID_LS_CA_ALARM            0x01
#define TSYNC_ID_LS_CA_VERSION          0x02
#define TSYNC_ID_LS_CA_SERIAL_NO        0x03

/******************************************************
**     Define Structures
******************************************************/

#define LS_ERROR_LOG_FIELDS                        \
    TSYNC_X_BUFFER( int8_t,         msg, 120)

#define LS_ALARM_OBJ_FIELDS                        \
    TSYNC_X( LS_ALARM,         index)

#define LS_ALARM_FLAG_FIELDS                        \
    TSYNC_X( uint32_t,         flag)

#define LS_ALARM_SET_CMD_FIELDS                        \
    TSYNC_X( LS_ALARM,         index)           \
    TSYNC_X( uint32_t,         flag)

#if defined(NIOS)
    // Need to transmit KTS's revision hash code along with firmware version
    #define LS_VERSION_FIELDS                       \
        TSYNC_X_BUFFER( int8_t,         ver, 21)
#else
    #define LS_VERSION_FIELDS                       \
        TSYNC_X_BUFFER( int8_t,         ver, 6)
#endif

#define LS_SERIAL_NO_FIELDS                     \
    TSYNC_X_BUFFER( int8_t,         ser, 32)


#include "tsync_struct_define.h"

GEN_STRUCT(LS_ERROR_LOG)
GEN_STRUCT(LS_ALARM_OBJ)
GEN_STRUCT(LS_ALARM_FLAG)
GEN_STRUCT(LS_ALARM_SET_CMD)
GEN_STRUCT(LS_VERSION)
GEN_STRUCT(LS_SERIAL_NO)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_LS_SERVICES_H */
