
/***************************************************************************
**  Module:     tsync_ppsoutput_services_recipes.c
**
**  Date:       08/05/08
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              08/05/2008 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_pp_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(PP_SET_CMD)
RECIPE(PP_INT_SET_CMD)
RECIPE(PP_VALUE)
RECIPE(PP_INT_VALUE)
RECIPE(PP_FREQ)

#include "tsync_recipe_undef.h"
