#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_str_services.h"
#include "tsync_cs_services.h"
#include "tsync_misc_services.h"

extern uint8_t STR_VALUE_RECIPE[];
extern uint8_t STR_BUFFER_RECIPE[];
extern uint8_t EL_VALIDITY_RECIPE[];
extern uint8_t EL_REF_ID_RECIPE[];
extern uint8_t STR_VERSION_RECIPE[];
extern uint8_t STR_CONF_RECIPE[];
extern uint8_t STR_CONF_SET_CMD_RECIPE[];
extern uint8_t STR_STAT_VALUE_RECIPE[];
extern uint8_t STR_SUB_RECIPE[];
extern uint8_t STR_SUBK_RECIPE[];
extern uint8_t STR_SUBK_SET_CMD_RECIPE[];

TSYNC_ERROR
TSYNC_STR_getNumInst(
    TSYNC_BoardHandle hnd,
    unsigned int *nInstances)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(nInstances);

    uint16_t ctl = 0x00;//get
    uint8_t  pos = 0;
    uint32_t pyldLen = 0;

    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(STR_VALUE_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_STR,
        TSYNC_ID_STR_CA_NUM_INST,
        ctl,
        pyldLen,
        NULL,
        NULL,
        STR_VALUE_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    struct STR_VALUE* outPayload =
        (STR_VALUE*)GetPayload(result);

    *nInstances = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_STR_getRefId(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_RefIdObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    struct STR_VALUE inPayload;
    inPayload.value = nInstance;

    uint16_t ctl = 0x00;
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(STR_VALUE_RECIPE, &pos);

    pos = 0;
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(EL_REF_ID_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_STR,
        TSYNC_ID_STR_CA_REF_ID,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        STR_VALUE_RECIPE,
        EL_REF_ID_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    struct EL_REF_ID* outPayload =
        (EL_REF_ID*)GetPayload(result);

    memset(pObj->refid, '\0', sizeof(pObj->refid));
    memcpy(pObj->refid, outPayload->ref, sizeof(outPayload->ref));

    return ( err );
}

TSYNC_ERROR
TSYNC_STR_getValidity(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *bTimeValid,
    int *bPpsValid)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(bTimeValid);
    CHECK_NOT_NULL(bPpsValid);

    struct STR_VALUE inPayload;
    inPayload.value = nInstance;

    uint16_t ctl = 0x00;//get
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(STR_VALUE_RECIPE, &pos);

    pos = 0;
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(EL_VALIDITY_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_STR,
        TSYNC_ID_STR_CA_VALIDITY,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        STR_VALUE_RECIPE,
        EL_VALIDITY_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    struct EL_VALIDITY* outPayload =
        (EL_VALIDITY*)GetPayload(result);

    *bTimeValid = outPayload->timeValid;
    *bPpsValid = outPayload->ppsValid;

    return ( err );
}

TSYNC_ERROR
TSYNC_STR_getVersion(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_StrVersionObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    struct STR_VALUE inPayload;
    inPayload.value = nInstance;

    uint16_t ctl = 0x00;
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(STR_VALUE_RECIPE, &pos);

    pos = 0;
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(STR_VERSION_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_STR,
        TSYNC_ID_STR_CA_VERSION,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        STR_VALUE_RECIPE,
        STR_VERSION_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    struct STR_VERSION* outPayload =
        (STR_VERSION*)GetPayload(result);

    memset(pObj->application, '\0', sizeof(pObj->application));
    memset(pObj->system, '\0', sizeof(pObj->system));
    memset(pObj->serialnb, '\0', sizeof(pObj->serialnb));

    memcpy(pObj->serialnb, outPayload->serialnb, sizeof(outPayload->serialnb));
    memcpy(pObj->application, outPayload->application, sizeof(outPayload->application));
    memcpy(pObj->system, outPayload->system, sizeof(outPayload->system));

    return ( err );
}

TSYNC_ERROR
TSYNC_STR_getSubscription(
    TSYNC_BoardHandle  hnd,
    unsigned int       nInstance,
    TSYNC_StrSubObj *pSub)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pSub);

    struct STR_VALUE inPayload;
    inPayload.value = nInstance;

    uint16_t ctl = 0x00;
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(STR_VALUE_RECIPE, &pos);

    pos = 0;
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(STR_SUB_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_STR,
        TSYNC_ID_STR_CA_SUBSCRIPTION,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        STR_VALUE_RECIPE,
        STR_SUB_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    struct STR_SUB* outPayload =
        (STR_SUB*)GetPayload(result);

    memset(pSub->beginSub, '\0', 16);
    memcpy(pSub->beginSub, outPayload->beginSub, 16);

    memset(pSub->endSub, '\0', 16);
    memcpy(pSub->endSub, outPayload->endSub, 16);
    pSub->state = outPayload->state;


    return ( err );
}

TSYNC_ERROR
TSYNC_STR_getActFeat(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *nActFeat)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(nActFeat);

    struct STR_VALUE inPayload;
    inPayload.value = nInstance;

    uint16_t ctl = 0x00;//get
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(STR_VALUE_RECIPE, &pos);

    pos = 0;
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(STR_VALUE_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_STR,
        TSYNC_ID_STR_CA_ACT_FEAT,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        STR_VALUE_RECIPE,
        STR_VALUE_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    struct STR_VALUE* outPayload =
        (STR_VALUE*)GetPayload(result);

    *nActFeat = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_STR_getConf(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_StrConfObj *pConf)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pConf);

    struct STR_VALUE inPayload;
    inPayload.value = nInstance;

    uint16_t ctl = 0x00;
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(STR_VALUE_RECIPE, &pos);

    pos = 0;
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(STR_CONF_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_STR,
        TSYNC_ID_STR_CA_CONF,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        STR_VALUE_RECIPE,
        STR_CONF_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    struct STR_CONF* outPayload =
        (STR_CONF*)GetPayload(result);

    memset(pConf->serialnb, 0, 16);
    memcpy(pConf->serialnb, outPayload->serialnb, 16);

    pConf->pos.lat   = outPayload->lat;
    pConf->pos.lon   = outPayload->lon;
    pConf->pos.alt   = outPayload->alt;
    pConf->ee_axis   = outPayload->ee_axis;
    pConf->nn_axis   = outPayload->nn_axis;
    pConf->uu_axis   = outPayload->uu_axis;
    pConf->geoMode   = outPayload->geoMode;
    pConf->sensLevel = outPayload->sensLevel;

    return ( err );
}

TSYNC_ERROR
TSYNC_STR_setConf(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_StrConfObj conf)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);

    struct STR_CONF_SET_CMD inPayload;
    inPayload.nInstance = nInstance;

    memset(inPayload.serialnb, 0, 16);
    memcpy(inPayload.serialnb, conf.serialnb, 16);

    inPayload.lat = conf.pos.lat;
    inPayload.lon = conf.pos.lon;
    inPayload.alt = conf.pos.alt;
    inPayload.ee_axis = conf.ee_axis;
    inPayload.nn_axis = conf.nn_axis;
    inPayload.uu_axis = conf.uu_axis;
    inPayload.geoMode = conf.geoMode;
    inPayload.sensLevel = conf.sensLevel;

    uint16_t ctl = 0x02;
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(STR_CONF_SET_CMD_RECIPE, &pos);

    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(0));

    err = BaseTransaction(
        TSYNC_ID_STR,
        TSYNC_ID_STR_CA_CONF,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        STR_CONF_SET_CMD_RECIPE,
        NULL,
        result,
        handle);

    CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_STR_getIpAddr(
    TSYNC_BoardHandle  hnd,
    unsigned int       nInstance,
    char *IpAddr)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(IpAddr);

    struct STR_VALUE inPayload;
    inPayload.value = nInstance;

    uint16_t ctl = 0x00;
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(STR_VALUE_RECIPE, &pos);

    pos = 0;
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(STR_BUFFER_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_STR,
        TSYNC_ID_STR_CA_IP_ADDR,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        STR_VALUE_RECIPE,
        STR_BUFFER_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    struct STR_BUFFER* outPayload =
        (STR_BUFFER*)GetPayload(result);

    memset(IpAddr, '\0', 16);
    memcpy(IpAddr, outPayload->buffer, 16);

    return ( err );
}

TSYNC_ERROR
TSYNC_STR_getStat(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_StrStatusObj *pStat)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pStat);

    struct STR_VALUE inPayload;
    inPayload.value = nInstance;

    uint16_t ctl = 0x00;
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(STR_VALUE_RECIPE, &pos);

    pos = 0;
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(STR_STAT_VALUE_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_STR,
        TSYNC_ID_STR_CA_STAT,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        STR_VALUE_RECIPE,
        STR_STAT_VALUE_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    struct STR_STAT_VALUE* outPayload =
        (STR_STAT_VALUE*)GetPayload(result);

    pStat->rcvBurst = outPayload->rcvBurst;
    pStat->rcvStrongBurst = outPayload->rcvStrongBurst;

    return ( err );
}

TSYNC_ERROR
TSYNC_STR_getSubk(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_StrSubkObj *pSubk)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pSubk);

    struct STR_VALUE inPayload;
    inPayload.value = nInstance;

    uint16_t ctl = 0x00;
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(STR_VALUE_RECIPE, &pos);

    pos = 0;
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(STR_SUBK_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_STR,
        TSYNC_ID_STR_CA_SUBK,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        STR_VALUE_RECIPE,
        STR_SUBK_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    struct STR_SUBK* outPayload =
        (STR_SUBK*)GetPayload(result);

    memset(pSubk->key, 0, 32);
    memcpy(pSubk->key, outPayload->key, 32);

    return ( err );
}

TSYNC_ERROR
TSYNC_STR_setSubk(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_StrSubkObj subk)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);

    struct STR_SUBK_SET_CMD inPayload;
    inPayload.nInstance = nInstance;

    memset(inPayload.key, 0, 32);
    memcpy(inPayload.key, subk.key, 32);

    uint16_t ctl = 0x02;
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(STR_SUBK_SET_CMD_RECIPE, &pos);

    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(0));

    err = BaseTransaction(
        TSYNC_ID_STR,
        TSYNC_ID_STR_CA_SUBK,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        STR_SUBK_SET_CMD_RECIPE,
        NULL,
        result,
        handle);

    CHECK_SUCCESS(err)

    return ( err );
}
