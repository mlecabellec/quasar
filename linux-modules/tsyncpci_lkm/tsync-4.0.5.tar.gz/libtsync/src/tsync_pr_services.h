
#ifndef _defined_TSYNC_PR_SERVICES_H
#define _defined_TSYNC_PR_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_pr_services.h
**
**  Date:       07/28/08
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2006, 2009 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/28/2008 Creation
**              09/09/2009 Added Reference ID
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_PR                     0x2E
#define TSYNC_ID_PR_CA_OFFSET           0x00
#define TSYNC_ID_PR_CA_EDGE             0x01
#define TSYNC_ID_PR_CA_VALIDITY         0x02
#define TSYNC_ID_PR_CA_NUM_INST         0x03
#define TSYNC_ID_PR_CA_REF_ID           0x04

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define PR_VALUE_FIELDS                   \
    TSYNC_X(        uint32_t,   value)
    
#define PR_OFFSET_SET_CMD_FIELDS                   \
    TSYNC_X(        uint32_t,   inst)          \
    TSYNC_X(        int32_t,   offset)

#define PR_EDGE_SET_CMD_FIELDS                   \
    TSYNC_X(        uint32_t,   inst)          \
    TSYNC_X(        EDGE,   edge)


#include "tsync_struct_define.h"

GEN_STRUCT(PR_VALUE)
GEN_STRUCT(PR_OFFSET_SET_CMD)
GEN_STRUCT(PR_EDGE_SET_CMD)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_PR_SERVICES_H */
