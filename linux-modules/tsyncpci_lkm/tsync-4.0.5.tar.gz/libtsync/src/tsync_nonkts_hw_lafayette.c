#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "ddtsync.h"
#include "tsync_macros.h"

#include "tsync_hw.h"

#ifdef LAFAYETTE
static inline TSYNC_ERROR Write(TSYNC_BoardHandle handle,
                         uint32_t cmdWord) {

    /* Create the objects the accessor call will reference */
    TSYNC_ERROR err;
    ITEM_ID     iid;
    uint32_t    actualOutLength;

    iid.hnkid = HW_NONKTS_LCD;

    /* Call the generic accessor */
    err = TSYNC_set(handle,
                    DEST_ID_HW_NONKTS,
                    iid,
                    (void*)&cmdWord,
                    sizeof(cmdWord),
                    NULL,
                    0,
                    &actualOutLength);

    return (err);

} /* end SetPageAddr */


static inline TSYNC_ERROR ReadByte(TSYNC_BoardHandle handle,
                            LCD_CHIP chip,
                            uint32_t status,
                            uint32_t *value) {

    /* Create the objects the accessor call will reference */
    TSYNC_ERROR err;
    ITEM_ID     iid;
    uint32_t    actualOutLength;
    uint32_t    cmdWord;


    /* Decide if we need to read status or data.  The value we write consists
     * of the bit to select the desired chip and bits that indicate whether or
     * not this cycle is a read data or a read status cycle.
     */
    if (status) {
        cmdWord = (chip | LCD_READ_STAT);
    } else {
        cmdWord = (chip | LCD_READ_DATA);
    }

    iid.hnkid = HW_NONKTS_LCD;

    /* Call the generic accessor */
    err = TSYNC_get(handle,
                    DEST_ID_HW_NONKTS,
                    iid,
                    (void*)&cmdWord,
                    sizeof(cmdWord),
                    (void*)value,
                    sizeof(uint32_t),
                    &actualOutLength);

    return (err);

} /* end SetPageAddr */


static inline TSYNC_ERROR SetPageAddr(TSYNC_BoardHandle handle,
                               uint32_t page) {

    /* Create the objects the accessor call will reference */
    TSYNC_ERROR err;
    uint32_t    cmdWord;

    /* Build the command word.  Select both chips for a write command cycle and
     * the command is set page address.
     */
    cmdWord = (LCD_CHIP_BOTH | LCD_WRITE_CMD | LCD_CMD_PAGE);

    /* Insert the page address into the lower 2 bits of the command word */
    cmdWord |= (page % LCD_NUM_PAGES_V);

    err = Write(handle, cmdWord);

    return (err);

} /* end SetPageAddr */


static inline TSYNC_ERROR SetColAddr(TSYNC_BoardHandle handle,
                              LCD_CHIP chip,
                              uint32_t column) {

    /* Create the objects the accessor call will reference */
    TSYNC_ERROR err;
    uint32_t    cmdWord;

    /* Build the command word: select the desired chips for a write command
    ** cycle and set column address
    */
    cmdWord = (chip | LCD_WRITE_CMD | LCD_CMD_COLUMN);

    /* Insert column address into the lower 7 bits of the command word */
    cmdWord |= (column % LCD_PAGE_WIDTH);

    err = Write(handle, cmdWord);

    return (err);

} /* End SetColAddr */


static inline int BoundsCheck(LCD_IMAGE *img) {

    int      size;
    uint32_t lowerRightCol;     /* Location of image lower right corner */
    uint32_t lowerRightRow;

    /* The upper left corner of the image cannot be at a negative coordinate
     * because the coordinates and offsets are unsigned.  We do need to make
     * sure that the lower right corner is not out of bounds though.
     * Remember that as you go down the screen the row numbers get larger.
     */
    lowerRightCol = ((img->upperLeftCol + img->colSize) - 1);
    lowerRightRow = ((img->upperLeftRow + img->rowSize) - 1);

    if ((lowerRightCol >= (LCD_NUM_PAGES_H * LCD_PAGE_WIDTH)) ||
        (lowerRightRow >= (LCD_NUM_PAGES_V * LCD_PAGE_HEIGHT))) {
        size = -1;
    }
    else {
        size = (img->colSize * img->rowSize);
    }

    /* If the image covers zero pixels it probably isn't what was intended */
    if (size == 0) {
        size = -1;
    }

    return (size);

} /* End BoundsCheck */


static inline TSYNC_ERROR VertCalc(uint32_t page,
                            LCD_IMAGE *img,
                            uint32_t *ovlTop,
                            uint32_t *ovlBottom,
                            uint32_t *ovlTopImg) {

    uint32_t pageTop;           /* vertical coordinate of top of page */
    uint32_t pageBottom;        /* vertical coordinate of bottom of page */
    uint32_t otopLocal;         /* Work with local data so we don't need to */
    uint32_t obotLocal;         /* keep dereferencing them.  Hopefully this */
    uint32_t otopImgLocal;      /* will save a little speed */

    /* Find vertical coordinates covered by this page.  These are relative
     * to the absolute coordinate space (whole display)
     */
    pageTop = (page * LCD_PAGE_HEIGHT);
    pageBottom = (pageTop + LCD_PAGE_HEIGHT - 1);

    /* Find the vertical region where the image overlaps the current page.
     * This is a vertical range from top (smaller row) to bottom (larger row).
     * As the driver document illustrates, and image fit onto the display may
     * or may not overlap a portion of some page.
     * Vertically, this region can be described as a range from the larger
     * (lower on the screen) of the tops of the image and the page to the
     * smaller of the bottoms.
     * Find these in absolute coordinates (relative to the whole screen).
     */

    /* First, look at the "tops" and take the larger one.
     */
    otopLocal = (pageTop > img->upperLeftRow) ? pageTop : img->upperLeftRow;

    /* And now look at the "bottoms" and take the smaller one */
    obotLocal = (pageBottom < (img->upperLeftRow + img->rowSize - 1))
                ? pageBottom : (img->upperLeftRow + img->rowSize - 1);

    /* If the top > the bottom, then the image and the page don't overlap.
     * The data is considered invalid and is not passed back in this event.
     */
    if (otopLocal > obotLocal) {
        return (TSYNC_INVALID_INPUT);
    }

    /* Find the Y offset into the image that corresponds to the bit at the top
     * of the overlap.  This lets us map from the page's coordinates to the
     * image's coordinates.
     */
    otopImgLocal = (otopLocal - img->upperLeftRow);

    /* Change overlap top and bottom from absolute coordinates to page
     * coordinates.
     * This is safe to do now because we determined that the overTop < the
     * overBot and therefore they must be on the same page (overTop cannot
     * be smaller than pageTop and overBot cannot be greater than pageBot)
     */
    otopLocal %= LCD_PAGE_HEIGHT;
    obotLocal %= LCD_PAGE_HEIGHT;

    /* The data is valid so pass it back it to the caller */
    *ovlTop    = otopLocal;
    *ovlBottom = obotLocal;
    *ovlTopImg = otopImgLocal;

    return (TSYNC_SUCCESS);

} /* End VertCalc */


static inline TSYNC_ERROR HorizCalc(TSYNC_BoardHandle handle,
                             LCD_IMAGE *img,
                             LCD_CHIP *chip,
                             uint32_t *rolloverCol) {

    TSYNC_ERROR err;

    /* Initialize the columns to zero.  In the event we start in chip 1 and we
     * rollover to the next chip, we won't have to set chip 2 to column 0.
     * Doing so would require disabling RMW if it was on since the column can't
     * be set when RMW is on.  Basically, the chips are both set to column 0
     * here to avoid a mess later
     */
    err = SetColAddr(handle, LCD_CHIP_BOTH, 0);
    CHECK_SUCCESS(err)

    /* Two things are done here.  First, we find the chip that we start with.
     * This is based on the first column in the image.  If this column is in
     * the left half of the display, it falls under chip 1.  Otherwise it falls
     * under chip 2.
     * Second, we set a rollover point for the main loop in LCD_xferPage.  If
     * the loop counter (the columns in the image) matches this count, chip 2
     * will be selected.  If we start from chip 2 we should never rollover.  If
     * we start from chip 1, we rollover when the column in the image we are
     * sending equals the difference between the highest column in the chip and
     * the image starting offset.
     */
    if (img->upperLeftCol < LCD_PAGE_WIDTH) {
        *chip = LCD_CHIP_ONE;
        *rolloverCol = (LCD_PAGE_WIDTH - img->upperLeftCol);
    }
    else {
        *chip = LCD_CHIP_TWO;
        /* Don't rollover if starting in chip 2 */
        *rolloverCol = 0xFFFFFFFF;
    }

    /* Set the column address to the first x location in the image.  Mod it by
     * the number of columns in each chip in case it starts in chip 2.
     */
    err = SetColAddr(handle, *chip, (img->upperLeftCol % LCD_PAGE_WIDTH));
    CHECK_SUCCESS(err)

    return (TSYNC_SUCCESS);

} /* End HorizCalc */


static inline TSYNC_ERROR SetRmw(TSYNC_BoardHandle handle,
                          uint32_t on) {

    TSYNC_ERROR err;
    uint32_t    cmdWord;

    /* Build the command word.  Select both chips for a write command cycle */
    cmdWord = (LCD_CHIP_BOTH | LCD_WRITE_CMD);

    /* If we are supposed to turn RMW on, select the start RMW command */
    if (on) {
        cmdWord |= LCD_CMD_RMW;
    }
        /* If we are supposed to turn RMW off, select the end RMW command */
    else {
        cmdWord |= LCD_CMD_END;
    }

    err = Write(handle, cmdWord);

    return (err);

} /* End SetRmw */


static inline TSYNC_ERROR Fill(TSYNC_BoardHandle handle,
                        uint32_t pattern) {

    TSYNC_ERROR err;
    uint32_t    cmdWord;
    uint32_t    currPage;
    uint32_t    currCol;

    /* Precalculate the command word to write the pattern to the display RAM.
     * Doing it out here makes the loop faster as well.
     * Select both chips, write data cycle, insert the lower 8 bits of pattern
     */
    cmdWord = (LCD_CHIP_BOTH | LCD_WRITE_DATA | (pattern & 0xFF));

    /* Write pattern to all RAM, write to both chips at once to make faster */
    for (currPage = 0; currPage < LCD_NUM_PAGES_V; currPage++) {
        /* Set the page to the current page and start at column 0 */
        err = SetPageAddr(handle, currPage);
        CHECK_SUCCESS(err)
        err = SetColAddr(handle, LCD_CHIP_BOTH, 0);
        CHECK_SUCCESS(err)

        /* Fill this page, the column automatically increments (hopefully) */
        for (currCol = 0; currCol < LCD_PAGE_WIDTH; currCol++) {

            err = Write(handle, cmdWord);
            CHECK_SUCCESS(err)
        }
    }

    return (err);

} /* End Fill */


static inline TSYNC_ERROR EnableDisable(TSYNC_BoardHandle handle,
                                 uint32_t enable) {

    TSYNC_ERROR err;
    uint32_t    cmdWord;

    /* Build the command word.  Select both chips for a write command cycle and
     * the command is enable/disable display
     */
    cmdWord = (LCD_CHIP_BOTH | LCD_WRITE_CMD | LCD_CMD_ONOFF);

    /* The command word will currently disable the display (bit 0 is a 0).  If
     * we are to enable the display, set bit 0 to a 1.
     */
    if (enable) {
        cmdWord |= 1;
    }

    err = Write(handle, cmdWord);

    return (err);

} /* End EnableDisable */


static inline TSYNC_ERROR LineTest(TSYNC_BoardHandle handle) {

    TSYNC_ERROR err     = 0;
    uint32_t    pattern = 0;  /* The pattern to write to memory - walking one */
    uint32_t    readVal = 0;  /* What we read back from memory */
    uint32_t    cmdWord = 0;  /* Command sent to the LCD driver chip */

    /* Work in page 0 */
    err = SetPageAddr(handle, 0);
    CHECK_SUCCESS(err)

    /* For each bit in a location */
    for (pattern = 1; pattern <= 0x80; pattern <<= 1) {
        /* Work in column 0 */
        err = SetColAddr(handle, LCD_CHIP_BOTH, 0);
        CHECK_SUCCESS(err)

        /* Build the command word.  Select both chips for a write data cycle
         * and use the patern from the loop.
         */
        cmdWord = (LCD_CHIP_BOTH | LCD_WRITE_DATA | pattern);

        /* Write the command word */
        err = Write(handle, cmdWord);
        CHECK_SUCCESS(err)

        /* Set column back to 0 so we can read what we just wrote */
        err = SetColAddr(handle, LCD_CHIP_BOTH, 0);
        CHECK_SUCCESS(err)

        /* Dummy reads needed before valid data is returned */
        err = ReadByte(handle, LCD_CHIP_ONE, 0, &readVal);
        CHECK_SUCCESS(err)
        err = ReadByte(handle, LCD_CHIP_TWO, 0, &readVal);
        CHECK_SUCCESS(err)

        /* Read from chip 1 */
        err = ReadByte(handle, LCD_CHIP_ONE, 0, &readVal);
        CHECK_SUCCESS(err)

        if (readVal != pattern) {
            return (TSYNC_COMM_ERR);
        }

        /* Read from chip 2 */
        err = ReadByte(handle, LCD_CHIP_TWO, 0, &readVal);
        CHECK_SUCCESS(err)

        if (readVal != pattern) {
            return (TSYNC_COMM_ERR);
        }
    }

    /* Set the column to 0 again because we will erase the byte we changed */
    err = SetColAddr(handle, LCD_CHIP_BOTH, 0);
    CHECK_SUCCESS(err)

    /* Build command word and write 0 to both chips */
    cmdWord = (LCD_CHIP_BOTH | LCD_WRITE_DATA | 0);

    err = Write(handle, cmdWord);

    return (err);

} /* End LineTest */


static inline TSYNC_ERROR TransferPage(TSYNC_BoardHandle handle,
                                uint32_t page,
                                LCD_IMAGE *img,
                                LCD_DRAW_MODE mode) {

    TSYNC_ERROR err;
    uint32_t    ovlTop;       /* Top of overlap region of image and page */
    uint32_t    ovlBottom;    /* Bottom of overlap region of image and page */
    uint32_t    ovlTopImg;    /* OverTop in image coordinates */
    uint32_t    row;          /* Current row in page coordinates */
    uint32_t    rowImg;       /* Current row in image coordinates */
    uint32_t    keepBits = 0; /* Mask off bits in overlap region */
    uint32_t    rolloverCol;  /* Which column (in image), write to chip 2 */
    uint32_t    imgCol;       /* Current column in the image (x coordinate) */
    uint32_t    ramVal = 0;   /* What we read from the display RAM */
    uint32_t    outVal;       /* Data we will write out to the display */
    uint32_t    imgWidth;     /* Width of the image */
    LCD_CHIP    chip;         /* The chip we are currently using */
    uint8_t     rmwMode = 0;  /* 1 if in Read-Modify-Write mode, 0 otherwise */
    uint8_t    *dots;         /* De-ref this from image outside the loop */

    /* Calculate region of vertical overlap between this page and image.
     * This function returns 0 if there is no work to be done on this page
     */
    err = VertCalc(page, img, &ovlTop, &ovlBottom, &ovlTopImg);
    CHECK_SUCCESS(err)

    /* Calculate the chip we'll write to first, calculate when we should start
     * using the next chip, and set the column number in the first chip we use.
     */
    err = HorizCalc(handle, img, &chip, &rolloverCol);
    CHECK_SUCCESS(err)

    /* Construct a mask that has ones in the bit positions that correspond to
     * the rows of the current page that are outside of the vertical overlap
     */
    for (row = 0; row < LCD_PAGE_HEIGHT; row++) {
        /* Outside of overlap if above the top or below the bottom */
        if ((row < ovlTop) || (row > ovlBottom)) {
            keepBits |= 1 << row;
        }
    }

    /* Set the page address to the current page */
    err = SetPageAddr(handle, page);
    CHECK_SUCCESS(err)

    /* Decide whether or not we need to read the device's RAM for this page.
     * Conditions to use Read-Modify-Write:
     *      -The image doesn't cover the whole page vertically
     *      -Any draw mode other than override is being used
     */
    if ((ovlTop != 0) || (ovlBottom != (LCD_PAGE_HEIGHT - 1)) ||
        (mode != LCD_DRAW_MODE_OVER)) {
        rmwMode = 1;
        err = SetRmw(handle, 1);
        CHECK_SUCCESS(err)
    }

    /* De-reference some fields from the image before we enter the loop to
     * hopefully make the loop faster
     */
    imgWidth = img->colSize;
    dots = (uint8_t*)img->dots;

    /* Loop for each column in the image */
    for (imgCol = 0; imgCol < imgWidth; imgCol++ ) {
        /* If rollover, select chip 2 */
        if (imgCol == rolloverCol) {
            chip = LCD_CHIP_TWO;
        }

        /* If in RMW, we must read the value to start from.
         * This requires a dummy read first.
         */
        if (rmwMode) {
            err = ReadByte(handle, chip, 0, &ramVal);
            CHECK_SUCCESS(err)
            err = ReadByte(handle, chip, 0, &ramVal);
            CHECK_SUCCESS(err)
        }

        /* Reset vertical offset into image and byte that we build */
        rowImg = ovlTopImg;
        outVal = 0;

        /* Done only for write operations */
        if (mode != LCD_DRAW_MODE_READ) {
            /* Collect the bits we need and build them into a byte.  In this
              * loop, row and rowImg correspond to the same bit.
              */
            for (row = ovlTop; row <= ovlBottom; row++) {
                /* This takes the dots from the image vertically one by one and
                 * ORs them into a bit.  The commented line shows a little more
                 * clearly what this intends to do.
                 */
                outVal |= (*(dots + (rowImg++ * imgWidth) + imgCol) << row);
            }

            /* Combine the starting value with the byte we just constructed
             * using the specified mode.
             */
            switch (mode) {
                case LCD_DRAW_MODE_OR:  outVal |= ramVal; break;
                case LCD_DRAW_MODE_AND: outVal &= ramVal; break;
                case LCD_DRAW_MODE_XOR: outVal ^= ramVal; break;
                default:                                  break;
            }

            outVal &= ~keepBits;            /* Only keep overlap area */
            outVal |= (ramVal & keepBits);  /* Save previous bits */
        }
            /* Done for read operations only */
        else {
            /* Take apart the read byte and set the bits in the image.  In this
             * loop, row and rowImage correspond to the same bit.
             */
            for (row = ovlTop; row <= ovlBottom; row++) {
                *(dots + (rowImg++ * imgWidth) + imgCol) =
                    (ramVal >> row) & 0x01;
            }

            /* Just write this back */
            outVal = ramVal;
        }

        /* Send this out to the display
         * Send it to the current chip and indicate a write data cycle
         */
        outVal |= (chip | LCD_WRITE_DATA);

        err = Write(handle, outVal);
        CHECK_SUCCESS(err)
    }

    /* The page write operation is complete, make sure RMW mode is off */
    err = SetRmw(handle, 0);

    return (err);

} /* End TransferPage */


/******************************************************************************/
/* API Functions **************************************************************/
/******************************************************************************/

TSYNC_ERROR TSYNC_HW_getLcdSize(TSYNC_BoardHandle handle,
                                unsigned int* col,
                                unsigned int* row) {

    CHECK_NOT_NULL(col);
    CHECK_NOT_NULL(row);

    *col = (LCD_NUM_PAGES_H * LCD_PAGE_WIDTH);
    *row = (LCD_NUM_PAGES_V * LCD_PAGE_HEIGHT);

    return (TSYNC_SUCCESS);
}


TSYNC_ERROR TSYNC_HW_fillLcd(TSYNC_BoardHandle handle,
                             unsigned int pattern) {

    return (Fill(handle, pattern));

} /* End TSYNC_HW_fillLcd */


TSYNC_ERROR TSYNC_HW_setLcdActive(TSYNC_BoardHandle handle,
                                  unsigned int enable) {

    return (EnableDisable(handle, enable));

} /* End TSYNC_HW_setLcdActive */


TSYNC_ERROR TSYNC_HW_setLcdStartLine(TSYNC_BoardHandle handle,
                                     unsigned int line) {

    TSYNC_ERROR err     = TSYNC_SUCCESS;
    uint32_t    cmdWord = 0;

    /* Build the command word.  Select both chips for a write command cycle and
     * the command is set start line.
     */
    cmdWord = (LCD_CHIP_BOTH | LCD_WRITE_CMD | LCD_CMD_START);

    /* Insert start line address into lower 5 bits of command word */
    cmdWord |= (line % (LCD_NUM_PAGES_V * LCD_PAGE_HEIGHT));

    err = Write(handle, cmdWord);

    return (err);

} /* End TSYNC_HW_setLcdStartLine */


TSYNC_ERROR TSYNC_HW_setLcdAdc(TSYNC_BoardHandle handle,
                               unsigned int reverse) {

    TSYNC_ERROR err     = TSYNC_SUCCESS;
    uint32_t    cmdWord = 0;

    /* Build the command word.  Select both chips for a write command cycle and
     * the command is set ADC.
     */
    cmdWord = (LCD_CHIP_BOTH | LCD_WRITE_CMD | LCD_CMD_ADC);

    /* The command word will currently set ADC forward (bit 0 is a 0).  If
     * we are to set it to reverse, set bit 0 to a 1.
     */
    if (reverse) {
        cmdWord |= 1;
    }

    err = Write(handle, cmdWord);

    return (err);

} /* End TSYNC_HW_setLcdAdc */


TSYNC_ERROR TSYNC_HW_setLcdStaticDrv(TSYNC_BoardHandle handle,
                                     unsigned int on) {

    TSYNC_ERROR err     = TSYNC_SUCCESS;
    uint32_t    cmdWord = 0;

    /* Build the command word.  Select both chips for a write command cycle and
     * the command is set static drive on/off.
     */
    cmdWord = (LCD_CHIP_BOTH | LCD_WRITE_CMD | LCD_CMD_STATIC);

    /* The command word will currently set static drive off (bit 0 is a 0). If
     * we are to turn it on, set bit 0 to a 1.
     */
    if (on) {
        cmdWord |= 1;
    }

    err = Write(handle, cmdWord);

    return (err);

} /* End TSYNC_HW_setLcdStaticDrv */


TSYNC_ERROR TSYNC_HW_setLcdDuty(TSYNC_BoardHandle handle,
                                unsigned int by32) {

    TSYNC_ERROR err     = TSYNC_SUCCESS;
    uint32_t    cmdWord = 0;

    /* Build the command word.  Select both chips for a write command cycle and
     * the command is set duty cycle
     */
    cmdWord = (LCD_CHIP_BOTH | LCD_WRITE_CMD | LCD_CMD_DUTY);

    /* The command word will currently set 1/16 duty (bit 0 is a 0).  If
     * we are to set it to 1/32, set bit 0 to a 1.
     */
    if (by32) {
        cmdWord |= 1;
    }

    err = Write(handle, cmdWord);

    return (err);

} /* End TSYNC_HW_setLcdDuty */


TSYNC_ERROR TSYNC_HW_resetLcd(TSYNC_BoardHandle handle) {

    TSYNC_ERROR err     = TSYNC_SUCCESS;
    uint32_t    cmdWord = 0;

    /* Build the command word.  Select both chips for a write command cycle and
    ** the command is software reset.
    */
    cmdWord = (LCD_CHIP_BOTH | LCD_WRITE_CMD | LCD_CMD_RESET);

    err = Write(handle, cmdWord);

    return (err);

} /* End TSYNC_HW_resetLcd */


TSYNC_ERROR TSYNC_HW_setLcdRmw(TSYNC_BoardHandle handle,
                               unsigned int on) {

    return (SetRmw(handle, on));

} /* End TSYNC_HW_setLcdRmw */


TSYNC_ERROR TSYNC_HW_initLcd(TSYNC_BoardHandle handle) {

    TSYNC_ERROR err;

    /* Activate the display */
    err = EnableDisable(handle, 1);
    CHECK_SUCCESS(err)

    err = LineTest(handle);

    /* If the display passed the line test */
    if (err == TSYNC_SUCCESS)
    {
        /* Clear the display */
        err = Fill(handle, 0);
    }

    return (err);

} /* End TSYNC_HW_initLcd */


TSYNC_ERROR TSYNC_HW_readLcd(TSYNC_BoardHandle handle,
                             LCD_IMAGE *img) {

    TSYNC_ERROR err;
    uint32_t    currPage;
    int32_t     size;

    CHECK_NOT_NULL(img);

    /* Check the image bounds */
    size = BoundsCheck(img);

    if (size < 0) {
        return (TSYNC_BUFFER_OVERRUN);
    }

    /* Read it one page at a time */
    for (currPage = 0; currPage < LCD_NUM_PAGES_V; currPage++) {
        err = TransferPage(handle, currPage, img, LCD_DRAW_MODE_READ);
        CHECK_SUCCESS(err)
    }

    return (TSYNC_SUCCESS);

} /* End TSYNC_HW_readLcd */


TSYNC_ERROR TSYNC_HW_writeLcd(TSYNC_BoardHandle handle,
                              LCD_IMAGE *img) {

    uint32_t currPage;

    CHECK_NOT_NULL(img);

    /* Check the image bounds */
    if (BoundsCheck(img) < 0) {
        return (TSYNC_BUFFER_OVERRUN);
    }

    /* Read it one page at a time */
    for (currPage = 0; currPage < LCD_NUM_PAGES_V; currPage++) {
        (void)TransferPage(handle, currPage, img, img->mode);
    }

    return (TSYNC_SUCCESS);

} /* End TSYNC_HW_writeLcd */


TSYNC_ERROR TSYNC_HW_getKeypad(TSYNC_BoardHandle handle,
                               unsigned int* keys) {

    /* Create the objects the accessor call will reference */
    TSYNC_ERROR err;
    ITEM_ID     iid;
    uint32_t    actualOutLength;
    uint16_t    outPayload;


    iid.hnkid = HW_NONKTS_KEYPAD;

    CHECK_NOT_NULL(keys);


    /* Call the generic accessor */
    err = TSYNC_get(handle,
                    DEST_ID_HW_NONKTS,
                    iid,
                    NULL,
                    0,
                    (void*)&outPayload,
                    sizeof(outPayload),
                    &actualOutLength);

    // return the error if not success
    CHECK_SUCCESS(err);

    // fill in the output object
    *keys = outPayload;

    return (TSYNC_SUCCESS);

} /* End TSYNC_HW_getKeypad */


TSYNC_ERROR TSYNC_HW_getPowerStatus(TSYNC_BoardHandle handle,
                                    unsigned int* status) {

    /* Create the objects the accessor call will reference */
    TSYNC_ERROR err;
    ITEM_ID     iid;
    uint32_t    actualOutLength;
    uint16_t    outPayload;


    iid.hnkid = HW_NONKTS_POWER;

    CHECK_NOT_NULL(status);


    /* Call the generic accessor */
    err = TSYNC_get(handle,
                    DEST_ID_HW_NONKTS,
                    iid,
                    NULL,
                    0,
                    (void*)&outPayload,
                    sizeof(outPayload),
                    &actualOutLength);

    // return the error if not success
    CHECK_SUCCESS(err);

    // fill in the output object
    *status = outPayload;

    return (TSYNC_SUCCESS);

}/* End TSYNC_HW_getKeypad */


TSYNC_ERROR TSYNC_HW_getFanEnable(TSYNC_BoardHandle handle,
                                  int* bEnable){

    CHECK_NOT_NULL(bEnable);

    //create the objects the accessor call will reference
    ITEM_ID iid;
    TSYNCD_Boolean outPayload;
    uint32_t actualOutLength;

    //set some values
    iid.hid = HW_FAN_EN;

    //call the generic accessor
    TSYNC_ERROR err = TSYNC_get(handle,
                                DEST_ID_HW_NONKTS,
                                iid,
                                NULL,
                                0,
                                (void*) &outPayload,
                                sizeof(outPayload),
                                &actualOutLength);

    //return the error if not success
    CHECK_SUCCESS(err)

    //fill in the output object
    *bEnable = ((outPayload & 0x1) == TDB_TRUE) ? 1 : 0;

    return ( TSYNC_SUCCESS );
}


TSYNC_ERROR TSYNC_HW_setFanEnable(TSYNC_BoardHandle handle,
                                  int bEnable){

    //create the objects the accessor call will reference
    ITEM_ID iid;
    TSYNCD_Boolean inPayload;
    uint32_t actualOutLength;

    //set some values
    iid.hid = HW_FAN_EN;
    inPayload = (bEnable == 1) ? TDB_TRUE : TDB_FALSE;

    //call the generic accessor
    TSYNC_ERROR err = TSYNC_set(handle,
                                DEST_ID_HW_NONKTS,
                                iid,
                                (void*) &inPayload,
                                sizeof(inPayload),
                                NULL,
                                0,
                                &actualOutLength);

    return ( err );
}
#endif // defined(LAFAYETTE)
