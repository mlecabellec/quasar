
#ifndef _defined_TSYNC_HS_SERVICES_H
#define _defined_TSYNC_HS_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_hs_services.h
**
**  Date:       04/15/2020
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2020 Orolia All rights reserved.
**
***************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_HS                      0x4A
#define TSYNC_ID_HS_CA_NUM_INST          0x00
#define TSYNC_ID_HS_CA_VERSION           0x01
#define TSYNC_ID_HS_CA_STATUS            0x02
#define TSYNC_ID_HS_CA_CTL               0x03

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define HS_VALUE_FIELDS                           \
    TSYNC_X(        uint32_t,           value)

#define HS_LCL_STATUS_FIELDS                      \
    TSYNC_X(        uint32_t,           fan_en)   \
    TSYNC_X(        uint32_t,           fan_pwm)  \
    TSYNC_X(        uint32_t,           fan_speed)\
    TSYNC_X(           float,           temp)     \
    TSYNC_X(           float,           voltage)  \
    TSYNC_X(           float,           current)

#define HS_LCL_CTL_FIELDS                         \
    TSYNC_X(        uint32_t,           fan_en)   \
    TSYNC_X(        uint32_t,           fan_pwm)

#define HS_STATUS_FIELDS                          \
    TSYNC_X(         uint32_t,         statusReg) \
    TSYNC_X_STRUCT(  HS_LCL_STATUS,    sled1)     \
    TSYNC_X_STRUCT(  HS_LCL_STATUS,    sled2)

#define HS_CTL_SET_FIELDS                         \
    TSYNC_X_STRUCT(  HS_LCL_CTL,       sled1)     \
    TSYNC_X_STRUCT(  HS_LCL_CTL,       sled2)


#include "tsync_struct_define.h"

GEN_STRUCT(HS_VALUE)
GEN_STRUCT(HS_LCL_STATUS)
GEN_STRUCT(HS_LCL_CTL)
GEN_STRUCT(HS_STATUS)
GEN_STRUCT(HS_CTL_SET)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_HS_SERVICES_H */
