#if defined(__GNUC__) || defined(__SUNPRO_C) || defined(lint)
#   undef PACKED
#elif defined(_MSC_VER)
#   undef PACKED
#   pragma pack(pop)
#else
#   error Structures must be packed. Do it yourself depending on your compiler.
#endif

#undef GEN_STRUCT
#undef TSYNC_X_ARRAY
#undef TSYNC_X_BUFFER
#undef TSYNC_X_STRUCT
#undef TSYNC_X
