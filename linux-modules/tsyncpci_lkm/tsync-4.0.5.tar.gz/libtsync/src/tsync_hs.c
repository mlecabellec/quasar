#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_hs_services.h"

extern uint8_t HS_VALUE_RECIPE[];
extern uint8_t HS_STATUS_RECIPE[];
extern uint8_t HS_CTL_SET_RECIPE[];



TSYNC_ERROR
TSYNC_HS_getNumInst(
    TSYNC_BoardHandle hnd,
    unsigned int *nInstances)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nInstances);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(HS_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_HS,
            TSYNC_ID_HS_CA_NUM_INST,
            ctl,
            pyldLen,
            NULL,
            NULL,
            HS_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct HS_VALUE* outPayload =
            (HS_VALUE*)GetPayload(result);

        *nInstances = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_HS_getVersion(
    TSYNC_BoardHandle hnd,
    unsigned int *version)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(version);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(HS_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_HS,
            TSYNC_ID_HS_CA_VERSION,
            ctl,
            pyldLen,
            NULL,
            NULL,
            HS_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct HS_VALUE* outPayload =
            (HS_VALUE*)GetPayload(result);

        *version = outPayload->value;

    return ( err );
}


TSYNC_ERROR
TSYNC_HS_getStatus(
    TSYNC_BoardHandle hnd,
    TSYNC_HsStatusObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(HS_STATUS_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_HS,
            TSYNC_ID_HS_CA_STATUS,
            ctl,
            pyldLen,
            NULL,
            NULL,
            HS_STATUS_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct HS_STATUS* outPayload =
            (HS_STATUS*)GetPayload(result);

        pObj->statusReg       = outPayload->statusReg;
        pObj->sled1.fan_en    = outPayload->sled1.fan_en;
        pObj->sled1.fan_pwm   = outPayload->sled1.fan_pwm;
        pObj->sled1.fan_speed = outPayload->sled1.fan_speed;
        pObj->sled1.temp      = outPayload->sled1.temp;
        pObj->sled1.voltage   = outPayload->sled1.voltage;
        pObj->sled1.current   = outPayload->sled1.current;
        pObj->sled2.fan_en    = outPayload->sled2.fan_en;
        pObj->sled2.fan_pwm   = outPayload->sled2.fan_pwm;
        pObj->sled2.fan_speed = outPayload->sled2.fan_speed;
        pObj->sled2.temp      = outPayload->sled2.temp;
        pObj->sled2.voltage   = outPayload->sled2.voltage;
        pObj->sled2.current   = outPayload->sled2.current;

    return ( err );
}


TSYNC_ERROR
TSYNC_HS_setCtl(
    TSYNC_BoardHandle hnd,
    TSYNC_HsCtlObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct HS_CTL_SET inPayload;
        inPayload.sled1.fan_en  = pObj->sled1.fan_en;
        inPayload.sled1.fan_pwm = pObj->sled1.fan_pwm;
        inPayload.sled2.fan_en  = pObj->sled2.fan_en;
        inPayload.sled2.fan_pwm = pObj->sled2.fan_pwm;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(HS_CTL_SET_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_HS,
            TSYNC_ID_HS_CA_CTL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            HS_CTL_SET_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}
