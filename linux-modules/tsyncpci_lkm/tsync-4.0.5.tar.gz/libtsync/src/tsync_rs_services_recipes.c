
/***************************************************************************
**  Module:     tsync_rs_services_recipes.c
**
**  Date:       07/25/08
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/25/2008 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_rs_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(RS_TABLE_TYPE_OBJ)
RECIPE(RS_TABLE_ENTRY)
RECIPE(RS_REF_TABLE)
RECIPE(RS_TABLE_INDEX_OBJ)
RECIPE(RS_TABLE_INDEX_VALUE)
RECIPE(RS_TABLE_VALUE)
RECIPE(RS_REF_STATE_ENTRY)
RECIPE(RS_STATE_TABLE)
RECIPE(RS_REF_PHASE_INDEX_OBJ)
RECIPE(RS_REF_PHASE_DATA)
RECIPE(RS_REF_PHASE_INDEX_THRESHOLD)
RECIPE(RS_REF_PHASE_THRESHOLD)

#include "tsync_recipe_undef.h"
