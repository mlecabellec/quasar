
#ifndef _defined_TSYNC_STR_SERVICES_H
#define _defined_TSYNC_STR_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_str_services.h
**
**  Date:       09/08/09
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2009 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              09/08/2009 Creation
**
****************************************************************************/

#include "tsync.h"
#include "tsync_cs_services.h"

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_STR                     0x49
#define TSYNC_ID_STR_CA_VALIDITY         0x01
#define TSYNC_ID_STR_CA_REF_ID           0x02
#define TSYNC_ID_STR_CA_NUM_INST         0x03
#define TSYNC_ID_STR_CA_VERSION          0x04
#define TSYNC_ID_STR_CA_SUBSCRIPTION     0x05
#define TSYNC_ID_STR_CA_ACT_FEAT         0x06
#define TSYNC_ID_STR_CA_CONF             0x07
#define TSYNC_ID_STR_CA_IP_ADDR          0x08
#define TSYNC_ID_STR_CA_STAT             0x09
#define TSYNC_ID_STR_CA_SUBK             0x0a

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define STR_VALUE_FIELDS                        \
    TSYNC_X(        uint32_t,           value)

#define STR_VALUE_SET_CMD_FIELDS                \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X(        uint32_t,           value)

#define STR_VERSION_FIELDS                      \
    TSYNC_X_BUFFER(int8_t,  application,  16)   \
    TSYNC_X_BUFFER(int8_t,  system,       16)   \
    TSYNC_X_BUFFER(int8_t,  serialnb,     16)

#define STR_BUFFER_FIELDS                       \
    TSYNC_X_BUFFER(int8_t,  buffer,  16)

#define STR_CONF_FIELDS                         \
    TSYNC_X_BUFFER(int8_t,   serialnb,     16)  \
    TSYNC_X( double,         lat)               \
    TSYNC_X( double,         lon)               \
    TSYNC_X( double,         alt)               \
    TSYNC_X( double,         ee_axis)           \
    TSYNC_X( double,         nn_axis)           \
    TSYNC_X( double,         uu_axis)           \
    TSYNC_X( uint32_t,       geoMode)           \
    TSYNC_X( uint32_t,       sensLevel)

#define STR_CONF_SET_CMD_FIELDS                 \
    TSYNC_X( uint32_t,       nInstance)         \
    TSYNC_X_BUFFER(int8_t,   serialnb,     16)  \
    TSYNC_X( double,         lat)               \
    TSYNC_X( double,         lon)               \
    TSYNC_X( double,         alt)               \
    TSYNC_X( double,         ee_axis)           \
    TSYNC_X( double,         nn_axis)           \
    TSYNC_X( double,         uu_axis)           \
    TSYNC_X( uint32_t,       geoMode)           \
    TSYNC_X( uint32_t,       sensLevel)

#define STR_STAT_VALUE_FIELDS                   \
    TSYNC_X(        uint32_t, rcvBurst)         \
    TSYNC_X(        uint32_t, rcvStrongBurst)

#define STR_SUB_FIELDS                       \
    TSYNC_X_BUFFER(int8_t,  beginSub,  16)   \
    TSYNC_X_BUFFER(int8_t,  endSub,  16)     \
    TSYNC_X(       uint32_t, state)          \
    TSYNC_X(       uint32_t, unused)

#define STR_SUBK_FIELDS                         \
    TSYNC_X_BUFFER(int8_t,   key,          32)

#define STR_SUBK_SET_CMD_FIELDS                 \
    TSYNC_X( uint32_t,       nInstance)         \
    TSYNC_X_BUFFER(int8_t,   key,          32)

#include "tsync_struct_define.h"

GEN_STRUCT(STR_VALUE)
GEN_STRUCT(STR_VERSION)
GEN_STRUCT(STR_VALUE_SET_CMD)
GEN_STRUCT(STR_BUFFER)
GEN_STRUCT(STR_CONF)
GEN_STRUCT(STR_CONF_SET_CMD)
GEN_STRUCT(STR_STAT_VALUE)
GEN_STRUCT(STR_SUB)
GEN_STRUCT(STR_SUBK)
GEN_STRUCT(STR_SUBK_SET_CMD)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_STR_SERVICES_H */
