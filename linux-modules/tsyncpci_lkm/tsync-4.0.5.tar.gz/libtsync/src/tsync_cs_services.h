
#ifndef _defined_TSYNC_CS_SERVICES_H
#define _defined_TSYNC_CS_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_cs_services.h
**
**  Date:       07/10/08
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/10/2008 Creation
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_CS                         0x23
#define TSYNC_ID_CS_CA_TIME_SCALE           0x01
#define TSYNC_ID_CS_CA_TIME_SCALE_OFF       0x02
#define TSYNC_ID_CS_CA_TIME_SUBSEC_ADJ      0x03
#define TSYNC_ID_CS_CA_TIME                 0x05
#define TSYNC_ID_CS_CA_TIME_DISCONT         0x06
#define TSYNC_ID_CS_CA_LEAP_SEC             0x07
#define TSYNC_ID_CS_CA_TIME_ZONE_OFF        0x08
#define TSYNC_ID_CS_CA_DST_RULE             0x0A
#define TSYNC_ID_CS_CA_YEAR                 0x0B
#define TSYNC_ID_CS_CA_DST_STATE            0x0C
#define TSYNC_ID_CS_CA_NEXT_SEC             0x0D


/******************************************************
**     Define Enumerations
******************************************************/



/******************************************************
**     Define Structures
******************************************************/


#define ML_DST_POINT_FIELDS                    \
    TSYNC_X( ML_MONTH,     month)                \
    TSYNC_X( ML_WOM,    wom)                \
    TSYNC_X( ML_DOW,    dow)                \
    TSYNC_X( uint32_t,    hour)

#define ML_DST_RULE_FIELDS                    \
    TSYNC_X( ML_DST_REF,     ref)                \
    TSYNC_X_STRUCT( ML_DST_POINT,    in)                \
    TSYNC_X_STRUCT( ML_DST_POINT,    out)                \
    TSYNC_X( uint32_t,    offset)

#define ML_CLK_LOCAL_FIELDS                    \
    TSYNC_X( ML_DST_REF,     ref)                \
    TSYNC_X_STRUCT( ML_DST_POINT,    in)                \
    TSYNC_X_STRUCT( ML_DST_POINT,    out)                \
    TSYNC_X( uint32_t,    offset)                        \
    TSYNC_X( int32_t,        tz)

#define ML_TIME_GET_FIELDS                    \
    TSYNC_X( ML_TIME_TYPE,     type)

#define ML_SECTIME_FIELDS                    \
    TSYNC_X( uint32_t,    seconds)            \
    TSYNC_X( uint32_t,    ns)

#define ML_DOYTIME_FIELDS                    \
    TSYNC_X( uint32_t,     year)                \
    TSYNC_X( uint32_t,    doy)                \
    TSYNC_X( uint32_t,     hour)                \
    TSYNC_X( uint32_t,    minute)                \
    TSYNC_X( uint32_t,    second)                \
    TSYNC_X( uint32_t,    ns)

#define ML_BCDTIME_FIELDS                    \
    TSYNC_X( uint32_t,     year)                \
    TSYNC_X( uint32_t,    doy)                \
    TSYNC_X( uint32_t,     hour)                \
    TSYNC_X( uint32_t,    minute)                \
    TSYNC_X( uint32_t,    second)                \
    TSYNC_X( uint32_t,    ms)                    \
    TSYNC_X( uint32_t,    us)

#define CS_TIME_DISCONT_FIELDS                    \
    TSYNC_X_STRUCT( ML_DOYTIME,     newDt)                \
    TSYNC_X_STRUCT( ML_DOYTIME,     effDt)                \
    TSYNC_X( uint32_t,        bActive)

#define ML_DOYTIME_GET_RESP_FIELDS                    \
    TSYNC_X( ML_TIME_TYPE,     type)            \
    TSYNC_X_STRUCT( ML_DOYTIME,     time)

#define ML_BCDTIME_GET_RESP_FIELDS                    \
    TSYNC_X( ML_TIME_TYPE,     type)            \
    TSYNC_X_STRUCT( ML_BCDTIME,     time)

#define ML_SECTIME_GET_RESP_FIELDS                    \
    TSYNC_X( ML_TIME_TYPE,     type)            \
    TSYNC_X_STRUCT( ML_SECTIME,     time)

#define ML_NEXTSEC_GET_RESP_FIELDS                    \
    TSYNC_X_STRUCT( ML_DOYTIME,     time)

#define ML_SECTIME_SET_CMD_FIELDS                    \
    TSYNC_X( ML_TIME_TYPE,     typeHack)        \
    TSYNC_X( ML_TIME_TYPE,     type)            \
    TSYNC_X_STRUCT( ML_SECTIME,     time)

#define ML_DOYTIME_SET_CMD_FIELDS                    \
    TSYNC_X( ML_TIME_TYPE,     typeHack)        \
    TSYNC_X( ML_TIME_TYPE,     type)            \
    TSYNC_X_STRUCT( ML_DOYTIME,     time)

#define ML_BCDTIME_SET_CMD_FIELDS                    \
    TSYNC_X( ML_TIME_TYPE,     typeHack)        \
    TSYNC_X( ML_TIME_TYPE,     type)            \
    TSYNC_X_STRUCT( ML_BCDTIME,     time)

#define ML_LEAP_SEC_FIELDS                    \
    TSYNC_X( int32_t,    offset)                \
    TSYNC_X_STRUCT( ML_DOYTIME,    utcDate)

#define ML_TIME_SCALE_OBJ_FIELDS                    \
    TSYNC_X( ML_TIME_SCALE,     scale)

#define ML_TIME_SCALE_OFFSET_GET_CMD_FIELDS                    \
    TSYNC_X( ML_TIME_SCALE,     scale)

#define ML_TIME_SCALE_OFFSET_GET_RESP_FIELDS                    \
    TSYNC_X( int32_t,          tsOffset)

#define ML_TIME_SCALE_OFFSET_SET_CMD_FIELDS                    \
    TSYNC_X( ML_TIME_SCALE,     scale)              \
    TSYNC_X( int32_t,          tsOffset)

#define ML_SUBSEC_ADJUST_FIELDS                    \
    TSYNC_X( int32_t,          ssAdjust)

#define ML_TIMEZONE_OFFSET_FIELDS                    \
    TSYNC_X( int32_t,          tzOffset)

#define ML_YEAR_FIELDS                    \
    TSYNC_X( int32_t,          year)

#define CS_DST_STATE_FIELDS                    \
    TSYNC_X( uint32_t,        bState)

#include "tsync_struct_define.h"

GEN_STRUCT(ML_DST_POINT)
GEN_STRUCT(ML_DST_RULE)
GEN_STRUCT(ML_CLK_LOCAL)
GEN_STRUCT(ML_TIME_GET)
GEN_STRUCT(ML_DOYTIME)
GEN_STRUCT(ML_BCDTIME)
GEN_STRUCT(ML_SECTIME)
GEN_STRUCT(ML_SECTIME_GET_RESP)
GEN_STRUCT(ML_DOYTIME_GET_RESP)
GEN_STRUCT(ML_BCDTIME_GET_RESP)
GEN_STRUCT(ML_NEXTSEC_GET_RESP)
GEN_STRUCT(ML_SECTIME_SET_CMD)
GEN_STRUCT(ML_DOYTIME_SET_CMD)
GEN_STRUCT(ML_BCDTIME_SET_CMD)
GEN_STRUCT(ML_LEAP_SEC)
GEN_STRUCT(ML_TIME_SCALE_OBJ)
GEN_STRUCT(ML_TIME_SCALE_OFFSET_GET_CMD)
GEN_STRUCT(ML_TIME_SCALE_OFFSET_GET_RESP)
GEN_STRUCT(ML_TIME_SCALE_OFFSET_SET_CMD)
GEN_STRUCT(ML_SUBSEC_ADJUST)
GEN_STRUCT(CS_TIME_DISCONT)
GEN_STRUCT(ML_TIMEZONE_OFFSET)
GEN_STRUCT(ML_YEAR)
GEN_STRUCT(CS_DST_STATE)

#include "tsync_struct_undef.h"


typedef union
{
ML_SECTIME st;
ML_DOYTIME dt;
ML_BCDTIME bt;
} ML_TIME;

typedef union
{
ML_SECTIME_GET_RESP st;
ML_DOYTIME_GET_RESP dt;
ML_BCDTIME_GET_RESP bt;
} ML_TIME_UNION_GET_RESP;

typedef union
{
ML_SECTIME_SET_CMD st;
ML_DOYTIME_SET_CMD dt;
ML_BCDTIME_SET_CMD bt;
} ML_TIME_UNION_SET_CMD;

#endif  /* _defined_TSYNC_CS_SERVICES_H */
