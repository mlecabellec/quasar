
/***************************************************************************
**  Module:     tsync_dcs_services_recipes.c
**
**  Date:       09/11/09
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2009 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              09/11/2009 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_dcs_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(DCS_VALUE)
RECIPE(DCS_INT_VALUE)
RECIPE(DCS_OC_CISH)
RECIPE(DCS_OC_HDR)
RECIPE(DCS_OC_SFI)
RECIPE(DCS_OC_LFI)
RECIPE(DCS_OC_FI)
RECIPE(DCS_FILE_OPTION)

#include "tsync_recipe_undef.h"
