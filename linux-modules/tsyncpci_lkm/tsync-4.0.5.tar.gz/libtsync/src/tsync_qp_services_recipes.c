
/***************************************************************************
**  Module:     tsync_qp_services_recipes.c
**
**  Date:       09/09/09
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2009 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              09/09/2009 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_qp_services.h"
#include "tsync_cs_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(QP_VALUE)
RECIPE(QP_SET_CMD)
RECIPE(QP_INT_VALUE)
RECIPE(QP_INT_SET_CMD)
RECIPE(QP_LOCAL_SET_CMD)
RECIPE(QP_TIME_SCALE_SET_CMD)

#include "tsync_recipe_undef.h"
