
#define TSYNC_X(fieldType, fieldName) sizeof(fieldType),
#define TSYNC_X_BUFFER(fieldType, fieldName, fieldLength)    \
    TSYNC_RECIPE_BUFFER,                                    \
    ((sizeof(fieldType)*fieldLength) & 0xff00) >> 8,        \
    ((sizeof(fieldType)*fieldLength) & 0x00ff) >> 0,
#define TSYNC_X_ARRAY(fieldType, fieldName, fieldLength)    \
    TSYNC_RECIPE_ARRAY,                                     \
    fieldLength,                                           \
    fieldType##_FIELDS                                     \
    TSYNC_END_OF_RECIPE,
#define TSYNC_X_STRUCT(fieldType, fieldName) TSYNC_X_ARRAY(fieldType, fieldName,1)
#define RECIPE(recipeSource)            \
uint8_t recipeSource##_RECIPE[] = {     \
       recipeSource##_FIELDS            \
    TSYNC_END_OF_RECIPE                 \
};
