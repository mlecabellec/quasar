
#ifndef _defined_TSYNC_MISC_SERVICES_RECIPES_H
#define _defined_TSYNC_MISC_SERVICES_RECIPES_H 1

/***************************************************************************
**  Module:     tsync_misc_services_recipes.h
**
**  Date:       07/28/08
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/28/2008 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_misc_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(EL_VALIDITY)
RECIPE(EL_REF_ID)

#include "tsync_recipe_undef.h"

#endif  /* _defined_TSYNC_MISC_SERVICES_RECIPES_H */
