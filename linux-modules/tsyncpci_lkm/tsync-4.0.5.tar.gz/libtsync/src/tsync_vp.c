#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_vp_services.h"
#include "tsync_cs_services.h"

extern uint8_t VP_VALUE_RECIPE[];
extern uint8_t VP_FLOAT_RECIPE[];
extern uint8_t VP_DOUBLE_RECIPE[];
extern uint8_t VP_SET_CMD_RECIPE[];
extern uint8_t VP_SET_FLOAT_RECIPE[];
extern uint8_t VP_SET_DOUBLE_RECIPE[];
extern uint8_t VP_CFG_OBJ_RECIPE[];

TSYNC_ERROR
TSYNC_VP_getSigCtrl(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    SIG_CTL *sig)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(sig);

        struct VP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(VP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(VP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_VP,
            TSYNC_ID_VP_CA_SIG_CTL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            VP_VALUE_RECIPE,
            VP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct VP_VALUE* outPayload =
            (VP_VALUE*)GetPayload(result);

        *sig = (SIG_CTL)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_VP_setSigCtrl(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    SIG_CTL sig)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct VP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = sig;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(VP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_VP,
            TSYNC_ID_VP_CA_SIG_CTL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            VP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_VP_getFreq(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    double *freq)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(freq);

        struct VP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(VP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(VP_DOUBLE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_VP,
            TSYNC_ID_VP_CA_FREQ,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            VP_VALUE_RECIPE,
            VP_DOUBLE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct VP_DOUBLE* outPayload =
            (VP_DOUBLE*)GetPayload(result);

        *freq = (double)outPayload->value;

    return ( err );
}


TSYNC_ERROR
TSYNC_VP_setFreq(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    double freq)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct VP_SET_DOUBLE inPayload;
        inPayload.inst = nInstance;
        inPayload.value = freq;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(VP_SET_DOUBLE_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_VP,
            TSYNC_ID_VP_CA_FREQ,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            VP_SET_DOUBLE_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}


TSYNC_ERROR
TSYNC_VP_getPhase(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    float *phase)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(phase);

        struct VP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(VP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(VP_FLOAT_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_VP,
            TSYNC_ID_VP_CA_PHASE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            VP_VALUE_RECIPE,
            VP_FLOAT_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct VP_FLOAT* outPayload =
            (VP_FLOAT*)GetPayload(result);

        *phase = (float)outPayload->value;

    return ( err );
}


TSYNC_ERROR
TSYNC_VP_setPhase(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    float phase)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct VP_SET_FLOAT inPayload;
        inPayload.inst = nInstance;
        inPayload.value = phase;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(VP_SET_FLOAT_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_VP,
            TSYNC_ID_VP_CA_PHASE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            VP_SET_FLOAT_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}


TSYNC_ERROR
TSYNC_VP_getCfg(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_VPCfgObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct VP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(VP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(VP_CFG_OBJ_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_VP,
            TSYNC_ID_VP_CA_RANGE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            VP_VALUE_RECIPE,
            VP_CFG_OBJ_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct VP_CFG_OBJ* outPayload =
            (VP_CFG_OBJ*)GetPayload(result);

        pObj->min  = outPayload->min;
        pObj->max  = outPayload->max;
        pObj->step = outPayload->step;

    return ( err );
}

TSYNC_ERROR
TSYNC_VP_getNumInst(
    TSYNC_BoardHandle hnd,
    unsigned int *nInstances)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nInstances);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(VP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_VP,
            TSYNC_ID_VP_CA_NUM_INST,
            ctl,
            pyldLen,
            NULL,
            NULL,
            VP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct VP_VALUE* outPayload =
            (VP_VALUE*)GetPayload(result);

        *nInstances = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_VP_getLock(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *lock)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(lock);

        struct VP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(VP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(VP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_VP,
            TSYNC_ID_VP_CA_LOCK,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            VP_VALUE_RECIPE,
            VP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct VP_VALUE* outPayload =
            (VP_VALUE*)GetPayload(result);

        *lock = outPayload->value;

    return ( err );
}
