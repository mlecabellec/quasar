#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_ep_services.h"
#include "tsync_cs_services.h"

extern uint8_t EP_VALUE_RECIPE[];
extern uint8_t EP_SET_CMD_RECIPE[];
extern uint8_t EP_INT_VALUE_RECIPE[];
extern uint8_t EP_INT_SET_CMD_RECIPE[];
extern uint8_t ML_CLK_LOCAL_RECIPE[];
extern uint8_t EP_LOCAL_SET_CMD_RECIPE[];
extern uint8_t ML_TIME_SCALE_OBJ_RECIPE[];
extern uint8_t EP_TIME_SCALE_SET_CMD_RECIPE[];

TSYNC_ERROR
TSYNC_EP_getSigCtrl(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    SIG_CTL *sig)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(sig);

        struct EP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(EP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(EP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_EP,
            TSYNC_ID_EP_CA_SIG_CTL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            EP_VALUE_RECIPE,
            EP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct EP_VALUE* outPayload =
            (EP_VALUE*)GetPayload(result);

        *sig = (SIG_CTL)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_EP_setSigCtrl(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    SIG_CTL sig)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct EP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = sig;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(EP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_EP,
            TSYNC_ID_EP_CA_SIG_CTL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            EP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_EP_getOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *nOffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nOffset);

        struct EP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(EP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(EP_INT_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_EP,
            TSYNC_ID_EP_CA_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            EP_VALUE_RECIPE,
            EP_INT_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct EP_INT_VALUE* outPayload =
            (EP_INT_VALUE*)GetPayload(result);

        *nOffset = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_EP_setOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int nOffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct EP_INT_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = nOffset;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(EP_INT_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_EP,
            TSYNC_ID_EP_CA_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            EP_INT_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_EP_getLocal(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_LocalClockObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct EP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(EP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(ML_CLK_LOCAL_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_EP,
            TSYNC_ID_EP_CA_LOCAL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            EP_VALUE_RECIPE,
            ML_CLK_LOCAL_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct ML_CLK_LOCAL* outPayload =
            (ML_CLK_LOCAL*)GetPayload(result);

        pObj->rule.ref = outPayload->ref;
        pObj->rule.in.month = outPayload->in.month;
        pObj->rule.in.wom = outPayload->in.wom;
        pObj->rule.in.dow = outPayload->in.dow;
        pObj->rule.in.hour = outPayload->in.hour;
        pObj->rule.out.month = outPayload->out.month;
        pObj->rule.out.wom = outPayload->out.wom;
        pObj->rule.out.dow = outPayload->out.dow;
        pObj->rule.out.hour = outPayload->out.hour;
        pObj->rule.offset = outPayload->offset;
        pObj->tz = outPayload->tz;

    return ( err );
}

TSYNC_ERROR
TSYNC_EP_setLocal(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_LocalClockObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct EP_LOCAL_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.ref = pObj->rule.ref;
        inPayload.in.month = pObj->rule.in.month;
        inPayload.in.wom = pObj->rule.in.wom;
        inPayload.in.dow = pObj->rule.in.dow;
        inPayload.in.hour = pObj->rule.in.hour;
        inPayload.out.month = pObj->rule.out.month;
        inPayload.out.wom = pObj->rule.out.wom;
        inPayload.out.dow = pObj->rule.out.dow;
        inPayload.out.hour = pObj->rule.out.hour;
        inPayload.offset = pObj->rule.offset;
        inPayload.tz = pObj->tz;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(EP_LOCAL_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_EP,
            TSYNC_ID_EP_CA_LOCAL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            EP_LOCAL_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_EP_getFormat(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    ESL_FMT *format)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(format);

        struct EP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(EP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(EP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_EP,
            TSYNC_ID_EP_CA_FORMAT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            EP_VALUE_RECIPE,
            EP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct EP_VALUE* outPayload =
            (EP_VALUE*)GetPayload(result);

        *format = (ESL_FMT)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_EP_setFormat(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    ESL_FMT format)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct EP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = format;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(EP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_EP,
            TSYNC_ID_EP_CA_FORMAT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            EP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_EP_getTimeScale(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_TimeScaleObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    struct EP_VALUE inPayload;
    inPayload.value = nInstance;

    uint16_t ctl = 0x00;//get
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(EP_VALUE_RECIPE, &pos);

    pos = 0;
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(ML_TIME_SCALE_OBJ_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_EP,
        TSYNC_ID_EP_CA_TIME_SCALE,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        EP_VALUE_RECIPE,
        ML_TIME_SCALE_OBJ_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    struct ML_TIME_SCALE_OBJ* outPayload =
        (ML_TIME_SCALE_OBJ*)GetPayload(result);

    pObj->scale = outPayload->scale;

    return ( err );
}

TSYNC_ERROR
TSYNC_EP_setTimeScale(
    TSYNC_BoardHandle   hnd,
    unsigned int nInstance,
    TSYNC_TimeScaleObj *pObj)
{
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    struct EP_TIME_SCALE_SET_CMD inPayload;
    inPayload.inst = nInstance;
    inPayload.scale.scale = pObj->scale;

    uint16_t ctl = 0x02;//set
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(EP_TIME_SCALE_SET_CMD_RECIPE, &pos);

    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(0));

    TSYNC_ERROR err = BaseTransaction(
        TSYNC_ID_EP,
        TSYNC_ID_EP_CA_TIME_SCALE,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        EP_TIME_SCALE_SET_CMD_RECIPE,
        NULL,
        result,
        handle);

    return ( err );
}

TSYNC_ERROR
TSYNC_EP_getAmplitude(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int *amp)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(amp);

        struct EP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(EP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(EP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_EP,
            TSYNC_ID_EP_CA_AMPLITUDE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            EP_VALUE_RECIPE,
            EP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct EP_VALUE* outPayload =
            (EP_VALUE*)GetPayload(result);

        *amp = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_EP_setAmplitude(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int amp)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct EP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = amp;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(EP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_EP,
            TSYNC_ID_EP_CA_AMPLITUDE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            EP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_EP_getNumInst(
    TSYNC_BoardHandle hnd,
    unsigned int *nInstances)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nInstances);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(EP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_EP,
            TSYNC_ID_EP_CA_NUM_INST,
            ctl,
            pyldLen,
            NULL,
            NULL,
            EP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct EP_VALUE* outPayload =
            (EP_VALUE*)GetPayload(result);

        *nInstances = outPayload->value;

    return ( err );
}

