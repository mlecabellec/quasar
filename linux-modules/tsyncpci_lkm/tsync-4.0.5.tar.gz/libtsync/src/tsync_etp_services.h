
#ifndef _defined_TSYNC_ETP_SERVICES_H
#define _defined_TSYNC_ETP_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_etp_services.h
**
**  Date:       09/10/09
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2009 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              09/10/2009 Creation
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_ETP                    0x3D
#define TSYNC_ID_ETP_CA_SIG_CTL         0x00
#define TSYNC_ID_ETP_CA_CFG             0x01
#define TSYNC_ID_ETP_CA_NUM_INST        0x02

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define ETP_VALUE_FIELDS          \
    TSYNC_X(uint32_t, value)

#define ETP_SET_CMD_FIELDS        \
    TSYNC_X(uint32_t, inst)       \
    TSYNC_X(uint32_t, value)

#define ETP_CFG_FIELDS            \
    TSYNC_X( ETO_OUT_OPT, opt)    \
    TSYNC_X( ETO_MODE,    mode)   \
    TSYNC_X( ETO_T1_ENC,  t1enc)  \
    TSYNC_X( ETO_T1_FRM,  t1frm)  \
    TSYNC_X( ETO_E1_FRM,  e1frm)  \
    TSYNC_X( int32_t,     ssmen)  \
    TSYNC_X( ETO_T1_SSM,  t1ssm)  \
    TSYNC_X( ETO_E1_SSM,  e1ssm)

#define ETP_CFG_SET_CMD_FIELDS    \
    TSYNC_X( uint32_t,    inst)   \
    TSYNC_X( ETO_OUT_OPT, opt)    \
    TSYNC_X( ETO_MODE,    mode)   \
    TSYNC_X( ETO_T1_ENC,  t1enc)  \
    TSYNC_X( ETO_T1_FRM,  t1frm)  \
    TSYNC_X( ETO_E1_FRM,  e1frm)  \
    TSYNC_X( int32_t,     ssmen)  \
    TSYNC_X( ETO_T1_SSM,  t1ssm)  \
    TSYNC_X( ETO_E1_SSM,  e1ssm)

#include "tsync_struct_define.h"

GEN_STRUCT(ETP_VALUE)
GEN_STRUCT(ETP_SET_CMD)
GEN_STRUCT(ETP_CFG)
GEN_STRUCT(ETP_CFG_SET_CMD)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_ETP_SERVICES_H */
