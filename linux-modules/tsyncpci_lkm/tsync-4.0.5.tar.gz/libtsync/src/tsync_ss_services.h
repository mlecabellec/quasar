
#ifndef _defined_TSYNC_SS_SERVICES_H
#define _defined_TSYNC_SS_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_ss_services.h
**
**  Date:       07/25/08
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/25/2008 Creation
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_SS                         0x25
#define TSYNC_ID_SS_CA_REF                  0x00
#define TSYNC_ID_SS_CA_MAX_TFOM             0x01
#define TSYNC_ID_SS_CA_TFOM                 0x02
#define TSYNC_ID_SS_CA_SYNC                 0x03
#define TSYNC_ID_SS_CA_HOLDOVER             0x04
#define TSYNC_ID_SS_CA_HOLDOVER_TIMEOUT     0x05
#define TSYNC_ID_SS_CA_TIME_STAMP           0x06
#define TSYNC_ID_SS_CA_UPTIME               0x07
#define TSYNC_ID_SS_CA_RESET                0x08
#define TSYNC_ID_SS_CA_FREERUN              0x09

#define TSYNC_ID_SS_CA_INPUT_TFOM           0x0B

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define SS_RESET_OBJ_FIELDS                    \
    TSYNC_X( SS_RESET,     type)

#define SS_REF_OBJ_FIELDS                    \
    TSYNC_X_BUFFER(    int8_t,     time,    4)    \
    TSYNC_X_BUFFER(    int8_t,     pps,    4)

#define SS_VALUE_FIELDS                   \
    TSYNC_X(        uint32_t,   value)
    
#define SS_TS_REQ_FIELDS                    \
    TSYNC_X(        SS_TS_SRC,      src)    \
    TSYNC_X(        ML_TIME_TYPE,   type)
    


#include "tsync_struct_define.h"

GEN_STRUCT(SS_RESET_OBJ)
GEN_STRUCT(SS_REF_OBJ)
GEN_STRUCT(SS_VALUE)
GEN_STRUCT(SS_TS_REQ)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_SS_SERVICES_H */
