
#ifndef _defined_TSYNC_VP_SERVICES_H
#define _defined_TSYNC_VP_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_vp_services.h
**
**  Date:       09/10/09
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2009 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              09/10/2009 Creation
**
****************************************************************************/

#include "tsync_cs_services.h"

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_VP                     0x34
#define TSYNC_ID_VP_CA_SIG_CTL          0x00
#define TSYNC_ID_VP_CA_FREQ             0x01
#define TSYNC_ID_VP_CA_RANGE            0x02
#define TSYNC_ID_VP_CA_NUM_INST         0x03
#define TSYNC_ID_VP_CA_PHASE            0x04
#define TSYNC_ID_VP_CA_LOCK             0x05


/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define VP_VALUE_FIELDS               \
    TSYNC_X(uint32_t,  value)

#define VP_FLOAT_FIELDS               \
    TSYNC_X(float,     value)

#define VP_DOUBLE_FIELDS              \
    TSYNC_X(double,    value)
    
#define VP_SET_CMD_FIELDS            \
    TSYNC_X( uint32_t, inst)         \
    TSYNC_X( uint32_t, value)

#define VP_SET_FLOAT_FIELDS          \
    TSYNC_X( uint32_t, inst)         \
    TSYNC_X( float,    value)

#define VP_SET_DOUBLE_FIELDS         \
    TSYNC_X( uint32_t, inst)         \
    TSYNC_X( double,   value)
    
#define VP_CFG_OBJ_FIELDS            \
    TSYNC_X( float,    min)          \
    TSYNC_X( float,    max)          \
    TSYNC_X( float,    step)

#include "tsync_struct_define.h"

GEN_STRUCT(VP_VALUE)
GEN_STRUCT(VP_FLOAT)
GEN_STRUCT(VP_DOUBLE)
GEN_STRUCT(VP_SET_CMD)
GEN_STRUCT(VP_SET_FLOAT)
GEN_STRUCT(VP_SET_DOUBLE)
GEN_STRUCT(VP_CFG_OBJ)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_VP_SERVICES_H */
