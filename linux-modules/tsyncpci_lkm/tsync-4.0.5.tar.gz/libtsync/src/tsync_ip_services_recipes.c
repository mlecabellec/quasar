
/***************************************************************************
**  Module:     tsync_irigoutput_services_recipes.c
**
**  Date:       08/04/08
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              08/04/2008 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_ip_services.h"
#include "tsync_cs_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(IP_VALUE)
RECIPE(IP_SET_CMD)
RECIPE(IP_MOD_SET_CMD)
RECIPE(IP_INT_VALUE)
RECIPE(IP_INT_SET_CMD)
RECIPE(IP_SHORT)
RECIPE(IP_MSG)
RECIPE(IP_MSG_SET_CMD)
RECIPE(IP_LOCAL_SET_CMD)
RECIPE(IP_CFDATA)
RECIPE(IP_CFDATA_SET_CMD)
RECIPE(IP_TIME_SCALE_SET_CMD)

#include "tsync_recipe_undef.h"
