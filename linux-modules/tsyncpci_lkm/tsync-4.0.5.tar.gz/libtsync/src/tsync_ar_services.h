
#ifndef _defined_TSYNC_AR_SERVICES_H
#define _defined_TSYNC_AR_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_ar_services.h
**
**  Date:       09/08/09
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2009 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              09/08/2009 Creation
**
****************************************************************************/

#include "tsync.h"
#include "tsync_cs_services.h"

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_AR                     0x2C
#define TSYNC_ID_AR_CA_OFFSET           0x00
#define TSYNC_ID_AR_CA_VALIDITY         0x02
#define TSYNC_ID_AR_CA_UART_CFG         0x04
#define TSYNC_ID_AR_CA_LEAP_FLAG        0x05
#define TSYNC_ID_AR_CA_LOCAL            0x06
#define TSYNC_ID_AR_CA_TIME_SCALE       0x07
#define TSYNC_ID_AR_CA_REF_ID           0x08
#define TSYNC_ID_AR_CA_FORMAT           0x09
#define TSYNC_ID_AR_CA_NUM_INST         0x0A
#define TSYNC_ID_AR_CA_PPS_SRC          0x0B
#define TSYNC_ID_AR_STL_CA_VERSION      0x0C
#define TSYNC_ID_AR_STL_CA_SUBSCRIPTION 0x0D
#define TSYNC_ID_AR_STL_CA_ACT_FEAT     0x0E
#define TSYNC_ID_AR_STL_CA_CONF         0x0F
#define TSYNC_ID_AR_STL_CA_IP_ADDR      0x10
#define TSYNC_ID_AR_STL_CA_STAT         0x11
#define TSYNC_ID_AR_STL_CA_SUBK         0x12

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define AR_VALUE_FIELDS                         \
    TSYNC_X(        uint32_t,           value)

#define AR_OFFSET_SET_CMD_FIELDS                \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X(        int32_t,            offset)

#define AR_VALUE_SET_CMD_FIELDS                \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X(        uint32_t,           value)

#define AR_UART_CFG_OBJ_FIELDS                  \
    TSYNC_X(        UD_BR,              baud)   \
    TSYNC_X(        UD_DATA,            db)     \
    TSYNC_X(        UD_STOP,            sb)     \
    TSYNC_X(        UD_PAR,             par)

#define AR_UART_CFG_SET_CMD_FIELDS              \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X(        UD_BR,              baud)   \
    TSYNC_X(        UD_DATA,            db)     \
    TSYNC_X(        UD_STOP,            sb)     \
    TSYNC_X(        UD_PAR,             par)

#define AR_LOCAL_SET_CMD_FIELDS                 \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X(        ML_DST_REF,         ref)    \
    TSYNC_X_STRUCT( ML_DST_POINT,       in)     \
    TSYNC_X_STRUCT( ML_DST_POINT,       out)    \
    TSYNC_X(        uint32_t,           offset) \
    TSYNC_X(        int32_t,            tz)

#define AR_TIME_SCALE_SET_CMD_FIELDS            \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X_STRUCT( ML_TIME_SCALE_OBJ,  scale)

#define AR_FORMAT_SET_CMD_FIELDS                \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X(        AL_FMT,             format)

#define AR_PPS_SRC_SET_CMD_FIELDS              \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X(        AL_PPS,             pps)

#define AR_STL_VERSION_FIELDS                   \
    TSYNC_X_BUFFER(int8_t,  application,  16)   \
    TSYNC_X_BUFFER(int8_t,  system,       16)   \
    TSYNC_X_BUFFER(int8_t,  serialnb,     16)

#define AR_STL_BUFFER_FIELDS                    \
    TSYNC_X_BUFFER(int8_t,  buffer,  16)

#define AR_STL_CONF_FIELDS                      \
    TSYNC_X_BUFFER(int8_t,   serialnb,     16)  \
    TSYNC_X( double,         lat)               \
    TSYNC_X( double,         lon)               \
    TSYNC_X( double,         alt)               \
    TSYNC_X( double,         ee_axis)           \
    TSYNC_X( double,         nn_axis)           \
    TSYNC_X( double,         uu_axis)           \
    TSYNC_X( uint32_t,       geoMode)           \
    TSYNC_X( uint32_t,       sensLevel)

#define AR_STL_CONF_SET_CMD_FIELDS              \
    TSYNC_X( uint32_t,       nInstance)         \
    TSYNC_X_BUFFER(int8_t,   serialnb,     16)  \
    TSYNC_X( double,         lat)               \
    TSYNC_X( double,         lon)               \
    TSYNC_X( double,         alt)               \
    TSYNC_X( double,         ee_axis)           \
    TSYNC_X( double,         nn_axis)           \
    TSYNC_X( double,         uu_axis)           \
    TSYNC_X( uint32_t,       geoMode)           \
    TSYNC_X( uint32_t,       sensLevel)

#define AR_STL_STAT_VALUE_FIELDS                \
    TSYNC_X( uint32_t, rcvBurst)                \
    TSYNC_X( uint32_t, rcvStrongBurst)

#define AR_STL_SUB_FIELDS                       \
    TSYNC_X_BUFFER(int8_t,  beginSub,  16)      \
	TSYNC_X_BUFFER(int8_t,  endSub,  16)        \
    TSYNC_X(       uint32_t, state)             \
	TSYNC_X(       uint32_t, unused)

#define AR_STL_SUBK_FIELDS                      \
    TSYNC_X_BUFFER(int8_t,   key,          32)

#define AR_STL_SUBK_SET_CMD_FIELDS              \
    TSYNC_X( uint32_t,       nInstance)         \
    TSYNC_X_BUFFER(int8_t,   key,          32)

#include "tsync_struct_define.h"

GEN_STRUCT(AR_VALUE)
GEN_STRUCT(AR_OFFSET_SET_CMD)
GEN_STRUCT(AR_UART_CFG_OBJ)
GEN_STRUCT(AR_UART_CFG_SET_CMD)
GEN_STRUCT(AR_LOCAL_SET_CMD)
GEN_STRUCT(AR_TIME_SCALE_SET_CMD)
GEN_STRUCT(AR_FORMAT_SET_CMD)
GEN_STRUCT(AR_PPS_SRC_SET_CMD)
GEN_STRUCT(AR_VALUE_SET_CMD)

GEN_STRUCT(AR_STL_VERSION)
GEN_STRUCT(AR_STL_BUFFER)
GEN_STRUCT(AR_STL_CONF)
GEN_STRUCT(AR_STL_CONF_SET_CMD)
GEN_STRUCT(AR_STL_STAT_VALUE)
GEN_STRUCT(AR_STL_SUB)
GEN_STRUCT(AR_STL_SUBK)
GEN_STRUCT(AR_STL_SUBK_SET_CMD)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_AR_SERVICES_H */
