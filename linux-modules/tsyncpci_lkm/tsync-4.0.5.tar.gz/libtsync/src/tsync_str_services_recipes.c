
/***************************************************************************
**  Module:     tsync_str_services_recipes.c
**
**  Date:       09/08/09
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2009 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              09/08/2009 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_str_services.h"
#include "tsync_cs_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(STR_VALUE)
RECIPE(STR_VERSION)
RECIPE(STR_VALUE_SET_CMD)
RECIPE(STR_BUFFER)
RECIPE(STR_CONF)
RECIPE(STR_CONF_SET_CMD)
RECIPE(STR_STAT_VALUE)
RECIPE(STR_SUB)
RECIPE(STR_SUBK)
RECIPE(STR_SUBK_SET_CMD)

#include "tsync_recipe_undef.h"
