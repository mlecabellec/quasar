
/***************************************************************************
**  Module:     tsync_xs_services_recipes.c
**
**  Date:       07/22/08
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/22/2008 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_xs_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(METER_HANDLE)
RECIPE(XS_WIN_SIZE_GET_CMD)
RECIPE(XS_WIN_SIZE_GET_RESP)
RECIPE(XS_WIN_SIZE_SET_CMD)
RECIPE(XS_METER_DATA)
RECIPE(XS_COMMAND)

#include "tsync_recipe_undef.h"
