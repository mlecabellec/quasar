
#ifndef _defined_TSYNC_QR_SERVICES_H
#define _defined_TSYNC_QR_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_qr_services.h
**
**  Date:       09/08/09
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2009 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              09/08/2009 Creation 
**              17/06/2011 Add TSYNC_ID_QR_CA_TFOM
**              and TSYNC_ID_QR_CA_TIME_FAULT_DISCRETE
**              Replace QR_OFFSET_SET_CMD_RECIPE by QR_INT_SET_CMD_FIELDS  
****************************************************************************/

#include "tsync_cs_services.h"

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_QR                        0x2B
#define TSYNC_ID_QR_CA_OFFSET              0x00
#define TSYNC_ID_QR_CA_VALIDITY            0x01
#define TSYNC_ID_QR_CA_FORMAT              0x02
#define TSYNC_ID_QR_CA_LOCAL               0x03
#define TSYNC_ID_QR_CA_TIME_SCALE          0x04
#define TSYNC_ID_QR_CA_REF_ID              0x05
#define TSYNC_ID_QR_CA_NUM_INST            0x06

#define TSYNC_ID_QR_CA_TFOM                0x07
#define TSYNC_ID_QR_CA_ELECTYPE            0x08

#define TSYNC_ID_QR_CA_TFD                 0x09
#define TSYNC_ID_QR_CA_TFD_STATE           0x0a
#define TSYNC_ID_QR_CA_BS                  0x0b
#define TSYNC_ID_QR_CA_REF_SELECTION       0x0c
#define TSYNC_ID_QR_CA_SELECTED_REF        0x0d

#define TSYNC_ID_QR_CA_EXTOFFSET           0x0e
#define TSYNC_ID_QR_CA_EXTFORMAT           0x0f
#define TSYNC_ID_QR_CA_EXTTIME_SCALE       0x10
#define TSYNC_ID_QR_CA_EXTTFOM             0x11
#define TSYNC_ID_QR_CA_EXTELECTYPE         0x12

#define TSYNC_ID_QR_CA_PPS_ELECTYPE        0x13
#define TSYNC_ID_QR_CA_PPS_OFFSET          0x14
#define TSYNC_ID_QR_CA_PPS_EDGE            0x15
#define TSYNC_ID_QR_CA_TFOM_THRESHOLD      0x16
#define TSYNC_ID_QR_CA_EXTTFOM_THRESHOLD   0x17

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define QR_VALUE_FIELDS                       \
    TSYNC_X(        uint32_t,   value)    

#define QR_SET_CMD_FIELDS                     \
    TSYNC_X(        uint32_t,           inst) \
    TSYNC_X(        uint32_t,           value)
    
#define QR_INT_SET_CMD_FIELDS                 \
    TSYNC_X(        uint32_t,   inst)         \
    TSYNC_X(        int32_t,    value)    
                                          
#define QR_FORMAT_SET_CMD_FIELDS              \
    TSYNC_X(        uint32_t,   inst)         \
    TSYNC_X(        QL_FMT,     format)   
                                          
#define QR_LOCAL_SET_CMD_FIELDS               \
    TSYNC_X(        uint32_t,       inst)     \
    TSYNC_X( ML_DST_REF,     ref)             \
    TSYNC_X_STRUCT( ML_DST_POINT,    in)      \
    TSYNC_X_STRUCT( ML_DST_POINT,    out)     \
    TSYNC_X( uint32_t,    offset)             \
    TSYNC_X( int32_t,        tz)

#define QR_TIME_SCALE_SET_CMD_FIELDS          \
    TSYNC_X(        uint32_t,           inst) \
    TSYNC_X_STRUCT( ML_TIME_SCALE_OBJ,  scale)

#include "tsync_struct_define.h"

GEN_STRUCT(QR_VALUE)
GEN_STRUCT(QR_SET_CMD)
GEN_STRUCT(QR_INT_SET_CMD)
GEN_STRUCT(QR_FORMAT_SET_CMD)
GEN_STRUCT(QR_LOCAL_SET_CMD)
GEN_STRUCT(QR_TIME_SCALE_SET_CMD)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_IR_SERVICES_H */
