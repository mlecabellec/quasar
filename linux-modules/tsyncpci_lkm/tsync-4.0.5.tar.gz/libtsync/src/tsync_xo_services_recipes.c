
/***************************************************************************
**  Module:     tsync_xo_services_recipes.c
**
**  Date:       08/05/08
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              08/05/2008 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_xo_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(XO_VALUE)
RECIPE(XO_DAC)
RECIPE(XO_SERIAL_NUM)
RECIPE(XO_MFR_MDL)
RECIPE(XO_CUSTOM_MSG)
RECIPE(XO_DISC_GET_CMD)
RECIPE(XO_DISC_GET_RESP)
RECIPE(XO_DISC_SET_CMD)
RECIPE(XO_INT_VALUE)
RECIPE(XO_FLOAT_VALUE)

#include "tsync_recipe_undef.h"
