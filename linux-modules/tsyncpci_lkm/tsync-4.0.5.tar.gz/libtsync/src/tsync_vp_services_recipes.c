
/***************************************************************************
**  Module:     tsync_vp_services_recipes.c
**
**  Date:       09/10/09
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2009 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              09/10/2009 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_vp_services.h"
#include "tsync_cs_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(VP_VALUE)
RECIPE(VP_FLOAT)
RECIPE(VP_DOUBLE)
RECIPE(VP_SET_CMD)
RECIPE(VP_SET_FLOAT)
RECIPE(VP_SET_DOUBLE)
RECIPE(VP_CFG_OBJ)

#include "tsync_recipe_undef.h"
