
#ifndef _defined_TSYNC_QP_SERVICES_H
#define _defined_TSYNC_QP_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_qp_services.h
**
**  Date:       09/09/09
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2009 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              09/09/2009 Creation
**              17/06/2011 Add TSYNC_ID_QP_CA_TIME_FAULT_DISCRETE
**                         and TSYNC_ID_QP_CA_TFOM
**
****************************************************************************/

#include "tsync_cs_services.h"

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_QP                         0x30
#define TSYNC_ID_QP_CA_SIG_CTL              0x00
#define TSYNC_ID_QP_CA_OFFSET               0x01
#define TSYNC_ID_QP_CA_LOCAL                0x02
#define TSYNC_ID_QP_CA_FORMAT               0x03
#define TSYNC_ID_QP_CA_TIME_SCALE           0x04
#define TSYNC_ID_QP_CA_NUM_INST             0x05

#define TSYNC_ID_QP_CA_TFOM                 0x06
#define TSYNC_ID_QP_CA_REQUIRED_TFOM        0x07
#define TSYNC_ID_QP_CA_ELECTYPE             0x08

#define TSYNC_ID_QP_CA_TFD                  0x09
#define TSYNC_ID_QP_CA_TFD_STATE            0x0a
#define TSYNC_ID_QP_CA_BS                   0x0b
#define TSYNC_ID_QP_CA_LEVEL                0x0c

#define TSYNC_ID_QP_CA_EXTSIG_CTL           0x0d
#define TSYNC_ID_QP_CA_EXTOFFSET            0x0e
#define TSYNC_ID_QP_CA_EXTFORMAT            0x0f
#define TSYNC_ID_QP_CA_EXTTIME_SCALE        0x10
#define TSYNC_ID_QP_CA_EXTTFOM              0x11
#define TSYNC_ID_QP_CA_EXTELECTYPE          0x12

#define TSYNC_ID_QP_CA_PPS_SIG_CTL          0x13
#define TSYNC_ID_QP_CA_PPS_OFFSET           0x14
#define TSYNC_ID_QP_CA_PPS_ELECTYPE         0x15
#define TSYNC_ID_QP_CA_PPS_EDGE             0x16
#define TSYNC_ID_QP_CA_PPS_PW               0x17


/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define QP_VALUE_FIELDS                         \
    TSYNC_X(        uint32_t,           value)

#define QP_SET_CMD_FIELDS                       \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X(        uint32_t,           value)

#define QP_INT_VALUE_FIELDS                     \
    TSYNC_X(        int32_t,            value)

#define QP_INT_SET_CMD_FIELDS                   \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X(        int32_t,            value)

#define QP_LOCAL_SET_CMD_FIELDS                 \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X(        ML_DST_REF,         ref)    \
    TSYNC_X_STRUCT( ML_DST_POINT,       in)     \
    TSYNC_X_STRUCT( ML_DST_POINT,       out)    \
    TSYNC_X(        uint32_t,           offset) \
    TSYNC_X(        int32_t,            tz)

#define QP_TIME_SCALE_SET_CMD_FIELDS            \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X_STRUCT( ML_TIME_SCALE_OBJ,  scale)

#include "tsync_struct_define.h"

GEN_STRUCT(QP_VALUE)
GEN_STRUCT(QP_SET_CMD)
GEN_STRUCT(QP_INT_VALUE)
GEN_STRUCT(QP_INT_SET_CMD)
GEN_STRUCT(QP_LOCAL_SET_CMD)
GEN_STRUCT(QP_TIME_SCALE_SET_CMD)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_QP_SERVICES_H */
