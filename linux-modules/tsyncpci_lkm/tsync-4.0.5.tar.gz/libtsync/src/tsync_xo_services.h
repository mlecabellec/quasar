
#ifndef _defined_TSYNC_XO_SERVICES_H
#define _defined_TSYNC_XO_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_xo_services.h
**
**  Date:       08/05/08
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2006, 2009 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              08/05/2008 Creation
**              09/10/2009 Added Serrial Number, Phase Error and Frequency
**                         Error structures
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_XO                     0x36
#define TSYNC_ID_XO_CA_DISC_STATE       0x00
#define TSYNC_ID_XO_CA_MODE             0x01
#define TSYNC_ID_XO_CA_DAC              0x02
#define TSYNC_ID_XO_CA_ALARM            0x03
#define TSYNC_ID_XO_CA_SERIAL_NUM       0x04
#define TSYNC_ID_XO_CA_MFR_MDL          0x05
#define TSYNC_ID_XO_CA_CUSTOM_MSG       0x06
#define TSYNC_ID_XO_CA_DISC             0x07
#define TSYNC_ID_XO_CA_PHASE_ERR        0x08
#define TSYNC_ID_XO_CA_FREQ_ERR         0x09
#define TSYNC_ID_XO_CA_OSC_TYPE         0x0A
#define TSYNC_ID_XO_CA_CAL_VAL          0x0B
#define TSYNC_ID_XO_CA_PHASE_ERR_LIM    0x0C

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define XO_VALUE_FIELDS                   \
    TSYNC_X(        uint32_t,   value)
    
#define XO_DAC_FIELDS                   \
    TSYNC_X(        uint16_t,   value)
    
#define XO_SERIAL_NUM_FIELDS                   \
    TSYNC_X_BUFFER( int8_t,     ser,    TSYNC_OSC_SER_NUM_STRING_SIZE)

#define XO_MFR_MDL_FIELDS                    \
    TSYNC_X_BUFFER( int8_t,     mfr,    TSYNC_OSC_MAN_MOD_STRING_SIZE)    \
    TSYNC_X_BUFFER( int8_t,     mdl,    TSYNC_OSC_MAN_MOD_STRING_SIZE)
    
#define XO_CUSTOM_MSG_FIELDS                    \
    TSYNC_X(        int32_t,    len)    \
    TSYNC_X_BUFFER( int8_t,     msg,    64)
    
#define XO_DISC_GET_CMD_FIELDS                    \
    TSYNC_X_BUFFER( uint8_t,    cmd,    TSYNC_OSC_DISC_CMD_SIZE)
    
#define XO_DISC_GET_RESP_FIELDS                    \
    TSYNC_X_BUFFER( uint8_t,    data,   TSYNC_OSC_DISC_DATA_SIZE)
    
#define XO_DISC_SET_CMD_FIELDS                    \
    TSYNC_X_BUFFER( uint8_t,    cmd,    TSYNC_OSC_DISC_CMD_SIZE) \
    TSYNC_X_BUFFER( uint8_t,    data,   TSYNC_OSC_DISC_DATA_SIZE)
    
#define XO_INT_VALUE_FIELDS                   \
    TSYNC_X(        uint32_t,   value)
    
#define XO_FLOAT_VALUE_FIELDS                   \
    TSYNC_X(        float,      value)
    
    
#include "tsync_struct_define.h"

GEN_STRUCT(XO_VALUE)
GEN_STRUCT(XO_DAC)
GEN_STRUCT(XO_SERIAL_NUM)
GEN_STRUCT(XO_MFR_MDL)
GEN_STRUCT(XO_CUSTOM_MSG)
GEN_STRUCT(XO_DISC_GET_CMD)
GEN_STRUCT(XO_DISC_GET_RESP)
GEN_STRUCT(XO_DISC_SET_CMD)
GEN_STRUCT(XO_INT_VALUE)
GEN_STRUCT(XO_FLOAT_VALUE)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_XO_SERVICES_H */
