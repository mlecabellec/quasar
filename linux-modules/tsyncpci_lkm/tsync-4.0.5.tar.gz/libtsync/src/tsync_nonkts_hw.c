#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "ddtsync.h"
#include "tsync_macros.h"

#include "tsync_hw.h"


/******************************************************************************/
/* Helper Functions ***********************************************************/
/******************************************************************************/
