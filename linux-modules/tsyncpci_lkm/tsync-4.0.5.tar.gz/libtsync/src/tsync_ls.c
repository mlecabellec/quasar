#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_ls_services.h"

extern uint8_t LS_ERROR_LOG_RECIPE[];
extern uint8_t LS_ALARM_OBJ_RECIPE[];
extern uint8_t LS_ALARM_FLAG_RECIPE[];
extern uint8_t LS_ALARM_SET_CMD_RECIPE[];
extern uint8_t LS_VERSION_RECIPE[];
extern uint8_t LS_SERIAL_NO_RECIPE[];

TSYNC_ERROR
TSYNC_LS_getErrorLog(
    TSYNC_BoardHandle  hnd,
    TSYNC_ErrorLogObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(LS_ERROR_LOG_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_LS,
            TSYNC_ID_LS_CA_ERROR_LOG,
            ctl,
            pyldLen,
            NULL,
            NULL,
            LS_ERROR_LOG_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct LS_ERROR_LOG* outPayload =
            (LS_ERROR_LOG*)GetPayload(result);
            
        memcpy(pObj->message, outPayload->msg, sizeof(pObj->message));
        
    return ( err );
}

TSYNC_ERROR
TSYNC_LS_getAlarm(
    TSYNC_BoardHandle  hnd,
    TSYNC_AlarmObj    *pObj,
    TSYNC_FlagObj     *pObj2)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);
        CHECK_NOT_NULL(pObj2);

        struct LS_ALARM_OBJ inPayload;
        inPayload.index = pObj->index;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(LS_ALARM_OBJ_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(LS_ALARM_FLAG_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_LS,
            TSYNC_ID_LS_CA_ALARM,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            LS_ALARM_OBJ_RECIPE,
            LS_ALARM_FLAG_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct LS_ALARM_FLAG* outPayload =
            (LS_ALARM_FLAG*)GetPayload(result);
            
        pObj2->flag = outPayload->flag;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_LS_setAlarm(
    TSYNC_BoardHandle  hnd,
    TSYNC_AlarmObj    *pObj,
    TSYNC_FlagObj     *pObj2)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);
        CHECK_NOT_NULL(pObj2);

        struct LS_ALARM_SET_CMD inPayload;
        inPayload.index = pObj->index;
        inPayload.flag = pObj2->flag;
        
        uint16_t ctl = 0x02;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(LS_ALARM_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_LS,
            TSYNC_ID_LS_CA_ALARM,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            LS_ALARM_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

    return ( err );
}

TSYNC_ERROR
TSYNC_LS_getVersion(
    TSYNC_BoardHandle         hnd,
    TSYNC_FirmwareVersionObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(LS_VERSION_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_LS,
            TSYNC_ID_LS_CA_VERSION,
            ctl,
            pyldLen,
            NULL,
            NULL,
            LS_VERSION_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct LS_VERSION* outPayload =
            (LS_VERSION*)GetPayload(result);
            
        memset(pObj->version, '\0', sizeof(pObj->version));
        memcpy(pObj->version, outPayload->ver, sizeof(outPayload->ver));
        
    return ( err );
}

TSYNC_ERROR
TSYNC_LS_getSerialNo(
    TSYNC_BoardHandle  hnd,
    TSYNC_SerialNoObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(LS_SERIAL_NO_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_LS,
            TSYNC_ID_LS_CA_SERIAL_NO,
            ctl,
            pyldLen,
            NULL,
            NULL,
            LS_SERIAL_NO_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct LS_SERIAL_NO* outPayload =
            (LS_SERIAL_NO*)GetPayload(result);
            
        memset(pObj->serno, '\0', sizeof(pObj->serno));
        memcpy(pObj->serno, outPayload->ser, sizeof(outPayload->ser));
        
    return ( err );
}

