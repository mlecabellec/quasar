#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_gi_services.h"

extern uint8_t GI_VALUE_RECIPE[];
extern uint8_t GI_EDGE_SET_CMD_RECIPE[];
extern uint8_t GI_TIMESTAMP_ENABLE_SET_CMD_RECIPE[];
extern uint8_t GI_ASCII_TIMESTAMP_RECIPE[];

TSYNC_ERROR
TSYNC_GI_getValue(
    TSYNC_BoardHandle hnd,
    ID_PIN index,
    int *bEnabled)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(bEnabled);

        struct GI_VALUE inPayload;
        inPayload.value = index;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GI_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GI_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GI,
            TSYNC_ID_GI_CA_VALUE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GI_VALUE_RECIPE,
            GI_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct GI_VALUE* outPayload =
            (GI_VALUE*)GetPayload(result);
            
        *bEnabled = outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GI_getEdge(
    TSYNC_BoardHandle hnd,
    ID_PIN index,
    EDGE* edge)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(edge);

        struct GI_VALUE inPayload;
        inPayload.value = index;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GI_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GI_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GI,
            TSYNC_ID_GI_CA_EDGE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GI_VALUE_RECIPE,
            GI_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct GI_VALUE* outPayload =
            (GI_VALUE*)GetPayload(result);
            
        *edge = (EDGE)outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GI_setEdge(
    TSYNC_BoardHandle hnd,
    ID_PIN index,
    EDGE edge)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GI_EDGE_SET_CMD inPayload;
        inPayload.index = index;
        inPayload.edge = edge;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GI_EDGE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_GI,
            TSYNC_ID_GI_CA_EDGE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GI_EDGE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GI_getTsEnable(
    TSYNC_BoardHandle hnd,
    ID_PIN index,
    int *bEnable)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(bEnable);

        struct GI_VALUE inPayload;
        inPayload.value = index;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GI_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GI_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GI,
            TSYNC_ID_GI_CA_TIMESTAMP_EN,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GI_VALUE_RECIPE,
            GI_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct GI_VALUE* outPayload =
            (GI_VALUE*)GetPayload(result);
            
        *bEnable = outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GI_setTsEnable(
    TSYNC_BoardHandle hnd,
    ID_PIN index,
    int bEnable)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GI_TIMESTAMP_ENABLE_SET_CMD inPayload;
        inPayload.index = index;
        inPayload.enable = bEnable;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GI_TIMESTAMP_ENABLE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_GI,
            TSYNC_ID_GI_CA_TIMESTAMP_EN,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GI_TIMESTAMP_ENABLE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GI_getNumInst(
    TSYNC_BoardHandle hnd,
    unsigned int *nInstances)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nInstances);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GI_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GI,
            TSYNC_ID_GI_CA_NUM_INST,
            ctl,
            pyldLen,
            NULL,
            NULL,
            GI_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct GI_VALUE* outPayload =
            (GI_VALUE*)GetPayload(result);
            
        *nInstances = outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_GI_getTsType(
    TSYNC_BoardHandle hnd,
    ID_PIN index,
    int *bType)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(bType);

        struct GI_VALUE inPayload;
        inPayload.value = index;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GI_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GI_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GI,
            TSYNC_ID_GI_CA_TS_TYPE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GI_VALUE_RECIPE,
            GI_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GI_VALUE* outPayload =
            (GI_VALUE*)GetPayload(result);

        *bType = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_GI_getAsciiTs(
    TSYNC_BoardHandle hnd,
    ID_PIN index,
    TSYNC_AsciiEvtMsg *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GI_VALUE inPayload;
        inPayload.value = index;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GI_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GI_ASCII_TIMESTAMP_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GI,
            TSYNC_ID_GI_CA_TS_ASCII,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GI_VALUE_RECIPE,
            GI_ASCII_TIMESTAMP_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GI_ASCII_TIMESTAMP* outPayload =
            (GI_ASCII_TIMESTAMP*)GetPayload(result);

        memset(pObj->msg, 0,               sizeof(pObj->msg));

        memcpy(pObj->msg, outPayload->msg, sizeof(outPayload->msg));

    return ( err );
}

TSYNC_ERROR
TSYNC_GI_tsClear(
    TSYNC_BoardHandle hnd,
    ID_PIN index)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GI_VALUE inPayload;
        inPayload.value = index;

        uint16_t ctl = 0x02;//set
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GI_VALUE_RECIPE, &pos);

        pos = 0;

        err = BaseTransaction(
            TSYNC_ID_GI,
            TSYNC_ID_GI_CA_TS_CLEAR,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GI_VALUE_RECIPE,
            NULL,
            NULL,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}
