#include "tsync.h"
#include "tsync_driver_interface.h"

/**********************************************************************
*
* FUNCTION:     TSYNC_close
*
* DESCRIPTION:  This routine closes the device bound to the TSYNC_BoardObj
*               object and frees the allocated TSYNC_BoardObj object.
*
* Arguments:    Pointer to TSYNC_BoardObj handle
* 
* RETURNS:      TSYNC_SUCCESS
*               TSYNC_DEVICE_NOT_OPEN
* 
**********************************************************************/

TSYNC_ERROR
TSYNC_close( TSYNC_BoardHandle hnd )
{
    return TSYNC_closeImpl(hnd);
}
