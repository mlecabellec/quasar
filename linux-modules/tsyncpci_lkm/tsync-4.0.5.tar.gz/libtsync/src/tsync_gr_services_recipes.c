
/***************************************************************************
**  Module:     tsync_gr_services_recipes.c
**
**  Date:       07/29/08
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/29/2008 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_gr_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(GR_VALUE)
RECIPE(GR_VALIDITY_SET_CMD)
RECIPE(GR_POS_LLA)
RECIPE(GR_FIX_DATA)
RECIPE(GL_SAT_INFO)
RECIPE(GR_SAT_DATA)
RECIPE(GR_MFR_MDL)
RECIPE(GR_RCVR_INFO)
RECIPE(GR_CUSTOM_MSG)
RECIPE(GR_OFFSET_SET_CMD)
RECIPE(GR_POS_LLA_SET_CMD)
RECIPE(GR_RECMODE_SET_CMD)
RECIPE(GR_RECMODE_GET_CMD)
RECIPE(GR_DYNMODE_SET_CMD)
RECIPE(GR_CUSTOM_MSG_SET_CMD)
RECIPE(GR_RESET_CMD)
RECIPE(GR_RCVR_PARM_GET)
RECIPE(GR_RCVR_PARM)
RECIPE(GR_RCVR_PARM_SET)
RECIPE(GR_QUAL_LOG)
RECIPE(GR_CNST_SET_CMD)
RECIPE(GR_ALM_GET)
RECIPE(GR_ALM)
RECIPE(GR_ALM_SET)
RECIPE(GR_EPHM_GET)
RECIPE(GR_EPHM)
RECIPE(GR_EPHM_SET)
RECIPE(GR_AGPS_SERVER_STATE_GET)
RECIPE(GR_AGPS_SERVER_STATE)
RECIPE(GR_AGPS_SERVER_STATE_SET)
RECIPE(GR_IONO)
RECIPE(GR_UTC)


#include "tsync_recipe_undef.h"
