
#ifndef _defined_TSYNC_FR_SERVICES_H
#define _defined_TSYNC_FR_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_fr_services.h
**
**  Date:       09/09/09
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2009 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              09/09/2009 Creation
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_FR                     0x3A
#define TSYNC_ID_FR_CA_VALIDITY         0x01
#define TSYNC_ID_FR_CA_FREQUENCY        0x02
#define TSYNC_ID_FR_CA_NUM_INST         0x03
#define TSYNC_ID_FR_CA_REF_ID           0x04
#define TSYNC_ID_FR_CA_REF_MODE         0x05

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define FR_VALUE_FIELDS           \
    TSYNC_X(uint32_t, value)

#define FR_FREQ_SET_CMD_FIELDS    \
    TSYNC_X(uint32_t, inst)       \
    TSYNC_X(uint32_t, freq)

#define FR_MODE_GET_RESP_FIELDS     \
    TSYNC_X(FR_MODE,  mode)

#define FR_MODE_SET_CMD_FIELDS      \
    TSYNC_X(uint32_t, inst)         \
    TSYNC_X(FR_MODE,  mode)


#include "tsync_struct_define.h"

GEN_STRUCT(FR_VALUE)
GEN_STRUCT(FR_FREQ_SET_CMD)
GEN_STRUCT(FR_MODE_GET_RESP)
GEN_STRUCT(FR_MODE_SET_CMD)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_FR_SERVICES_H */
