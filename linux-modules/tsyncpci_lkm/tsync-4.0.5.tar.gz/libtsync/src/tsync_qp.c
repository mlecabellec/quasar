#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_qp_services.h"
#include "tsync_cs_services.h"

extern uint8_t QP_VALUE_RECIPE[];
extern uint8_t QP_SET_CMD_RECIPE[];
extern uint8_t QP_INT_VALUE_RECIPE[];
extern uint8_t QP_INT_SET_CMD_RECIPE[];
extern uint8_t ML_CLK_LOCAL_RECIPE[];
extern uint8_t QP_LOCAL_SET_CMD_RECIPE[];
extern uint8_t ML_TIME_SCALE_OBJ_RECIPE[];
extern uint8_t QP_TIME_SCALE_SET_CMD_RECIPE[];

TSYNC_ERROR
TSYNC_QP_getSigCtrl(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    SIG_CTL *sig)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(sig);

        struct QP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_SIG_CTL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_VALUE_RECIPE,
            QP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QP_VALUE* outPayload =
            (QP_VALUE*)GetPayload(result);

        *sig = (SIG_CTL)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_setSigCtrl(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    SIG_CTL sig)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = sig;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_SIG_CTL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_getExtSigCtrl(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    SIG_CTL *sig)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(sig);

        struct QP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_EXTSIG_CTL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_VALUE_RECIPE,
            QP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QP_VALUE* outPayload =
            (QP_VALUE*)GetPayload(result);

        *sig = (SIG_CTL)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_setExtSigCtrl(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    SIG_CTL sig)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = sig;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_EXTSIG_CTL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_getOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *nOffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nOffset);

        struct QP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QP_INT_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_VALUE_RECIPE,
            QP_INT_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QP_INT_VALUE* outPayload =
            (QP_INT_VALUE*)GetPayload(result);

        *nOffset = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_setOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int nOffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QP_INT_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = nOffset;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_INT_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_INT_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_getExtOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *nOffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nOffset);

        struct QP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QP_INT_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_EXTOFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_VALUE_RECIPE,
            QP_INT_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QP_INT_VALUE* outPayload =
            (QP_INT_VALUE*)GetPayload(result);

        *nOffset = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_setExtOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int nOffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QP_INT_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = nOffset;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_INT_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_EXTOFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_INT_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_getBs(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int *bs)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(bs);

        struct QP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_BS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_VALUE_RECIPE,
            QP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QP_VALUE* outPayload =
            (QP_VALUE*)GetPayload(result);

        *bs = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_setBs(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int bs)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = bs;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_BS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_getLocal(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_LocalClockObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct QP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(ML_CLK_LOCAL_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_LOCAL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_VALUE_RECIPE,
            ML_CLK_LOCAL_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct ML_CLK_LOCAL* outPayload =
            (ML_CLK_LOCAL*)GetPayload(result);

        pObj->rule.ref = outPayload->ref;
        pObj->rule.in.month = outPayload->in.month;
        pObj->rule.in.wom = outPayload->in.wom;
        pObj->rule.in.dow = outPayload->in.dow;
        pObj->rule.in.hour = outPayload->in.hour;
        pObj->rule.out.month = outPayload->out.month;
        pObj->rule.out.wom = outPayload->out.wom;
        pObj->rule.out.dow = outPayload->out.dow;
        pObj->rule.out.hour = outPayload->out.hour;
        pObj->rule.offset = outPayload->offset;
        pObj->tz = outPayload->tz;

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_setLocal(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_LocalClockObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QP_LOCAL_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.ref = pObj->rule.ref;
        inPayload.in.month = pObj->rule.in.month;
        inPayload.in.wom = pObj->rule.in.wom;
        inPayload.in.dow = pObj->rule.in.dow;
        inPayload.in.hour = pObj->rule.in.hour;
        inPayload.out.month = pObj->rule.out.month;
        inPayload.out.wom = pObj->rule.out.wom;
        inPayload.out.dow = pObj->rule.out.dow;
        inPayload.out.hour = pObj->rule.out.hour;
        inPayload.offset = pObj->rule.offset;
        inPayload.tz = pObj->tz;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_LOCAL_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_LOCAL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_LOCAL_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_getFormat(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    QL_FMT *format)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(format);

        struct QP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_FORMAT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_VALUE_RECIPE,
            QP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QP_VALUE* outPayload =
            (QP_VALUE*)GetPayload(result);

        *format = (QL_FMT)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_setFormat(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    QL_FMT format)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = format;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_FORMAT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_getExtFormat(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    QL_FMT *format)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(format);

        struct QP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_EXTFORMAT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_VALUE_RECIPE,
            QP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QP_VALUE* outPayload =
            (QP_VALUE*)GetPayload(result);

        *format = (QL_FMT)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_setExtFormat(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    QL_FMT format)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = format;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_EXTFORMAT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_getTimeScale(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_TimeScaleObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    struct QP_VALUE inPayload;
    inPayload.value = nInstance;

    uint16_t ctl = 0x00;//get
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(QP_VALUE_RECIPE, &pos);

    pos = 0;
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(ML_TIME_SCALE_OBJ_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_QP,
        TSYNC_ID_QP_CA_TIME_SCALE,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        QP_VALUE_RECIPE,
        ML_TIME_SCALE_OBJ_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    struct ML_TIME_SCALE_OBJ* outPayload =
        (ML_TIME_SCALE_OBJ*)GetPayload(result);

    pObj->scale = outPayload->scale;

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_setTimeScale(
    TSYNC_BoardHandle   hnd,
    unsigned int nInstance,
    TSYNC_TimeScaleObj *pObj)
{
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    struct QP_TIME_SCALE_SET_CMD inPayload;
    inPayload.inst = nInstance;
    inPayload.scale.scale = pObj->scale;

    uint16_t ctl = 0x02;//set
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(QP_TIME_SCALE_SET_CMD_RECIPE, &pos);

    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(0));

    TSYNC_ERROR err = BaseTransaction(
        TSYNC_ID_QP,
        TSYNC_ID_QP_CA_TIME_SCALE,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        QP_TIME_SCALE_SET_CMD_RECIPE,
        NULL,
        result,
        handle);

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_getExtTimeScale(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_TimeScaleObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    struct QP_VALUE inPayload;
    inPayload.value = nInstance;

    uint16_t ctl = 0x00;//get
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(QP_VALUE_RECIPE, &pos);

    pos = 0;
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(ML_TIME_SCALE_OBJ_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_QP,
        TSYNC_ID_QP_CA_EXTTIME_SCALE,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        QP_VALUE_RECIPE,
        ML_TIME_SCALE_OBJ_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    struct ML_TIME_SCALE_OBJ* outPayload =
        (ML_TIME_SCALE_OBJ*)GetPayload(result);

    pObj->scale = outPayload->scale;

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_setExtTimeScale(
    TSYNC_BoardHandle   hnd,
    unsigned int nInstance,
    TSYNC_TimeScaleObj *pObj)
{
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    struct QP_TIME_SCALE_SET_CMD inPayload;
    inPayload.inst = nInstance;
    inPayload.scale.scale = pObj->scale;

    uint16_t ctl = 0x02;//set
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(QP_TIME_SCALE_SET_CMD_RECIPE, &pos);

    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(0));

    TSYNC_ERROR err = BaseTransaction(
        TSYNC_ID_QP,
        TSYNC_ID_QP_CA_EXTTIME_SCALE,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        QP_TIME_SCALE_SET_CMD_RECIPE,
        NULL,
        result,
        handle);

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_getNumInst(
    TSYNC_BoardHandle hnd,
    unsigned int *nInstances)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nInstances);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_NUM_INST,
            ctl,
            pyldLen,
            NULL,
            NULL,
            QP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QP_VALUE* outPayload =
            (QP_VALUE*)GetPayload(result);

        *nInstances = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_getTfd(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int *tfd)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(tfd);

        struct QP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_TFD,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_VALUE_RECIPE,
            QP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QP_VALUE* outPayload =
            (QP_VALUE*)GetPayload(result);

        *tfd = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_setTfd(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int tfd)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = tfd;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_TFD,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_getTfdState(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int *tfd)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(tfd);

        struct QP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_TFD_STATE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_VALUE_RECIPE,
            QP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QP_VALUE* outPayload =
            (QP_VALUE*)GetPayload(result);

        *tfd = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_setTfdState(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int tfd)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = tfd;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_TFD_STATE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_getTfom(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int *tfom)
{
   TSYNC_ERROR err = TSYNC_SUCCESS;

   TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(tfom);

        struct QP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_TFOM,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_VALUE_RECIPE,
            QP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QP_VALUE* outPayload =
            (QP_VALUE*)GetPayload(result);

        *tfom = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_getRequiredTfom(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int *tfom)
{
   TSYNC_ERROR err = TSYNC_SUCCESS;

   TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(tfom);

        struct QP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_REQUIRED_TFOM,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_VALUE_RECIPE,
            QP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QP_VALUE* outPayload =
            (QP_VALUE*)GetPayload(result);

        *tfom = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_setRequiredTfom(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int tfom)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = tfom;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_REQUIRED_TFOM,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_getExtTfom(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int *tfom)
{
   TSYNC_ERROR err = TSYNC_SUCCESS;

   TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(tfom);

        struct QP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_EXTTFOM,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_VALUE_RECIPE,
            QP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QP_VALUE* outPayload =
            (QP_VALUE*)GetPayload(result);

        *tfom = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_getElecType(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    ELEC_TYPE *et)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(et);

        struct QP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_ELECTYPE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_VALUE_RECIPE,
            QP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QP_VALUE* outPayload =
            (QP_VALUE*)GetPayload(result);

        *et = (ELEC_TYPE)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_setElecType(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    ELEC_TYPE et)
{
   TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = et;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_ELECTYPE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_QP_getExtElecType(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    ELEC_TYPE *et)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(et);

        struct QP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_EXTELECTYPE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_VALUE_RECIPE,
            QP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QP_VALUE* outPayload =
            (QP_VALUE*)GetPayload(result);

        *et = (ELEC_TYPE)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_setExtElecType(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    ELEC_TYPE et)
{
   TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = et;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_EXTELECTYPE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_QP_getLevel(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    SIG_LEVEL *sl)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(sl);

        struct QP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_LEVEL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_VALUE_RECIPE,
            QP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QP_VALUE* outPayload =
            (QP_VALUE*)GetPayload(result);

        *sl = (SIG_LEVEL)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_setLevel(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    SIG_LEVEL sl)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = sl;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_LEVEL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_QP_getPpsSigCtrl(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    SIG_CTL *sig)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(sig);

        struct QP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_PPS_SIG_CTL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_VALUE_RECIPE,
            QP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QP_VALUE* outPayload =
            (QP_VALUE*)GetPayload(result);

        *sig = (SIG_CTL)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_setPpsSigCtrl(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    SIG_CTL sig)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = sig;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_PPS_SIG_CTL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_getPpsElecType(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    ELEC_TYPE *et)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(et);

        struct QP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_PPS_ELECTYPE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_VALUE_RECIPE,
            QP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QP_VALUE* outPayload =
            (QP_VALUE*)GetPayload(result);

        *et = (ELEC_TYPE)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_setPpsElecType(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    ELEC_TYPE et)
{
   TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = et;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_PPS_ELECTYPE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}
        
TSYNC_ERROR
TSYNC_QP_getPpsOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *nOffset)
{
   TSYNC_ERROR err = TSYNC_SUCCESS;

   TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nOffset);

        struct QP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QP_INT_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_PPS_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_VALUE_RECIPE,
            QP_INT_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QP_INT_VALUE* outPayload =
            (QP_INT_VALUE*)GetPayload(result);

        *nOffset = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_setPpsOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int nOffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QP_INT_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = nOffset;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_INT_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_PPS_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_INT_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}
TSYNC_ERROR
TSYNC_QP_getPpsEdge(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    EDGE* edge)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(edge);

        struct QP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_PPS_EDGE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_VALUE_RECIPE,
            QP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QP_VALUE* outPayload =
            (QP_VALUE*)GetPayload(result);

        *edge = (EDGE)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_setPpsEdge(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    EDGE edge)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = edge;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_PPS_EDGE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_getPpsPw(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int *pw)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pw);

        struct QP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_PPS_PW,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_VALUE_RECIPE,
            QP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QP_VALUE* outPayload =
            (QP_VALUE*)GetPayload(result);

        *pw = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QP_setPpsPw(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int pw)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = pw;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QP,
            TSYNC_ID_QP_CA_PPS_PW,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

