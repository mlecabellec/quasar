
#ifndef _defined_TSYNC_PTR_SERVICES_H
#define _defined_TSYNC_PTR_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_ptr_services.h
**
**  Date:       02/15/10
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2010 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              02/15/2010 Creation  DPR
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_PTR                          0x3B
#define TSYNC_ID_PTR_CA_MODULE_INFO           0x01
#define TSYNC_ID_PTR_CA_ETHERNET_ITF          0x02
#define TSYNC_ID_PTR_CA_PTP_CLOCK_SETTINGS    0x03
#define TSYNC_ID_PTR_CA_PTP_UNIT_SETTINGS     0x04
#define TSYNC_ID_PTR_CA_PTP_PORT_STATE        0x05
#define TSYNC_ID_PTR_CA_PTP_PORT_SETTINGS     0x06
#define TSYNC_ID_PTR_CA_PTP_CLOCK_QUALITY     0x07
#define TSYNC_ID_PTR_CA_PTP_TIME_PROPERTIES   0x08
#define TSYNC_ID_PTR_CA_PTP_PARENT_PROPERTIES 0x09
#define TSYNC_ID_PTR_CA_PTP_GM_PROPERTIES     0x0A
#define TSYNC_ID_PTR_CA_TOD_SETTINGS          0x0B
#define TSYNC_ID_PTR_CA_PPS_ENABLED           0x0C
#define TSYNC_ID_PTR_CA_PPS_RISING_EDGE       0x0D
#define TSYNC_ID_PTR_CA_SAVE_SETTINGS_TO_ROM  0x0E
#define TSYNC_ID_PTR_CA_RESET_MODULE          0x0F
#define TSYNC_ID_PTR_CA_NUM_INST              0x10
#define TSYNC_ID_PTR_CA_REINIT_MODULE         0x11
#define TSYNC_ID_PTR_CA_VALIDITY              0x12
#define TSYNC_ID_PTR_CA_MODE                  0x13
#define TSYNC_ID_PTR_CA_MAC_ADDR              0x14
#define TSYNC_ID_PTR_CA_MASTER_ACTIVE         0x15
#define TSYNC_ID_PTR_CA_MODULE_STATUS         0x16
#define TSYNC_ID_PTR_CA_PTP_USER_DESCRIPTION  0x17
#define TSYNC_ID_PTR_CA_CLOCK_PROPERTIES      0x18
#define TSYNC_ID_PTR_CA_REF_ID                0x19
#define TSYNC_ID_PTR_CA_DEBUG_OUTPUT          0x1A
#define TSYNC_ID_PTR_CA_ETHERNET_STATUS       0x1B
#define TSYNC_ID_PTR_CA_SYNC_ETHERNET_ITF     0x1C
#define TSYNC_ID_PTR_CA_PTP_ITF               0x1D
#define TSYNC_ID_PTR_CA_FTP_ITF               0x1E
#define TSYNC_ID_PTR_CA_PTP_STATISTICS        0x1F
#define TSYNC_ID_PTR_CA_START                 0x20
#define TSYNC_ID_PTR_CA_DATA                  0x21
#define TSYNC_ID_PTR_CA_END                   0x22
#define TSYNC_ID_PTR_CA_CANCEL                0x23
#define TSYNC_ID_PTR_CA_STATE                 0x24
#define TSYNC_ID_PTR_CA_BOOT_IMG              0x25
//-------- YS --------------------------------------
#define TSYNC_ID_PTR_CA_UNCT_MASTER_ADD       0x26
#define TSYNC_ID_PTR_CA_UNCT_SLAVE_PROP       0x27
#define TSYNC_ID_PTR_CA_UNCT_MASTER_PROP      0x28
#define TSYNC_ID_PTR_CA_VLAN_ITF              0x29



/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define PTR_VALUE_FIELDS                           \
    TSYNC_X( uint32_t,         value)              \
    
    
#define PTR_VALUE_SET_CMD_FIELDS                   \
    TSYNC_X( uint32_t,         nInstance)          \
    TSYNC_X( uint32_t,         value)
    
#define PTR_MODULE_INFO_FIELDS                     \
    TSYNC_X( uint32_t,         ptpVersionNumber)   \
    TSYNC_X( uint32_t,         softwareVersion)    \
    TSYNC_X( int8_t,           hardwareVersion)    \
    TSYNC_X_BUFFER( int8_t,    filler,         3)  \
    TSYNC_X_BUFFER( int8_t,    softDate,      12)  \
    TSYNC_X_BUFFER( int8_t,    softTime,       9)  \
    TSYNC_X_BUFFER( int8_t,    filler2,        3)
    
#define PTR_ETH_INFO_FIELDS                        \
    TSYNC_X( uint32_t,         dhcpEnabled)        \
    TSYNC_X_BUFFER( uint8_t,   staticIpAddr,   4)  \
    TSYNC_X_BUFFER( uint8_t,   netMask,        4)  \
    TSYNC_X_BUFFER( uint8_t,   defaultGateway, 4)  
    
#define PTR_ETH_INFO_SET_CMD_FIELDS                \
    TSYNC_X( uint32_t,         nInstance)          \
    PTR_ETH_INFO_FIELDS
    
#define PTR_CLK_SETTINGS_FIELDS                    \
    TSYNC_X( int32_t,          ptpClockRunning)    \
    TSYNC_X( int32_t,          usingExternalClock)
    
#define PTR_CLK_SETTINGS_SET_CMD_FIELDS            \
    TSYNC_X( uint32_t,         nInstance)          \
    PTR_CLK_SETTINGS_FIELDS
    
#define PTL_UNIT_SETTINGS_FIELDS                   \
    TSYNC_X_BUFFER( uint8_t,   clockIdentity,  8)  \
    TSYNC_X( int32_t,          oneStepMode)        \
    TSYNC_X( uint32_t,         domainNumber)       \
    TSYNC_X( uint32_t,         priority1)          \
    TSYNC_X( uint32_t,         priority2)          \
    TSYNC_X( int32_t,          forcedHoldover)            
    
#define PTL_UNIT_SETTINGS_SET_CMD_FIELDS           \
    TSYNC_X( uint32_t,         nInstance)          \
    PTL_UNIT_SETTINGS_FIELDS 
    
#define PTL_PORT_STATE_FIELDS                      \
    TSYNC_X( uint32_t,         portNumber)         \
    TSYNC_X( int32_t,          portEnabled)        \
    TSYNC_X( PTL_PTP_STATE,    portState)          \
    TSYNC_X( int32_t,          linkConnected)      \
    TSYNC_X( int32_t,          slaveLogAnn)        \
    TSYNC_X( int32_t,          slaveLogSync)       \
    TSYNC_X( int32_t,          slaveLogDelayReq)   \
    TSYNC_X( int32_t,          slaveOneStepMode)   
    
#define PTL_PORT_STATE_SET_CMD_FIELDS              \
    TSYNC_X( uint32_t,         nInstance)          \
    PTL_PORT_STATE_FIELDS

#define PTL_PORT_SETTINGS_FIELDS                        \
    TSYNC_X(uint32_t,          portNumber)              \
    TSYNC_X(uint32_t,          annRcptTimeout)          \
    TSYNC_X(int32_t,           logAnnInterval)          \
    TSYNC_X(int32_t,           logSyncInterval)         \
    TSYNC_X(int32_t,           logDelayReqInterval)     \
    TSYNC_X(int32_t,           logPeerDelayReqInterval) \
    TSYNC_X(PTL_DELAY_MECH,    delayMechanism)          \
	TSYNC_X( uint32_t,         syncTimeout)             \
	TSYNC_X( uint32_t,         delayRespTimeout)
    
#define PTL_PORT_SETTINGS_SET_CMD_FIELDS           \
    TSYNC_X( uint32_t,         nInstance)          \
    PTL_PORT_SETTINGS_FIELDS
    
#define PTL_CLK_QUALITY_FIELDS                          \
    TSYNC_X( int32_t,          clockClass)              \
    TSYNC_X( PTL_CLK_ACC,      clockAccuracy)           \
    TSYNC_X( uint32_t,         offsetScaledLogVariance) 
 
#define PTL_TIME_PROP_FIELDS                             \
    TSYNC_X( int32_t,          utcOffset)               \
    TSYNC_X( int32_t,          utcOffsetValid)          \
    TSYNC_X( int32_t,          forwardLeap)             \
    TSYNC_X( int32_t,          backwardLeap)            \
    TSYNC_X( int32_t,          timeTraceable)           \
    TSYNC_X( int32_t,          freqTraceable)           \
    TSYNC_X( int32_t,          ptpTimescale)            \
    TSYNC_X( PTL_TIME_SRC,     timeSource)
    
#define PTL_PARENT_PROP_FIELDS                          \
    TSYNC_X_BUFFER( uint8_t,   clockIdentity,  8)       \
    TSYNC_X( uint32_t,         portNumber)              \
    TSYNC_X( int32_t,          statsCalculated)         \
    TSYNC_X( uint32_t,         observedOSLV)            \
    TSYNC_X( uint32_t,         observedCPCR)
 
#define PTL_GM_PROP_FIELDS                              \
    TSYNC_X_BUFFER( uint8_t,   clockIdentity,  8)       \
    TSYNC_X_STRUCT( PTL_CLK_QUALITY,  clockQuality)     \
    TSYNC_X( uint32_t,         priority1)               \
    TSYNC_X( uint32_t,         priority2) 

#define PTL_TOD_SETTINGS_FIELDS                        \
    TSYNC_X( int32_t,          todEnabled         )    \
    TSYNC_X( uint32_t,         timeScale          )
    
#define PTL_TOD_SETTINGS_SET_CMD_FIELDS                \
    TSYNC_X( uint32_t,         nInstance)              \
    PTL_TOD_SETTINGS_FIELDS

#define PTL_MAC_ADDR_FIELDS                            \
    TSYNC_X_BUFFER( uint8_t,   macAddress,   8)

#define PTL_MAC_ADDR_SET_CMD_FIELDS                    \
    TSYNC_X( uint32_t,         nInstance)              \
    TSYNC_X_BUFFER( uint8_t,   macAddress,   8)        \
    TSYNC_X_BUFFER( uint8_t,   pw,           16)  

#define PTL_USER_DESC_FIELDS                           \
    TSYNC_X_BUFFER( uint8_t,   deviceName,     16)     \
    TSYNC_X_BUFFER( uint8_t,   deviceLocation, 16)

#define PTL_USER_DESC_SET_CMD_FIELDS                   \
    TSYNC_X( uint32_t,         nInstance)              \
    PTL_USER_DESC_FIELDS

#define PTL_DEBUG_OUTPUT_FIELDS                        \
    TSYNC_X( int32_t,          debugOutput)            \
    TSYNC_X( int32_t,          debugFilterOutput) 
    
#define PTL_DEBUG_OUTPUT_SET_CMD_FIELDS                \
    TSYNC_X( uint32_t,         nInstance)              \
    PTL_DEBUG_OUTPUT_FIELDS
 
#define PTL_ETH_STATUS_FIELDS                          \
    TSYNC_X_BUFFER( uint8_t,   ipAddress,      4)      \
    TSYNC_X_BUFFER( uint8_t,   netMask,        4)      \
    TSYNC_X_BUFFER( uint8_t,   gateway,        4)  
       
#define PTL_SYNC_ETHERNET_ITF_FIELDS                   \
    TSYNC_X( int32_t,          enableSyncE    )        \
    TSYNC_X( int32_t,          xmitSyncEClock )        \
	TSYNC_X( int32_t,          esmcEnable     )        \
    TSYNC_X( uint8_t,          ssmCode        )        \
	TSYNC_X_BUFFER( int8_t,    filler,      3)
#define PTL_SYNC_ETHERNET_ITF_SET_CMD_FIELDS           \
    TSYNC_X( uint32_t,         nInstance)              \
    PTL_SYNC_ETHERNET_ITF_FIELDS

#define PTL_PTP_ITF_FIELDS                             \
    TSYNC_X( uint32_t,         transProto)             \
    TSYNC_X( int32_t,          masterUnicast)          \
    TSYNC_X( int32_t,          slaveUnicast)           \
    TSYNC_X( uint8_t,          ttl)                    \
    TSYNC_X_BUFFER( int8_t,    filler,             3)  \
    TSYNC_X( int32_t,          mgtPortEna)    
    
#define PTL_PTP_ITF_SET_CMD_FIELDS                     \
    TSYNC_X( uint32_t,         nInstance)              \
    PTL_PTP_ITF_FIELDS     

#define PTL_FTP_ITF_FIELDS                             \
    TSYNC_X( int32_t,          ftpEnable)              
    
#define PTL_FTP_ITF_SET_CMD_FIELDS                     \
    TSYNC_X( uint32_t,         nInstance)              \
    PTL_FTP_ITF_FIELDS

#define PTL_PTP_STATISTICS_FIELDS                      \
    TSYNC_X( int32_t,          parentStats)            \
    TSYNC_X( int32_t,          clockStats)      
    
#define PTL_PTP_STATISTICS_SET_CMD_FIELDS              \
    TSYNC_X( uint32_t,         nInstance)              \
    PTL_PTP_STATISTICS_FIELDS   

#define PTL_PTP_CLOCK_PROPERTIES_FIELDS                \
    TSYNC_X( int64_t,          offFromMaster)          \
    TSYNC_X( int64_t,          meanPathDelay)          \
    TSYNC_X( uint16_t,         stepsRemoved)
	
#define PTL_PTP_UNCT_MASTER_ADD_FIELDS                      \
	TSYNC_X_BUFFER( uint8_t,   clockIdentity,  8        )   \
	TSYNC_X( uint32_t,         portNumber               )   \
	TSYNC_X_BUFFER( uint8_t,   staticIpAddr,   4        )   \
    TSYNC_X( int8_t,           logQuerySalveInterval    )   \
	TSYNC_X( int8_t,           filler1                  )   \
    TSYNC_X( uint16_t,         duationSlaveContracts    )   \
    TSYNC_X( int8_t,           logAnnSlaveInterval      )   \
    TSYNC_X( int8_t,           logSyncMasterInterval    )   \
	TSYNC_X( int8_t,           logDelayReqSlaveInterval )   \
	TSYNC_X( int8_t,           filler2                  )
			
		     
#define PTL_PTP_UNCT_MASTER_ADD_SET_CMD_FIELDS	    \
	TSYNC_X( uint32_t,         nInstance)           \
	PTL_PTP_UNCT_MASTER_ADD_FIELDS                               
	                                             
#define PTL_PTP_UNCT_MASTER_PROP_FIELDS                  \
    TSYNC_X ( int32_t,           negoEnabled          )  \
    TSYNC_X ( uint8_t,           nbSalveConnected     )  \
 	TSYNC_X_BUFFER( int8_t,      filler,           3  ) 
 
#define PTL_PTP_UNCT_SLAVE_PROP_FIELDS                       \
TSYNC_X( int32_t,            negoEnabled                 )   \
TSYNC_X_BUFFER( uint8_t,     contractAnnState, 16        )   \
TSYNC_X( uint16_t,           duationAnnContracts         )   \
TSYNC_X( uint16_t,           delayAnnContracts           )   \
TSYNC_X( int8_t,             logAnnMsgInterval           )   \
TSYNC_X_BUFFER( int8_t,      filler1,            3       )   \
TSYNC_X_BUFFER( uint8_t,     contractSyncState, 16       )   \
TSYNC_X( uint16_t,           duationSyncContracts        )   \
TSYNC_X( uint16_t,           delaySyncContracts          )   \
TSYNC_X( int8_t,             logSyncMsgInterval          )   \
TSYNC_X_BUFFER( int8_t,      filler2,            3       )   \
TSYNC_X_BUFFER( uint8_t,     contractDelayRespState, 16  )   \
TSYNC_X( uint16_t,           duationDelayRespContracts   )   \
TSYNC_X( uint16_t,           delayDelayRespContracts     )   \
TSYNC_X( int8_t,             logDelayRespMsgInterval     )   \
TSYNC_X_BUFFER( int8_t,      filler3,            3       ) 


#define PTL_PTP_VLAN_FIELDS                      \
TSYNC_X(int32_t,	vLanIntEnable            )   \
TSYNC_X(uint16_t,   vLanID                   )   \
TSYNC_X(int8_t, 	priorityCodePoint		 )   \
TSYNC_X(int8_t, 	filler           		 )

	
#define PTL_PTP_VLAN_SET_CMD_FIELDS                 \
    TSYNC_X( uint32_t,         nInstance)           \
    PTL_PTP_VLAN_FIELDS 



	
	
	
	
	
#include "tsync_struct_define.h"

GEN_STRUCT(PTR_VALUE)
GEN_STRUCT(PTR_VALUE_SET_CMD)
GEN_STRUCT(PTR_MODULE_INFO)
GEN_STRUCT(PTR_ETH_INFO)
GEN_STRUCT(PTR_ETH_INFO_SET_CMD)
GEN_STRUCT(PTR_CLK_SETTINGS)
GEN_STRUCT(PTR_CLK_SETTINGS_SET_CMD)
GEN_STRUCT(PTL_UNIT_SETTINGS)
GEN_STRUCT(PTL_UNIT_SETTINGS_SET_CMD)
GEN_STRUCT(PTL_PORT_STATE)
GEN_STRUCT(PTL_PORT_STATE_SET_CMD)
GEN_STRUCT(PTL_PORT_SETTINGS)
GEN_STRUCT(PTL_PORT_SETTINGS_SET_CMD)
GEN_STRUCT(PTL_CLK_QUALITY)
GEN_STRUCT(PTL_TIME_PROP)
GEN_STRUCT(PTL_PARENT_PROP)
GEN_STRUCT(PTL_GM_PROP)
GEN_STRUCT(PTL_TOD_SETTINGS)
GEN_STRUCT(PTL_TOD_SETTINGS_SET_CMD)
GEN_STRUCT(PTL_MAC_ADDR)
GEN_STRUCT(PTL_MAC_ADDR_SET_CMD)
GEN_STRUCT(PTL_USER_DESC)
GEN_STRUCT(PTL_USER_DESC_SET_CMD)
GEN_STRUCT(PTL_DEBUG_OUTPUT)
GEN_STRUCT(PTL_DEBUG_OUTPUT_SET_CMD)
GEN_STRUCT(PTL_ETH_STATUS)
GEN_STRUCT(PTL_SYNC_ETHERNET_ITF)
GEN_STRUCT(PTL_SYNC_ETHERNET_ITF_SET_CMD)
GEN_STRUCT(PTL_PTP_ITF)
GEN_STRUCT(PTL_PTP_ITF_SET_CMD)
GEN_STRUCT(PTL_FTP_ITF)
GEN_STRUCT(PTL_FTP_ITF_SET_CMD)
GEN_STRUCT(PTL_PTP_STATISTICS)
GEN_STRUCT(PTL_PTP_STATISTICS_SET_CMD)
GEN_STRUCT(PTL_PTP_CLOCK_PROPERTIES)
GEN_STRUCT(PTL_PTP_UNCT_MASTER_ADD)
GEN_STRUCT(PTL_PTP_UNCT_MASTER_ADD_SET_CMD)
GEN_STRUCT(PTL_PTP_UNCT_MASTER_PROP)
GEN_STRUCT(PTL_PTP_UNCT_SLAVE_PROP)
GEN_STRUCT(PTL_PTP_VLAN)
GEN_STRUCT(PTL_PTP_VLAN_SET_CMD)






#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_PTR_SERVICES_H */
