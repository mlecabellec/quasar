#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <tsync.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_sw_services.h"
#include "tsync_misc_services.h"

extern uint8_t SW_IO_SWITCH_VALUE_RECIPE[];
extern uint8_t SW_IO_SWITCH_GET_CMD_RECIPE[];

extern uint8_t SW_IO_SWITCH_OPTIONS_AMOUNT_VALUE_RECIPE[];

extern uint8_t SW_IO_SWITCH_OPTION_VALUE_RECIPE[];
extern uint8_t SW_IO_SWITCH_GET_OPTION_VALUE_RECIPE[];

extern uint8_t SW_IO_SWITCH_IO_NUM_VALUE_RECIPE[];

#define TSYNC_CTRL_GET 0x0000
#define TSYNC_CTRL_SET 0x0002

TSYNC_ERROR TSYNC_SW_getIOSwitch(TSYNC_BoardHandle pHandle, TSYNC_IOSwitchObj *sw, uint32_t io)
{
    CHECK_HANDLE(pHandle);
    CHECK_NOT_NULL(sw);

    TSYNC_ERROR err = TSYNC_SUCCESS;
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)pHandle;

    uint8_t pos = 0;
    uint32_t payloadLength = sizeofRecipe(SW_IO_SWITCH_GET_CMD_RECIPE, &pos);
    pos = 0;
    TSYNC_TransResult result = (TSYNC_TransResult)TSYNC_ALLOCA(SizeOfResult(sizeofRecipe(SW_IO_SWITCH_VALUE_RECIPE, &pos)));

    struct SW_IO_SWITCH_GET_CMD inputPayload;
    inputPayload.io = io;

    err = BaseTransaction(
        TSYNC_ID_SW,
        TSYNC_ID_SW_CA_SWITCH_IO,
        TSYNC_CTRL_GET,
        payloadLength,
        (uint8_t*) (&inputPayload),
        SW_IO_SWITCH_GET_CMD_RECIPE,
        SW_IO_SWITCH_VALUE_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err);
    struct SW_IO_SWITCH_VALUE *outputPayload = (SW_IO_SWITCH_VALUE*)GetPayload(result);
    memcpy(sw, outputPayload,sizeof(SW_IO_SWITCH_VALUE));

    return err;
}

TSYNC_ERROR TSYNC_SW_setIOSwitch(TSYNC_BoardHandle pHandle, uint8_t feature, uint8_t type, uint8_t io, uint8_t inst)
{
    CHECK_HANDLE(pHandle);
    TSYNC_ERROR err = TSYNC_SUCCESS;
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)pHandle;

    struct SW_IO_SWITCH_VALUE inPayload =
    {
        .feature  = feature,
        .type     = type,
        .io       = io,
        .instance = inst
    };

    uint8_t  pos = 0;
    uint32_t payloadLength = sizeofRecipe(SW_IO_SWITCH_VALUE_RECIPE, &pos);
    pos = 0;
    TSYNC_TransResult result = (TSYNC_TransResult)TSYNC_ALLOCA(SizeOfResult(sizeofRecipe(SW_IO_SWITCH_VALUE_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_SW,
        TSYNC_ID_SW_CA_SWITCH_IO,
        TSYNC_CTRL_SET,
        payloadLength,
        (uint8_t*) (&inPayload),
        SW_IO_SWITCH_VALUE_RECIPE,
        NULL,
        result,
        handle);

    CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR TSYNC_SW_getSwitchOptionsAmount(TSYNC_BoardHandle pHandle, uint32_t* optionsAmount)
{
    CHECK_HANDLE(pHandle);
    CHECK_NOT_NULL(optionsAmount);

    TSYNC_BoardObj* handle = (TSYNC_BoardObj*) pHandle;

    uint8_t pos = 0;
    uint32_t payloadLength = 0;

    TSYNC_TransResult result = (TSYNC_TransResult) TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(SW_IO_SWITCH_OPTIONS_AMOUNT_VALUE_RECIPE, &pos)));

    TSYNC_ERROR err = BaseTransaction(TSYNC_ID_SW,
                                      TSYNC_ID_SW_CA_SWITCH_OPTIONS_AMOUNT,
                                      TSYNC_CTRL_GET,
                                      payloadLength,
                                      NULL,
                                      NULL,
                                      SW_IO_SWITCH_OPTIONS_AMOUNT_VALUE_RECIPE,
                                      result,
                                      handle);

    CHECK_SUCCESS(err);

    struct SW_IO_SWITCH_OPTIONS_AMOUNT_VALUE* outputPayload = (SW_IO_SWITCH_OPTIONS_AMOUNT_VALUE*) GetPayload(result);
    memcpy(optionsAmount, outputPayload, sizeof(*optionsAmount));

    return err;
}

TSYNC_ERROR TSYNC_SW_getSwitchOption(TSYNC_BoardHandle pHandle, TSYNC_SwitchOptionObj* sw, uint32_t index)
{
    CHECK_HANDLE(pHandle);
    CHECK_NOT_NULL(sw);

    TSYNC_BoardObj* handle = (TSYNC_BoardObj*) pHandle;

    uint8_t pos = 0;
    uint32_t payloadLength = sizeofRecipe(SW_IO_SWITCH_GET_OPTION_VALUE_RECIPE, &pos);
    pos = 0;
    TSYNC_TransResult result = (TSYNC_TransResult) TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(SW_IO_SWITCH_OPTION_VALUE_RECIPE, &pos)));

    struct SW_IO_SWITCH_GET_OPTION_VALUE inputPayload;
    inputPayload.index = index;

    TSYNC_ERROR err = BaseTransaction(TSYNC_ID_SW,
                                      TSYNC_ID_SW_CA_SWITCH_GET_OPTION,
                                      TSYNC_CTRL_GET,
                                      payloadLength,
                                      (uint8_t*) (&inputPayload),
                                      SW_IO_SWITCH_GET_OPTION_VALUE_RECIPE,
                                      SW_IO_SWITCH_OPTION_VALUE_RECIPE,
                                      result,
                                      handle);

    CHECK_SUCCESS(err);

    struct SW_IO_SWITCH_OPTION_VALUE* outputPayload = (SW_IO_SWITCH_OPTION_VALUE*) GetPayload(result);

    memset(sw->value, 0, sizeof(sw->value));
    memcpy(sw->value, outputPayload->value, sizeof(outputPayload->value));

    return err;
}

TSYNC_ERROR TSYNC_SW_getSwitchIoNum(TSYNC_BoardHandle pHandle, uint32_t* ioNum)
{
    CHECK_HANDLE(pHandle);
    CHECK_NOT_NULL(ioNum);

    TSYNC_BoardObj* handle = (TSYNC_BoardObj*) pHandle;

    uint8_t pos = 0;
    uint32_t payloadLength = 0;

    TSYNC_TransResult result = (TSYNC_TransResult) TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(SW_IO_SWITCH_IO_NUM_VALUE_RECIPE, &pos)));

    TSYNC_ERROR err = BaseTransaction(TSYNC_ID_SW,
                                      TSYNC_ID_SW_CA_SWITCH_IO_NUM,
                                      TSYNC_CTRL_GET,
                                      payloadLength,
                                      NULL,
                                      NULL,
                                      SW_IO_SWITCH_IO_NUM_VALUE_RECIPE,
                                      result,
                                      handle);

    CHECK_SUCCESS(err);

    struct SW_IO_SWITCH_IO_NUM_VALUE* outputPayload = (SW_IO_SWITCH_IO_NUM_VALUE*) GetPayload(result);
    memcpy(ioNum, outputPayload, sizeof(*ioNum));

    return err;
}
