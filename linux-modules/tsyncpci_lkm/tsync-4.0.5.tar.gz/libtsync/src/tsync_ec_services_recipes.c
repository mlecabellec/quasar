
/***************************************************************************
**  Module:     tsync_ec_services_recipes.c
**
**  Date:       07/28/08
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/28/2008 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_ec_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(LED_GET_CMD)
RECIPE(LED_MODE_GET_RESP)
RECIPE(LED_MODE_SET_CMD)
RECIPE(LED_STATE_GET_RESP)
RECIPE(LED_STATE_SET_CMD)
RECIPE(LED_BLACKOUT_GET_RESP)
RECIPE(LED_BLACKOUT_SET_CMD)

#include "tsync_recipe_undef.h"
