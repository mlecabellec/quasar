#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_qr_services.h"
#include "tsync_cs_services.h"
#include "tsync_misc_services.h"

extern uint8_t QR_VALUE_RECIPE[];
extern uint8_t QR_INT_SET_CMD_RECIPE[];
extern uint8_t QR_SET_CMD_RECIPE[];
extern uint8_t EL_VALIDITY_RECIPE[];
extern uint8_t QR_FORMAT_SET_CMD_RECIPE[];
extern uint8_t ML_CLK_LOCAL_RECIPE[];
extern uint8_t QR_LOCAL_SET_CMD_RECIPE[];
extern uint8_t ML_TIME_SCALE_OBJ_RECIPE[];
extern uint8_t QR_TIME_SCALE_SET_CMD_RECIPE[];
extern uint8_t EL_REF_ID_RECIPE[];

TSYNC_ERROR
TSYNC_QR_getOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *nOffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nOffset);

        struct QR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_VALUE_RECIPE,
            QR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QR_VALUE* outPayload =
            (QR_VALUE*)GetPayload(result);

        *nOffset = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_setOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int nOffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QR_INT_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = nOffset;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_INT_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_INT_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_getExtOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *nOffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nOffset);

        struct QR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_EXTOFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_VALUE_RECIPE,
            QR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QR_VALUE* outPayload =
            (QR_VALUE*)GetPayload(result);

        *nOffset = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_setExtOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int nOffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QR_INT_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = nOffset;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_INT_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_EXTOFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_INT_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_getBs(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int *bs)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(bs);

        struct QR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_BS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_VALUE_RECIPE,
            QR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QR_VALUE* outPayload =
            (QR_VALUE*)GetPayload(result);

        *bs = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_setBs(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int bs)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QR_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = bs;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_BS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_getRefSelection(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int *refsel)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(refsel);

        struct QR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_REF_SELECTION,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_VALUE_RECIPE,
            QR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QR_VALUE* outPayload =
            (QR_VALUE*)GetPayload(result);

        *refsel = outPayload->value;

    return ( err );
}
TSYNC_ERROR
TSYNC_QR_setRefSelection(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int refsel)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QR_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = refsel;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_REF_SELECTION,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_getSelectedRef(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int *refsel)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(refsel);

        struct QR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_SELECTED_REF,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_VALUE_RECIPE,
            QR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QR_VALUE* outPayload =
            (QR_VALUE*)GetPayload(result);

        *refsel = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_getValidity(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *bTimeValid,
    int *bPpsValid)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(bTimeValid);
        CHECK_NOT_NULL(bPpsValid);

        struct QR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(EL_VALIDITY_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_VALIDITY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_VALUE_RECIPE,
            EL_VALIDITY_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct EL_VALIDITY* outPayload =
            (EL_VALIDITY*)GetPayload(result);

        *bTimeValid = outPayload->timeValid;
        *bPpsValid = outPayload->ppsValid;

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_getFormat(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    QL_FMT *format)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(format);

        struct QR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_FORMAT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_VALUE_RECIPE,
            QR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QR_VALUE* outPayload =
            (QR_VALUE*)GetPayload(result);

        *format = (QL_FMT)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_setFormat(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    QL_FMT format)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QR_FORMAT_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.format = format;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_FORMAT_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_FORMAT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_FORMAT_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_getExtFormat(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    QL_FMT *format)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(format);

        struct QR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_EXTFORMAT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_VALUE_RECIPE,
            QR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QR_VALUE* outPayload =
            (QR_VALUE*)GetPayload(result);

        *format = (QL_FMT)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_setExtFormat(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    QL_FMT format)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QR_FORMAT_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.format = format;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_FORMAT_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_EXTFORMAT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_FORMAT_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_getLocal(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_LocalClockObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct QR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(ML_CLK_LOCAL_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_LOCAL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_VALUE_RECIPE,
            ML_CLK_LOCAL_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct ML_CLK_LOCAL* outPayload =
            (ML_CLK_LOCAL*)GetPayload(result);

        pObj->rule.ref = outPayload->ref;
        pObj->rule.in.month = outPayload->in.month;
        pObj->rule.in.wom = outPayload->in.wom;
        pObj->rule.in.dow = outPayload->in.dow;
        pObj->rule.in.hour = outPayload->in.hour;
        pObj->rule.out.month = outPayload->out.month;
        pObj->rule.out.wom = outPayload->out.wom;
        pObj->rule.out.dow = outPayload->out.dow;
        pObj->rule.out.hour = outPayload->out.hour;
        pObj->rule.offset = outPayload->offset;
        pObj->tz = outPayload->tz;

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_setLocal(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_LocalClockObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QR_LOCAL_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.ref = pObj->rule.ref;
        inPayload.in.month = pObj->rule.in.month;
        inPayload.in.wom = pObj->rule.in.wom;
        inPayload.in.dow = pObj->rule.in.dow;
        inPayload.in.hour = pObj->rule.in.hour;
        inPayload.out.month = pObj->rule.out.month;
        inPayload.out.wom = pObj->rule.out.wom;
        inPayload.out.dow = pObj->rule.out.dow;
        inPayload.out.hour = pObj->rule.out.hour;
        inPayload.offset = pObj->rule.offset;
        inPayload.tz = pObj->tz;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_LOCAL_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_LOCAL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_LOCAL_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_getTimeScale(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_TimeScaleObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    struct QR_VALUE inPayload;
    inPayload.value = nInstance;

    uint16_t ctl = 0x00;//get
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(QR_VALUE_RECIPE, &pos);

    pos = 0;
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(ML_TIME_SCALE_OBJ_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_QR,
        TSYNC_ID_QR_CA_TIME_SCALE,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        QR_VALUE_RECIPE,
        ML_TIME_SCALE_OBJ_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    struct ML_TIME_SCALE_OBJ* outPayload =
        (ML_TIME_SCALE_OBJ*)GetPayload(result);

    pObj->scale = outPayload->scale;

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_setTimeScale (
    TSYNC_BoardHandle   hnd,
    unsigned int nInstance,
    TSYNC_TimeScaleObj *pObj)
{
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    struct QR_TIME_SCALE_SET_CMD inPayload;
    inPayload.inst = nInstance;
    inPayload.scale.scale = pObj->scale;

    uint16_t ctl = 0x02;//set
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(QR_TIME_SCALE_SET_CMD_RECIPE, &pos);

    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(0));

    TSYNC_ERROR err = BaseTransaction(
        TSYNC_ID_QR,
        TSYNC_ID_QR_CA_TIME_SCALE,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        QR_TIME_SCALE_SET_CMD_RECIPE,
        NULL,
        result,
        handle);

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_getExtTimeScale(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_TimeScaleObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    struct QR_VALUE inPayload;
    inPayload.value = nInstance;

    uint16_t ctl = 0x00;//get
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(QR_VALUE_RECIPE, &pos);

    pos = 0;
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(ML_TIME_SCALE_OBJ_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_QR,
        TSYNC_ID_QR_CA_EXTTIME_SCALE,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        QR_VALUE_RECIPE,
        ML_TIME_SCALE_OBJ_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    struct ML_TIME_SCALE_OBJ* outPayload =
        (ML_TIME_SCALE_OBJ*)GetPayload(result);

    pObj->scale = outPayload->scale;

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_setExtTimeScale (
    TSYNC_BoardHandle   hnd,
    unsigned int nInstance,
    TSYNC_TimeScaleObj *pObj)
{
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    struct QR_TIME_SCALE_SET_CMD inPayload;
    inPayload.inst = nInstance;
    inPayload.scale.scale = pObj->scale;

    uint16_t ctl = 0x02;//set
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(QR_TIME_SCALE_SET_CMD_RECIPE, &pos);

    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(0));

    TSYNC_ERROR err = BaseTransaction(
        TSYNC_ID_QR,
        TSYNC_ID_QR_CA_EXTTIME_SCALE,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        QR_TIME_SCALE_SET_CMD_RECIPE,
        NULL,
        result,
        handle);

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_getRefId(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_RefIdObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct QR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(EL_REF_ID_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_REF_ID,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_VALUE_RECIPE,
            EL_REF_ID_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct EL_REF_ID* outPayload =
            (EL_REF_ID*)GetPayload(result);
            
        memset(pObj->refid, '\0', sizeof(pObj->refid));
        memcpy(pObj->refid, outPayload->ref, sizeof(outPayload->ref));
        
    return ( err );
}

TSYNC_ERROR
TSYNC_QR_getNumInst(
    TSYNC_BoardHandle hnd,
    unsigned int *nInstances)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nInstances);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_NUM_INST,
            ctl,
            pyldLen,
            NULL,
            NULL,
            QR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QR_VALUE* outPayload =
            (QR_VALUE*)GetPayload(result);

        *nInstances = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_getTfd(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int  *tfd)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(tfd);

        struct QR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_TFD,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_VALUE_RECIPE,
            QR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QR_VALUE* outPayload =
            (QR_VALUE*)GetPayload(result);

        *tfd = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_setTfd(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int tfd)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QR_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = tfd;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_TFD,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_getTfdState(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int  *tfd)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(tfd);

        struct QR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_TFD_STATE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_VALUE_RECIPE,
            QR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QR_VALUE* outPayload =
            (QR_VALUE*)GetPayload(result);

        *tfd = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_setTfdState(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int tfd)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QR_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = tfd;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_TFD_STATE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_INT_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_getTfom(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int  *tfom)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(tfom);

        struct QR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_TFOM,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_VALUE_RECIPE,
            QR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QR_VALUE* outPayload =
            (QR_VALUE*)GetPayload(result);

        *tfom = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_getExtTfom(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int  *tfom)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(tfom);

        struct QR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_EXTTFOM,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_VALUE_RECIPE,
            QR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QR_VALUE* outPayload =
            (QR_VALUE*)GetPayload(result);

        *tfom = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_getElecType(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    ELEC_TYPE *et)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(et);

        struct QR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QR_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_ELECTYPE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_VALUE_RECIPE,
            QR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct QR_VALUE* outPayload =
            (QR_VALUE*)GetPayload(result);
            
        *et = (ELEC_TYPE)outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_QR_setElecType(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    ELEC_TYPE et)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QR_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = et;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_ELECTYPE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_QR_getExtElecType(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    ELEC_TYPE *et)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(et);

        struct QR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QR_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_EXTELECTYPE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_VALUE_RECIPE,
            QR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct QR_VALUE* outPayload =
            (QR_VALUE*)GetPayload(result);
            
        *et = (ELEC_TYPE)outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_QR_setExtElecType(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    ELEC_TYPE et)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QR_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = et;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_EXTELECTYPE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_QR_getPpsElecType(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    ELEC_TYPE *et)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(et);

        struct QR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QR_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_PPS_ELECTYPE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_VALUE_RECIPE,
            QR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct QR_VALUE* outPayload =
            (QR_VALUE*)GetPayload(result);
            
        *et = (ELEC_TYPE)outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_QR_setPpsElecType(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    ELEC_TYPE et)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QR_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = et;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_PPS_ELECTYPE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_QR_getPpsOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int  *offset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(offset);

        struct QR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_PPS_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_VALUE_RECIPE,
            QR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QR_VALUE* outPayload =
            (QR_VALUE*)GetPayload(result);

        *offset = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_setPpsOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int offset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QR_INT_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = offset;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_INT_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_PPS_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_INT_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_getPpsEdge(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    EDGE *edge)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(edge);

        struct QR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QR_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_PPS_EDGE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_VALUE_RECIPE,
            QR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct QR_VALUE* outPayload =
            (QR_VALUE*)GetPayload(result);
            
        *edge = (EDGE)outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_QR_setPpsEdge(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    EDGE edge)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QR_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = edge;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_PPS_EDGE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_INT_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_QR_getTfomThreshold(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int *tfom)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(tfom);

        struct QR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_TFOM_THRESHOLD,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_VALUE_RECIPE,
            QR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QR_VALUE* outPayload =
            (QR_VALUE*)GetPayload(result);

        *tfom = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_setTfomThreshold(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int tfom)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QR_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = tfom;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_TFOM_THRESHOLD,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_getExtTfomThreshold(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int *tfom)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(tfom);

        struct QR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(QR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_EXTTFOM_THRESHOLD,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_VALUE_RECIPE,
            QR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct QR_VALUE* outPayload =
            (QR_VALUE*)GetPayload(result);

        *tfom = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_QR_setExtTfomThreshold(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int tfom)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct QR_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = tfom;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(QR_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_QR,
            TSYNC_ID_QR_CA_EXTTFOM_THRESHOLD,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            QR_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}
