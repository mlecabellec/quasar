
/***************************************************************************
**  Module:     tsync_ms_services_recipes.c
**
**  Date:       08/05/08
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              08/05/2008 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_ms_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(MS_VALUE)
RECIPE(MS_SHARE_ITEM)
RECIPE(MS_DATA_SET_CMD)

#include "tsync_recipe_undef.h"
