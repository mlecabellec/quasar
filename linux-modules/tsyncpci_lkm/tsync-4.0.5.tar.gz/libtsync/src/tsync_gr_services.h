
#ifndef _defined_TSYNC_GR_SERVICES_H
#define _defined_TSYNC_GR_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_gr_services.h
**
**  Date:       07/29/08
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/29/2008 Creation
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_GR                       0x29
#define TSYNC_ID_GR_CA_OFFSET             0x00
#define TSYNC_ID_GR_CA_VALIDITY           0x02
#define TSYNC_ID_GR_CA_POSITION           0x03
#define TSYNC_ID_GR_CA_RCVR_MODE          0x04
#define TSYNC_ID_GR_CA_DYNAMICS           0x05
#define TSYNC_ID_GR_CA_FIX_DATA           0x06
#define TSYNC_ID_GR_CA_SAT_DATA           0x07
#define TSYNC_ID_GR_CA_SURVEY_PROG        0x08
#define TSYNC_ID_GR_CA_MFR_MDL            0x0B
#define TSYNC_ID_GR_CA_RCVR_INFO          0x0C
#define TSYNC_ID_GR_CA_CUSTOM_MSG         0x0D
#define TSYNC_ID_GR_CA_NUM_INST           0x0E
#define TSYNC_ID_GR_CA_DEL_POS            0x0F
#define TSYNC_ID_GR_CA_REF_ID             0x10
#define TSYNC_ID_GR_CA_RESET              0x11
#define TSYNC_ID_GR_CA_ANTENNA            0x12
#define TSYNC_ID_GR_CA_PARAMETER          0x13
#define TSYNC_ID_GR_CA_QUAL_LOG           0x14
#define TSYNC_ID_GR_CA_CNST               0x15
#define TSYNC_ID_GR_CA_ALM                0x16
#define TSYNC_ID_GR_CA_EPHM               0x17
#define TSYNC_ID_GR_CA_AGPS_TIME          0x18
#define TSYNC_ID_GR_CA_AGPS_SERVER_STATE  0x19
#define TSYNC_ID_GR_CA_IONO               0x20
#define TSYNC_ID_GR_CA_UTC                0x21

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define GR_VALUE_FIELDS                        \
    TSYNC_X( uint32_t,         value)

#define GR_VALIDITY_SET_CMD_FIELDS                 \
    TSYNC_X(        uint32_t,           nInstance) \
    TSYNC_X(        uint32_t,           timeValid) \
    TSYNC_X(        uint32_t,           ppsValid)

#define GR_OFFSET_SET_CMD_FIELDS                        \
    TSYNC_X( uint32_t,         nInstance)                        \
    TSYNC_X( uint32_t,         nOffset)

#define GR_POS_LLA_FIELDS                       \
    TSYNC_X( double,         lat)          \
    TSYNC_X( double,         lon)          \
    TSYNC_X( double,         alt)

// In the struct define below, the latitude, longitude, and altitude
// must be packed because the compiler will insert 4 bytes of padding
// after nInstance in order to 8-byte align the doubles.  Packing each
// double allows them to immediately follow the previous double, and ignore
// the requirement to 8-byte align the data.

#define GR_POS_LLA_SET_CMD_FIELDS             \
    TSYNC_X( uint32_t,       nInstance)       \
    TSYNC_X( double,         lat)             \
    TSYNC_X( double,         lon)             \
    TSYNC_X( double,         alt)

#define GR_RECMODE_SET_CMD_FIELDS           \
    TSYNC_X( uint32_t,         nInstance)   \
    TSYNC_X( GL_MODE,          mode)        \
    TSYNC_X( GL_DYN,           dyn)

#define GR_RECMODE_GET_CMD_FIELDS           \
    TSYNC_X( GL_MODE,          mode)        \
    TSYNC_X( GL_DYN,           dyn)

#define GR_DYNMODE_SET_CMD_FIELDS                        \
    TSYNC_X( uint32_t,         nInstance)                        \
    TSYNC_X( GL_DYN,           mode)

#define GR_FIX_DATA_FIELDS                  \
    TSYNC_X( uint32_t,       nSats)         \
    TSYNC_X( float,          pdop)          \
    TSYNC_X( float,          hdop)          \
    TSYNC_X( float,          vdop)          \
    TSYNC_X( float,          tdop)          \
    TSYNC_X( uint32_t,       fom)           \
    TSYNC_X( uint32_t,       tfom)          \
    TSYNC_X( uint32_t,       herr)          \
    TSYNC_X( uint32_t,       verr)

#define GL_SAT_INFO_FIELDS                  \
    TSYNC_X( uint32_t,       chnum)         \
    TSYNC_X( uint32_t,       svid)           \
    TSYNC_X( uint32_t,       str)          \
    TSYNC_X( uint32_t,       traim)          \
    TSYNC_X( uint32_t,       infix)          \
    TSYNC_X( uint32_t,       flags)

#define GR_SAT_DATA_FIELDS                  \
    TSYNC_X_ARRAY( GL_SAT_INFO,     info,       TSYNC_SAT_INFO_NUM)

#define GR_MFR_MDL_FIELDS                    \
    TSYNC_X_BUFFER(    int8_t,     mfr,    16)    \
    TSYNC_X_BUFFER(    int8_t,     mdl,    16)

#define GR_RCVR_INFO_FIELDS                    \
    TSYNC_X(            int32_t,    len)    \
    TSYNC_X_BUFFER(    int8_t,     info,    256)

#define GR_CUSTOM_MSG_FIELDS                    \
    TSYNC_X(            uint32_t,   len)    \
    TSYNC_X_BUFFER(     int8_t,     msg,    1000)

#define GR_CUSTOM_MSG_SET_CMD_FIELDS                    \
    TSYNC_X(            uint32_t,   nInstance)                        \
    TSYNC_X(            uint32_t,   len)    \
    TSYNC_X_BUFFER(     int8_t,     msg,    1000)

#define GR_RESET_CMD_FIELDS                                      \
    TSYNC_X( uint32_t,         nInstance)                        \
    TSYNC_X( GL_RESET,         reset)

#define GR_RCVR_PARM_GET_FIELDS                                      \
    TSYNC_X( uint32_t,         nInstance)                        \
    TSYNC_X(            uint32_t,   len)    \
    TSYNC_X(            GL_PARM,    parm)    \
    TSYNC_X_ARRAY( GR_VALUE,     cfg,       TSYNC_PARM_NUM)

#define GR_RCVR_PARM_FIELDS                    \
    TSYNC_X(            uint32_t,   len)    \
    TSYNC_X(            GL_PARM,    parm)    \
    TSYNC_X_ARRAY( GR_VALUE,     cfg,       TSYNC_PARM_NUM)

#define GR_RCVR_PARM_SET_FIELDS                    \
    TSYNC_X(            uint32_t,   nInstance)                        \
    TSYNC_X(            uint32_t,   len)    \
    TSYNC_X(            GL_PARM,    parm)    \
    TSYNC_X_ARRAY( GR_VALUE,     cfg,       TSYNC_PARM_NUM)

#define GR_QUAL_LOG_FIELDS                  \
    TSYNC_X_ARRAY( GR_VALUE,     ql,       TSYNC_QUAL_LOG_NUM)

	
#define GR_CNST_SET_CMD_FIELDS           \
    TSYNC_X( uint32_t,         nInstance)   \
    TSYNC_X( uint32_t,         constellation)

#define GR_ALM_GET_FIELDS                     \
    TSYNC_X( uint32_t,         nInstance )    \
    TSYNC_X( uint32_t,         prn       )

#define GR_ALM_FIELDS                         \
    TSYNC_X( uint32_t,         prn       )    \
    TSYNC_X( uint32_t,         svHealth  )    \
    TSYNC_X( uint32_t,         weekNumber)    \
    TSYNC_X( float,            e         )    \
    TSYNC_X( uint32_t,         toa       )    \
    TSYNC_X( float,            io        )    \
    TSYNC_X( float,            omegaDot  )    \
    TSYNC_X( float,            sqrtA     )    \
    TSYNC_X( float,            omega0    )    \
    TSYNC_X( float,            omega     )    \
    TSYNC_X( float,            m0        )    \
    TSYNC_X( float,            af0       )    \
    TSYNC_X( float,            af1       )

#define GR_ALM_SET_FIELDS                     \
    TSYNC_X( uint32_t,         nInstance )    \
    TSYNC_X( uint32_t,         prn       )    \
    TSYNC_X( uint32_t,         svHealth  )    \
    TSYNC_X( uint32_t,         weekNumber)    \
    TSYNC_X( float,            e         )    \
    TSYNC_X( uint32_t,         toa       )    \
    TSYNC_X( float,            io        )    \
    TSYNC_X( float,            omegaDot  )    \
    TSYNC_X( float,            sqrtA     )    \
    TSYNC_X( float,            omega0    )    \
    TSYNC_X( float,            omega     )    \
    TSYNC_X( float,            m0        )    \
    TSYNC_X( float,            af0       )    \
    TSYNC_X( float,            af1       )

#define GR_EPHM_GET_FIELDS                    \
    TSYNC_X( uint32_t,         nInstance   )  \
    TSYNC_X( uint32_t,         prn         )

#define GR_EPHM_FIELDS                        \
    TSYNC_X( uint32_t,         prn         )  \
    TSYNC_X( uint32_t,         svHealth    )  \
    TSYNC_X( float,            tephem      )  \
    TSYNC_X( uint32_t,         weekNumber  )  \
    TSYNC_X( uint32_t,         codeL2      )  \
    TSYNC_X( uint32_t,         L2Pdata     )  \
    TSYNC_X( uint32_t,         uraIdx      )  \
    TSYNC_X( uint32_t,         iodc        )  \
    TSYNC_X( float,            tgd         )  \
    TSYNC_X( float,            toc         )  \
    TSYNC_X( float,            af2         )  \
    TSYNC_X( float,            af1         )  \
    TSYNC_X( float,            af0         )  \
    TSYNC_X( float,            svAcc       )  \
    TSYNC_X( uint32_t,         iode        )  \
    TSYNC_X( uint32_t,         fit_interval)  \
    TSYNC_X( float,            crs         )  \
    TSYNC_X( float,            deltaN      )  \
    TSYNC_X( float,            m0          )  \
    TSYNC_X( float,            cuc         )  \
    TSYNC_X( float,            e           )  \
    TSYNC_X( float,            cus         )  \
    TSYNC_X( float,            sqrtA       )  \
    TSYNC_X( float,            toe         )  \
    TSYNC_X( float,            cic         )  \
    TSYNC_X( float,            omega0      )  \
    TSYNC_X( float,            cis         )  \
    TSYNC_X( float,            io          )  \
    TSYNC_X( float,            crc         )  \
    TSYNC_X( float,            omega       )  \
    TSYNC_X( float,            omegaDot    )  \
    TSYNC_X( float,            idot        )

#define GR_EPHM_SET_FIELDS                    \
    TSYNC_X( uint32_t,         nInstance   )  \
    TSYNC_X( uint32_t,         prn         )  \
    TSYNC_X( uint32_t,         svHealth    )  \
    TSYNC_X( float,            tephem      )  \
    TSYNC_X( uint32_t,         weekNumber  )  \
    TSYNC_X( uint32_t,         codeL2      )  \
    TSYNC_X( uint32_t,         L2Pdata     )  \
    TSYNC_X( uint32_t,         uraIdx      )  \
    TSYNC_X( uint32_t,         iodc        )  \
    TSYNC_X( float,            tgd         )  \
    TSYNC_X( float,            toc         )  \
    TSYNC_X( float,            af2         )  \
    TSYNC_X( float,            af1         )  \
    TSYNC_X( float,            af0         )  \
    TSYNC_X( float,            svAcc       )  \
    TSYNC_X( uint32_t,         iode        )  \
    TSYNC_X( uint32_t,         fit_interval)  \
    TSYNC_X( float,            crs         )  \
    TSYNC_X( float,            deltaN      )  \
    TSYNC_X( float,            m0          )  \
    TSYNC_X( float,            cuc         )  \
    TSYNC_X( float,            e           )  \
    TSYNC_X( float,            cus         )  \
    TSYNC_X( float,            sqrtA       )  \
    TSYNC_X( float,            toe         )  \
    TSYNC_X( float,            cic         )  \
    TSYNC_X( float,            omega0      )  \
    TSYNC_X( float,            cis         )  \
    TSYNC_X( float,            io          )  \
    TSYNC_X( float,            crc         )  \
    TSYNC_X( float,            omega       )  \
    TSYNC_X( float,            omegaDot    )  \
    TSYNC_X( float,            idot        )

#define GR_AGPS_SERVER_STATE_GET_FIELDS       \
    TSYNC_X( uint32_t,         nInstance )    \
    TSYNC_X( uint32_t,         bState)

#define GR_AGPS_SERVER_STATE_FIELDS           \
    TSYNC_X( uint32_t,         bState)

#define GR_AGPS_SERVER_STATE_SET_FIELDS       \
    TSYNC_X( uint32_t,         nInstance )    \
    TSYNC_X( uint32_t,         bState)
	
#define GR_IONO_FIELDS                        \
    TSYNC_X( float,            alpha0  )  \
    TSYNC_X( float,            alpha1  )  \
    TSYNC_X( float,            alpha2  )  \
    TSYNC_X( float,            alpha3  )  \
    TSYNC_X( float,            beta0   )  \
    TSYNC_X( float,            beta1   )  \
    TSYNC_X( float,            beta2   )  \
    TSYNC_X( float,            beta3   ) 

#define GR_UTC_FIELDS                      \
    TSYNC_X( double,           a0       )  \
    TSYNC_X( float,            a1       )  \
    TSYNC_X( int32_t,          deltaTls )  \
    TSYNC_X( float,            tot      )  \
    TSYNC_X( uint32_t,         wnt      )  \
    TSYNC_X( uint32_t,         wnlsf    )  \
    TSYNC_X( uint32_t,         dn       )  \
    TSYNC_X( int32_t,          deltaTlsf)


#include "tsync_struct_define.h"

GEN_STRUCT(GR_VALUE)
GEN_STRUCT(GR_VALIDITY_SET_CMD)
GEN_STRUCT(GR_POS_LLA)
GEN_STRUCT(GR_FIX_DATA)
GEN_STRUCT(GL_SAT_INFO)
GEN_STRUCT(GR_SAT_DATA)
GEN_STRUCT(GR_MFR_MDL)
GEN_STRUCT(GR_RCVR_INFO)
GEN_STRUCT(GR_CUSTOM_MSG)
GEN_STRUCT(GR_OFFSET_SET_CMD)
GEN_STRUCT(GR_POS_LLA_SET_CMD)
GEN_STRUCT(GR_RECMODE_SET_CMD)
GEN_STRUCT(GR_RECMODE_GET_CMD)
GEN_STRUCT(GR_DYNMODE_SET_CMD)
GEN_STRUCT(GR_CUSTOM_MSG_SET_CMD)
GEN_STRUCT(GR_RESET_CMD)
GEN_STRUCT(GR_RCVR_PARM_GET)
GEN_STRUCT(GR_RCVR_PARM)
GEN_STRUCT(GR_RCVR_PARM_SET)
GEN_STRUCT(GR_QUAL_LOG)
GEN_STRUCT(GR_CNST_SET_CMD)
GEN_STRUCT(GR_ALM_GET)
GEN_STRUCT(GR_ALM)
GEN_STRUCT(GR_ALM_SET)
GEN_STRUCT(GR_EPHM_GET)
GEN_STRUCT(GR_EPHM)
GEN_STRUCT(GR_EPHM_SET)
GEN_STRUCT(GR_AGPS_SERVER_STATE_GET)
GEN_STRUCT(GR_AGPS_SERVER_STATE)
GEN_STRUCT(GR_AGPS_SERVER_STATE_SET)
GEN_STRUCT(GR_IONO)
GEN_STRUCT(GR_UTC)


#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_GR_SERVICES_H */
