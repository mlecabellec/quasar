
#ifndef _defined_TSYNC_IN_SERVICES_H
#define _defined_TSYNC_IN_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_in_services.h
**
**  Date:       07/28/08
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/28/2008 Creation
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_IN                     0x20
#define TSYNC_ID_IN_CA_STATUS           0x00

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define IN_VALUE_FIELDS                   \
    TSYNC_X(        uint32_t,   value)

#define IN_RESULT_FIELDS                       \
    TSYNC_X_BUFFER( int8_t,         module,        32)          \
    TSYNC_X(        TSYNC_ERROR,    result)

#define IN_STATUS_FIELDS                   \
    TSYNC_X(        uint32_t,   page)          \
    TSYNC_X(        uint32_t,   more)          \
    TSYNC_X_ARRAY(  IN_RESULT,  results, TSYNC_INIT_RESULT_NUM)


#include "tsync_struct_define.h"

GEN_STRUCT(IN_VALUE)
GEN_STRUCT(IN_RESULT)
GEN_STRUCT(IN_STATUS)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_IN_SERVICES_H */
