
#ifndef _defined_TSYNC_IR_SERVICES_H
#define _defined_TSYNC_IR_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_ir_services.h
**
**  Date:       08/04/08
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              08/04/2008 Creation
**
****************************************************************************/

#include "tsync_cs_services.h"

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_IR                     0x2A
#define TSYNC_ID_IR_CA_OFFSET           0x00
#define TSYNC_ID_IR_CA_VALIDITY         0x02
#define TSYNC_ID_IR_CA_MODE             0x03
#define TSYNC_ID_IR_CA_FORMAT           0x04
#define TSYNC_ID_IR_CA_MOD              0x05
#define TSYNC_ID_IR_CA_FRQ              0x06
#define TSYNC_ID_IR_CA_CODED_EXP        0x07
#define TSYNC_ID_IR_CA_CTRL_FLD         0x08
#define TSYNC_ID_IR_CA_MESSAGE          0x09
#define TSYNC_ID_IR_CA_NUM_INST         0x0A
#define TSYNC_ID_IR_CA_CFDATA           0x0B
#define TSYNC_ID_IR_CA_LOCAL            0x0C
#define TSYNC_ID_IR_CA_TIME_SCALE       0x0D
#define TSYNC_ID_IR_CA_REF_ID           0x0E
#define TSYNC_ID_IR_CA_TYPE             0x0F

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define IR_VALUE_FIELDS                   \
    TSYNC_X(        uint32_t,   value)

#define IR_OFFSET_SET_CMD_FIELDS                   \
    TSYNC_X(        uint32_t,   inst)          \
    TSYNC_X(        int32_t,   offset)

#define IR_MODE_SET_CMD_FIELDS                   \
    TSYNC_X(        uint32_t,   inst)          \
    TSYNC_X(        IL_MODE,    mode)

#define IR_FORMAT_SET_CMD_FIELDS                   \
    TSYNC_X(        uint32_t,   inst)          \
    TSYNC_X(        IL_FMT,     format)

#define IR_MOD_SET_CMD_FIELDS                   \
    TSYNC_X(        uint32_t,   inst)          \
    TSYNC_X(        IL_MOD,     mod)

#define IR_FREQ_SET_CMD_FIELDS                   \
    TSYNC_X(        uint32_t,   inst)          \
    TSYNC_X(        IL_FRQ,     freq)

#define IR_CE_SET_CMD_FIELDS                   \
    TSYNC_X(        uint32_t,   inst)          \
    TSYNC_X(        IL_CE,      ce)

#define IR_CF_SET_CMD_FIELDS                   \
    TSYNC_X(        uint32_t,   inst)          \
    TSYNC_X(        IL_CF,      cf)

#define IR_SHORT_FIELDS                   \
    TSYNC_X(        uint16_t,   value)

#define IR_MSG_FIELDS                   \
    TSYNC_X_ARRAY(  IR_SHORT,   subframes,    TSYNC_IR_SUBFRAME_NUM)

#define IR_MSG_SET_CMD_FIELDS                   \
    TSYNC_X(        uint32_t,   inst)          \
    TSYNC_X_ARRAY(  IR_SHORT,   subframes,    TSYNC_IR_SUBFRAME_NUM)

#define IR_CFDATA_FIELDS                   \
    TSYNC_X_ARRAY(  IR_SHORT,   cfData,    TSYNC_IR_CFDATA_NUM)

#define IR_LOCAL_SET_CMD_FIELDS         \
    TSYNC_X(        uint32_t,       inst)   \
    TSYNC_X( ML_DST_REF,     ref)                \
    TSYNC_X_STRUCT( ML_DST_POINT,    in)                \
    TSYNC_X_STRUCT( ML_DST_POINT,    out)                \
    TSYNC_X( uint32_t,    offset)                        \
    TSYNC_X( int32_t,        tz)

#define IR_TIME_SCALE_SET_CMD_FIELDS         \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X_STRUCT( ML_TIME_SCALE_OBJ,  scale)

/*
typedef struct
{
    UINT16 subP0; // Sub-frame P0 from current second
    UINT16 subP1; // Sub-frame P1 from current second
    UINT16 subP2; // Sub-frame P2 from current second
    UINT16 subP3; // Sub-frame P3 from current second
    UINT16 subP4; // Sub-frame P4 from current second
    UINT16 subP5; // Sub-frame P5 from current second
    UINT16 subP6; // Sub-frame P6 from previous second
    UINT16 subP7; // Sub-frame P7 from previous second
    UINT16 subP8; // Sub-frame P8 from previous second
    UINT16 subP9; // Sub-frame P9 from previous second
    } IR_MSG;
*/

#include "tsync_struct_define.h"

GEN_STRUCT(IR_VALUE)
GEN_STRUCT(IR_OFFSET_SET_CMD)
GEN_STRUCT(IR_MODE_SET_CMD)
GEN_STRUCT(IR_FORMAT_SET_CMD)
GEN_STRUCT(IR_MOD_SET_CMD)
GEN_STRUCT(IR_FREQ_SET_CMD)
GEN_STRUCT(IR_CE_SET_CMD)
GEN_STRUCT(IR_CF_SET_CMD)
GEN_STRUCT(IR_SHORT)
GEN_STRUCT(IR_MSG)
GEN_STRUCT(IR_MSG_SET_CMD)
GEN_STRUCT(IR_CFDATA)
GEN_STRUCT(IR_LOCAL_SET_CMD)
GEN_STRUCT(IR_TIME_SCALE_SET_CMD)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_IR_SERVICES_H */
