
#ifndef _defined_TSYNC_EC_SERVICES_H
#define _defined_TSYNC_EC_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_ec_services.h
**
**  Date:       07/28/08
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/28/2008 Creation
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_EC                     0x37
#define TSYNC_ID_EC_CA_MODE             0x00
#define TSYNC_ID_EC_CA_STATE            0x01
#define TSYNC_ID_EC_CA_BLACKOUT         0x02

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define LED_GET_CMD_FIELDS                  \
    TSYNC_X(        LE_INDEX,   index)

#define LED_MODE_GET_RESP_FIELDS            \
    TSYNC_X(        EC_MODE,   mode)

#define LED_MODE_SET_CMD_FIELDS             \
    TSYNC_X(        LE_INDEX,   index)      \
    TSYNC_X(        EC_MODE,    mode)

#define LED_STATE_GET_RESP_FIELDS           \
    TSYNC_X(        EC_STATE,   state)

#define LED_STATE_SET_CMD_FIELDS            \
    TSYNC_X(        LE_INDEX,   index)      \
    TSYNC_X(        EC_STATE,   state)

#define LED_BLACKOUT_GET_RESP_FIELDS      \
    TSYNC_X(        EC_BLACKOUT_MODE,    mode)

#define LED_BLACKOUT_SET_CMD_FIELDS       \
    TSYNC_X(        EC_BLACKOUT_MODE,    mode)

#include "tsync_struct_define.h"

GEN_STRUCT(LED_GET_CMD)
GEN_STRUCT(LED_MODE_GET_RESP)
GEN_STRUCT(LED_MODE_SET_CMD)
GEN_STRUCT(LED_STATE_GET_RESP)
GEN_STRUCT(LED_STATE_SET_CMD)
GEN_STRUCT(LED_BLACKOUT_GET_RESP)
GEN_STRUCT(LED_BLACKOUT_SET_CMD)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_EC_SERVICES_H */
