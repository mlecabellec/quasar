#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_etp_services.h"

extern uint8_t ETP_VALUE_RECIPE[];
extern uint8_t ETP_SET_CMD_RECIPE[];
extern uint8_t ETP_CFG_RECIPE[];
extern uint8_t ETP_CFG_SET_CMD_RECIPE[];

TSYNC_ERROR
TSYNC_ETP_getSigCtrl(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    SIG_CTL *sig)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(sig);

        struct ETP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(ETP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(ETP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_ETP,
            TSYNC_ID_ETP_CA_SIG_CTL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            ETP_VALUE_RECIPE,
            ETP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct ETP_VALUE* outPayload =
            (ETP_VALUE*)GetPayload(result);

        *sig = (SIG_CTL)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_ETP_setSigCtrl(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    SIG_CTL sig)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct ETP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = sig;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(ETP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_ETP,
            TSYNC_ID_ETP_CA_SIG_CTL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            ETP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_ETP_getCfg(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    ETO_CFG *pCfg)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pCfg);

        struct ETP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(ETP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(ETP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_ETP,
            TSYNC_ID_ETP_CA_CFG,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            ETP_VALUE_RECIPE,
            ETP_CFG_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct ETP_CFG* outPayload =
            (ETP_CFG*)GetPayload(result);

        pCfg->outOpt   = (ETO_OUT_OPT)outPayload->opt;
        pCfg->mode     = (ETO_MODE)outPayload->mode;
        pCfg->e1Frame  = (ETO_E1_FRM)outPayload->e1frm;
        pCfg->t1Frame  = (ETO_T1_FRM)outPayload->t1frm;
        pCfg->t1Encode = (ETO_T1_ENC)outPayload->t1enc;
        pCfg->ssmEn    = (int)outPayload->ssmen;
        pCfg->t1Ssm    = (ETO_T1_SSM)outPayload->t1ssm;
        pCfg->e1Ssm    = (ETO_E1_SSM)outPayload->e1ssm;

    return ( err );
}

TSYNC_ERROR
TSYNC_ETP_setCfg(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    ETO_CFG* pCfg)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pCfg);

        struct ETP_CFG_SET_CMD inPayload;
        inPayload.inst  = nInstance;
        inPayload.opt   = pCfg->outOpt;
        inPayload.mode  = pCfg->mode;
        inPayload.e1frm = pCfg->e1Frame;
        inPayload.t1frm = pCfg->t1Frame;
        inPayload.t1enc = pCfg->t1Encode;
        inPayload.ssmen = pCfg->ssmEn;
        inPayload.t1ssm = pCfg->t1Ssm;
        inPayload.e1ssm = pCfg->e1Ssm;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(ETP_CFG_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_ETP,
            TSYNC_ID_ETP_CA_CFG,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            ETP_CFG_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_ETP_getNumInst(
    TSYNC_BoardHandle hnd,
    unsigned int *nInstances)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nInstances);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(ETP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_ETP,
            TSYNC_ID_ETP_CA_NUM_INST,
            ctl,
            pyldLen,
            NULL,
            NULL,
            ETP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct ETP_VALUE* outPayload =
            (ETP_VALUE*)GetPayload(result);

        *nInstances = outPayload->value;

    return ( err );
}
