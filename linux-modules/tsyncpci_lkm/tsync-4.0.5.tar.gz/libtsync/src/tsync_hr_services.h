
#ifndef _defined_TSYNC_HR_SERVICES_H
#define _defined_TSYNC_HR_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_hr_services.h
**
**  Date:       07/28/08
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2006, 2009 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/28/2008 Creation
**              09/11/2009 Lafayette updates
**
****************************************************************************/

#include "tsync_cs_services.h"

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_HR                     0x2D
#define TSYNC_ID_HR_CA_VALIDITY         0x00
#define TSYNC_ID_HR_CA_TIME             0x01
#define TSYNC_ID_HR_CA_LOCAL            0x02
#define TSYNC_ID_HR_CA_TIME_SCALE       0x03
#define TSYNC_ID_HR_CA_REF_ID           0x04
#define TSYNC_ID_HR_CA_NUM_INST         0x05
#define TSYNC_ID_HR_CA_OFFSET           0x06
#define TSYNC_ID_HR_CA_MODE             0x07

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define HR_VALUE_FIELDS                            \
    TSYNC_X(        uint32_t,           value)

#define HR_VALIDITY_SET_CMD_FIELDS                 \
    TSYNC_X(        uint32_t,           nInstance) \
    TSYNC_X(        uint32_t,           timeValid) \
    TSYNC_X(        uint32_t,           ppsValid)

#define HR_DOYTIME_SET_CMD_FIELDS                  \
    TSYNC_X(        uint32_t,           nInstance) \
    TSYNC_X(        uint32_t,           year)      \
    TSYNC_X(        uint32_t,           doy)       \
    TSYNC_X(        uint32_t,           hour)      \
    TSYNC_X(        uint32_t,           minute)    \
    TSYNC_X(        uint32_t,           second)    \
    TSYNC_X(        uint32_t,           ns)

#define HR_LOCAL_SET_CMD_FIELDS                    \
    TSYNC_X(        uint32_t,           inst)      \
    TSYNC_X(        ML_DST_REF,         ref)       \
    TSYNC_X_STRUCT( ML_DST_POINT,       in)        \
    TSYNC_X_STRUCT( ML_DST_POINT,       out)       \
    TSYNC_X(        uint32_t,           offset)    \
    TSYNC_X(        int32_t,            tz)

#define HR_TIME_SCALE_SET_CMD_FIELDS               \
    TSYNC_X(        uint32_t,           inst)      \
    TSYNC_X_STRUCT( ML_TIME_SCALE_OBJ,  scale)

#define HR_OFFSET_SET_CMD_FIELDS                   \
    TSYNC_X(        uint32_t,   inst)          \
    TSYNC_X(        int32_t,   offset)

#define HR_MODE_SET_CMD_FIELDS                   \
    TSYNC_X(        uint32_t,   inst)          \
    TSYNC_X(        HR_TS_MODE,   mode)

#include "tsync_struct_define.h"

GEN_STRUCT(HR_VALUE)
GEN_STRUCT(HR_VALIDITY_SET_CMD)
GEN_STRUCT(HR_DOYTIME_SET_CMD)
GEN_STRUCT(HR_LOCAL_SET_CMD)
GEN_STRUCT(HR_TIME_SCALE_SET_CMD)
GEN_STRUCT(HR_OFFSET_SET_CMD)
GEN_STRUCT(HR_MODE_SET_CMD)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_HR_SERVICES_H */
