
#ifndef _defined_TSYNC_FP_SERVICES_H
#define _defined_TSYNC_FP_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_fp_services.h
**
**  Date:       08/05/08
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              08/05/2008 Creation
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_FP                     0x31
#define TSYNC_ID_FP_CA_SIG_CTL          0x00
#define TSYNC_ID_FP_CA_FREQ             0x01
#define TSYNC_ID_FP_CA_NUM_INST         0x02
#define TSYNC_ID_FP_CA_PLL_LOCK         0x03

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define FP_SET_CMD_FIELDS                 \
    TSYNC_X(        uint32_t,   inst)     \
    TSYNC_X(        uint32_t,   value)
#define FP_VALUE_FIELDS                   \
    TSYNC_X(        uint32_t,   value)
#define FP_FREQ_FIELDS                    \
    TSYNC_X(        float,      freq)

#include "tsync_struct_define.h"

GEN_STRUCT(FP_SET_CMD)
GEN_STRUCT(FP_VALUE)
GEN_STRUCT(FP_FREQ)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_FP_SERVICES_H */
