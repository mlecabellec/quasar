#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_ptr_services.h"
#include "tsync_misc_services.h"
#include "tsync_us_services.h"
#include "tsync_fs_services.h"


extern uint8_t PTR_VALUE_RECIPE[];
extern uint8_t PTR_VALUE_SET_CMD_RECIPE[];
extern uint8_t PTR_MODULE_INFO_RECIPE[];
extern uint8_t PTR_ETH_INFO_RECIPE[];
extern uint8_t PTR_ETH_INFO_SET_CMD_RECIPE[];
extern uint8_t PTR_CLK_SETTINGS_RECIPE[];
extern uint8_t PTR_CLK_SETTINGS_SET_CMD_RECIPE[];
extern uint8_t PTL_UNIT_SETTINGS_RECIPE[];
extern uint8_t PTL_UNIT_SETTINGS_SET_CMD_RECIPE[];
extern uint8_t PTL_PORT_STATE_RECIPE[];
extern uint8_t PTL_PORT_STATE_SET_CMD_RECIPE[];
extern uint8_t PTL_PORT_SETTINGS_RECIPE[];
extern uint8_t PTL_PORT_SETTINGS_SET_CMD_RECIPE[];
extern uint8_t PTL_CLK_QUALITY_RECIPE[];
extern uint8_t PTL_TIME_PROP_RECIPE[];
extern uint8_t PTL_PARENT_PROP_RECIPE[];
extern uint8_t PTL_GM_PROP_RECIPE[];
extern uint8_t PTL_TOD_SETTINGS_RECIPE[];
extern uint8_t PTL_TOD_SETTINGS_SET_CMD_RECIPE[];
extern uint8_t EL_VALIDITY_RECIPE[];
extern uint8_t PTL_MAC_ADDR_RECIPE[];
extern uint8_t PTL_MAC_ADDR_SET_CMD_RECIPE[];
extern uint8_t PTL_USER_DESC_RECIPE[];
extern uint8_t PTL_USER_DESC_SET_CMD_RECIPE[];
extern uint8_t EL_REF_ID_RECIPE[];
extern uint8_t PTL_DEBUG_OUTPUT_RECIPE[];
extern uint8_t PTL_DEBUG_OUTPUT_SET_CMD_RECIPE[];
extern uint8_t PTL_ETH_STATUS_RECIPE[];
extern uint8_t PTL_SYNC_ETHERNET_ITF_RECIPE[];
extern uint8_t PTL_SYNC_ETHERNET_ITF_SET_CMD_RECIPE[];
extern uint8_t PTL_PTP_ITF_RECIPE[];
extern uint8_t PTL_PTP_ITF_SET_CMD_RECIPE[];
extern uint8_t PTL_FTP_ITF_RECIPE[];
extern uint8_t PTL_FTP_ITF_SET_CMD_RECIPE[];
extern uint8_t PTL_PTP_STATISTICS_RECIPE[];
extern uint8_t PTL_PTP_STATISTICS_SET_CMD_RECIPE[];
extern uint8_t PTL_PTP_CLOCK_PROPERTIES_RECIPE[];
extern uint8_t DATA_CMD_RECIPE[];
extern uint8_t UL_IMG_HDR_RECIPE[];
extern uint8_t UL_IMG_OBJ_RECIPE[];
extern uint8_t UL_IMG_TRL_RECIPE[];
extern uint8_t UPDATE_START_CMD_RECIPE[];
extern uint8_t UPDATE_START_OC_CMD_RECIPE[];
extern uint8_t US_STATE_RECIPE[];
extern uint8_t PTL_PTP_UNCT_MASTER_ADD_RECIPE[];
extern uint8_t PTL_PTP_UNCT_MASTER_ADD_SET_CMD_RECIPE[];
extern uint8_t PTL_PTP_UNCT_MASTER_PROP_RECIPE[];
extern uint8_t PTL_PTP_UNCT_SLAVE_PROP_RECIPE[];
extern uint8_t PTL_PTP_VLAN_SET_CMD_RECIPE[];
extern uint8_t PTL_PTP_VLAN_RECIPE[];


TSYNC_ERROR 
TSYNC_PTR_getModuleInfo(
    TSYNC_BoardHandle       hnd,
    unsigned int            nInstance,
    TSYNC_PTPModuleInfoObj *pObj)
{


    TSYNC_ERROR     err    = TSYNC_SUCCESS;    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTR_MODULE_INFO_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_MODULE_INFO,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTR_MODULE_INFO_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTR_MODULE_INFO* outPayload =
            (PTR_MODULE_INFO*)GetPayload(result);
            
        memset(pObj->filler   , '\0', sizeof(pObj->filler   ));
        memset(pObj->softDate , '\0', sizeof(pObj->softDate ));
        memset(pObj->softTime , '\0', sizeof(pObj->softTime ));
              
        pObj->ptpVerisonNumber = outPayload->ptpVersionNumber;
        pObj->softwareVersion  = outPayload->softwareVersion;
        pObj->hardwareVersion  = outPayload->hardwareVersion;
        // filler not copied
        memcpy(pObj->softDate , outPayload->softDate , 
               sizeof(outPayload->softDate ));
        memcpy(pObj->softTime , outPayload->softTime , 
               sizeof(outPayload->softTime ));
        
        
    return ( err );

}


TSYNC_ERROR
TSYNC_PTR_getEthernetItf(
    TSYNC_BoardHandle        hnd,
    unsigned int             nInstance,
    TSYNC_PTPEthernetItfObj *pObj) 
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTR_ETH_INFO_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_ETHERNET_ITF,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTR_ETH_INFO_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTR_ETH_INFO* outPayload =
            (PTR_ETH_INFO*)GetPayload(result);
            
        memset(pObj->staticIpAddr,   '\0', sizeof(pObj->staticIpAddr ));
        memset(pObj->netMask,        '\0', sizeof(pObj->netMask ));
        memset(pObj->defaultGateway, '\0', sizeof(pObj->defaultGateway ));
        
        pObj->dhcpEnabled    = outPayload->dhcpEnabled;
               
        memcpy(pObj->staticIpAddr, 
               outPayload->staticIpAddr, 
               sizeof(outPayload->staticIpAddr));
               
        memcpy(pObj->netMask, 
               outPayload->netMask, 
               sizeof(outPayload->netMask));
               
        memcpy(pObj->defaultGateway, 
               outPayload->defaultGateway, 
               sizeof(outPayload->defaultGateway));
               
        
    return ( err );

}


TSYNC_ERROR TSYNC_PTR_setEthernetItf(
    TSYNC_BoardHandle        hnd,
    unsigned int             nInstance,
    TSYNC_PTPEthernetItfObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_ETH_INFO_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.dhcpEnabled = pObj->dhcpEnabled;
               
        memcpy(inPayload.staticIpAddr, 
               pObj->staticIpAddr, 
               sizeof(inPayload.staticIpAddr));
               
        memcpy(inPayload.netMask, 
               pObj->netMask, 
               sizeof(inPayload.netMask));
               
        memcpy(inPayload.defaultGateway, 
               pObj->defaultGateway, 
               sizeof(inPayload.defaultGateway));

        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_ETH_INFO_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_ETHERNET_ITF,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_ETH_INFO_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );

}

TSYNC_ERROR 
TSYNC_PTR_getClockSettings(
    TSYNC_BoardHandle        hnd,
    unsigned int             nInstance,
    TSYNC_PTPClkSettingsObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTR_CLK_SETTINGS_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_PTP_CLOCK_SETTINGS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTR_CLK_SETTINGS_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTR_CLK_SETTINGS* outPayload =
            (PTR_CLK_SETTINGS*)GetPayload(result);
                    
        pObj->ptpClockRunning    = outPayload->ptpClockRunning;
        pObj->usingExternalClock = outPayload->usingExternalClock;

        
    return ( err );
    
}
        
TSYNC_ERROR 
TSYNC_PTR_setClockSettings(
    TSYNC_BoardHandle        hnd,
    unsigned int             nInstance,
    TSYNC_PTPClkSettingsObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_CLK_SETTINGS_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.ptpClockRunning    = pObj->ptpClockRunning;
        inPayload.usingExternalClock = pObj->usingExternalClock;

        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_CLK_SETTINGS_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_PTP_CLOCK_SETTINGS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_CLK_SETTINGS_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );

    
}


TSYNC_ERROR 
TSYNC_PTR_getUnitSettings(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    TSYNC_PTPUnitSettingsObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTL_UNIT_SETTINGS_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_PTP_UNIT_SETTINGS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTL_UNIT_SETTINGS_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTL_UNIT_SETTINGS* outPayload =
            (PTL_UNIT_SETTINGS*)GetPayload(result);
                    
        memset(pObj->clockIdentity, '\0', sizeof(pObj->clockIdentity ));
        memcpy(pObj->clockIdentity, 
               outPayload->clockIdentity, 
               sizeof(outPayload->clockIdentity));
               
        pObj->oneStepMode       = outPayload->oneStepMode;
        pObj->domainNumber      = outPayload->domainNumber;
        pObj->priority1         = outPayload->priority1;
        pObj->priority2         = outPayload->priority2;
        pObj->forcedHoldover    = outPayload->forcedHoldover;

        
    return ( err );
    
}

TSYNC_ERROR 
TSYNC_PTR_setUnitSettings(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    TSYNC_PTPUnitSettingsObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTL_UNIT_SETTINGS_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        memcpy(inPayload.clockIdentity , 
               pObj->clockIdentity, 
               sizeof(inPayload.clockIdentity));
        inPayload.oneStepMode       = pObj->oneStepMode;
        inPayload.domainNumber      = pObj->domainNumber;
        inPayload.priority1         = pObj->priority1;
        inPayload.priority2         = pObj->priority2;
        inPayload.forcedHoldover    = pObj->forcedHoldover;

        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTL_UNIT_SETTINGS_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_PTP_UNIT_SETTINGS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTL_UNIT_SETTINGS_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );

    

}
        
TSYNC_ERROR 
TSYNC_PTR_getPortState(
    TSYNC_BoardHandle      hnd,
    unsigned int           nInstance,
    TSYNC_PTPPortStateObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTL_PORT_STATE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_PTP_PORT_STATE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTL_PORT_STATE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTL_PORT_STATE* outPayload =
            (PTL_PORT_STATE*)GetPayload(result);
                    
        pObj->portNumber       = outPayload->portNumber;
        pObj->portEnabled      = outPayload->portEnabled;
        pObj->portState        = outPayload->portState;
        pObj->linkConnected    = outPayload->linkConnected;
        pObj->slaveLogAnn      = outPayload->slaveLogAnn;
        pObj->slaveLogSync     = outPayload->slaveLogSync;
        pObj->slaveLogDelayReq = outPayload->slaveLogDelayReq;
        pObj->slaveOneStepMode = outPayload->slaveOneStepMode;
        
    return ( err );
    
        
}
    
TSYNC_ERROR 
TSYNC_PTR_setPortState(
    TSYNC_BoardHandle      hnd,
    unsigned int           nInstance,
    TSYNC_PTPPortStateObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTL_PORT_STATE_SET_CMD inPayload;
        inPayload.nInstance         = nInstance;
        inPayload.portNumber        = pObj->portNumber;
        inPayload.portEnabled       = pObj->portEnabled;
        inPayload.portState         = pObj->portState;
        inPayload.linkConnected     = pObj->linkConnected;
        inPayload.slaveLogAnn       = pObj->slaveLogAnn;
        inPayload.slaveLogSync      = pObj->slaveLogSync;
        inPayload.slaveLogDelayReq  = pObj->slaveLogDelayReq;
        inPayload.slaveOneStepMode  = pObj->slaveOneStepMode;
        
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTL_PORT_STATE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_PTP_PORT_STATE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTL_PORT_STATE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );

    

}

        
TSYNC_ERROR 
TSYNC_PTR_getPortSettings(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    TSYNC_PTPPortSettingsObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTL_PORT_SETTINGS_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_PTP_PORT_SETTINGS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTL_PORT_SETTINGS_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTL_PORT_SETTINGS* outPayload =
            (PTL_PORT_SETTINGS*)GetPayload(result);
        
        pObj->portNumber              = outPayload->portNumber;
        pObj->annRcptTimeout          = outPayload->annRcptTimeout;
        pObj->logAnnInterval          = outPayload->logAnnInterval;
        pObj->logSyncInterval         = outPayload->logSyncInterval;
        pObj->logDelayReqInterval     = outPayload->logDelayReqInterval;
        pObj->logPeerDelayReqInterval = outPayload->logPeerDelayReqInterval;
        pObj->delayMechanism          = outPayload->delayMechanism;
		pObj->syncTimeout             = outPayload->syncTimeout;
		pObj->delayRespTimeout        = outPayload->delayRespTimeout;
        
    return ( err );
    
}

TSYNC_ERROR 
TSYNC_PTR_setPortSettings(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    TSYNC_PTPPortSettingsObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTL_PORT_SETTINGS_SET_CMD inPayload;
        inPayload.nInstance               = nInstance;
        inPayload.portNumber              = pObj->portNumber;
        inPayload.annRcptTimeout          = pObj->annRcptTimeout;
        inPayload.logAnnInterval          = pObj->logAnnInterval;
        inPayload.logSyncInterval         = pObj->logSyncInterval;
        inPayload.logDelayReqInterval     = pObj->logDelayReqInterval;
        inPayload.logPeerDelayReqInterval = pObj->logPeerDelayReqInterval;
        inPayload.delayMechanism          = pObj->delayMechanism;
		inPayload.syncTimeout             = pObj->syncTimeout;
		inPayload.delayRespTimeout        = pObj->delayRespTimeout;

        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTL_PORT_SETTINGS_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_PTP_PORT_SETTINGS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTL_PORT_SETTINGS_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );

}
        
TSYNC_ERROR 
TSYNC_PTR_getClkQuality(
    TSYNC_BoardHandle       hnd,
    unsigned int            nInstance,
    TSYNC_PTPClkQualityObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTL_CLK_QUALITY_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_PTP_CLOCK_QUALITY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTL_CLK_QUALITY_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTL_CLK_QUALITY* outPayload =
            (PTL_CLK_QUALITY*)GetPayload(result);
                    
        pObj->clockClass              = outPayload->clockClass;
        pObj->clockAccuracy           = outPayload->clockAccuracy;
        pObj->offsetScaledLogVariance = outPayload->offsetScaledLogVariance;

        
    return ( err );
    
    
}


TSYNC_ERROR 
TSYNC_PTR_getTimeProperties(
    TSYNC_BoardHandle     hnd,
    unsigned int          nInstance,
    TSYNC_PTPTimePropObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTL_TIME_PROP_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_PTP_TIME_PROPERTIES,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTL_TIME_PROP_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTL_TIME_PROP* outPayload =
            (PTL_TIME_PROP*)GetPayload(result);
                    
        pObj->utcOffset       = outPayload->utcOffset;
        pObj->utcOffsetValid  = outPayload->utcOffsetValid;
        pObj->forwardLeap     = outPayload->forwardLeap;
        pObj->backwardLeap    = outPayload->backwardLeap;
        pObj->timeTraceable   = outPayload->timeTraceable;
        pObj->freqTraceable   = outPayload->freqTraceable;
        pObj->ptpTimescale    = outPayload->ptpTimescale;
        pObj->timeSource      = outPayload->timeSource;
        
    return ( err );

}


TSYNC_ERROR 
TSYNC_PTR_getParentProperties(
    TSYNC_BoardHandle       hnd,
    unsigned int            nInstance,
    TSYNC_PTPParentPropObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTL_PARENT_PROP_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_PTP_PARENT_PROPERTIES,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTL_PARENT_PROP_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTL_PARENT_PROP* outPayload =
            (PTL_PARENT_PROP*)GetPayload(result);
            
        memset(pObj->clockIdentity, '\0', sizeof(pObj->clockIdentity ));
        memcpy(pObj->clockIdentity, 
               outPayload->clockIdentity, 
               sizeof(outPayload->clockIdentity));
                    
        pObj->portNumber       = outPayload->portNumber;
        pObj->statsCalculated  = outPayload->statsCalculated;
        pObj->observedOSLV     = outPayload->observedOSLV;
        pObj->observedCPCR     = outPayload->observedCPCR;
        
    return ( err );
    
}

        
TSYNC_ERROR 
TSYNC_PTR_getGrandmasterProperties(
    TSYNC_BoardHandle            hnd,
    unsigned int                 nInstance,
    TSYNC_PTPGrandmasterPropObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTL_GM_PROP_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_PTP_GM_PROPERTIES,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTL_GM_PROP_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTL_GM_PROP* outPayload =
            (PTL_GM_PROP*)GetPayload(result);
            
        memset(pObj->clockIdentity, '\0', sizeof(pObj->clockIdentity ));

        memcpy(pObj->clockIdentity, 
               outPayload->clockIdentity, 
               sizeof(outPayload->clockIdentity));

        pObj->clockQuality.clockClass = outPayload->clockQuality.clockClass;
        pObj->clockQuality.clockAccuracy =
              outPayload->clockQuality.clockAccuracy;
        pObj->clockQuality.offsetScaledLogVariance =
              outPayload->clockQuality.offsetScaledLogVariance;
        pObj->priority1   = outPayload->priority1;
        pObj->priority2   = outPayload->priority2;
        
    return ( err );
    
}


TSYNC_ERROR 
TSYNC_PTR_getTODSettings(
    TSYNC_BoardHandle      hnd,
    unsigned int           nInstance,
    TSYNC_PTPTODSettingsObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTL_TOD_SETTINGS_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_TOD_SETTINGS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTL_TOD_SETTINGS_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTL_TOD_SETTINGS* outPayload =
            (PTL_TOD_SETTINGS*)GetPayload(result);
            
        pObj->todEnabled = outPayload->todEnabled;
        pObj->timeScale  = outPayload->timeScale;
        
    return ( err );
        
}

        
TSYNC_ERROR 
TSYNC_PTR_setTODSettings(
    TSYNC_BoardHandle      hnd,
    unsigned int           nInstance,
    TSYNC_PTPTODSettingsObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTL_TOD_SETTINGS_SET_CMD inPayload;
        inPayload.nInstance  = nInstance;
        inPayload.todEnabled = pObj->todEnabled;
        inPayload.timeScale  = pObj->timeScale;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTL_TOD_SETTINGS_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_TOD_SETTINGS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTL_TOD_SETTINGS_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );

}

        
TSYNC_ERROR 
TSYNC_PTR_getPPSEnabled(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    int              *bPpsEnabled)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(bPpsEnabled);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTR_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_PPS_ENABLED,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTR_VALUE* outPayload =
            (PTR_VALUE*)GetPayload(result);
            
        *bPpsEnabled = (int)outPayload->value;
        
    return ( err );
    
}

        
TSYNC_ERROR 
TSYNC_PTR_setPPSEnabled(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    int               bPpsEnabled)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct PTR_VALUE_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.value     = bPpsEnabled;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_PPS_ENABLED,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
    
}

        
TSYNC_ERROR 
TSYNC_PTR_getPPSRisingEdge(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    int              *bPpsRisingEdge)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(bPpsRisingEdge);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTR_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_PPS_RISING_EDGE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTR_VALUE* outPayload =
            (PTR_VALUE*)GetPayload(result);
            
        *bPpsRisingEdge = (int)outPayload->value;
        
    return ( err );
    
}

        
TSYNC_ERROR 
TSYNC_PTR_setPPSRisingEdge(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    int               bPpsRisingEdge)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct PTR_VALUE_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.value     = bPpsRisingEdge;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_PPS_RISING_EDGE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
    
}

        
TSYNC_ERROR 
TSYNC_PTR_saveSettingsToROM(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
                    
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_SAVE_SETTINGS_TO_ROM,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
    
    
}

        
TSYNC_ERROR 
TSYNC_PTR_getNumInst(
    TSYNC_BoardHandle hnd,
    unsigned int     *nInstances)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nInstances);
       
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTR_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_NUM_INST,
            ctl,
            pyldLen,
            NULL,
            NULL,
            PTR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTR_VALUE* outPayload =
            (PTR_VALUE*)GetPayload(result);
            
        *nInstances = (int)outPayload->value;
        
    return ( err );
    
}
 
 
TSYNC_ERROR 
TSYNC_PTR_resetModule(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    PTL_RESET         resetType)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct PTR_VALUE_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.value     = resetType;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_RESET_MODULE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );

}

TSYNC_ERROR 
TSYNC_PTR_reinitModule(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
                    
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_REINIT_MODULE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
    
    
}

TSYNC_ERROR
TSYNC_PTR_getValidity(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *bTimeValid,
    int *bPpsValid)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(bTimeValid);
        CHECK_NOT_NULL(bPpsValid);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(EL_VALIDITY_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_VALIDITY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            EL_VALIDITY_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct EL_VALIDITY* outPayload =
            (EL_VALIDITY*)GetPayload(result);
            
        *bTimeValid = outPayload->timeValid;
        *bPpsValid = outPayload->ppsValid;
        
    return ( err );
}

TSYNC_ERROR 
TSYNC_PTR_getMode(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    int              *bMode)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(bMode);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTR_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_MODE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTR_VALUE* outPayload =
            (PTR_VALUE*)GetPayload(result);
            
        *bMode = (int)outPayload->value;
        
    return ( err );
    
}

        
TSYNC_ERROR 
TSYNC_PTR_setMode(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    int               bMode)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct PTR_VALUE_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.value     = bMode;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_MODE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
    
}

TSYNC_ERROR 
TSYNC_PTR_getMacAddr(
    TSYNC_BoardHandle     hnd,
    unsigned int          nInstance,
    TSYNC_PTPMacAddrObj  *pObj)
{

    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTL_MAC_ADDR_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_MAC_ADDR,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTL_MAC_ADDR_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTL_MAC_ADDR* outPayload =
            (PTL_MAC_ADDR*)GetPayload(result);
            
        memset(pObj->macAddress, '\0', sizeof(pObj->macAddress ));
        memcpy(pObj->macAddress, 
               outPayload->macAddress, 
               sizeof(outPayload->macAddress));
        
    return ( err );
    
}


TSYNC_ERROR TSYNC_PTR_setMacAddr(
    TSYNC_BoardHandle        hnd,
    unsigned int             nInstance,
    TSYNC_PTPMacAddrPwObj   *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTL_MAC_ADDR_SET_CMD inPayload;
        inPayload.nInstance  = nInstance;
        
        memcpy(inPayload.macAddress, 
               pObj->macAddress, 
               sizeof(inPayload.macAddress));
               
        memcpy(inPayload.pw, 
               pObj->pw, 
               sizeof(inPayload.pw));
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTL_MAC_ADDR_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_MAC_ADDR,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTL_MAC_ADDR_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );

}

TSYNC_ERROR 
TSYNC_PTR_getMasterActive(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    int              *bMasterActive)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(bMasterActive);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTR_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_MASTER_ACTIVE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTR_VALUE* outPayload =
            (PTR_VALUE*)GetPayload(result);
            
        *bMasterActive = (int)outPayload->value;
        
    return ( err );

}


TSYNC_ERROR 
TSYNC_PTR_getModuleStatus(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    int              *bModuleStatus)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(bModuleStatus);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTR_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_MODULE_STATUS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTR_VALUE* outPayload =
            (PTR_VALUE*)GetPayload(result);
            
        *bModuleStatus = (int)outPayload->value;
        
    return ( err );

}


TSYNC_ERROR
TSYNC_PTR_getUserDesc(
    TSYNC_BoardHandle        hnd,
    unsigned int             nInstance,
    TSYNC_PTPUserDescObj    *pObj) 
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTL_USER_DESC_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_PTP_USER_DESCRIPTION,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTL_USER_DESC_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTL_USER_DESC* outPayload =
            (PTL_USER_DESC*)GetPayload(result);
            
        memset(pObj->deviceName,     '\0', sizeof(pObj->deviceName ));
        memset(pObj->deviceLocation, '\0', sizeof(pObj->deviceLocation ));
             
        memcpy(pObj->deviceName, 
               outPayload->deviceName, 
               sizeof(outPayload->deviceName));
               
        memcpy(pObj->deviceLocation, 
               outPayload->deviceLocation, 
               sizeof(outPayload->deviceLocation));
        
    return ( err );

}


TSYNC_ERROR TSYNC_PTR_setUserDesc(
    TSYNC_BoardHandle        hnd,
    unsigned int             nInstance,
    TSYNC_PTPUserDescObj    *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTL_USER_DESC_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
               
        memcpy(inPayload.deviceName, 
               pObj->deviceName, 
               sizeof(inPayload.deviceName));
               
        memcpy(inPayload.deviceLocation, 
               pObj->deviceLocation, 
               sizeof(inPayload.deviceLocation));
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTL_USER_DESC_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_PTP_USER_DESCRIPTION,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTL_USER_DESC_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );

}

TSYNC_ERROR
TSYNC_PTR_getRefId(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_RefIdObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(EL_REF_ID_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_REF_ID,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            EL_REF_ID_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct EL_REF_ID* outPayload =
            (EL_REF_ID*)GetPayload(result);
            
        memset(pObj->refid, '\0', sizeof(pObj->refid));
        memcpy(pObj->refid, outPayload->ref, sizeof(outPayload->ref));
        
    return ( err );
}


TSYNC_ERROR 
TSYNC_PTR_getDebugOutput(
    TSYNC_BoardHandle        hnd,
    unsigned int             nInstance,
    TSYNC_PTPDebugOutputObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTL_DEBUG_OUTPUT_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_DEBUG_OUTPUT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTL_DEBUG_OUTPUT_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTL_DEBUG_OUTPUT* outPayload =
            (PTL_DEBUG_OUTPUT*)GetPayload(result);
            
        pObj->debugOutput        = outPayload->debugOutput;
        pObj->debugFilterOutput  = outPayload->debugFilterOutput;
        
    return ( err );
        
}

        
TSYNC_ERROR 
TSYNC_PTR_setDebugOutput(
    TSYNC_BoardHandle      hnd,
    unsigned int           nInstance,
    TSYNC_PTPDebugOutputObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTL_DEBUG_OUTPUT_SET_CMD inPayload;
        inPayload.nInstance          = nInstance;
        inPayload.debugOutput        = pObj->debugOutput;
        inPayload.debugFilterOutput  = pObj->debugFilterOutput;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTL_DEBUG_OUTPUT_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_DEBUG_OUTPUT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTL_DEBUG_OUTPUT_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );

}


TSYNC_ERROR
TSYNC_PTR_getEthernetStatus(
    TSYNC_BoardHandle           hnd,
    unsigned int                nInstance,
    TSYNC_PTPEthernetStatusObj *pObj) 
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTL_ETH_STATUS_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_ETHERNET_STATUS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTL_ETH_STATUS_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTL_ETH_STATUS* outPayload =
            (PTL_ETH_STATUS*)GetPayload(result);
            
        memset(pObj->ipAddress, '\0', sizeof(pObj->ipAddress ));
        memset(pObj->netMask,   '\0', sizeof(pObj->netMask ));
        memset(pObj->gateway,   '\0', sizeof(pObj->gateway ));
               
        memcpy(pObj->ipAddress, 
               outPayload->ipAddress, 
               sizeof(outPayload->ipAddress));
               
        memcpy(pObj->netMask, 
               outPayload->netMask, 
               sizeof(outPayload->netMask));
               
        memcpy(pObj->gateway, 
               outPayload->gateway, 
               sizeof(outPayload->gateway));
               
        
    return ( err );

}


TSYNC_ERROR 
TSYNC_PTR_getSyncEItf(
    TSYNC_BoardHandle        hnd,
    unsigned int             nInstance,
    TSYNC_PTPSyncEStatusObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTL_SYNC_ETHERNET_ITF_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_SYNC_ETHERNET_ITF,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTL_SYNC_ETHERNET_ITF_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTL_SYNC_ETHERNET_ITF* outPayload =
            (PTL_SYNC_ETHERNET_ITF*)GetPayload(result);
            
        pObj->enableSyncE     = outPayload->enableSyncE;
        pObj->xmitSyncEClock  = outPayload->xmitSyncEClock;
        pObj->esmcEnable      = outPayload->esmcEnable;
        pObj->ssmCode         = outPayload->ssmCode;
		memset(pObj->filler,   '\0', sizeof(pObj->filler ));
			
    return ( err );
        
}

        
TSYNC_ERROR 
TSYNC_PTR_setSyncEItf(
    TSYNC_BoardHandle        hnd,
    unsigned int             nInstance,
    TSYNC_PTPSyncEStatusObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTL_SYNC_ETHERNET_ITF_SET_CMD inPayload;
        inPayload.nInstance       = nInstance;
        inPayload.enableSyncE     = pObj->enableSyncE;
        inPayload.xmitSyncEClock  = pObj->xmitSyncEClock;
		inPayload.esmcEnable      = pObj->esmcEnable;
        inPayload.ssmCode         = pObj->ssmCode;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTL_SYNC_ETHERNET_ITF_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_SYNC_ETHERNET_ITF,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTL_SYNC_ETHERNET_ITF_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );

}

    
TSYNC_ERROR 
TSYNC_PTR_getPTPItf(
    TSYNC_BoardHandle   hnd,
    unsigned int        nInstance,
    TSYNC_PTPItfObj    *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTL_PTP_ITF_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_PTP_ITF,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTL_PTP_ITF_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTL_PTP_ITF* outPayload =
            (PTL_PTP_ITF*)GetPayload(result);

        // Clear Filler
        memset(pObj->filler   , '\0', sizeof(pObj->filler   ));
            
        pObj->transProto     = (PTL_TRANS_PROTO)outPayload->transProto;
        pObj->masterUnicast  = outPayload->masterUnicast;
        pObj->slaveUnicast   = outPayload->slaveUnicast;
        pObj->ttl            = outPayload->ttl;
        pObj->mgtPortEna     = outPayload->mgtPortEna;
        
    return ( err );
        
}

        
TSYNC_ERROR 
TSYNC_PTR_setPTPItf(
    TSYNC_BoardHandle   hnd,
    unsigned int        nInstance,
    TSYNC_PTPItfObj    *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTL_PTP_ITF_SET_CMD inPayload;
        inPayload.nInstance       = nInstance;
        inPayload.transProto      = pObj->transProto;
        inPayload.masterUnicast   = pObj->masterUnicast;
        inPayload.slaveUnicast    = pObj->slaveUnicast;
        inPayload.ttl             = pObj->ttl;
        inPayload.mgtPortEna      = pObj->mgtPortEna;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTL_PTP_ITF_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_PTP_ITF,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTL_PTP_ITF_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );

}

    
TSYNC_ERROR 
TSYNC_PTR_getFTPItf(
    TSYNC_BoardHandle      hnd,
    unsigned int           nInstance,
    TSYNC_PTPFtpItfObj    *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTL_FTP_ITF_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_FTP_ITF,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTL_FTP_ITF_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTL_FTP_ITF* outPayload =
            (PTL_FTP_ITF*)GetPayload(result);
            
        pObj->ftpEnable     = outPayload->ftpEnable;
        
    return ( err );
        
}

        
TSYNC_ERROR 
TSYNC_PTR_setFTPItf(
    TSYNC_BoardHandle      hnd,
    unsigned int           nInstance,
    TSYNC_PTPFtpItfObj    *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTL_FTP_ITF_SET_CMD inPayload;
        inPayload.nInstance      = nInstance;
        inPayload.ftpEnable      = pObj->ftpEnable;
   
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTL_FTP_ITF_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_FTP_ITF,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTL_FTP_ITF_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );

}

    
TSYNC_ERROR 
TSYNC_PTR_getPTPStatistics(
    TSYNC_BoardHandle        hnd,
    unsigned int             nInstance,
    TSYNC_PTPStatisticsObj  *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTL_PTP_STATISTICS_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_PTP_STATISTICS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTL_PTP_STATISTICS_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTL_PTP_STATISTICS* outPayload =
            (PTL_PTP_STATISTICS*)GetPayload(result);
            
        pObj->parentStats     = outPayload->parentStats;
        pObj->clockStats      = outPayload->clockStats;  
     
    return ( err );
        
}

        
TSYNC_ERROR 
TSYNC_PTR_setPTPStatistics(
    TSYNC_BoardHandle        hnd,
    unsigned int             nInstance,
    TSYNC_PTPStatisticsObj  *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTL_PTP_STATISTICS_SET_CMD inPayload;
        inPayload.nInstance      = nInstance;
        inPayload.parentStats    = pObj->parentStats;
        inPayload.clockStats     = pObj->clockStats;
   
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTL_PTP_STATISTICS_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_PTP_STATISTICS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTL_PTP_STATISTICS_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );

}

TSYNC_ERROR 
TSYNC_PTR_getClockProperties(
    TSYNC_BoardHandle            hnd,
    unsigned int                 nInstance,
    TSYNC_PTPClockPropertiesObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTL_PTP_CLOCK_PROPERTIES_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_CLOCK_PROPERTIES,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTL_PTP_CLOCK_PROPERTIES_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTL_PTP_CLOCK_PROPERTIES* outPayload =
            (PTL_PTP_CLOCK_PROPERTIES*)GetPayload(result);

        pObj->offFromMaster = outPayload->offFromMaster;
        pObj->meanPathDelay = outPayload->meanPathDelay;
        pObj->stepsRemoved  = outPayload->stepsRemoved;
        
    return ( err );
    
}

/*             YS                      */

TSYNC_ERROR 
TSYNC_PTR_setUnctMasterAdd(
    TSYNC_BoardHandle        hnd,
    unsigned int             nInstance,
    TSYNC_PTPUnctMasterAddObj  *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTL_PTP_UNCT_MASTER_ADD_SET_CMD inPayload;
        inPayload.nInstance      = nInstance;
        memcpy(inPayload.clockIdentity, 
               pObj->clockIdentity, 
               sizeof(inPayload.clockIdentity));
		 inPayload.portNumber= pObj->portNumber;
		 memcpy(inPayload.staticIpAddr, 
               pObj->staticIpAddr, 
               sizeof(inPayload.staticIpAddr));
		 inPayload.logQuerySalveInterval    = pObj->logQuerySalveInterval;
		 inPayload.duationSlaveContracts    = pObj->duationSlaveContracts;
		 inPayload.logAnnSlaveInterval      = pObj->logAnnSlaveInterval;
		 inPayload.logSyncMasterInterval    = pObj->logSyncMasterInterval;
		 inPayload.logDelayReqSlaveInterval = pObj->logDelayReqSlaveInterval;
   
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTL_PTP_UNCT_MASTER_ADD_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_UNCT_MASTER_ADD,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTL_PTP_UNCT_MASTER_ADD_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );

}

TSYNC_ERROR 
TSYNC_PTR_getUnctMasterAdd(
    TSYNC_BoardHandle            hnd,
    unsigned int                 nInstance,
    TSYNC_PTPUnctMasterAddObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTL_PTP_UNCT_MASTER_ADD_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_UNCT_MASTER_ADD ,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTL_PTP_UNCT_MASTER_ADD_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
		
        struct PTL_PTP_UNCT_MASTER_ADD* outPayload =
            (PTL_PTP_UNCT_MASTER_ADD*)GetPayload(result)                ;
		
		pObj->filler1 = '\0';
		pObj->filler2 = '\0';
		memset(pObj->clockIdentity, '\0', sizeof(pObj->clockIdentity ))        ;
        memcpy(pObj->clockIdentity, 
               outPayload->clockIdentity, 
               sizeof(outPayload->clockIdentity))                              ;
		 pObj-> portNumber              = outPayload->portNumber               ;
		memset(pObj->staticIpAddr, '\0', sizeof(pObj->staticIpAddr ))          ;
        memcpy(pObj->staticIpAddr, 
               outPayload->staticIpAddr, 
               sizeof(outPayload->staticIpAddr));
		 pObj-> logQuerySalveInterval   = outPayload->logQuerySalveInterval    ;
		 pObj-> duationSlaveContracts   = outPayload->duationSlaveContracts    ;
		 pObj-> logAnnSlaveInterval     = outPayload->logAnnSlaveInterval      ;
		 pObj-> logSyncMasterInterval   = outPayload->logSyncMasterInterval    ;
		 pObj-> logDelayReqSlaveInterval= outPayload->logDelayReqSlaveInterval ;
        
    return ( err );
	
        
            
    
}



TSYNC_ERROR 
TSYNC_PTR_getUnctMasterProp(
    TSYNC_BoardHandle            hnd,
    unsigned int                 nInstance,
    TSYNC_PTPUnctMasterPropObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTL_PTP_UNCT_MASTER_PROP_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_UNCT_MASTER_PROP,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTL_PTP_UNCT_MASTER_PROP_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
		
        struct PTL_PTP_UNCT_MASTER_PROP* outPayload =
            (PTL_PTP_UNCT_MASTER_PROP*)GetPayload(result) ;
			
		 pObj-> negoEnabled      = outPayload-> negoEnabled      ; 
		 pObj-> nbSalveConnected = outPayload-> nbSalveConnected ;
		 memset(pObj->filler   , '\0', sizeof(pObj->filler   ));
        
    return ( err );
	
        
            
    
}

TSYNC_ERROR 
TSYNC_PTR_getUnctSlaveProp(
    TSYNC_BoardHandle            hnd,
    unsigned int                 nInstance,
    TSYNC_PTPUnctSlavePropObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTL_PTP_UNCT_SLAVE_PROP_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_UNCT_SLAVE_PROP,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTL_PTP_UNCT_SLAVE_PROP_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
		
        struct PTL_PTP_UNCT_SLAVE_PROP* outPayload =
            (PTL_PTP_UNCT_SLAVE_PROP*)GetPayload(result);
		
		 memset(pObj->filler1   , '\0', sizeof(pObj->filler1   ));
		 memset(pObj->filler2   , '\0', sizeof(pObj->filler2  ));
		 memset(pObj->filler3   , '\0', sizeof(pObj->filler3   ));
		 
		 pObj-> negoEnabled               = outPayload-> negoEnabled                ;
		 memcpy (pObj-> contractAnnState, outPayload-> contractAnnState, sizeof(outPayload-> contractAnnState));
		 pObj-> duationAnnContracts       = outPayload-> duationAnnContracts        ;
		 pObj-> delayAnnContracts         = outPayload-> delayAnnContracts          ;	 
         pObj-> logAnnMsgInterval         = outPayload-> logAnnMsgInterval          ; 	
		 memcpy (pObj-> contractSyncState, outPayload-> contractSyncState, sizeof(outPayload-> contractSyncState));
		 pObj-> duationSyncContracts      = outPayload-> duationSyncContracts       ;
		 pObj-> delaySyncContracts        = outPayload-> delaySyncContracts         ;
		 pObj-> logSyncMsgInterval        = outPayload-> logSyncMsgInterval         ;
		 memcpy (pObj-> contractDelayRespState, outPayload-> contractDelayRespState, sizeof(outPayload-> contractDelayRespState));
		 pObj-> duationDelayRespContracts = outPayload-> duationDelayRespContracts  ;
		 pObj-> delayDelayRespContracts   = outPayload-> delayDelayRespContracts    ;
		 pObj-> logDelayRespMsgInterval   = outPayload-> logDelayRespMsgInterval    ;
		 
    return ( err );
	
        
            
    
}


TSYNC_ERROR 
TSYNC_PTR_setVLAN(
    TSYNC_BoardHandle        hnd,
    unsigned int             nInstance,
    TSYNC_PTPVLANObj  *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTL_PTP_VLAN_SET_CMD inPayload;
        inPayload.nInstance         = nInstance               ;
        inPayload.vLanIntEnable     = pObj-> vLanIntEnable    ;   
        inPayload.vLanID            = pObj-> vLanID           ;
        inPayload.priorityCodePoint = pObj-> priorityCodePoint;
		
   
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTL_PTP_VLAN_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_VLAN_ITF,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTL_PTP_VLAN_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );

}

TSYNC_ERROR 
TSYNC_PTR_getVLAN(
    TSYNC_BoardHandle            hnd,
    unsigned int                 nInstance,
    TSYNC_PTPVLANObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTL_PTP_VLAN_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_VLAN_ITF,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTL_PTP_VLAN_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
		
        struct PTL_PTP_VLAN* outPayload =
            (PTL_PTP_VLAN*)GetPayload(result);
			
		pObj-> vLanIntEnable     = outPayload-> vLanIntEnable    ;   
        pObj-> vLanID            = outPayload-> vLanID           ;
        pObj-> priorityCodePoint = outPayload-> priorityCodePoint;
		pObj-> filler = '\0';
		
        
    return ( err );
	
        
            
    
}
/*             end            YS                                   */

/*  Upgrade APIs  */

/**********************************************************************
*
* FUNCTION:     TSYNC_PTR_start
*
* DESCRIPTION:  Routine starts upgrade process to option card.
*
* Arguments:    Pointer to TSYNC_BoardObj handle
*               Pointer to TSYNC_ULImageHeaderObj object
*
* RETURNS:      TSYNC_SUCCESS    - success
*               TSYNC_HANDLE_ERR - invalid arg pointers
*               TSYNC_COMM_ERR   - error interacting with device
*
**********************************************************************/
TSYNC_ERROR
TSYNC_PTR_start(
    TSYNC_BoardHandle       hnd,
    TSYNC_ULImageIdObj     *obj1,
    TSYNC_ULImageHeaderObj *obj2)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    if ( ( handle == NULL ) || ( obj1 == NULL ) || ( obj2 == NULL ))
    {
        return (TSYNC_HANDLE_ERR);
    }

        struct UPDATE_START_OC_CMD inPayload;
        inPayload.imgId.type = obj1->type;
        inPayload.imgId.slot = obj1->slot;
        inPayload.hdr.mark   = obj2->mark;
        inPayload.hdr.type   = obj2->type;
        inPayload.hdr.len    = obj2->len;

        uint16_t ctl = 0x02;//set
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(UPDATE_START_OC_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_START,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            UPDATE_START_OC_CMD_RECIPE,
            NULL,
            result,
            handle);

    return ( err );
}

/**********************************************************************
*
* FUNCTION:     TSYNC_PTR_data
*
* DESCRIPTION:  Routine retrieves the Status from  the
*               TSYNC board.
*
* Arguments:    Pointer to TSYNC_BoardObj handle
*               Pointer to TSYNC_UpdateDataObj object
*
* RETURNS:      TSYNC_SUCCESS    - success
*               TSYNC_HANDLE_ERR - invalid arg pointers
*               TSYNC_COMM_ERR   - error interacting with device
*
**********************************************************************/
TSYNC_ERROR
TSYNC_PTR_data( TSYNC_BoardHandle hnd, TSYNC_UpdateDataObj *obj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(obj);

        struct DATA_CMD inPayload;
        inPayload.image = obj->type;
        memcpy(inPayload.data, obj->data, 1024);

        uint16_t ctl = 0x02;//set
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(DATA_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_DATA,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            DATA_CMD_RECIPE,
            NULL,
            result,
            handle);

    return ( err );
}


TSYNC_ERROR
TSYNC_PTR_getState( TSYNC_BoardHandle hnd, TSYNC_StateObj *obj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(obj);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(US_STATE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_STATE,
            ctl,
            pyldLen,
            NULL,
            NULL,
            US_STATE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct US_STATE* outPayload =
            (US_STATE*)GetPayload(result);

        obj->image = (unsigned int)outPayload->image;
        obj->step = (unsigned int)outPayload->step;
        obj->complete = (unsigned int)outPayload->complete;

        return ( err );
}

/**********************************************************************
*
* FUNCTION:     TSYNC_PTR_end
*
* DESCRIPTION:  Routine retrieves the Status from  the
*               TSYNC board.
*
* Arguments:    Pointer to TSYNC_BoardObj handle
*               Pointer to TSYNC_UpdateEndObj object
*
* RETURNS:      TSYNC_SUCCESS    - success
*               TSYNC_HANDLE_ERR - invalid arg pointers
*               TSYNC_COMM_ERR   - error interacting with device
*
**********************************************************************/
TSYNC_ERROR
TSYNC_PTR_end( TSYNC_BoardHandle hnd, TSYNC_UpdateEndObj *obj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(obj);

        struct UL_IMG_TRL inPayload;
        inPayload.image = obj->type;
        inPayload.crc = obj->crc;
        memcpy(inPayload.ver, obj->ver, sizeof(inPayload.ver));

        uint16_t ctl = 0x02;//set
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(UL_IMG_TRL_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_END,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            UL_IMG_TRL_RECIPE,
            NULL,
            result,
            handle);

    return ( err );
}



TSYNC_ERROR
TSYNC_PTR_cancel( TSYNC_BoardHandle hnd, UL_IMG imageType)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct UL_IMG_OBJ inPayload;
        inPayload.image = imageType;

        uint16_t ctl = 0x02;//set
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(UL_IMG_OBJ_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_CANCEL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            UL_IMG_OBJ_RECIPE,
            NULL,
            result,
            handle);

        return ( err );
}


TSYNC_ERROR 
TSYNC_PTR_getBootImg(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    int              *bBootImg)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(bBootImg);

        struct PTR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PTR_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_BOOT_IMG,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_RECIPE,
            PTR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct PTR_VALUE* outPayload =
            (PTR_VALUE*)GetPayload(result);
            
        *bBootImg = (int)outPayload->value;
        
    return ( err );
    
}

        
TSYNC_ERROR 
TSYNC_PTR_setBootImg(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    int               bBootImg)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct PTR_VALUE_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.value     = bBootImg;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PTR_VALUE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_PTR,
            TSYNC_ID_PTR_CA_BOOT_IMG,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PTR_VALUE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
    
}

