
/***************************************************************************
**  Module:     tsync_fr_services_recipes.h
**
**  Date:       09/09/09
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2009 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              09/09/2009 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_fr_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(FR_VALUE)
RECIPE(FR_FREQ_SET_CMD)
RECIPE(FR_MODE_GET_RESP)
RECIPE(FR_MODE_SET_CMD)

#include "tsync_recipe_undef.h"
