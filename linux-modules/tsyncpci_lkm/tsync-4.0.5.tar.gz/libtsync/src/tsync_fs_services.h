
#ifndef _defined_TSYNC_FS_SERVICES_H
#define _defined_TSYNC_FS_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_fs_services.h
**
**  Date:       07/10/08
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/10/2008 Creation
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_FS                     0x28
#define TSYNC_ID_FS_CA_GET_CRC          0x00
#define TSYNC_ID_FS_CA_CALC_CRC         0x01
#define TSYNC_ID_FS_CA_IMG_HEADER       0x02
#define TSYNC_ID_FS_CA_GET_VERSION      0x03

/******************************************************
**     Define Structures
******************************************************/

#define UL_IMG_ID_FIELDS                \
    TSYNC_X( UL_IMG,    type)           \
    TSYNC_X( uint32_t,  slot)

#define UL_IMG_HDR_FIELDS                    \
    TSYNC_X( uint32_t,     mark)                \
    TSYNC_X( UL_IMG,    type)                \
    TSYNC_X( uint32_t,    len)

#define UL_IMG_TRL_FIELDS                    \
    TSYNC_X(        UL_IMG,     image)        \
    TSYNC_X_BUFFER(    uint8_t,     ver,    4)    \
    TSYNC_X(        uint32_t,    crc)

#define UL_IMG_OBJ_FIELDS                        \
    TSYNC_X( UL_IMG,         image)

#define FS_CRC_OBJ_FIELDS                        \
    TSYNC_X( uint32_t,         crc)

#define FS_VERS_OBJ_FIELDS                        \
    TSYNC_X_BUFFER( int8_t,         ver, 4)


#include "tsync_struct_define.h"

GEN_STRUCT(UL_IMG_ID)
GEN_STRUCT(UL_IMG_HDR)
GEN_STRUCT(UL_IMG_TRL)
GEN_STRUCT(UL_IMG_OBJ)
GEN_STRUCT(FS_CRC_OBJ)
GEN_STRUCT(FS_VERS_OBJ)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_FS_SERVICES_H */
