#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_sw_services.h"

#include "tsync_recipe_define.h"
RECIPE(SW_IO_SWITCH_VALUE)
RECIPE(SW_IO_SWITCH_GET_CMD)

RECIPE(SW_IO_SWITCH_OPTIONS_AMOUNT_VALUE)

RECIPE(SW_IO_SWITCH_OPTION_VALUE)
RECIPE(SW_IO_SWITCH_GET_OPTION_VALUE)

RECIPE(SW_IO_SWITCH_IO_NUM_VALUE)
#include "tsync_recipe_undef.h"
