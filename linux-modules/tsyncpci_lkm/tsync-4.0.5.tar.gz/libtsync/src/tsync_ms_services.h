
#ifndef _defined_TSYNC_MS_SERVICES_H
#define _defined_TSYNC_MS_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_ms_services.h
**
**  Date:       08/05/08
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC MSI library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              08/05/2008 Creation
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_MS                     0x22
#define TSYNC_ID_MS_CA_RESET            0x00
#define TSYNC_ID_MS_CA_DATA             0x01

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define MS_VALUE_FIELDS                   \
    TSYNC_X(        uint32_t,   value)
    
#define MS_SHARE_ITEM_FIELDS                    \
    TSYNC_X(            uint32_t,   seqNum)    \
    TSYNC_X_BUFFER(     int8_t,     data,    256)
    
#define MS_DATA_SET_CMD_FIELDS                    \
    TSYNC_X(            uint32_t,   index)    \
    TSYNC_X(            uint32_t,   seqNum)    \
    TSYNC_X_BUFFER(     int8_t,     data,    256)
    
#include "tsync_struct_define.h"

GEN_STRUCT(MS_VALUE)
GEN_STRUCT(MS_SHARE_ITEM)
GEN_STRUCT(MS_DATA_SET_CMD)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_MS_SERVICES_H */
