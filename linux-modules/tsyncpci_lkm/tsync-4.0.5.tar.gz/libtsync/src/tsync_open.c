#include "tsync.h"
#include "tsync_driver_interface.h"

/*==========================================================================
  TSYNC_open
==========================================================================*/

TSYNC_ERROR TSYNC_open (TSYNC_BoardHandle* hnd, const char *deviceName)
{
    return TSYNC_openImpl(hnd, deviceName);
}
