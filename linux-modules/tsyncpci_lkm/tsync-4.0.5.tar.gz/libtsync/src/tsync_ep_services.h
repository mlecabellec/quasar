
#ifndef _defined_TSYNC_EP_SERVICES_H
#define _defined_TSYNC_EP_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_ep_services.h
**
**  Date:       07/19/2010
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2010 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              09/09/2009 Creation
**
****************************************************************************/

#include "tsync_cs_services.h"

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_EP                      0x44
#define TSYNC_ID_EP_CA_SIG_CTL           0x00
#define TSYNC_ID_EP_CA_OFFSET            0x01
#define TSYNC_ID_EP_CA_LOCAL             0x02
#define TSYNC_ID_EP_CA_FORMAT            0x03
#define TSYNC_ID_EP_CA_TIME_SCALE        0x04
#define TSYNC_ID_EP_CA_AMPLITUDE         0x05
#define TSYNC_ID_EP_CA_NUM_INST          0x06

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define EP_VALUE_FIELDS                         \
    TSYNC_X(        uint32_t,           value)

#define EP_SET_CMD_FIELDS                       \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X(        uint32_t,           value)

#define EP_INT_VALUE_FIELDS                     \
    TSYNC_X(        int32_t,            value)

#define EP_INT_SET_CMD_FIELDS                   \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X(        int32_t,            value)

#define EP_LOCAL_SET_CMD_FIELDS                 \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X(        ML_DST_REF,         ref)    \
    TSYNC_X_STRUCT( ML_DST_POINT,       in)     \
    TSYNC_X_STRUCT( ML_DST_POINT,       out)    \
    TSYNC_X(        uint32_t,           offset) \
    TSYNC_X(        int32_t,            tz)

#define EP_TIME_SCALE_SET_CMD_FIELDS            \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X_STRUCT( ML_TIME_SCALE_OBJ,  scale)

#include "tsync_struct_define.h"

GEN_STRUCT(EP_VALUE)
GEN_STRUCT(EP_SET_CMD)
GEN_STRUCT(EP_INT_VALUE)
GEN_STRUCT(EP_INT_SET_CMD)
GEN_STRUCT(EP_LOCAL_SET_CMD)
GEN_STRUCT(EP_TIME_SCALE_SET_CMD)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_EP_SERVICES_H */
