
/***************************************************************************
**  Module:     tsync_genpurpoutput_services_recipes.h
**
**  Date:       08/05/08
**
**  Purpose:    Recipes used by the driver and TSYNC GOI library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              08/05/2008 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_go_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(GO_VALUE)
RECIPE(GO_INDEX_VALUE)
RECIPE(GO_INT_SET_CMD)
RECIPE(GO_INT_VALUE)
RECIPE(GO_MATCH_ENABLE_GET_CMD)
RECIPE(GO_MATCH_ENABLE_SET_CMD)
RECIPE(GO_SQUARE_WAVE_GET_RESP)
RECIPE(GO_SQUARE_WAVE_SET_CMD)
RECIPE(GO_SET_PER_CORR)
RECIPE(GO_PER_CORR)

#include "tsync_recipe_undef.h"
