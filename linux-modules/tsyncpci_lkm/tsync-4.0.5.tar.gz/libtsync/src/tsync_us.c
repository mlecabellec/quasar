#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_us_services.h"
#include "tsync_fs_services.h"

extern uint8_t DATA_CMD_RECIPE[];
extern uint8_t UL_IMG_HDR_RECIPE[];
extern uint8_t UL_IMG_OBJ_RECIPE[];
extern uint8_t UL_IMG_TRL_RECIPE[];
extern uint8_t UPDATE_START_CMD_RECIPE[];
extern uint8_t UPDATE_START_OC_CMD_RECIPE[];
extern uint8_t UPDATE_START_COMP_CMD_RECIPE[];
extern uint8_t US_STATE_RECIPE[];


/**********************************************************************
*
* FUNCTION:     TSYNC_US_start
*
* DESCRIPTION:  Routine starts upgrade process.
*
* Arguments:    Pointer to TSYNC_BoardObj handle
*               Pointer to TSYNC_ULImageHeaderObj object
*
* RETURNS:      TSYNC_SUCCESS    - success
*               TSYNC_HANDLE_ERR - invalid arg pointers
*               TSYNC_COMM_ERR   - error interacting with device
*
**********************************************************************/
TSYNC_ERROR
TSYNC_US_start(
    TSYNC_BoardHandle       hnd,
    TSYNC_ULImageHeaderObj *obj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    if ( ( handle == NULL ) || ( obj == NULL ))
    {
        return (TSYNC_HANDLE_ERR);
    }

        struct UPDATE_START_CMD inPayload;
        inPayload.typeHack = obj->type;
        inPayload.hdr.mark = obj->mark;
        inPayload.hdr.type = obj->type;
        inPayload.hdr.len = obj->len;

        uint16_t ctl = 0x02;//set
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(UPDATE_START_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_US,
            TSYNC_ID_US_CA_START,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            UPDATE_START_CMD_RECIPE,
            NULL,
            result,
            handle);

    return ( err );
}


/**********************************************************************
*
* FUNCTION:     TSYNC_US_startOC
*
* DESCRIPTION:  Routine starts upgrade process to option card.
*
* Arguments:    Pointer to TSYNC_BoardObj handle
*               Pointer to TSYNC_ULImageHeaderObj object
*
* RETURNS:      TSYNC_SUCCESS    - success
*               TSYNC_HANDLE_ERR - invalid arg pointers
*               TSYNC_COMM_ERR   - error interacting with device
*
**********************************************************************/
TSYNC_ERROR
TSYNC_US_startOC(
    TSYNC_BoardHandle       hnd,
    TSYNC_ULImageIdObj     *obj1,
    TSYNC_ULImageHeaderObj *obj2)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    if ( ( handle == NULL ) || ( obj1 == NULL ) || ( obj2 == NULL ))
    {
        return (TSYNC_HANDLE_ERR);
    }

        struct UPDATE_START_OC_CMD inPayload;
        inPayload.imgId.type = obj1->type;
        inPayload.imgId.slot = obj1->slot;
        inPayload.hdr.mark   = obj2->mark;
        inPayload.hdr.type   = obj2->type;
        inPayload.hdr.len    = obj2->len;

        uint16_t ctl = 0x02;//set
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(UPDATE_START_OC_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_US,
            TSYNC_ID_US_CA_START_OC,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            UPDATE_START_OC_CMD_RECIPE,
            NULL,
            result,
            handle);

    return ( err );
}

/**********************************************************************
*
* FUNCTION:     TSYNC_US_startComp
*
* DESCRIPTION:  Routine starts upgrade process for components.
*
* Arguments:    Pointer to TSYNC_BoardObj handle
*               Pointer to TSYNC_ULImageHeaderObj object
*
* RETURNS:      TSYNC_SUCCESS    - success
*               TSYNC_HANDLE_ERR - invalid arg pointers
*               TSYNC_COMM_ERR   - error interacting with device
*
**********************************************************************/
TSYNC_ERROR
TSYNC_US_startComp(
    TSYNC_BoardHandle       hnd,
    TSYNC_ULImageIdObj     *obj1,
    TSYNC_ULImageHeaderObj *obj2)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    if ( ( handle == NULL ) || ( obj1 == NULL ) || ( obj2 == NULL ))
    {
        return (TSYNC_HANDLE_ERR);
    }

        struct UPDATE_START_COMP_CMD inPayload;
        inPayload.imgId.type = obj1->type;
        inPayload.imgId.slot = obj1->slot;
        inPayload.hdr.mark   = obj2->mark;
        inPayload.hdr.type   = obj2->type;
        inPayload.hdr.len    = obj2->len;

        uint16_t ctl = 0x02;//set
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(UPDATE_START_COMP_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_US,
            TSYNC_ID_US_CA_START_COMP,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            UPDATE_START_COMP_CMD_RECIPE,
            NULL,
            result,
            handle);

    return ( err );
}

/**********************************************************************
*
* FUNCTION:     TSYNC_US_data
*
* DESCRIPTION:  Routine retrieves the Status from  the
*               TSYNC board.
*
* Arguments:    Pointer to TSYNC_BoardObj handle
*               Pointer to TSYNC_UpdateDataObj object
*
* RETURNS:      TSYNC_SUCCESS    - success
*               TSYNC_HANDLE_ERR - invalid arg pointers
*               TSYNC_COMM_ERR   - error interacting with device
*
**********************************************************************/
TSYNC_ERROR
TSYNC_US_data( TSYNC_BoardHandle hnd, TSYNC_UpdateDataObj *obj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(obj);

        struct DATA_CMD inPayload;
        inPayload.image = obj->type;
        memcpy(inPayload.data, obj->data, 1024);

        uint16_t ctl = 0x02;//set
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(DATA_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_US,
            TSYNC_ID_US_CA_DATA,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            DATA_CMD_RECIPE,
            NULL,
            result,
            handle);

    return ( err );
}


TSYNC_ERROR
TSYNC_US_getState( TSYNC_BoardHandle hnd, TSYNC_StateObj *obj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(obj);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(US_STATE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_US,
            TSYNC_ID_US_CA_STATE,
            ctl,
            pyldLen,
            NULL,
            NULL,
            US_STATE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct US_STATE* outPayload =
            (US_STATE*)GetPayload(result);

        obj->image = (unsigned int)outPayload->image;
        obj->step = (unsigned int)outPayload->step;
        obj->complete = (unsigned int)outPayload->complete;

        return ( err );
}

/**********************************************************************
*
* FUNCTION:     TSYNC_US_end
*
* DESCRIPTION:  Routine retrieves the Status from  the
*               TSYNC board.
*
* Arguments:    Pointer to TSYNC_BoardObj handle
*               Pointer to TSYNC_UpdateEndObj object
*
* RETURNS:      TSYNC_SUCCESS    - success
*               TSYNC_HANDLE_ERR - invalid arg pointers
*               TSYNC_COMM_ERR   - error interacting with device
*
**********************************************************************/
TSYNC_ERROR
TSYNC_US_end( TSYNC_BoardHandle hnd, TSYNC_UpdateEndObj *obj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(obj);

        struct UL_IMG_TRL inPayload;
        inPayload.image = obj->type;
        inPayload.crc = obj->crc;
        memcpy(inPayload.ver, obj->ver, sizeof(inPayload.ver));

        uint16_t ctl = 0x02;//set
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(UL_IMG_TRL_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_US,
            TSYNC_ID_US_CA_END,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            UL_IMG_TRL_RECIPE,
            NULL,
            result,
            handle);

    return ( err );
}



TSYNC_ERROR
TSYNC_US_cancel( TSYNC_BoardHandle hnd, UL_IMG imageType)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct UL_IMG_OBJ inPayload;
        inPayload.image = imageType;

        uint16_t ctl = 0x02;//set
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(UL_IMG_OBJ_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_US,
            TSYNC_ID_US_CA_CANCEL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            UL_IMG_OBJ_RECIPE,
            NULL,
            result,
            handle);

        return ( err );
}

