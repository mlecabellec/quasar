
#ifndef _defined_TSYNC_AP_SERVICES_H
#define _defined_TSYNC_AP_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_ap_services.h
**
**  Date:       09/10/09
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2009 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              09/10/2009 Creation
**
****************************************************************************/

#include "tsync_cs_services.h"

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_AP                     0x33
#define TSYNC_ID_AP_CA_SIG_CTL          0x00
#define TSYNC_ID_AP_CA_LOCAL            0x02
#define TSYNC_ID_AP_CA_TIME_SCALE       0x03
#define TSYNC_ID_AP_CA_FORMAT           0x04
#define TSYNC_ID_AP_CA_MODE             0x06
#define TSYNC_ID_AP_CA_REQ_CHAR         0x08
#define TSYNC_ID_AP_CA_UART_CFG         0x09
#define TSYNC_ID_AP_CA_NUM_INST         0x0A
#define TSYNC_ID_AP_CA_SOURCE           0x0B
#define TSYNC_ID_AP_CA_OFFSET           0x0C

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define AP_VALUE_FIELDS                         \
    TSYNC_X(        uint32_t,           value)

#define AP_SET_CMD_FIELDS                       \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X(        uint32_t,           value)

#define AP_REQ_CHAR_OBJ_FIELDS                  \
    TSYNC_X(        int32_t,            reqchar)

#define AP_REQ_CHAR_SET_CMD_FIELDS              \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X(        int32_t,            reqchar)

#define AP_UART_CFG_OBJ_FIELDS                  \
    TSYNC_X(        UD_BR,              baud)   \
    TSYNC_X(        UD_DATA,            db)     \
    TSYNC_X(        UD_STOP,            sb)     \
    TSYNC_X(        UD_PAR,             par)

#define AP_UART_CFG_SET_CMD_FIELDS              \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X(        UD_BR,              baud)   \
    TSYNC_X(        UD_DATA,            db)     \
    TSYNC_X(        UD_STOP,            sb)     \
    TSYNC_X(        UD_PAR,             par)

#define AP_LOCAL_SET_CMD_FIELDS                 \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X(        ML_DST_REF,         ref)    \
    TSYNC_X_STRUCT( ML_DST_POINT,       in)     \
    TSYNC_X_STRUCT( ML_DST_POINT,       out)    \
    TSYNC_X(        uint32_t,           offset) \
    TSYNC_X(        int32_t,            tz)

#define AP_TIME_SCALE_SET_CMD_FIELDS            \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X_STRUCT( ML_TIME_SCALE_OBJ,  scale)

#define AP_FORMAT_OBJ_FIELDS                    \
    TSYNC_X(        AL_FMT,             fmt0)   \
    TSYNC_X(        AL_FMT,             fmt1)   \
    TSYNC_X(        AL_FMT,             fmt2)

#define AP_FORMAT_SET_CMD_FIELDS                \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X(        AL_FMT,             fmt0)   \
    TSYNC_X(        AL_FMT,             fmt1)   \
    TSYNC_X(        AL_FMT,             fmt2)

#include "tsync_struct_define.h"

GEN_STRUCT(AP_VALUE)
GEN_STRUCT(AP_SET_CMD)
GEN_STRUCT(AP_REQ_CHAR_OBJ)
GEN_STRUCT(AP_REQ_CHAR_SET_CMD)
GEN_STRUCT(AP_UART_CFG_OBJ)
GEN_STRUCT(AP_UART_CFG_SET_CMD)
GEN_STRUCT(AP_LOCAL_SET_CMD)
GEN_STRUCT(AP_TIME_SCALE_SET_CMD)
GEN_STRUCT(AP_FORMAT_OBJ)
GEN_STRUCT(AP_FORMAT_SET_CMD)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_AP_SERVICES_H */
