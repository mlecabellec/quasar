
#ifndef _defined_TSYNC_GO_SERVICES_H
#define _defined_TSYNC_GO_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_go_services.h
**
**  Date:       08/05/08
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC GOI library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              08/05/2008 Creation
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_GO                     0x39
#define TSYNC_ID_GO_CA_SIG_CTL          0x00
#define TSYNC_ID_GO_CA_OUTPUT_EN        0x01
#define TSYNC_ID_GO_CA_VALUE            0x02
#define TSYNC_ID_GO_CA_MODE             0x03
#define TSYNC_ID_GO_CA_DVM_VALUE        0x04
#define TSYNC_ID_GO_CA_MATCH_EN         0x05
#define TSYNC_ID_GO_CA_SQUARE           0x06
#define TSYNC_ID_GO_CA_NUM_INST         0x07
#define TSYNC_ID_GO_CA_SW_OFFSET        0x08
#define TSYNC_ID_GO_CA_SW_PERIOD        0x09
#define TSYNC_ID_GO_CA_SW_PW            0x0A
#define TSYNC_ID_GO_CA_SW_EDGE          0x0B
#define TSYNC_ID_GO_CA_SW_PER_CORR      0x0C
#define TSYNC_ID_GO_CA_SW_ALIGN_CNT     0x0D
#define TSYNC_ID_GO_CA_SW_INIT          0x0E
#define TSYNC_ID_GO_CA_SW_TM_ALGN_EN    0x0F
#define TSYNC_ID_GO_CA_SW_OTP_PW        0x10

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define GO_VALUE_FIELDS                     \
    TSYNC_X(        uint32_t,   value)

#define GO_INDEX_VALUE_FIELDS               \
    TSYNC_X(        uint32_t,   index)      \
    TSYNC_X(        uint32_t,   value)

#define GO_INT_SET_CMD_FIELDS               \
    TSYNC_X(        uint32_t,   index)      \
    TSYNC_X(        int32_t,    value)

#define GO_INT_VALUE_FIELDS                 \
    TSYNC_X(        int32_t,    value)

#define GO_MATCH_ENABLE_GET_CMD_FIELDS      \
    TSYNC_X(        uint32_t,   index)      \
    TSYNC_X(        LEVEL,      level)

#define GO_MATCH_ENABLE_SET_CMD_FIELDS      \
    TSYNC_X(        uint32_t,   index)      \
    TSYNC_X(        LEVEL,      level)      \
    TSYNC_X(        uint32_t,   bEnable)

#define GO_SQUARE_WAVE_GET_RESP_FIELDS      \
    TSYNC_X(        int32_t,    off)        \
    TSYNC_X(        uint32_t,   per)        \
    TSYNC_X(        uint32_t,   pw)         \
    TSYNC_X(        EDGE,       ae)

#define GO_SQUARE_WAVE_SET_CMD_FIELDS       \
    TSYNC_X(        uint32_t,   index)      \
    TSYNC_X(        int32_t,    off)        \
    TSYNC_X(        uint32_t,   per)        \
    TSYNC_X(        uint32_t,   pw)         \
    TSYNC_X(        EDGE,       ae)

#define GO_SET_PER_CORR_FIELDS              \
    TSYNC_X(        uint32_t,   index)      \
    TSYNC_X(        uint32_t,   num)        \
    TSYNC_X(        uint32_t,   den)

#define GO_PER_CORR_FIELDS                  \
    TSYNC_X(        uint32_t,   num)        \
    TSYNC_X(        uint32_t,   den)

#include "tsync_struct_define.h"

GEN_STRUCT(GO_VALUE)
GEN_STRUCT(GO_INDEX_VALUE)
GEN_STRUCT(GO_INT_SET_CMD)
GEN_STRUCT(GO_INT_VALUE)
GEN_STRUCT(GO_MATCH_ENABLE_GET_CMD)
GEN_STRUCT(GO_MATCH_ENABLE_SET_CMD)
GEN_STRUCT(GO_SQUARE_WAVE_GET_RESP)
GEN_STRUCT(GO_SQUARE_WAVE_SET_CMD)
GEN_STRUCT(GO_SET_PER_CORR)
GEN_STRUCT(GO_PER_CORR)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_GO_SERVICES_H */
