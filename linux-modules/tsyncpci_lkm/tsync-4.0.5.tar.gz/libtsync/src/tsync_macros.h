#ifndef __tsync_macros_h__
#define __tsync_macros_h__ 1


#include <stdio.h>
#define errorLog(...) fprintf(stderr, __VA_ARGS__)

#define CHECK(CALLEE,EXPECTED)                                          \
{                                                                       \
    TSYNC_ERROR actualReturned = (CALLEE);                              \
    if (actualReturned != (EXPECTED)) {                                 \
                                                                        \
        errorLog("%s returned %u (%s), expected %u. (%s:%u)\n", #CALLEE, \
                 actualReturned, tsync_strerror(actualReturned),        \
                 EXPECTED, __FILE__,__LINE__);                          \
        return actualReturned;                                          \
    }                                                                   \
}

#define CHECK_NO_LOG(CALLEE,EXPECTED)                                   \
{                                                                       \
    TSYNC_ERROR actualReturned = (CALLEE);                              \
    if (actualReturned != (EXPECTED)) {                                 \
        return actualReturned;                                          \
    }                                                                   \
}

#define CHECK_HANDLE(handle) if ((handle) == NULL) { return TSYNC_HANDLE_ERR; }
#define CHECK_NOT_NULL(pointer) if ((pointer) == NULL) { return TSYNC_NULL_POINTER; }
#define CHECK_SUCCESS(callee) CHECK_NO_LOG(callee, TSYNC_SUCCESS)

#endif
