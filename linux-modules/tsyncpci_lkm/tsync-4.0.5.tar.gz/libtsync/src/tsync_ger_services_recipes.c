
/***************************************************************************
**  Module:     tsync_ger_services_recipes.c
**
**  Date:       12/15/2016
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2016 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              12/15/2016 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_ger_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(GER_VALUE)
RECIPE(GER_CUSTOM_MSG)
RECIPE(GER_OFFSET_SET_CMD)
RECIPE(GER_CUSTOM_MSG_SET_CMD)



#include "tsync_recipe_undef.h"
