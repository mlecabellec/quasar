
#ifndef _defined_TSYNC_DP_SERVICES_H
#define _defined_TSYNC_DP_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_dp_services.h
**
**  Date:       09/10/09
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2009 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              09/10/2009 Creation
**
****************************************************************************/

#include "tsync_cs_services.h"

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_DP                      0x32
#define TSYNC_ID_DP_CA_LOCAL             0x00
#define TSYNC_ID_DP_CA_FORMAT            0x01
#define TSYNC_ID_DP_CA_TIME_SCALE        0x02
#define TSYNC_ID_DP_CA_NUM_INST          0x03
#define TSYNC_ID_DP_CA_MODE              0x04

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define DP_VALUE_FIELDS                         \
    TSYNC_X(        uint32_t,           value)

#define DP_SET_CMD_FIELDS                       \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X(        uint32_t,           value)

#define DP_LOCAL_SET_CMD_FIELDS                 \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X(        ML_DST_REF,         ref)    \
    TSYNC_X_STRUCT( ML_DST_POINT,       in)     \
    TSYNC_X_STRUCT( ML_DST_POINT,       out)    \
    TSYNC_X(        uint32_t,           offset) \
    TSYNC_X(        int32_t,            tz)

#define DP_TIME_SCALE_SET_CMD_FIELDS            \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X_STRUCT( ML_TIME_SCALE_OBJ,  scale)

#include "tsync_struct_define.h"

GEN_STRUCT(DP_VALUE)
GEN_STRUCT(DP_SET_CMD)
GEN_STRUCT(DP_LOCAL_SET_CMD)
GEN_STRUCT(DP_TIME_SCALE_SET_CMD)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_QP_SERVICES_H */
