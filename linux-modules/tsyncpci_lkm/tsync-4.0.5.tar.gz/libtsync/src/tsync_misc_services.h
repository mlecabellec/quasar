
#ifndef _defined_TSYNC_MISC_SERVICES_H
#define _defined_TSYNC_MISC_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_misc_services.h
**
**  Date:       07/28/08
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/28/2008 Creation
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define EL_VALIDITY_FIELDS                   \
    TSYNC_X(        uint32_t,   timeValid)          \
    TSYNC_X(        uint32_t,   ppsValid)

#define EL_REF_ID_FIELDS                    \
    TSYNC_X_BUFFER( int8_t,     ref,    4)

#include "tsync_struct_define.h"

GEN_STRUCT(EL_VALIDITY)
GEN_STRUCT(EL_REF_ID)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_MISC_SERVICES_H */
