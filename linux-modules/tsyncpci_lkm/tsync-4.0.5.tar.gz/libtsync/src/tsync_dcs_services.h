
#ifndef _defined_TSYNC_DCS_SERVICES_H
#define _defined_TSYNC_DCS_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_dcs_services.h
**
**  Date:       09/11/09
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2009 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              09/11/2009 Creation
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_DCS                    0x42
#define TSYNC_ID_DCS_CA_OC_INFO         0x00
#define TSYNC_ID_DCS_CA_OC_FEAT_IDX     0x01
#define TSYNC_ID_DCS_CA_INSTANCE        0x02
#define TSYNC_ID_DCS_CA_SLOT            0x03
#define TSYNC_ID_DCS_CA_GET_OPTIONS     0x04
#define TSYNC_ID_DCS_CA_CHECK_OPTION    0x05
#define TSYNC_ID_DCS_CA_DELETE_OPTION   0x06

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define DCS_VALUE_FIELDS                    \
    TSYNC_X(        uint32_t,     value)

#define DCS_INT_VALUE_FIELDS                \
    TSYNC_X(        int32_t,      value)

#define DCS_OC_CISH_FIELDS                  \
    TSYNC_X(        uint32_t,     pldId)    \
    TSYNC_X(        uint32_t,     pldVer)   \
    TSYNC_X(        uint32_t,     unused1)  \
    TSYNC_X(        uint32_t,     unused2)  \
    TSYNC_X(        uint32_t,     numFeats) \

#define DCS_OC_HDR_FIELDS                   \
    TSYNC_X(        uint32_t,     id)       \
    TSYNC_X(        uint32_t,     ver)      \
    TSYNC_X_STRUCT( DCS_OC_CISH, cish)

#define DCS_OC_SFI_FIELDS                   \
    TSYNC_X(        int32_t,      slot)     \
    TSYNC_X(        uint32_t,     idx)

#define DCS_OC_LFI_FIELDS                   \
    TSYNC_X(        int32_t,      slot)     \
    TSYNC_X(        uint32_t,     id)       \
    TSYNC_X(        uint32_t,     inst)

#define DCS_OC_FI_FIELDS                    \
    TSYNC_X(        uint32_t,     id)       \
    TSYNC_X(        uint32_t,     inst)     \
    TSYNC_X(        uint32_t,     version)

#define DCS_FILE_OPTION_FIELDS                   \
    TSYNC_X(        uint8_t,   length)       \
	TSYNC_X_BUFFER( uint8_t,    filler,         3)  \
	TSYNC_X_BUFFER( uint8_t,   type,    DCS_TYPE_LICENSE_MAX)
	
#include "tsync_struct_define.h"

GEN_STRUCT(DCS_VALUE)
GEN_STRUCT(DCS_INT_VALUE)
GEN_STRUCT(DCS_OC_CISH)
GEN_STRUCT(DCS_OC_HDR)
GEN_STRUCT(DCS_OC_SFI)
GEN_STRUCT(DCS_OC_LFI)
GEN_STRUCT(DCS_OC_FI)
GEN_STRUCT(DCS_FILE_OPTION)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_DCS_SERVICES_H */
