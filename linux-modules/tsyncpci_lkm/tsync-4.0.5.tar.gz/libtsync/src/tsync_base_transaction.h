
#include "tsync.h"
#include "tsync_trans.h"

uint32_t
SizeOfResult(uint32_t expectedPayloadSize);

TSYNC_ERROR
BaseTransaction(
        uint8_t     cai,
        uint8_t     iid,
        uint16_t     ctl,
        uint32_t     pyldLen,
        uint8_t*    pInPayload,
        uint8_t*    pInRecipe,
        uint8_t*    pOutRecipe,
        TSYNC_TransResult     outHolder,
        TSYNC_BoardObj *hnd);

TSYNC_TransResult
GetPayload(TSYNC_TransResult     outHolder);
        
uint8_t
IsResultError(
        TSYNC_TransResult     outHolder);
        
uint32_t sizeofRecipe(uint8_t *pRecipe, uint8_t *pPos);

uint32_t sizeofUnion(uintptr_t *pRecipe);
