#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_fp_services.h"
#include "tsync_misc_services.h"

extern uint8_t FP_SET_CMD_RECIPE[];
extern uint8_t FP_VALUE_RECIPE[];
extern uint8_t FP_FREQ_RECIPE[];

TSYNC_ERROR
TSYNC_FP_getSigCtrl(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    SIG_CTL *sig)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(sig);

        struct FP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(FP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(FP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_FP,
            TSYNC_ID_FP_CA_SIG_CTL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            FP_VALUE_RECIPE,
            FP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct FP_VALUE* outPayload =
            (FP_VALUE*)GetPayload(result);

        *sig = (SIG_CTL)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_FP_setSigCtrl(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    SIG_CTL sig)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct FP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = sig;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(FP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_FP,
            TSYNC_ID_FP_CA_SIG_CTL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            FP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_FP_getFreq(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    float *freq)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(freq);

        struct FP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(FP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(FP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_FP,
            TSYNC_ID_FP_CA_FREQ,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            FP_VALUE_RECIPE,
            FP_FREQ_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct FP_FREQ* outPayload =
            (FP_FREQ*)GetPayload(result);

        *freq = outPayload->freq;

    return ( err );
}

TSYNC_ERROR
TSYNC_FP_getNumInst(
    TSYNC_BoardHandle hnd,
    unsigned int *nInstances)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nInstances);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(FP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_FP,
            TSYNC_ID_FP_CA_NUM_INST,
            ctl,
            pyldLen,
            NULL,
            NULL,
            FP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct FP_VALUE* outPayload =
            (FP_VALUE*)GetPayload(result);

        *nInstances = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_FP_getPllLock(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int *pllLock)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pllLock);

        struct FP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(FP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(FP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_FP,
            TSYNC_ID_FP_CA_PLL_LOCK,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            FP_VALUE_RECIPE,
            FP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct FP_VALUE* outPayload =
            (FP_VALUE*)GetPayload(result);

        *pllLock = outPayload->value;

    return ( err );
}

