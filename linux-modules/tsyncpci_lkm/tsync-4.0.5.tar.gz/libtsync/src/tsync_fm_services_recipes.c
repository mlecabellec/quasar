
/***************************************************************************
**  Module:     tsync_fm_services_recipes.h
**
**  Date:       09/09/09
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2009 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              09/09/2009 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_fm_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(FM_VALUE)
RECIPE(FM_SET_CMD)
RECIPE(FM_FLOAT_VALUE)
RECIPE(FM_SET_FLOAT_CMD)
RECIPE(FM_FLOAT_BUF)

#include "tsync_recipe_undef.h"
