
#ifndef _defined_TSYNC_IP_SERVICES_H
#define _defined_TSYNC_IP_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_ip_services.h
**
**  Date:       08/04/08
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              08/04/2008 Creation
**
****************************************************************************/

#include "tsync_cs_services.h"

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_IP                     0x2F
#define TSYNC_ID_IP_CA_SIG_CTL          0x00
#define TSYNC_ID_IP_CA_OFFSET           0x01
#define TSYNC_ID_IP_CA_LOCAL            0x02
#define TSYNC_ID_IP_CA_FORMAT           0x03
#define TSYNC_ID_IP_CA_AMPLITUDE        0x04
#define TSYNC_ID_IP_CA_MOD              0x05
#define TSYNC_ID_IP_CA_FREQ             0x06
#define TSYNC_ID_IP_CA_CODED_EXP        0x07
#define TSYNC_ID_IP_CA_CTRL_FLD         0x08
#define TSYNC_ID_IP_CA_MESSAGE          0x09
#define TSYNC_ID_IP_CA_CFDATA           0x0A
#define TSYNC_ID_IP_CA_NUM_INST         0x0B
#define TSYNC_ID_IP_CA_PHASE            0x0C
#define TSYNC_ID_IP_CA_PHASE_ERR        0x0D
#define TSYNC_ID_IP_CA_TIME_SCALE       0x0E
#define TSYNC_ID_IP_CA_TYPE             0x0F

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define IP_VALUE_FIELDS                     \
    TSYNC_X(        uint32_t,   value)

#define IP_SET_CMD_FIELDS                   \
    TSYNC_X(        uint32_t,   inst)       \
    TSYNC_X(        uint32_t,   value)

#define IP_MOD_SET_CMD_FIELDS                   \
    TSYNC_X(        uint32_t,   inst)          \
    TSYNC_X(        IL_MOD,     mod)

#define IP_INT_VALUE_FIELDS                 \
    TSYNC_X(        int32_t,    value)

#define IP_INT_SET_CMD_FIELDS               \
    TSYNC_X(        uint32_t,   inst)       \
    TSYNC_X(        int32_t,    value)

#define IP_SHORT_FIELDS                     \
    TSYNC_X(        uint16_t,   value)

#define IP_MSG_FIELDS                       \
    TSYNC_X_ARRAY(  IP_SHORT,   subframes,  TSYNC_IP_SUBFRAME_NUM)

#define IP_MSG_SET_CMD_FIELDS               \
    TSYNC_X(        uint32_t,   inst)       \
    TSYNC_X_ARRAY(  IP_SHORT,   subframes,  TSYNC_IP_SUBFRAME_NUM)

#define IP_LOCAL_SET_CMD_FIELDS             \
    TSYNC_X(        uint32_t,       inst)   \
    TSYNC_X( ML_DST_REF,     ref)                \
    TSYNC_X_STRUCT( ML_DST_POINT,    in)                \
    TSYNC_X_STRUCT( ML_DST_POINT,    out)                \
    TSYNC_X( uint32_t,    offset)                        \
    TSYNC_X( int32_t,        tz)

#define IP_CFDATA_FIELDS                    \
    TSYNC_X_ARRAY(  IP_SHORT,   cfData,     TSYNC_IP_CFDATA_NUM)

#define IP_CFDATA_SET_CMD_FIELDS            \
    TSYNC_X(        uint32_t,   inst)       \
    TSYNC_X_ARRAY(  IP_SHORT,   cfData,     TSYNC_IP_CFDATA_NUM)

#define IP_TIME_SCALE_SET_CMD_FIELDS            \
    TSYNC_X(        uint32_t,           inst)   \
    TSYNC_X_STRUCT( ML_TIME_SCALE_OBJ,  scale)

#include "tsync_struct_define.h"

GEN_STRUCT(IP_VALUE)
GEN_STRUCT(IP_SET_CMD)
GEN_STRUCT(IP_MOD_SET_CMD)
GEN_STRUCT(IP_INT_VALUE)
GEN_STRUCT(IP_INT_SET_CMD)
GEN_STRUCT(IP_SHORT)
GEN_STRUCT(IP_MSG)
GEN_STRUCT(IP_MSG_SET_CMD)
GEN_STRUCT(IP_LOCAL_SET_CMD)
GEN_STRUCT(IP_CFDATA)
GEN_STRUCT(IP_CFDATA_SET_CMD)
GEN_STRUCT(IP_TIME_SCALE_SET_CMD)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_IP_SERVICES_H */
