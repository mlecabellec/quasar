#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"
#include "tsync_gpr_services.h"
#include "tsync_misc_services.h"
//#include "tsync_us_services.h"
//#include "tsync_fs_services.h"


extern uint8_t GPR_VALUE_RECIPE[];
extern uint8_t GPR_VALUE_SET_CMD_RECIPE[];
extern uint8_t GPL_CLOCK_ID_RECIPE[];
extern uint8_t GPL_CLOCK_ID_SET_RECIPE[];
extern uint8_t GPL_PRIORITY_RECIPE[];
extern uint8_t GPL_PRIORITY_SET_RECIPE[];
extern uint8_t GPL_CLOCK_QUAL_RECIPE[];
extern uint8_t GPL_STATISTICS_RECIPE[];
extern uint8_t GPL_PARENT_DATA_RECIPE[];
extern uint8_t GPL_TIME_PROP_RECIPE[];

extern uint8_t GPL_USER_DESC_RECIPE[];
extern uint8_t GPL_USER_DESC_SET_RECIPE[];
extern uint8_t GPL_UNCT_MASTER_ADD_RECIPE[];
extern uint8_t GPL_UNCT_MASTER_ADD_SET_RECIPE[];
extern uint8_t GPL_PORT_IDENTITY_RECIPE[];
extern uint8_t GPL_PORT_IDENTITY_SET_RECIPE[];
extern uint8_t GPL_UNCT_SLAVE_PROP_RECIPE[];
extern uint8_t GPL_UNCT_MASTER_PROP_RECIPE[];
extern uint8_t GPL_UNCT_MASTER_CFG_RECIPE[];
extern uint8_t GPL_UNCT_MASTER_CFG_SET_RECIPE[];
extern uint8_t GPL_MSG_RATES_RECIPE[];
extern uint8_t GPL_MSG_RATES_SET_RECIPE[];
extern uint8_t GPL_MSG_TO_RECIPE[];
extern uint8_t GPL_MSG_TO_SET_RECIPE[];
extern uint8_t GPL_IPV4_RECIPE[];
extern uint8_t GPL_IPV4_SET_RECIPE[];
extern uint8_t GPL_MAC_ADDR_RECIPE[];
extern uint8_t GPL_MAC_ADDR_SET_RECIPE[];
extern uint8_t GPL_SYNC_ETH_ITF_RECIPE[];
extern uint8_t GPL_SYNC_ETH_ITF_SET_RECIPE[];
extern uint8_t GPL_VLAN_RECIPE[];
extern uint8_t GPL_VLAN_SET_RECIPE[];
extern uint8_t GPL_MODULE_INFO_RECIPE[];
extern uint8_t GPL_CONTROL_RECIPE[];
extern uint8_t GPL_CONTROL_SET_RECIPE[];
extern uint8_t GPL_BCAST_MECH_RECIPE[];
extern uint8_t GPL_BCAST_MECH_SET_RECIPE[];
extern uint8_t GPL_SLAVE_STATS_RECIPE[];
extern uint8_t GPL_SLAVE_SUMMARY_RECIPE[];

TSYNC_ERROR 
TSYNC_GPR_getNumInst(
    TSYNC_BoardHandle hnd,
    unsigned int     *nInstances)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nInstances);
       
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPR_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_NUM_INST,
            ctl,
            pyldLen,
            NULL,
            NULL,
            GPR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct GPR_VALUE* outPayload =
            (GPR_VALUE*)GetPayload(result);
            
        *nInstances = (int)outPayload->value;
        
    return ( err );
    
}

TSYNC_ERROR
TSYNC_GPR_getClockIdentity(
    TSYNC_BoardHandle hnd,
    unsigned int 	  nInstance,
    TSYNC_GplClockId  *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPL_CLOCK_ID_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_CLOCK_IDENTITY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPL_CLOCK_ID_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPL_CLOCK_ID* outPayload =
            (GPL_CLOCK_ID*)GetPayload(result);

        memset(pObj->cid, '\0', sizeof(pObj->cid));

        memcpy(pObj->cid,
        		outPayload->cid,
                sizeof(outPayload->cid));

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setClockIdentity(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    TSYNC_GplClockId  *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPL_CLOCK_ID_SET inPayload;
        inPayload.nInstance = nInstance;

        memset(inPayload.cid,     '\0', sizeof(inPayload.cid));
        memcpy(inPayload.cid,
               pObj->cid,
               sizeof(inPayload.cid));

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPL_CLOCK_ID_SET_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_CLOCK_IDENTITY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPL_CLOCK_ID_SET_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getPriority(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    TSYNC_GplPriority *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPL_PRIORITY_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_PRIORITY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPL_PRIORITY_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPL_PRIORITY* outPayload =
            (GPL_PRIORITY*)GetPayload(result);

        pObj->priority1 = outPayload->priority1;
        pObj->priority2 = outPayload->priority2;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setPriority(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    TSYNC_GplPriority *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPL_PRIORITY_SET inPayload;
        inPayload.nInstance = nInstance;
        inPayload.priority1 = pObj->priority1;
        inPayload.priority2 = pObj->priority2;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPL_PRIORITY_SET_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_PRIORITY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPL_PRIORITY_SET_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getDomain(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    unsigned int      *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_DOMAIN,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPR_VALUE* outPayload =
            (GPR_VALUE*)GetPayload(result);

        *pVal = outPayload->value;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setDomain(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    unsigned int      *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.value     = *pVal;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_DOMAIN,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getClockMode(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    unsigned int      *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_CLOCK_MODE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPR_VALUE* outPayload =
            (GPR_VALUE*)GetPayload(result);

        *pVal = outPayload->value;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setClockMode(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    unsigned int      *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.value     = *pVal;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_CLOCK_MODE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getClockSteps(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    unsigned int      *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_CLOCK_STEPS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPR_VALUE* outPayload =
            (GPR_VALUE*)GetPayload(result);

        *pVal = outPayload->value;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setClockSteps(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    unsigned int      *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.value     = *pVal;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_CLOCK_STEPS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getClockPorts(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    unsigned int      *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_CLOCK_PORTS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPR_VALUE* outPayload =
            (GPR_VALUE*)GetPayload(result);

        *pVal = outPayload->value;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getClockQual(
    TSYNC_BoardHandle   hnd,
    unsigned int        nInstance,
    TSYNC_GplClockQual *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPL_CLOCK_QUAL_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_CLOCK_QUALITY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPL_CLOCK_QUAL_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPL_CLOCK_QUAL* outPayload =
            (GPL_CLOCK_QUAL*)GetPayload(result);

        pObj->clockAcc   = outPayload->clockAccuracy;
        pObj->clockClass = outPayload->clockClass;
        pObj->oSLV       = outPayload->oSLV;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getStatistics(
    TSYNC_BoardHandle    hnd,
    unsigned int         nInstance,
    TSYNC_GplStatistics *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPL_STATISTICS_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_STATISTICS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPL_STATISTICS_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPL_STATISTICS* outPayload =
            (GPL_STATISTICS*)GetPayload(result);

        pObj->meanPathDelay = outPayload->meanPathDelay;
        pObj->offFromMaster = outPayload->offFromMaster;
        pObj->stepsRemoved  = outPayload->stepsRemoved;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getParentData(
    TSYNC_BoardHandle    hnd,
    unsigned int         nInstance,
    TSYNC_GplParentData *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPL_PARENT_DATA_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_PARENT_DATA,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPL_PARENT_DATA_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPL_PARENT_DATA* outPayload =
            (GPL_PARENT_DATA*)GetPayload(result);

        memset(pObj->parentCid.cid, '\0', sizeof(pObj->parentCid.cid));

        memcpy(pObj->parentCid.cid,
                outPayload->parentCid,
                sizeof(outPayload->parentCid));

        pObj->gmPortid        = outPayload->gmPid;
        pObj->parentStatsCalc = outPayload->parentStatsCalc;
        pObj->parentObsOSLV   = outPayload->parentObsOSLV;
        pObj->parentObsCPCR   = outPayload->parentObsCPCR;

        memset(pObj->gmCid.cid, '\0', sizeof(pObj->gmCid.cid));

        memcpy(pObj->gmCid.cid,
                outPayload->gmCid,
                sizeof(outPayload->gmCid));

        pObj->gmPortid          = outPayload->gmPid;
        pObj->gmQual.clockAcc   = outPayload->gmClockAccuracy;
        pObj->gmQual.clockClass = outPayload->gmClockClass;
        pObj->gmQual.oSLV       = outPayload->gmOSLV;
        pObj->gmpri.priority1   = outPayload->gmpriority1;
        pObj->gmpri.priority2   = outPayload->gmpriority2;


    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getTimeProp(
    TSYNC_BoardHandle    hnd,
    unsigned int         nInstance,
    TSYNC_GplTimeProp    *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPL_TIME_PROP_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_TIME_PROP,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPL_TIME_PROP_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPL_TIME_PROP* outPayload =
            (GPL_TIME_PROP*)GetPayload(result);

        pObj->utcOffset      = outPayload->utcOffset;
        pObj->utcOffsetValid = outPayload->utcOffsetValid;
        pObj->forwardLeap    = outPayload->forwardLeap;
        pObj->backwardLeap   = outPayload->backwardLeap;
        pObj->timeTraceable  = outPayload->timeTraceable;
        pObj->freqTraceable  = outPayload->freqTraceable;
        pObj->ptpTimescale   = outPayload->ptpTimescale;
        pObj->timeSource     = outPayload->timeSource;


    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getUserDesc(
    TSYNC_BoardHandle    hnd,
    unsigned int         nInstance,
    TSYNC_GplUserDesc    *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPL_USER_DESC_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_USER_DESCRIPTION,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPL_USER_DESC_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPL_USER_DESC* outPayload =
            (GPL_USER_DESC*)GetPayload(result);

        memset(pObj->deviceName,     '\0', sizeof(pObj->deviceName));
        memset(pObj->deviceLocation, '\0', sizeof(pObj->deviceLocation));

        memcpy(pObj->deviceName,
                outPayload->deviceName,
                sizeof(outPayload->deviceName));

        memcpy(pObj->deviceLocation,
                outPayload->deviceLocation,
                sizeof(outPayload->deviceLocation));

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setUserDesc(
    TSYNC_BoardHandle    hnd,
    unsigned int         nInstance,
    TSYNC_GplUserDesc    *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPL_USER_DESC_SET inPayload;
        inPayload.nInstance = nInstance;

        memset(inPayload.deviceName,     '\0', sizeof(inPayload.deviceName));
        memset(inPayload.deviceLocation,
                '\0', sizeof(inPayload.deviceLocation));

        memcpy(inPayload.deviceName,
                pObj->deviceName,
                sizeof(pObj->deviceName));

        memcpy(inPayload.deviceLocation,
                pObj->deviceLocation,
                sizeof(pObj->deviceLocation));


        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPL_USER_DESC_SET_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_USER_DESCRIPTION,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPL_USER_DESC_SET_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getUnctMasterAdd(
    TSYNC_BoardHandle          hnd,
    unsigned int              nInstance,
    TSYNC_GplUnctMasterAdd    *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPL_UNCT_MASTER_ADD_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_UNCT_MASTER_ADD,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPL_UNCT_MASTER_ADD_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPL_UNCT_MASTER_ADD* outPayload =
            (GPL_UNCT_MASTER_ADD*)GetPayload(result);

        memset(pObj->masterCid,     '\0', sizeof(pObj->masterCid));

        memcpy(pObj->masterCid,
                outPayload->cid,
                sizeof(outPayload->cid));

        pObj->masterPid = outPayload->pid;

        memset(pObj->masterIPV4,     '\0', sizeof(pObj->masterIPV4));

        memcpy(pObj->masterIPV4,
                outPayload->ip,
                sizeof(outPayload->ip));

        pObj->logQuerySlaveInterval    = outPayload->logQuerySlaveInterval;
        pObj->durationSlaveContracts   = outPayload->durationSlaveContracts;
        pObj->logAnnSlaveInterval      = outPayload->logAnnSlaveInterval;
        pObj->logSyncMasterInterval    = outPayload->logSyncMasterInterval;
        pObj->logDelayReqSlaveInterval = outPayload->logDelayReqSlaveInterval;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setUnctMasterAdd(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    TSYNC_GplUnctMasterAdd    *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPL_UNCT_MASTER_ADD_SET inPayload;
        inPayload.nInstance = nInstance;

        memset(inPayload.cid,     '\0', sizeof(inPayload.cid));

        memcpy(inPayload.cid,
                pObj->masterCid,
                sizeof(pObj->masterCid));

        inPayload.pid = pObj->masterPid;

        memset(inPayload.ip,     '\0', sizeof(inPayload.ip));

        memcpy(inPayload.ip,
                pObj->masterIPV4,
                sizeof(pObj->masterIPV4));

        inPayload.logQuerySlaveInterval    = pObj->logQuerySlaveInterval;
        inPayload.durationSlaveContracts   = pObj->durationSlaveContracts;
        inPayload.logAnnSlaveInterval      = pObj->logAnnSlaveInterval;
        inPayload.logSyncMasterInterval    = pObj->logSyncMasterInterval;
        inPayload.logDelayReqSlaveInterval = pObj->logDelayReqSlaveInterval;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPL_UNCT_MASTER_ADD_SET_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_UNCT_MASTER_ADD,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPL_UNCT_MASTER_ADD_SET_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setUnctMasterDel(
    TSYNC_BoardHandle    hnd,
    unsigned int         nInstance,
    TSYNC_GplPortId      *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPL_PORT_IDENTITY_SET inPayload;
        inPayload.nInstance = nInstance;

        memset(inPayload.cid,     '\0', sizeof(inPayload.cid));

        memcpy(inPayload.cid,
               pObj->cid,
               sizeof(inPayload.cid));

        inPayload.pid = pObj->pid;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPL_PORT_IDENTITY_SET_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_UNCT_MASTER_DEL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPL_PORT_IDENTITY_SET_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getUnctSlaveProp(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    TSYNC_GplUnctSlaveProp    *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPL_UNCT_SLAVE_PROP_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_UNCT_SLAVE_PROP,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPL_UNCT_SLAVE_PROP_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPL_UNCT_SLAVE_PROP* outPayload =
            (GPL_UNCT_SLAVE_PROP*)GetPayload(result);

        pObj->negoEnabled   = outPayload->negoEnabled;

        memset(pObj->contractAnnState, '\0', sizeof(pObj->contractAnnState));

        memcpy(pObj->contractAnnState,
                outPayload->contractAnnState,
                sizeof(outPayload->contractAnnState));

        pObj->durationAnnContracts = outPayload->durationAnnContracts;
        pObj->delayAnnContracts    = outPayload->delayAnnContracts;
        pObj->logAnnMsgInterval    = outPayload->logAnnMsgInterval;

        memset(pObj->contractSyncState, '\0', sizeof(pObj->contractSyncState));

        memcpy(pObj->contractSyncState,
                outPayload->contractSyncState,
                sizeof(outPayload->contractSyncState));

        pObj->durationSyncContracts = outPayload->durationSyncContracts;
        pObj->delaySyncContracts    = outPayload->delaySyncContracts;
        pObj->logSyncMsgInterval    = outPayload->logSyncMsgInterval;

        memset(pObj->contractDelayRespState, '\0',
                sizeof(pObj->contractDelayRespState));

        memcpy(pObj->contractDelayRespState,
                outPayload->contractDelayRespState,
                sizeof(outPayload->contractDelayRespState));

        pObj->durationDelayRespContracts =
                outPayload->durationDelayRespContracts;
        pObj->delayDelayRespContracts    = outPayload->delayDelayRespContracts;
        pObj->logDelayRespMsgInterval    = outPayload->logDelayRespMsgInterval;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getUnctMasterProp(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    TSYNC_GplUnctMasterProp   *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPL_UNCT_MASTER_PROP_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_UNCT_MASTER_PROP,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPL_UNCT_MASTER_PROP_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPL_UNCT_MASTER_PROP* outPayload =
            (GPL_UNCT_MASTER_PROP*)GetPayload(result);

        pObj->negoEnabled      = outPayload->negoEnabled;
        pObj->nbSlaveConnected = outPayload->nbSlaveConnected;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getUnctMasterCfg(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    TSYNC_GplUnctMasterCfg    *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPL_UNCT_MASTER_CFG_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_UNCT_MASTER_CFG,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPL_UNCT_MASTER_CFG_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPL_UNCT_MASTER_CFG* outPayload =
            (GPL_UNCT_MASTER_CFG*)GetPayload(result);

        pObj->minAnnInt   = outPayload->minAnnInt;
        pObj->maxAnnDur   = outPayload->maxAnnDur;
        pObj->minSyncInt  = outPayload->minSyncInt;
        pObj->maxSyncDur  = outPayload->maxSyncDur;
        pObj->minDRqInt   = outPayload->minDRqInt;
        pObj->maxDRqDur   = outPayload->maxDRqDur;
        pObj->maxSlaves   = outPayload->maxSlaves;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setUnctMasterCfg(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    TSYNC_GplUnctMasterCfg    *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPL_UNCT_MASTER_CFG_SET inPayload;
        inPayload.nInstance   = nInstance;
        inPayload.minAnnInt   = pObj->minAnnInt;
        inPayload.maxAnnDur   = pObj->maxAnnDur;
        inPayload.minSyncInt  = pObj->minSyncInt;
        inPayload.maxSyncDur  = pObj->maxSyncDur;
        inPayload.minDRqInt   = pObj->minDRqInt;
        inPayload.maxDRqDur   = pObj->maxDRqDur;
        inPayload.maxSlaves   = pObj->maxSlaves;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPL_UNCT_MASTER_CFG_SET_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_UNCT_MASTER_CFG,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPL_UNCT_MASTER_CFG_SET_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getPortState(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    unsigned int              *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_PORT_STATE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPR_VALUE* outPayload =
            (GPR_VALUE*)GetPayload(result);

        *pVal = outPayload->value;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getMsgRates(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    TSYNC_GplMsgRates    *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPL_MSG_RATES_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_MSG_RATES,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPL_MSG_RATES_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPL_MSG_RATES* outPayload =
            (GPL_MSG_RATES*)GetPayload(result);

        pObj->logAnnInterval       = outPayload->logAnnInterval;
        pObj->logSyncInterval      = outPayload->logSyncInterval;
        pObj->logDelayReqInterval  = outPayload->logDelayReqInterval;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setMsgRates(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    TSYNC_GplMsgRates        *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPL_MSG_RATES_SET inPayload;
        inPayload.nInstance = nInstance;
        inPayload.logAnnInterval       = pObj->logAnnInterval;
        inPayload.logSyncInterval      = pObj->logSyncInterval;
        inPayload.logDelayReqInterval  = pObj->logDelayReqInterval;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPL_MSG_RATES_SET_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_MSG_RATES,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPL_MSG_RATES_SET_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getMsgTo(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    TSYNC_GplMsgTo            *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPL_MSG_TO_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_MSG_TO,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPL_MSG_TO_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPL_MSG_TO* outPayload =
            (GPL_MSG_TO*)GetPayload(result);

        pObj->annRcptTimeout    = outPayload->annRcptTimeout;
        pObj->syncTimeout       = outPayload->syncTimeout;
        pObj->delayRespTimeout  = outPayload->delayRespTimeout;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setMsgTo(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    TSYNC_GplMsgTo            *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPL_MSG_TO_SET inPayload;
        inPayload.nInstance = nInstance;
        inPayload.annRcptTimeout    = pObj->annRcptTimeout;
        inPayload.syncTimeout       = pObj->syncTimeout;
        inPayload.delayRespTimeout  = pObj->delayRespTimeout;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPL_MSG_TO_SET_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_MSG_TO,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPL_MSG_TO_SET_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getDelayMech(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    unsigned int              *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_DELAY_MECH,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPR_VALUE* outPayload =
            (GPR_VALUE*)GetPayload(result);

        *pVal = outPayload->value;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setDelayMech(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    unsigned int              *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.value     = *pVal;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_DELAY_MECH,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getBcastMech(
    TSYNC_BoardHandle    hnd,
    unsigned int         nInstance,
    TSYNC_GplBcastMech  *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPL_BCAST_MECH_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_BCAST_MECH,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPL_BCAST_MECH_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPL_BCAST_MECH* outPayload =
            (GPL_BCAST_MECH*)GetPayload(result);

        pObj->mSync   = outPayload->mSync;
        pObj->mDelReq = outPayload->mDlyReq;
        pObj->uSync   = outPayload->uSync;
        pObj->uDelReq = outPayload->uDlyReq;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setBcastMech(
    TSYNC_BoardHandle    hnd,
    unsigned int         nInstance,
    TSYNC_GplBcastMech  *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPL_BCAST_MECH_SET inPayload;
        inPayload.nInstance = nInstance;
        inPayload.mSync   = pObj->mSync;
        inPayload.mDlyReq = pObj->mDelReq;
        inPayload.uSync   = pObj->uSync;
        inPayload.uDlyReq = pObj->uDelReq;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPL_BCAST_MECH_SET_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_BCAST_MECH,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPL_BCAST_MECH_SET_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}



TSYNC_ERROR
TSYNC_GPR_getStaticIPV4(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    TSYNC_GplIpV4             *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPL_IPV4_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_STATIC_IPV4,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPL_IPV4_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPL_IPV4* outPayload =
            (GPL_IPV4*)GetPayload(result);

        memset(pObj->ipV4Addr,    '\0', sizeof(pObj->ipV4Addr));

        memcpy(pObj->ipV4Addr,
                outPayload->ipV4Addr,
                sizeof(outPayload->ipV4Addr));

        memset(pObj->netmask,     '\0', sizeof(pObj->netmask));

        memcpy(pObj->netmask,
                outPayload->netmask,
                sizeof(outPayload->netmask));

        memset(pObj->gateway,     '\0', sizeof(pObj->gateway));

        memcpy(pObj->gateway,
                outPayload->gateway,
                sizeof(outPayload->gateway));


    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setStaticIPV4(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    TSYNC_GplIpV4             *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPL_IPV4_SET inPayload;
        inPayload.nInstance = nInstance;
        memset(inPayload.ipV4Addr,    '\0', sizeof(inPayload.ipV4Addr));

        memcpy(inPayload.ipV4Addr,
                pObj->ipV4Addr,
                sizeof(pObj->ipV4Addr));

        memset(inPayload.netmask,     '\0', sizeof(inPayload.netmask));

        memcpy(inPayload.netmask,
                pObj->netmask,
                sizeof(pObj->netmask));

        memset(inPayload.gateway,     '\0', sizeof(inPayload.gateway));

        memcpy(inPayload.gateway,
                pObj->gateway,
                sizeof(pObj->gateway));

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPL_IPV4_SET_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_STATIC_IPV4,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPL_IPV4_SET_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getCurrentIPV4(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    TSYNC_GplIpV4             *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPL_IPV4_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_CURRENT_IPV4,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPL_IPV4_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPL_IPV4* outPayload =
            (GPL_IPV4*)GetPayload(result);

        memset(pObj->ipV4Addr,    '\0', sizeof(pObj->ipV4Addr));

        memcpy(pObj->ipV4Addr,
                outPayload->ipV4Addr,
                sizeof(outPayload->ipV4Addr));

        memset(pObj->netmask,     '\0', sizeof(pObj->netmask));

        memcpy(pObj->netmask,
                outPayload->netmask,
                sizeof(outPayload->netmask));

        memset(pObj->gateway,     '\0', sizeof(pObj->gateway));

        memcpy(pObj->gateway,
                outPayload->gateway,
                sizeof(outPayload->gateway));


    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getDHCPEn(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    unsigned int              *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_DHCP,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPR_VALUE* outPayload =
            (GPR_VALUE*)GetPayload(result);

        *pVal = outPayload->value;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setDHCPEn(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    unsigned int              *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.value     = *pVal;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_DHCP,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getMacAddr(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    TSYNC_GplMacAddr          *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPL_MAC_ADDR_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_MAC_ADDR,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPL_MAC_ADDR_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPL_MAC_ADDR* outPayload =
            (GPL_MAC_ADDR*)GetPayload(result);

        memset(pObj->macAddr,     '\0', sizeof(pObj->macAddr));

        memcpy(pObj->macAddr,
                outPayload->macAddr,
                sizeof(outPayload->macAddr));

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setMacAddr(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    TSYNC_GplMacAddr          *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPL_MAC_ADDR_SET inPayload;
        inPayload.nInstance = nInstance;

        memset(inPayload.macAddr,     '\0', sizeof(inPayload.macAddr));

        memcpy(inPayload.macAddr,
                pObj->macAddr,
                sizeof(pObj->macAddr));

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPL_MAC_ADDR_SET_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_MAC_ADDR,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPL_MAC_ADDR_SET_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getTTL(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    unsigned int              *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_TTL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPR_VALUE* outPayload =
            (GPR_VALUE*)GetPayload(result);

        *pVal = outPayload->value;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setTTL(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    unsigned int              *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.value     = *pVal;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_TTL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getEthTrans(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    unsigned int              *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_ETH_TRANS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPR_VALUE* outPayload =
            (GPR_VALUE*)GetPayload(result);

        *pVal = outPayload->value;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setEthTrans(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    unsigned int              *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.value     = *pVal;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_ETH_TRANS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getSyncEth(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    TSYNC_GplSyncEth          *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPL_SYNC_ETH_ITF_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_SYNC_ETH,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPL_SYNC_ETH_ITF_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPL_SYNC_ETH_ITF* outPayload =
            (GPL_SYNC_ETH_ITF*)GetPayload(result);

        pObj->enableSyncE = outPayload->enableSyncE;
        pObj->esmcEnable  = outPayload->esmcEnable;
        pObj->esmcSigCtl  = outPayload->esmcSigCtl;
        pObj->ssmCode     = outPayload->ssmCode;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setSyncEth(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    TSYNC_GplSyncEth          *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPL_SYNC_ETH_ITF_SET inPayload;
        inPayload.nInstance = nInstance;
        inPayload.enableSyncE = pObj->enableSyncE;
        inPayload.esmcEnable  = pObj->esmcEnable;
        inPayload.esmcSigCtl  = pObj->esmcSigCtl;
        inPayload.ssmCode     = pObj->ssmCode;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPL_SYNC_ETH_ITF_SET_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_SYNC_ETH,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPL_SYNC_ETH_ITF_SET_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getVLAN(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    TSYNC_GplVlan             *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPL_VLAN_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_VLAN,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPL_VLAN_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPL_VLAN* outPayload =
            (GPL_VLAN*)GetPayload(result);

        pObj->vLanIntEnable      = outPayload->vLanIntEnable;
        pObj->vLanID             = outPayload->vLanID;
        pObj->priorityCodePoint  = outPayload->priorityCodePoint;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setVLAN(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    TSYNC_GplVlan             *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPL_VLAN_SET inPayload;
        inPayload.nInstance = nInstance;
        inPayload.vLanIntEnable      = pObj->vLanIntEnable;
        inPayload.vLanID             = pObj->vLanID;
        inPayload.priorityCodePoint  = pObj->priorityCodePoint;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPL_VLAN_SET_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_VLAN,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPL_VLAN_SET_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getClassCfg(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    unsigned int      *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_CLASS_CFG,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPR_VALUE* outPayload =
            (GPR_VALUE*)GetPayload(result);

        *pVal = outPayload->value;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setClassCfg(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    unsigned int      *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.value     = *pVal;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_CLASS_CFG,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getModuleInfo(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    TSYNC_GplModuleInfo       *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPL_MODULE_INFO_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_MODULE_INFO,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPL_MODULE_INFO_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPL_MODULE_INFO* outPayload =
            (GPL_MODULE_INFO*)GetPayload(result);

        pObj->ptpVerisonNumber = outPayload->ptpVersionNumber;
        pObj->softwareVersion = outPayload->softwareVersion;
        pObj->hardwareVersion  = outPayload->hardwareVersion;

        memset(pObj->softDate,     '\0', sizeof(pObj->softDate));

        memcpy(pObj->softDate,
                outPayload->softDate,
                sizeof(outPayload->softDate));

        memset(pObj->softTime,     '\0', sizeof(pObj->softTime));

        memcpy(pObj->softTime,
                outPayload->softTime,
                sizeof(outPayload->softTime));

    return ( err );

}

TSYNC_ERROR
TSYNC_GPR_getControl(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    TSYNC_GplControl  *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPL_CONTROL_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_CONTROL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPL_CONTROL_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPL_CONTROL* outPayload =
            (GPL_CONTROL*)GetPayload(result);

        pObj->networkEn = outPayload->networkEn;
        pObj->ptpEn     = outPayload->ptpEn;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setControl(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    TSYNC_GplControl  *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPL_CONTROL_SET inPayload;
        inPayload.nInstance = nInstance;
        inPayload.networkEn = pObj->networkEn;
        inPayload.ptpEn     = pObj->ptpEn;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPL_CONTROL_SET_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_CONTROL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPL_CONTROL_SET_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}

TSYNC_ERROR
TSYNC_GPR_getPortSpeed(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    unsigned int      *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_PORT_SPEED,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPR_VALUE* outPayload =
            (GPR_VALUE*)GetPayload(result);

        *pVal = outPayload->value;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setPortSpeed(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    unsigned int      *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.value     = *pVal;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_PORT_SPEED,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}

TSYNC_ERROR
TSYNC_GPR_getSlaveStats(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    TSYNC_GplSlaveStats  *pObj)

{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPL_SLAVE_STATS_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_SLAVE_STATS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPL_SLAVE_STATS_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPL_SLAVE_STATS* outPayload =
            (GPL_SLAVE_STATS*)GetPayload(result);

        pObj->slaveNum  = outPayload->slaveNum;

        memset(pObj->cid, '\0', sizeof(pObj->cid));
        memcpy(pObj->cid,
                outPayload->cid,
                sizeof(outPayload->cid));

        pObj->pid       = outPayload->pid;

        memset(pObj->ipV4Addr, '\0', sizeof(pObj->ipV4Addr));
        memcpy(pObj->ipV4Addr,
                outPayload->ipV4Addr,
                sizeof(outPayload->ipV4Addr));

        memset(pObj->macAddr, '\0', sizeof(pObj->macAddr));
        memcpy(pObj->macAddr,
                outPayload->macAddr,
                sizeof(outPayload->macAddr));

        pObj->syncPeriod  = outPayload->syncPeriod;
        pObj->annPeriod   = outPayload->annPeriod;
        pObj->dRqPeriod   = outPayload->dRqPeriod;
        pObj->syncDur     = outPayload->syncDur;
        pObj->syncRem     = outPayload->syncRem;
        pObj->annDur      = outPayload->annDur;
        pObj->annRem      = outPayload->annRem;
        pObj->dRqDur      = outPayload->dRqDur;
        pObj->dRqRem      = outPayload->dRqRem;


        return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setSlaveStats(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    unsigned int      *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.value     = *pVal;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_SLAVE_STATS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}

TSYNC_ERROR
TSYNC_GPR_getSlaveSummary(
    TSYNC_BoardHandle      hnd,
    unsigned int           nInstance,
    TSYNC_GplSlaveSummary *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPL_SLAVE_SUMMARY_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_SLAVE_SUMMARY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPL_PRIORITY_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPL_SLAVE_SUMMARY* outPayload =
            (GPL_SLAVE_SUMMARY*)GetPayload(result);

        pObj->dRqPerSec       = outPayload->dRqPerSec;
        pObj->numUniSlaveConn = outPayload->numUniSlaveConn;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getDebug(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    unsigned int              *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_DEBUG,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPR_VALUE* outPayload =
            (GPR_VALUE*)GetPayload(result);

        *pVal = outPayload->value;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setDebug(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    unsigned int              *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.value     = *pVal;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_DEBUG,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getProfile(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    unsigned int              *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_PROFILE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPR_VALUE* outPayload =
            (GPR_VALUE*)GetPayload(result);

        *pVal = outPayload->value;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setProfile(
    TSYNC_BoardHandle         hnd,
    unsigned int              nInstance,
    unsigned int              *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.value     = *pVal;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_PROFILE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_getPPSOffset(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    unsigned int      *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GPR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_PPS_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_RECIPE,
            GPR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GPR_VALUE* outPayload =
            (GPR_VALUE*)GetPayload(result);

        *pVal = outPayload->value;

    return ( err );

}


TSYNC_ERROR
TSYNC_GPR_setPPSOffset(
    TSYNC_BoardHandle hnd,
    unsigned int      nInstance,
    unsigned int      *pVal)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pVal);

        struct GPR_VALUE_SET_CMD inPayload;
        inPayload.nInstance = nInstance;
        inPayload.value     = *pVal;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GPR_VALUE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GPR,
            TSYNC_ID_GPR_CA_PPS_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GPR_VALUE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );

}


