
/***************************************************************************
**  Module:     tsync_ptr_services_recipes.c
**
**  Date:       02/15/10
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2010 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              02/15/10 Creation DPR
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_ptr_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(PTR_VALUE)
RECIPE(PTR_VALUE_SET_CMD)
RECIPE(PTR_MODULE_INFO)
RECIPE(PTR_ETH_INFO)
RECIPE(PTR_ETH_INFO_SET_CMD)
RECIPE(PTR_CLK_SETTINGS)
RECIPE(PTR_CLK_SETTINGS_SET_CMD)
RECIPE(PTL_UNIT_SETTINGS)
RECIPE(PTL_UNIT_SETTINGS_SET_CMD)
RECIPE(PTL_PORT_STATE)
RECIPE(PTL_PORT_STATE_SET_CMD)
RECIPE(PTL_PORT_SETTINGS)
RECIPE(PTL_PORT_SETTINGS_SET_CMD)
RECIPE(PTL_CLK_QUALITY)
RECIPE(PTL_TIME_PROP)
RECIPE(PTL_PARENT_PROP)
RECIPE(PTL_GM_PROP)
RECIPE(PTL_TOD_SETTINGS)
RECIPE(PTL_TOD_SETTINGS_SET_CMD)
RECIPE(PTL_MAC_ADDR)
RECIPE(PTL_MAC_ADDR_SET_CMD)
RECIPE(PTL_USER_DESC)
RECIPE(PTL_USER_DESC_SET_CMD)
RECIPE(PTL_DEBUG_OUTPUT)
RECIPE(PTL_DEBUG_OUTPUT_SET_CMD)
RECIPE(PTL_ETH_STATUS)
RECIPE(PTL_SYNC_ETHERNET_ITF)
RECIPE(PTL_SYNC_ETHERNET_ITF_SET_CMD)
RECIPE(PTL_PTP_ITF)
RECIPE(PTL_PTP_ITF_SET_CMD)
RECIPE(PTL_FTP_ITF)
RECIPE(PTL_FTP_ITF_SET_CMD)
RECIPE(PTL_PTP_STATISTICS)
RECIPE(PTL_PTP_STATISTICS_SET_CMD)
RECIPE(PTL_PTP_CLOCK_PROPERTIES)
RECIPE(PTL_PTP_UNCT_MASTER_ADD)
RECIPE(PTL_PTP_UNCT_MASTER_ADD_SET_CMD)
RECIPE(PTL_PTP_UNCT_MASTER_PROP)
RECIPE(PTL_PTP_UNCT_SLAVE_PROP)
RECIPE(PTL_PTP_VLAN_SET_CMD)
RECIPE(PTL_PTP_VLAN)




#include "tsync_recipe_undef.h"
