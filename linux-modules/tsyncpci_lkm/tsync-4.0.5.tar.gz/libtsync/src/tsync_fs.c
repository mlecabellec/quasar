#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_fs_services.h"

extern uint8_t UL_IMG_OBJ_RECIPE[];
extern uint8_t FS_CRC_OBJ_RECIPE[];
extern uint8_t UL_IMG_HDR_RECIPE[];
extern uint8_t FS_VERS_OBJ_RECIPE[];
extern uint8_t LS_ERROR_LOG_RECIPE[];
extern uint8_t LS_ALARM_OBJ_RECIPE[];
extern uint8_t LS_ALARM_FLAG_RECIPE[];
extern uint8_t LS_ALARM_SET_CMD_RECIPE[];
extern uint8_t LS_VERSION_RECIPE[];

TSYNC_ERROR
TSYNC_FS_getCrc(
    TSYNC_BoardHandle  hnd,
    TSYNC_ULImageObj  *pObj,
    TSYNC_FSCRCObj    *pObj2)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);
        CHECK_NOT_NULL(pObj2);

        struct UL_IMG_OBJ inPayload;
        inPayload.image = pObj->image;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(UL_IMG_OBJ_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(FS_CRC_OBJ_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_FS,
            TSYNC_ID_FS_CA_GET_CRC,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            UL_IMG_OBJ_RECIPE,
            FS_CRC_OBJ_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct FS_CRC_OBJ* outPayload =
            (FS_CRC_OBJ*)GetPayload(result);

        pObj2->crc = outPayload->crc;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_FS_calcCrc(
    TSYNC_BoardHandle  hnd,
    TSYNC_ULImageObj  *pObj,
    TSYNC_FSCRCObj    *pObj2)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);
        CHECK_NOT_NULL(pObj2);

        struct UL_IMG_OBJ inPayload;
        inPayload.image = pObj->image;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(UL_IMG_OBJ_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(FS_CRC_OBJ_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_FS,
            TSYNC_ID_FS_CA_CALC_CRC,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            UL_IMG_OBJ_RECIPE,
            FS_CRC_OBJ_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct FS_CRC_OBJ* outPayload =
            (FS_CRC_OBJ*)GetPayload(result);

        pObj2->crc = outPayload->crc;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_FS_getHeader(
    TSYNC_BoardHandle       hnd,
    TSYNC_ULImageObj       *pObj,
    TSYNC_ULImageHeaderObj *pObj2)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);
        CHECK_NOT_NULL(pObj2);

        struct UL_IMG_OBJ inPayload;
        inPayload.image = pObj->image;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(UL_IMG_OBJ_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(UL_IMG_HDR_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_FS,
            TSYNC_ID_FS_CA_IMG_HEADER,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            UL_IMG_OBJ_RECIPE,
            UL_IMG_HDR_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct UL_IMG_HDR* outPayload =
            (UL_IMG_HDR*)GetPayload(result);

        pObj2->mark = outPayload->mark;
        pObj2->type = outPayload->type;
        pObj2->len = outPayload->len;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_FS_getVersion(
    TSYNC_BoardHandle   hnd,
    TSYNC_ULImageObj   *pObj,
    TSYNC_FSVersionObj *pObj2)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);
        CHECK_NOT_NULL(pObj2);

        struct UL_IMG_OBJ inPayload;
        inPayload.image = pObj->image;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(UL_IMG_OBJ_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(FS_VERS_OBJ_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_FS,
            TSYNC_ID_FS_CA_GET_VERSION,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            UL_IMG_OBJ_RECIPE,
            FS_VERS_OBJ_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct FS_VERS_OBJ* outPayload =
            (FS_VERS_OBJ*)GetPayload(result);
            
        memcpy(pObj2->version, outPayload->ver, sizeof(pObj2->version));
        
    return ( err );
}
