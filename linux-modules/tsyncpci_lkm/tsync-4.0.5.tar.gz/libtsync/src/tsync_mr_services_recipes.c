
/***************************************************************************
**  Module:     tsync_hr_services_recipes.c
**
**  Date:       20/02/20
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2020 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              20/02/2020 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_mr_services.h"
#include "tsync_cs_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(MR_VALUE)
RECIPE(MR_SVALUE)
RECIPE(MR_VALIDITY_SET_CMD)
RECIPE(MR_UTC_OFF_SET_CMD)
RECIPE(MR_USE_CS_OFF_SET_CMD)
#include "tsync_recipe_undef.h"
