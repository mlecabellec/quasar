#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_pp_services.h"
#include "tsync_misc_services.h"

extern uint8_t PP_SET_CMD_RECIPE[];
extern uint8_t PP_INT_SET_CMD_RECIPE[];
extern uint8_t PP_VALUE_RECIPE[];
extern uint8_t PP_INT_VALUE_RECIPE[];
extern uint8_t PP_FREQ_RECIPE[];

TSYNC_ERROR
TSYNC_PP_getSigCtrl(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    SIG_CTL *sig)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(sig);

        struct PP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_PP,
            TSYNC_ID_PP_CA_SIG_CTL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PP_VALUE_RECIPE,
            PP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct PP_VALUE* outPayload =
            (PP_VALUE*)GetPayload(result);

        *sig = (SIG_CTL)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_PP_setSigCtrl(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    SIG_CTL sig)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct PP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = sig;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_PP,
            TSYNC_ID_PP_CA_SIG_CTL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_PP_getFreq(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    float *freq)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(freq);

        struct PP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_PP,
            TSYNC_ID_PP_CA_FREQ,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PP_VALUE_RECIPE,
            PP_FREQ_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct PP_FREQ* outPayload =
            (PP_FREQ*)GetPayload(result);

        *freq = outPayload->freq;

    return ( err );
}

TSYNC_ERROR
TSYNC_PP_getOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *nOffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nOffset);

        struct PP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PP_INT_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_PP,
            TSYNC_ID_PP_CA_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PP_VALUE_RECIPE,
            PP_INT_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct PP_INT_VALUE* outPayload =
            (PP_INT_VALUE*)GetPayload(result);

        *nOffset = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_PP_setOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int nOffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct PP_INT_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = nOffset;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PP_INT_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_PP,
            TSYNC_ID_PP_CA_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PP_INT_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_PP_getEdge(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    EDGE* edge)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(edge);

        struct PP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_PP,
            TSYNC_ID_PP_CA_EDGE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PP_VALUE_RECIPE,
            PP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct PP_VALUE* outPayload =
            (PP_VALUE*)GetPayload(result);

        *edge = (EDGE)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_PP_setEdge(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    EDGE edge)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct PP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = edge;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_PP,
            TSYNC_ID_PP_CA_EDGE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_PP_getPulseWidth(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int *pw)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pw);

        struct PP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_PP,
            TSYNC_ID_PP_CA_PW,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PP_VALUE_RECIPE,
            PP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct PP_VALUE* outPayload =
            (PP_VALUE*)GetPayload(result);

        *pw = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_PP_setPulseWidth(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int pw)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct PP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = pw;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(PP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_PP,
            TSYNC_ID_PP_CA_PW,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            PP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_PP_getNumInst(
    TSYNC_BoardHandle hnd,
    unsigned int *nInstances)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nInstances);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(PP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_PP,
            TSYNC_ID_PP_CA_NUM_INST,
            ctl,
            pyldLen,
            NULL,
            NULL,
            PP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct PP_VALUE* outPayload =
            (PP_VALUE*)GetPayload(result);

        *nInstances = outPayload->value;

    return ( err );
}


