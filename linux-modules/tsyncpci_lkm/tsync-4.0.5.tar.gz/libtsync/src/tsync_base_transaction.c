#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync_base_transaction.h"
#include "ddtsync.h"
#include "tsync_macros.h"

#define MAX_BUFFER_SIZE_IN 2048
#define MAX_BUFFER_SIZE_OUT 1024

uint8_t TSYNC_TRANS_ERROR_RECIPE[] = {
#define TSYNC_X(fieldType, fieldName) sizeof(fieldType),
    TSYNC_TRANS_ERROR_FIELDS
#undef TSYNC_X
    TSYNC_END_OF_RECIPE
};

uint8_t TSYNC_IOCTL_TRANS_HEADER_RECIPE[] = {
#define TSYNC_X(fieldType, fieldName) sizeof(fieldType),
    TSYNC_IOCTL_TRANS_HEADER_FIELDS
#undef TSYNC_X
    TSYNC_END_OF_RECIPE
};

typedef struct
{
    uint8_t*    pInPos;
    uint8_t*    pOutPos;
    uint8_t*    pRecipe;
    uint8_t*    pInEnd;
    uint8_t*    pOutEnd;
}BT_SERIALIZE_INFO;


static TSYNC_ERROR
SerializeTransaction(
        uint8_t*    pSrc,
        uint8_t*    pDst,
        uint8_t*    pRecipe,
        uint32_t    ulPayloadLength);

static TSYNC_ERROR
SerializeRecursive(BT_SERIALIZE_INFO* info);

static TSYNC_ERROR
DeserializeTransaction(
        TSYNC_ERROR                 err,
        uint32_t                    ulPayloadLength,
        uint8_t*                    pPayloadDst,
        uint8_t*                    pSrc,
        uint8_t*                    pRecipe);

static void
PrintTransactionBuffer(
        uint8_t*    pBuffer,
        uint32_t    ulLen);

static void
PrintRecipe(uint8_t*    pRecipe);

static TSYNC_ERROR
DoTransaction(
        uint8_t     cai,
        uint8_t     iid,
        uint16_t    ctl,
        uint8_t*    inBuffer,
        uint32_t    inBufferLength,
        uint8_t*    outBuffer,
        uint32_t    maxOutBufferLength,
        uint32_t*    actOutBufferLength,
        TSYNC_BoardObj *hnd);




uint32_t
SizeOfResult(uint32_t expectedPayloadSize)
{
    uint32_t resultSize =
        (expectedPayloadSize > sizeof(TSYNC_TRANS_ERROR)) ?
            expectedPayloadSize : sizeof(TSYNC_TRANS_ERROR);

    return resultSize;
}

TSYNC_TransResult
GetPayload(TSYNC_TransResult     outHolder)
{
    /*struct TSYNC_IOCTL_TRANS_HEADER* header =
        (TSYNC_IOCTL_TRANS_HEADER*) outHolder;*/

    /*if(header->pyldLen == 0)
    {
        return NULL;
    }
    else
    {*/
        return outHolder;
    //}
}

TSYNC_ERROR
BaseTransaction(
        uint8_t     cai,
        uint8_t     iid,
        uint16_t     ctl,
        uint32_t     pyldLen,
        uint8_t*    pInPayload,
        uint8_t*    pInRecipe,
        uint8_t*    pOutRecipe,
        TSYNC_TransResult     outHolder,
        TSYNC_BoardObj *hnd)
{

    TSYNC_ERROR err = TSYNC_SUCCESS;

    /* Create the incoming and outgoing buffers */
    uint8_t* inBuffer = (uint8_t*)TSYNC_ALLOCA(MAX_BUFFER_SIZE_IN);
    uint8_t* outBuffer = (uint8_t*)TSYNC_ALLOCA(MAX_BUFFER_SIZE_OUT);

    /* Serialize the incoming header */
    /*struct TSYNC_IOCTL_TRANS_HEADER inHeader;
    inHeader.cai = cai;
    inHeader.iid = iid;
    inHeader.ctl = ctl;
    inHeader.pyldLen = pyldLen;*/

    /* Serialize the incoming payload */
    /*err = SerializeTransaction(
            (uint8_t*) (&inHeader),
            inBuffer,
            TSYNC_IOCTL_TRANS_HEADER_RECIPE,
            TSYNC_TRANS_HEADER_SIZE);
    CHECK_SUCCESS(err)*/

    if(pyldLen != 0 && pInRecipe != NULL)
    {
        if(0) PrintTransactionBuffer(pInPayload, pyldLen);
        if(0) PrintRecipe(pInRecipe);

        err = SerializeTransaction(
                pInPayload,
                inBuffer,
                pInRecipe,
                pyldLen);
        CHECK_SUCCESS(err)
    }

    /* Do the transaction */
    uint32_t actInBufferLength = pyldLen;
    uint32_t actOutBufferLength = 0;


    //PrintTransactionBuffer(inBuffer, actInBufferLength);
    //PrintRecipe(pOutRecipe);

    err = DoTransaction(
                       cai,
                       iid,
                       ctl,
                       inBuffer,
                       actInBufferLength,
                       outBuffer,
                       MAX_BUFFER_SIZE_OUT,
                       &actOutBufferLength,
                       hnd);

    // skip over the error check if the error is a
    // TSYNC_DRV_FW_TRANS_ERROR, we'll deal with that one after
    if(err != TSYNC_DRV_FW_TRANS_ERROR)
    {
        CHECK_SUCCESS(err)
    }

    //save the firmware error (if any) to a separate result
    TSYNC_ERROR fw_err = err;
    //reset the overall error status
    err = TSYNC_SUCCESS;

    if (actOutBufferLength > MAX_BUFFER_SIZE_OUT) {
		return TSYNC_BUFFER_OVERRUN;
    }

	/* Deserialize the outgoing header */
        err = DeserializeTransaction(
                fw_err,
                actOutBufferLength,
                outHolder,
                outBuffer,
                pOutRecipe);
        CHECK_SUCCESS(err)

        // Do some further error investigation
        if(fw_err == TSYNC_DRV_FW_TRANS_ERROR)
        {
            struct TSYNC_TRANS_ERROR* outPayload =
                (TSYNC_TRANS_ERROR*)GetPayload(outHolder);

            outPayload->error = (TSYNC_ERROR)(outPayload->error + EC_BOARD_RC_OFFSET);
            outPayload->errorOpt = (TSYNC_ERROR)(outPayload->errorOpt + EC_BOARD_OPT_OFFSET);

            //board ha_rc error
            if(outPayload->error != HA_RC_CMD_ERR)
            {
                err = outPayload->error;
            }
            //board optional error
            else
            {
                err = outPayload->errorOpt;
            }

		}

    return err;
}


uint8_t WriteWordEndianSafe(uint8_t* pDst, uint8_t* pSrc, unsigned int wordLength)
{

#ifdef NIOS
    memcpy(pDst, pSrc, wordLength);
#else
    #ifdef HOST_BIG_ENDIAN
        memcpy(pDst, pSrc, wordLength);
    #else
        uint8_t iByte;
        for(iByte = 0; iByte < wordLength; iByte++)
        {
            pDst[iByte] = pSrc[wordLength - iByte - 1];
        }
    #endif
#endif

    return wordLength;
}

TSYNC_ERROR
SerializeTransaction(
        uint8_t*    pSrc,
        uint8_t*    pDst,
        uint8_t*    pRecipe,
        uint32_t    ulPayloadLength)
{
    memset(pDst, '\0', ulPayloadLength);

    BT_SERIALIZE_INFO info;
    info.pInPos = pSrc;
    info.pOutPos = pDst;
    info.pRecipe = pRecipe;
    info.pInEnd = pSrc + ulPayloadLength;
    info.pOutEnd = pDst + ulPayloadLength;

    TSYNC_ERROR err = SerializeRecursive(&info);

    /*if(err != TSYNC_SUCCESS)
    {
        //printf("%p, %p, %lu\n", pDst, info.pOutEnd, info.pOutEnd - pDst);
        PrintTransactionBuffer(pSrc, ulPayloadLength);
        PrintRecipe(pRecipe);
        PrintTransactionBuffer(pDst, info.pOutEnd - pDst);
    }*/

    return err;
}

TSYNC_ERROR
SerializeRecursive(BT_SERIALIZE_INFO* info)
{
    uint8_t bRecipeDone = 0;

    while(1)
    {
        uint16_t ulLen = 0;
        uint8_t val = info->pRecipe[0];

        switch(val)
        {

        case sizeof(uint8_t):
            ulLen = val;

            if (info->pInPos + ulLen > info->pInEnd ||
                info->pOutPos + ulLen > info->pOutEnd)
                return TSYNC_BUFFER_OVERRUN;

            *info->pOutPos = *info->pInPos;
            break;

        case sizeof(uint16_t):    // FALLTHROUGH
        case sizeof(uint32_t):  // FALLTHROUGH
        case sizeof(uint64_t):
            ulLen = val;

            if (info->pInPos + ulLen > info->pInEnd ||
                info->pOutPos + ulLen > info->pOutEnd)
            {
                //printf("%p, %u, %p\n", info->pInPos, ulLen, info->pInEnd);
                return TSYNC_BUFFER_OVERRUN;
            }

            WriteWordEndianSafe(info->pOutPos, info->pInPos, ulLen);
            break;

        case TSYNC_END_OF_RECIPE:
            bRecipeDone = 1;
            break;

        case TSYNC_RECIPE_BUFFER:
            ulLen = (info->pRecipe[1] << 8) + (info->pRecipe[2]);

            if (info->pInPos + ulLen > info->pInEnd ||
                info->pOutPos + ulLen > info->pOutEnd)
                return TSYNC_BUFFER_OVERRUN;

            memcpy(info->pOutPos, info->pInPos, ulLen);
            info->pRecipe += 2; // skip over the buffer length
            break;

        case TSYNC_RECIPE_ARRAY:
            {
                info->pInPos = info->pInPos;
                info->pOutPos = info->pOutPos;

                uint8_t* pRecipeStart = &info->pRecipe[2];
                uint8_t numIters = info->pRecipe[1];
                uint8_t j;
                //printf("start: %p\n", info->pInPos);
                for(j = 0; j < numIters; j++)
                {
                    //printf("[%u]\n", j);
                    info->pRecipe = pRecipeStart;
                    TSYNC_ERROR err = SerializeRecursive(info);
                    CHECK_SUCCESS(err)
                }
                //printf("end: %p\n", info->pInPos);
            }
            break;
        };

        //Don't update anything after recursion, cause the recursive
        //call already updated things
        if(val != TSYNC_RECIPE_ARRAY)
        {
            info->pInPos += ulLen;
            info->pOutPos += ulLen;
            info->pRecipe++;
        }

        // We've finished reading the recipe
        if (bRecipeDone == 1)
        {
            break;
        }
        // If the read pointer has reached the end of the source area,
        // we're done regardless of the whether the recipe is or not
        if (info->pInPos == info->pInEnd)
        {
            break;
        }
    }

    return TSYNC_SUCCESS;
}


TSYNC_ERROR
DeserializeTransaction(
        TSYNC_ERROR                 err,
        uint32_t                    ulPayloadLength,
        uint8_t*                    pPayloadDst,
        uint8_t*                    pSrc,
        uint8_t*                    pRecipe)
{
    if(0) PrintTransactionBuffer(pSrc, ulPayloadLength);

    /* No error condition */
    if(err != TSYNC_DRV_FW_TRANS_ERROR)
    {
        if(pRecipe != NULL)
        {
            if(0) PrintRecipe(pRecipe);

            err = SerializeTransaction(
                    pSrc,//copy from here
                    pPayloadDst,//copy to here
                    pRecipe,//use this recipe
                    ulPayloadLength);//MAX_BUFFER_SIZE_OUT);//don't go over this amount
            CHECK_SUCCESS(err)
        }
    }
    else
    {

        // Zeroize the fields of the error first, in case we don't get
        // the optional parameter back in the payload
        memset(pPayloadDst, '\0', sizeof(TSYNC_TRANS_ERROR));

        if(0) PrintRecipe(TSYNC_TRANS_ERROR_RECIPE);

        err = SerializeTransaction(
                pSrc,//copy from here
                pPayloadDst,//copy to here
                TSYNC_TRANS_ERROR_RECIPE,//use this recipe
                ulPayloadLength);//don't go over this amount
        CHECK_SUCCESS(err)
    }

    return TSYNC_SUCCESS;
}

TSYNC_ERROR
DoTransaction(
        uint8_t     cai,
        uint8_t     iid,
        uint16_t    ctl,
        uint8_t*    inBuffer,
        uint32_t    inBufferLength,
        uint8_t*    outBuffer,
        uint32_t    maxOutBufferLength,
        uint32_t*    actOutBufferLength,
        TSYNC_BoardObj *hnd)
{
    //create the objects the accessor call will reference
    TSYNC_BoardHandle handle = (TSYNC_BoardHandle) hnd;
    TSYNC_ERROR err = TSYNC_SUCCESS;
    DEST_ID dest;
    ITEM_ID item;

    //set some values
    dest = DEST_ID_FW;
    item.fid = (cai << 8) | iid;

    if(ctl == 0x00)
    {
        //call the generic get
        err = TSYNC_get(
            handle,
            dest,
            item,
            (void*) inBuffer,
            inBufferLength,
            (void*) outBuffer,
            maxOutBufferLength,
            actOutBufferLength);
    }
    else
    {
        //call the generic set
        err = TSYNC_set(
            handle,
            dest,
            item,
            (void*) inBuffer,
            inBufferLength,
            (void*) outBuffer,
            maxOutBufferLength,
            actOutBufferLength);
    }

    return err;

}

void PrintTransactionBuffer(
        uint8_t*    pBuffer,
        uint32_t    ulLen)
{
    /* Print the serialized contents of the buffer */
    uint32_t i;
    printf("\n******* %u bytes\n", ulLen);
    for(i = 0; i < ulLen; i++)
    {
        if(i % 16 == 0)
        {
            printf("0x%02X: ", i);
        }

        printf("%02X ", pBuffer[i]);

        if(i % 16 == 7)
        {
            printf(" ");
        }
        else if(i % 16 == 15)
        {
            printf("\n");
        }

    }
    printf("\n*******\n\n");
}

void PrintRecipe(
        uint8_t*    pRecipe)
{
    /* Print the serialized contents of the buffer */
    printf("\n*******\n");
    uint8_t     i = 0;
    uint8_t     listFifo = 0;

    for(i = 0; i < 50; i++)
    {
        if(i % 16 == 0)
        {
            printf("0x%02X: ", i);
        }

        printf("%02X ", pRecipe[i]);

        if(i % 16 == 7)
        {
            printf(" ");
        }
        else if(i % 16 == 15)
        {
            printf("\n");
        }

        if(pRecipe[i] == TSYNC_RECIPE_ARRAY)
        {
            ++listFifo;
        }

        if(pRecipe[i] == TSYNC_END_OF_RECIPE)
        {
            if(listFifo > 0)
            {
                --listFifo;
            }
            else
            {
                break;
            }
        }
    }
    printf("\n*******\n\n");
}

////////////////////////////////////////////////////////////////////////////////
// Function:    sizeofRecipe
// Description: This function parses a message recipe to determine the size of
//              the total payload.  It is called recursively to dig down into
//              array structures.  pPos is modified during the call, and should
//              be passed in as 0 at the top level call.
////////////////////////////////////////////////////////////////////////////////
uint32_t sizeofRecipe(uint8_t *pRecipe, uint8_t *pPos)
{
    uint32_t len      = 0;              // Calculated length
    uint8_t  listFifo = 1;              // Level indicator
    uint8_t  val;                       // Current recipe byte
    uint8_t  numItems;                  // Number of array elements


    // Loop through recipe until finished with top level (listFifo == 0)
    for(; listFifo > 0; (*pPos)++)
    {
        // Read byte from recipe
        val = pRecipe[*pPos];
        if (0) printf("pPos, val: %d, %02X\n", *pPos, val);

        switch(val)
        {
            // Add recipe value if data size indicator
            case sizeof(uint8_t):
            case sizeof(uint16_t):
            case sizeof(uint32_t):
            case sizeof(uint64_t):
                len += val;
                break;

            // Decrement level if end of recipe field indicator
            case TSYNC_END_OF_RECIPE:
                listFifo--;
                break;

            // Read buffer byte length and add to overall length if buffer
            // indicator
            case TSYNC_RECIPE_BUFFER:
                len   += (pRecipe[*pPos + 1] << 8) + pRecipe[*pPos + 2];
                *pPos += 2;
                break;

            // Read number of array items and recurse if array indicator
            case TSYNC_RECIPE_ARRAY:
                numItems  = pRecipe[*pPos + 1];
                (*pPos)  += 2;
                len      += numItems * sizeofRecipe(pRecipe, pPos);
                (*pPos)  -= 1;
                break;
        }
    }

    return len;

} // End sizeofRecipe

////////////////////////////////////////////////////////////////////////////////
// Function:    sizeofUnion
// Description: This function calculates the payload length of a union.  It
//              loops through the union members and returns the size of the
//              largest member as the union size.
////////////////////////////////////////////////////////////////////////////////
uint32_t sizeofUnion(uintptr_t *pRecipe)
{
    uint32_t  len = 0;                  // Calculated length
    uint32_t  len2;                     // Union member length
    uint8_t   i;                        // Loop variable
    uint8_t   pos;                      // Recipe position variable


    // Loop through union members calculating individual sizes and keep the
    // maximum member size for the uion size
    for(i = 0; i < (uint32_t)(pRecipe[0]); i++)
    {
        pos  = 0;
        len2 = sizeofRecipe((uint8_t*)(pRecipe[i + 1]), &pos);
        len  = (len < len2) ? len2 : len;
        if (0) printf("len, len2: %d, %d\n", len, len2);
    }

    return len;

} // End sizeofUnion
