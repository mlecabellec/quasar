
#ifndef _defined_TSYNC_TRANS_H
#define _defined_TSYNC_TRANS_H 1

/***************************************************************************
**  Module:     tsync_trans.h
**
**  Date:       07/03/08
**
**  Purpose:    IOCTL definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/03/2008 Creation
**
****************************************************************************/

#include "tsync.h"
#include "tsync_error_codes.h"

/******************************************************
**     Defines
******************************************************/


/*
** Seconds to wait after issue of firmware reset
** Spec says at least 8... use 10 for good measure. Its
** a diagnostic anyway.
*/
#define TSYNC_FWARE_RESET_DELAY_SEC  ( 10 )

/*
** NTP reference ID options for boards
*/
#define TSYNC_NTP_REF_NON_SAT        "IRIG"
#define TSYNC_NTP_REF_SAT            "GPS "
#define TSYNC_NTP_REF_LENGTH         4





#define TSYNC_END_OF_RECIPE        0xff
#define TSYNC_RECIPE_BUFFER        0xb0
#define TSYNC_RECIPE_ARRAY          0xb1

#define TSYNC_IOCTL_TRANS_HEADER_FIELDS        \
    TSYNC_X( uint8_t,     cai)                \
    TSYNC_X( uint8_t,    iid)                \
    TSYNC_X( uint16_t,    ctl)                \
    TSYNC_X( uint32_t,    pyldLen)

#define TSYNC_TRANS_ERROR_FIELDS        \
    TSYNC_X( TSYNC_ERROR,    error)                \
    TSYNC_X( TSYNC_ERROR,    errorOpt)

//#define TSYNC_TRANS_HEADER_SIZE sizeof(TSYNC_IOCTL_TRANS_HEADER)


/*=========================================================================
        TYPEDEFS
==========================================================================*/

typedef struct TSYNC_BoardObj
{
    TSYNC_BOARD_DESCRIPTOR_T    file_descriptor;    /* handle to device */
    unsigned short              devid;              /* PCI Device ID */
    unsigned short              options;            /* PCI Subsystem Product ID */
}
TSYNC_BoardObj;

typedef uint8_t* TSYNC_TransResult;

#include "tsync_struct_define.h"

GEN_STRUCT(TSYNC_IOCTL_TRANS_HEADER)
GEN_STRUCT(TSYNC_TRANS_ERROR)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_KTYPES_H */
