#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_go_services.h"
#include "tsync_misc_services.h"

extern uint8_t GO_VALUE_RECIPE[];
extern uint8_t GO_INDEX_VALUE_RECIPE[];
extern uint8_t GO_INT_SET_CMD_RECIPE[];
extern uint8_t GO_INT_VALUE_RECIPE[];
extern uint8_t GO_MATCH_ENABLE_GET_CMD_RECIPE[];
extern uint8_t GO_MATCH_ENABLE_SET_CMD_RECIPE[];
extern uint8_t GO_SQUARE_WAVE_GET_RESP_RECIPE[];
extern uint8_t GO_SQUARE_WAVE_SET_CMD_RECIPE[];
extern uint8_t GO_SET_PER_CORR_RECIPE[];
extern uint8_t GO_PER_CORR_RECIPE[];

TSYNC_ERROR
TSYNC_GO_getSigCtrl(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    SIG_CTL *sig)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(sig);

        struct GO_VALUE inPayload;
        inPayload.value = gpo;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GO_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_SIG_CTL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_VALUE_RECIPE,
            GO_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GO_VALUE* outPayload =
            (GO_VALUE*)GetPayload(result);

        *sig = (SIG_CTL)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_setSigCtrl(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    SIG_CTL sig)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GO_INDEX_VALUE inPayload;
        inPayload.index = gpo;
        inPayload.value = sig;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_INDEX_VALUE_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_SIG_CTL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_INDEX_VALUE_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_getEnable(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    int *bEnable)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(bEnable);

        struct GO_VALUE inPayload;
        inPayload.value = gpo;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GO_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_OUTPUT_EN,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_VALUE_RECIPE,
            GO_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GO_VALUE* outPayload =
            (GO_VALUE*)GetPayload(result);

        *bEnable = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_setEnable(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    int bEnable)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GO_INDEX_VALUE inPayload;
        inPayload.index = gpo;
        inPayload.value = bEnable;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_INDEX_VALUE_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_OUTPUT_EN,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_INDEX_VALUE_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_getValue(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    int *bValue)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(bValue);

        struct GO_VALUE inPayload;
        inPayload.value = gpo;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GO_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_VALUE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_VALUE_RECIPE,
            GO_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GO_VALUE* outPayload =
            (GO_VALUE*)GetPayload(result);

        *bValue = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_getMode(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    OD_MODE *mode)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(mode);

        struct GO_VALUE inPayload;
        inPayload.value = gpo;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GO_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_MODE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_VALUE_RECIPE,
            GO_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GO_VALUE* outPayload =
            (GO_VALUE*)GetPayload(result);

        *mode = (OD_MODE)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_setMode(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    OD_MODE mode)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GO_INDEX_VALUE inPayload;
        inPayload.index = gpo;
        inPayload.value = mode;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_INDEX_VALUE_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_MODE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_INDEX_VALUE_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_getDvmValue(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    int *bValue)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(bValue);

        struct GO_VALUE inPayload;
        inPayload.value = gpo;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GO_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_DVM_VALUE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_VALUE_RECIPE,
            GO_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GO_VALUE* outPayload =
            (GO_VALUE*)GetPayload(result);

        *bValue = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_setDvmValue(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    int bValue)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GO_INDEX_VALUE inPayload;
        inPayload.index = gpo;
        inPayload.value = bValue;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_INDEX_VALUE_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_DVM_VALUE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_INDEX_VALUE_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_getMatchEnable(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    LEVEL lvl,
    int *bEnable)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(bEnable);

        struct GO_MATCH_ENABLE_GET_CMD inPayload;
        inPayload.index = gpo;
        inPayload.level = lvl;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_MATCH_ENABLE_GET_CMD_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GO_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_MATCH_EN,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_MATCH_ENABLE_GET_CMD_RECIPE,
            GO_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GO_VALUE* outPayload =
            (GO_VALUE*)GetPayload(result);

        *bEnable = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_setMatchEnable(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    LEVEL lvl,
    int bEnable)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GO_MATCH_ENABLE_SET_CMD inPayload;
        inPayload.index = gpo;
        inPayload.level = lvl;
        inPayload.bEnable = bEnable;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_MATCH_ENABLE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_MATCH_EN,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_MATCH_ENABLE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_getSquareWave(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    TSYNC_GPOSquareObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct GO_VALUE inPayload;
        inPayload.value = gpo;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GO_SQUARE_WAVE_GET_RESP_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_SQUARE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_VALUE_RECIPE,
            GO_SQUARE_WAVE_GET_RESP_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GO_SQUARE_WAVE_GET_RESP* outPayload =
            (GO_SQUARE_WAVE_GET_RESP*)GetPayload(result);

        pObj->off = outPayload->off;
        pObj->per = outPayload->per;
        pObj->pw = outPayload->pw;
        pObj->ae = outPayload->ae;

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_setSquareWave(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    TSYNC_GPOSquareObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GO_SQUARE_WAVE_SET_CMD inPayload;
        inPayload.index = gpo;
        inPayload.off = pObj->off;
        inPayload.per = pObj->per;
        inPayload.pw = pObj->pw;
        inPayload.ae = pObj->ae;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_SQUARE_WAVE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_SQUARE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_SQUARE_WAVE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_getSWOffset(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    int *off)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(off);

        struct GO_VALUE inPayload;
        inPayload.value = gpo;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GO_INT_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_SW_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_VALUE_RECIPE,
            GO_INT_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GO_INT_VALUE* outPayload =
            (GO_INT_VALUE*)GetPayload(result);

        *off = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_setSWOffset(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    int off)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GO_INT_SET_CMD inPayload;
        inPayload.index = gpo;
        inPayload.value = off;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_INT_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_SW_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_INT_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_getSWPeriod(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    unsigned int *per)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(per);

        struct GO_VALUE inPayload;
        inPayload.value = gpo;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GO_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_SW_PERIOD,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_VALUE_RECIPE,
            GO_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GO_VALUE* outPayload =
            (GO_VALUE*)GetPayload(result);

        *per = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_setSWPeriod(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    unsigned int per)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GO_INDEX_VALUE inPayload;
        inPayload.index = gpo;
        inPayload.value = per;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_INDEX_VALUE_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_SW_PERIOD,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_INDEX_VALUE_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_getSWPW(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    unsigned int *pw)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pw);

        struct GO_VALUE inPayload;
        inPayload.value = gpo;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GO_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_SW_PW,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_VALUE_RECIPE,
            GO_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GO_VALUE* outPayload =
            (GO_VALUE*)GetPayload(result);

        *pw = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_setSWPW(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    unsigned int pw)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GO_INDEX_VALUE inPayload;
        inPayload.index = gpo;
        inPayload.value = pw;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_INDEX_VALUE_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_SW_PW,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_INDEX_VALUE_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_getSWEdge(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    EDGE *edge)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(edge);

        struct GO_VALUE inPayload;
        inPayload.value = gpo;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GO_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_SW_EDGE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_VALUE_RECIPE,
            GO_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GO_VALUE* outPayload =
            (GO_VALUE*)GetPayload(result);

        *edge = (EDGE)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_setSWEdge(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    EDGE edge)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GO_INDEX_VALUE inPayload;
        inPayload.index = gpo;
        inPayload.value = edge;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_INDEX_VALUE_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_SW_EDGE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_INDEX_VALUE_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_getSWPerCorr(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    unsigned int *num,
    unsigned int *den)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(num);
        CHECK_NOT_NULL(den);

        struct GO_VALUE inPayload;
        inPayload.value = gpo;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GO_PER_CORR_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_SW_PER_CORR,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_VALUE_RECIPE,
            GO_PER_CORR_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GO_PER_CORR* outPayload =
            (GO_PER_CORR*)GetPayload(result);

        *num = outPayload->num;
        *den = outPayload->den;

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_setSWPerCorr(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    unsigned int num,
    unsigned int den)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GO_SET_PER_CORR inPayload;
        inPayload.index = gpo;
        inPayload.num   = num;
        inPayload.den   = den;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_SET_PER_CORR_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_SW_PER_CORR,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_SET_PER_CORR_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_getSWAlignCnt(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    unsigned int *cnt)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(cnt);

        struct GO_VALUE inPayload;
        inPayload.value = gpo;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GO_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_SW_ALIGN_CNT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_VALUE_RECIPE,
            GO_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GO_VALUE* outPayload =
            (GO_VALUE*)GetPayload(result);

        *cnt = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_setSWAlignCnt(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    unsigned int cnt)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GO_INDEX_VALUE inPayload;
        inPayload.index = gpo;
        inPayload.value = cnt;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_INDEX_VALUE_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_SW_ALIGN_CNT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_INDEX_VALUE_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_getSWTmAlgnEn(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    int *bEnable)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(bEnable);

        struct GO_VALUE inPayload;
        inPayload.value = gpo;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GO_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_SW_TM_ALGN_EN,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_VALUE_RECIPE,
            GO_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GO_VALUE* outPayload =
            (GO_VALUE*)GetPayload(result);

        *bEnable = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_setSWTmAlgnEn(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    int bEnable)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GO_INDEX_VALUE inPayload;
        inPayload.index = gpo;
        inPayload.value = bEnable;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_INDEX_VALUE_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_SW_TM_ALGN_EN,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_INDEX_VALUE_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_setSWInit(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GO_VALUE inPayload;
        inPayload.value = gpo;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_VALUE_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_SW_INIT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_VALUE_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_getNumInst(
    TSYNC_BoardHandle hnd,
    unsigned int *nInstances)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nInstances);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GO_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_NUM_INST,
            ctl,
            pyldLen,
            NULL,
            NULL,
            GO_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GO_VALUE* outPayload =
            (GO_VALUE*)GetPayload(result);

        *nInstances = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_getSWOtpPW(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    unsigned int *pw)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pw);

        struct GO_VALUE inPayload;
        inPayload.value = gpo;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(GO_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_SW_OTP_PW,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_VALUE_RECIPE,
            GO_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct GO_VALUE* outPayload =
            (GO_VALUE*)GetPayload(result);

        *pw = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_GO_setSWOtpPW(
    TSYNC_BoardHandle hnd,
    OD_PIN gpo,
    unsigned int pw)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct GO_INDEX_VALUE inPayload;
        inPayload.index = gpo;
        inPayload.value = pw;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(GO_INDEX_VALUE_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_GO,
            TSYNC_ID_GO_CA_SW_OTP_PW,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            GO_INDEX_VALUE_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

