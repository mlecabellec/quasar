
/***************************************************************************
**  Module:     tsync_ir_services_recipes.c
**
**  Date:       08/04/08
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              08/04/2008 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_ir_services.h"
#include "tsync_cs_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(IR_VALUE)
RECIPE(IR_OFFSET_SET_CMD)
RECIPE(IR_MODE_SET_CMD)
RECIPE(IR_FORMAT_SET_CMD)
RECIPE(IR_MOD_SET_CMD)
RECIPE(IR_FREQ_SET_CMD)
RECIPE(IR_CE_SET_CMD)
RECIPE(IR_CF_SET_CMD)
RECIPE(IR_SHORT)
RECIPE(IR_MSG)
RECIPE(IR_MSG_SET_CMD)
RECIPE(IR_CFDATA)
RECIPE(IR_LOCAL_SET_CMD)
RECIPE(IR_TIME_SCALE_SET_CMD)

#include "tsync_recipe_undef.h"
