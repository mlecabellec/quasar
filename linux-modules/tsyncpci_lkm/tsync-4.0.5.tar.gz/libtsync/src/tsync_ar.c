#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_ar_services.h"
#include "tsync_cs_services.h"
#include "tsync_misc_services.h"

extern uint8_t AR_VALUE_RECIPE[];
extern uint8_t AR_OFFSET_SET_CMD_RECIPE[];
extern uint8_t EL_VALIDITY_RECIPE[];
extern uint8_t AR_UART_CFG_OBJ_RECIPE[];
extern uint8_t AR_UART_CFG_SET_CMD_RECIPE[];
extern uint8_t ML_CLK_LOCAL_RECIPE[];
extern uint8_t AR_LOCAL_SET_CMD_RECIPE[];
extern uint8_t ML_TIME_SCALE_OBJ_RECIPE[];
extern uint8_t AR_TIME_SCALE_SET_CMD_RECIPE[];
extern uint8_t AR_FORMAT_SET_CMD_RECIPE[];
extern uint8_t AR_PPS_SRC_SET_CMD_RECIPE[];
extern uint8_t EL_REF_ID_RECIPE[];
extern uint8_t AR_VALUE_SET_CMD_RECIPE[];

extern uint8_t AR_STL_BUFFER_RECIPE[];
extern uint8_t AR_STL_VERSION_RECIPE[];
extern uint8_t AR_STL_CONF_RECIPE[];
extern uint8_t AR_STL_CONF_SET_CMD_RECIPE[];
extern uint8_t AR_STL_STAT_VALUE_RECIPE[];
extern uint8_t AR_STL_SUB_RECIPE[];
extern uint8_t AR_STL_SUBK_RECIPE[];
extern uint8_t AR_STL_SUBK_SET_CMD_RECIPE[];

TSYNC_ERROR
TSYNC_AR_getOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *nOffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nOffset);

        struct AR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(AR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_AR,
            TSYNC_ID_AR_CA_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AR_VALUE_RECIPE,
            AR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct AR_VALUE* outPayload =
            (AR_VALUE*)GetPayload(result);

        *nOffset = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_AR_setOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int nOffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct AR_OFFSET_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.offset = nOffset;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AR_OFFSET_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_AR,
            TSYNC_ID_AR_CA_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AR_OFFSET_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_AR_getValidity(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *bTimeValid,
    int *bPpsValid)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(bTimeValid);
        CHECK_NOT_NULL(bPpsValid);

        struct AR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(EL_VALIDITY_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_AR,
            TSYNC_ID_AR_CA_VALIDITY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AR_VALUE_RECIPE,
            EL_VALIDITY_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct EL_VALIDITY* outPayload =
            (EL_VALIDITY*)GetPayload(result);

        *bTimeValid = outPayload->timeValid;
        *bPpsValid = outPayload->ppsValid;

    return ( err );
}

TSYNC_ERROR
TSYNC_AR_getUartCfg(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    UD_CFG *pCfg)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pCfg);

        struct AR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(AR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_AR,
            TSYNC_ID_AR_CA_UART_CFG,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AR_VALUE_RECIPE,
            AR_UART_CFG_OBJ_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct AR_UART_CFG_OBJ* outPayload =
            (AR_UART_CFG_OBJ*)GetPayload(result);

        pCfg->br       = outPayload->baud;
        pCfg->numbits  = outPayload->db;
        pCfg->parity   = outPayload->par;
        pCfg->stopbits = outPayload->sb;

    return ( err );
}

TSYNC_ERROR
TSYNC_AR_setUartCfg(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    UD_CFG* pCfg)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pCfg);

        struct AR_UART_CFG_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.baud = pCfg->br;
        inPayload.db   = pCfg->numbits;
        inPayload.par  = pCfg->parity;
        inPayload.sb   = pCfg->stopbits;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AR_UART_CFG_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_AR,
            TSYNC_ID_AR_CA_UART_CFG,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AR_UART_CFG_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_AR_getLeapFlag(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int *bLeap)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(bLeap);

        struct AR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(AR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_AR,
            TSYNC_ID_AR_CA_LEAP_FLAG,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AR_VALUE_RECIPE,
            AR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct AR_VALUE* outPayload =
            (AR_VALUE*)GetPayload(result);

        *bLeap = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_AR_getLocal(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_LocalClockObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct AR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(ML_CLK_LOCAL_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_AR,
            TSYNC_ID_AR_CA_LOCAL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AR_VALUE_RECIPE,
            ML_CLK_LOCAL_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct ML_CLK_LOCAL* outPayload =
            (ML_CLK_LOCAL*)GetPayload(result);

        pObj->rule.ref = outPayload->ref;
        pObj->rule.in.month = outPayload->in.month;
        pObj->rule.in.wom = outPayload->in.wom;
        pObj->rule.in.dow = outPayload->in.dow;
        pObj->rule.in.hour = outPayload->in.hour;
        pObj->rule.out.month = outPayload->out.month;
        pObj->rule.out.wom = outPayload->out.wom;
        pObj->rule.out.dow = outPayload->out.dow;
        pObj->rule.out.hour = outPayload->out.hour;
        pObj->rule.offset = outPayload->offset;
        pObj->tz = outPayload->tz;

    return ( err );
}

TSYNC_ERROR
TSYNC_AR_setLocal(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_LocalClockObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct AR_LOCAL_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.ref = pObj->rule.ref;
        inPayload.in.month = pObj->rule.in.month;
        inPayload.in.wom = pObj->rule.in.wom;
        inPayload.in.dow = pObj->rule.in.dow;
        inPayload.in.hour = pObj->rule.in.hour;
        inPayload.out.month = pObj->rule.out.month;
        inPayload.out.wom = pObj->rule.out.wom;
        inPayload.out.dow = pObj->rule.out.dow;
        inPayload.out.hour = pObj->rule.out.hour;
        inPayload.offset = pObj->rule.offset;
        inPayload.tz = pObj->tz;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AR_LOCAL_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_AR,
            TSYNC_ID_AR_CA_LOCAL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AR_LOCAL_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_AR_getTimeScale(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_TimeScaleObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    struct AR_VALUE inPayload;
    inPayload.value = nInstance;

    uint16_t ctl = 0x00;//get
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(AR_VALUE_RECIPE, &pos);

    pos = 0;
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(ML_TIME_SCALE_OBJ_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_AR,
        TSYNC_ID_AR_CA_TIME_SCALE,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        AR_VALUE_RECIPE,
        ML_TIME_SCALE_OBJ_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    struct ML_TIME_SCALE_OBJ* outPayload =
        (ML_TIME_SCALE_OBJ*)GetPayload(result);

    pObj->scale = outPayload->scale;

    return ( err );
}

TSYNC_ERROR TSYNC_AR_setTimeScale (
    TSYNC_BoardHandle   hnd,
    unsigned int nInstance,
    TSYNC_TimeScaleObj *pObj)
{
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    struct AR_TIME_SCALE_SET_CMD inPayload;
    inPayload.inst = nInstance;
    inPayload.scale.scale = pObj->scale;

    uint16_t ctl = 0x02;//set
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(AR_TIME_SCALE_SET_CMD_RECIPE, &pos);

    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(0));

    TSYNC_ERROR err = BaseTransaction(
        TSYNC_ID_AR,
        TSYNC_ID_AR_CA_TIME_SCALE,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        AR_TIME_SCALE_SET_CMD_RECIPE,
        NULL,
        result,
        handle);

    return ( err );
}

TSYNC_ERROR
TSYNC_AR_getRefId(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_RefIdObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct AR_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(EL_REF_ID_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_AR,
            TSYNC_ID_AR_CA_REF_ID,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AR_VALUE_RECIPE,
            EL_REF_ID_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct EL_REF_ID* outPayload =
            (EL_REF_ID*)GetPayload(result);
            
        memset(pObj->refid, '\0', sizeof(pObj->refid));
        memcpy(pObj->refid, outPayload->ref, sizeof(outPayload->ref));
        
    return ( err );
}

TSYNC_ERROR
TSYNC_AR_getFormat(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    AL_FMT *format)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(format);

        struct AR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(AR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_AR,
            TSYNC_ID_AR_CA_FORMAT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AR_VALUE_RECIPE,
            AR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct AR_VALUE* outPayload =
            (AR_VALUE*)GetPayload(result);

        *format = (AL_FMT)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_AR_setFormat(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    AL_FMT format)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct AR_FORMAT_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.format = format;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AR_FORMAT_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_AR,
            TSYNC_ID_AR_CA_FORMAT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AR_FORMAT_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_AR_getNumInst(
    TSYNC_BoardHandle hnd,
    unsigned int *nInstances)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nInstances);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(AR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_AR,
            TSYNC_ID_AR_CA_NUM_INST,
            ctl,
            pyldLen,
            NULL,
            NULL,
            AR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct AR_VALUE* outPayload =
            (AR_VALUE*)GetPayload(result);

        *nInstances = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_AR_getPpsSrc(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    AL_PPS  *pps)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pps);

        struct AR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(AR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_AR,
            TSYNC_ID_AR_CA_PPS_SRC,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AR_VALUE_RECIPE,
            AR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct AR_VALUE* outPayload =
            (AR_VALUE*)GetPayload(result);

        *pps = (AL_PPS)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_AR_setPpsSrc(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    AL_PPS pps)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct AR_PPS_SRC_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.pps = pps;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AR_PPS_SRC_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_AR,
            TSYNC_ID_AR_CA_PPS_SRC,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AR_PPS_SRC_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}


TSYNC_ERROR
TSYNC_AR_StlgetVersion(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_StrVersionObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct AR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(AR_STL_VERSION_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_AR,
            TSYNC_ID_AR_STL_CA_VERSION,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AR_VALUE_RECIPE,
            AR_STL_VERSION_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct AR_STL_VERSION* outPayload =
            (AR_STL_VERSION*)GetPayload(result);

        memset(pObj->application, '\0', sizeof(pObj->application));
        memset(pObj->system, '\0', sizeof(pObj->system));
        memset(pObj->serialnb, '\0', sizeof(pObj->serialnb));

        memcpy(pObj->serialnb, outPayload->serialnb, sizeof(outPayload->serialnb));
        memcpy(pObj->application, outPayload->application, sizeof(outPayload->application));
        memcpy(pObj->system, outPayload->system, sizeof(outPayload->system));

    return ( err );
}

TSYNC_ERROR
TSYNC_AR_StlgetSubscription(
    TSYNC_BoardHandle  hnd,
    unsigned int       nInstance,
    TSYNC_StrSubObj *pSub)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pSub);

        struct AR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(AR_STL_SUB_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_AR,
            TSYNC_ID_AR_STL_CA_SUBSCRIPTION,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AR_VALUE_RECIPE,
            AR_STL_SUB_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct AR_STL_SUB* outPayload =
            (AR_STL_SUB*)GetPayload(result);

        memset(pSub->beginSub, '\0', sizeof(outPayload->beginSub));
        memcpy(pSub->beginSub, outPayload->beginSub, sizeof(outPayload->beginSub));

		memset(pSub->endSub, '\0',  sizeof(outPayload->endSub));
        memcpy(pSub->endSub, outPayload->endSub, sizeof(outPayload->endSub));
		pSub->state = outPayload->state;

    return ( err );
}

TSYNC_ERROR
TSYNC_AR_StlgetActFeat(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *nActFeat)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nActFeat);

        struct AR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(AR_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_AR,
            TSYNC_ID_AR_STL_CA_ACT_FEAT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AR_VALUE_RECIPE,
            AR_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct AR_VALUE* outPayload =
            (AR_VALUE*)GetPayload(result);

        *nActFeat = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_AR_StlgetConf(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_StrConfObj *pConf)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pConf);

        struct AR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(AR_STL_CONF_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_AR,
            TSYNC_ID_AR_STL_CA_CONF,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AR_VALUE_RECIPE,
            AR_STL_CONF_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct AR_STL_CONF* outPayload =
            (AR_STL_CONF*)GetPayload(result);

        memset(pConf->serialnb, 0, 16);
        memcpy(pConf->serialnb, outPayload->serialnb, 16);

        pConf->pos.lat   = outPayload->lat;
        pConf->pos.lon   = outPayload->lon;
        pConf->pos.alt   = outPayload->alt;
        pConf->ee_axis   = outPayload->ee_axis;
        pConf->nn_axis   = outPayload->nn_axis;
        pConf->uu_axis   = outPayload->uu_axis;
        pConf->geoMode   = outPayload->geoMode;
        pConf->sensLevel = outPayload->sensLevel;

    return ( err );
}

TSYNC_ERROR
TSYNC_AR_StlsetConf(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_StrConfObj conf)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct AR_STL_CONF_SET_CMD inPayload;
        inPayload.nInstance = nInstance;

        memset(inPayload.serialnb, 0, 16);
        memcpy(inPayload.serialnb, conf.serialnb, 16);

        inPayload.lat = conf.pos.lat;
        inPayload.lon = conf.pos.lon;
        inPayload.alt = conf.pos.alt;
        inPayload.ee_axis = conf.ee_axis;
        inPayload.nn_axis = conf.nn_axis;
        inPayload.uu_axis = conf.uu_axis;
        inPayload.geoMode = conf.geoMode;
        inPayload.sensLevel = conf.sensLevel;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AR_STL_CONF_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_AR,
            TSYNC_ID_AR_STL_CA_CONF,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AR_STL_CONF_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_AR_StlgetIpAddr(
    TSYNC_BoardHandle  hnd,
    unsigned int       nInstance,
    char *IpAddr)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(IpAddr);

        struct AR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(AR_STL_BUFFER_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_AR,
            TSYNC_ID_AR_STL_CA_IP_ADDR,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AR_VALUE_RECIPE,
            AR_STL_BUFFER_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct AR_STL_BUFFER* outPayload =
            (AR_STL_BUFFER*)GetPayload(result);

        memset(IpAddr, '\0', 16);
        memcpy(IpAddr, outPayload->buffer, 16);

    return ( err );
}

TSYNC_ERROR
TSYNC_AR_StlgetStat(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_StrStatusObj *pStatus)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pStatus);

        struct AR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(AR_STL_STAT_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_AR,
            TSYNC_ID_AR_STL_CA_STAT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AR_VALUE_RECIPE,
            AR_STL_STAT_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct AR_STL_STAT_VALUE* outPayload =
            (AR_STL_STAT_VALUE*)GetPayload(result);

        pStatus->rcvBurst   = outPayload->rcvBurst;
        pStatus->rcvStrongBurst   = outPayload->rcvStrongBurst;


    return ( err );
}

TSYNC_ERROR
TSYNC_AR_StlgetSubk(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_StrSubkObj *pSubk)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pSubk);

        struct AR_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AR_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(AR_STL_SUBK_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_AR,
            TSYNC_ID_AR_STL_CA_SUBK,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AR_VALUE_RECIPE,
            AR_STL_SUBK_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct AR_STL_SUBK* outPayload =
            (AR_STL_SUBK*)GetPayload(result);

        memset(pSubk->key, 0, 32);
        memcpy(pSubk->key, outPayload->key, 32);

    return ( err );
}

TSYNC_ERROR
TSYNC_AR_StlsetSubk(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_StrSubkObj subk)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct AR_STL_SUBK_SET_CMD inPayload;
        inPayload.nInstance = nInstance;

        memset(inPayload.key, 0, 32);
        memcpy(inPayload.key, subk.key, 32);

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AR_STL_SUBK_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_AR,
            TSYNC_ID_AR_STL_CA_SUBK,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AR_STL_SUBK_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

