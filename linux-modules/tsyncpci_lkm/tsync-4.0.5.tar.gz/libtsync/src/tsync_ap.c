#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_ap_services.h"
#include "tsync_cs_services.h"

extern uint8_t AP_VALUE_RECIPE[];
extern uint8_t AP_SET_CMD_RECIPE[];
extern uint8_t AP_REQ_CHAR_OBJ_RECIPE[];
extern uint8_t AP_REQ_CHAR_SET_CMD_RECIPE[];
extern uint8_t AP_UART_CFG_OBJ_RECIPE[];
extern uint8_t AP_UART_CFG_SET_CMD_RECIPE[];
extern uint8_t ML_CLK_LOCAL_RECIPE[];
extern uint8_t AP_LOCAL_SET_CMD_RECIPE[];
extern uint8_t ML_TIME_SCALE_OBJ_RECIPE[];
extern uint8_t AP_TIME_SCALE_SET_CMD_RECIPE[];
extern uint8_t AP_FORMAT_OBJ_RECIPE[];
extern uint8_t AP_FORMAT_SET_CMD_RECIPE[];

TSYNC_ERROR
TSYNC_AP_getSigCtrl(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    SIG_CTL *sig)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(sig);

        struct AP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(AP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_AP,
            TSYNC_ID_AP_CA_SIG_CTL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AP_VALUE_RECIPE,
            AP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct AP_VALUE* outPayload =
            (AP_VALUE*)GetPayload(result);

        *sig = (SIG_CTL)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_AP_setSigCtrl(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    SIG_CTL sig)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct AP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = sig;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_AP,
            TSYNC_ID_AP_CA_SIG_CTL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_AP_getLocal(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_LocalClockObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct AP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(ML_CLK_LOCAL_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_AP,
            TSYNC_ID_AP_CA_LOCAL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AP_VALUE_RECIPE,
            ML_CLK_LOCAL_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct ML_CLK_LOCAL* outPayload =
            (ML_CLK_LOCAL*)GetPayload(result);

        pObj->rule.ref = outPayload->ref;
        pObj->rule.in.month = outPayload->in.month;
        pObj->rule.in.wom = outPayload->in.wom;
        pObj->rule.in.dow = outPayload->in.dow;
        pObj->rule.in.hour = outPayload->in.hour;
        pObj->rule.out.month = outPayload->out.month;
        pObj->rule.out.wom = outPayload->out.wom;
        pObj->rule.out.dow = outPayload->out.dow;
        pObj->rule.out.hour = outPayload->out.hour;
        pObj->rule.offset = outPayload->offset;
        pObj->tz = outPayload->tz;

    return ( err );
}

TSYNC_ERROR
TSYNC_AP_setLocal(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_LocalClockObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct AP_LOCAL_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.ref = pObj->rule.ref;
        inPayload.in.month = pObj->rule.in.month;
        inPayload.in.wom = pObj->rule.in.wom;
        inPayload.in.dow = pObj->rule.in.dow;
        inPayload.in.hour = pObj->rule.in.hour;
        inPayload.out.month = pObj->rule.out.month;
        inPayload.out.wom = pObj->rule.out.wom;
        inPayload.out.dow = pObj->rule.out.dow;
        inPayload.out.hour = pObj->rule.out.hour;
        inPayload.offset = pObj->rule.offset;
        inPayload.tz = pObj->tz;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AP_LOCAL_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_AP,
            TSYNC_ID_AP_CA_LOCAL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AP_LOCAL_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_AP_getTimeScale(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_TimeScaleObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    struct AP_VALUE inPayload;
    inPayload.value = nInstance;

    uint16_t ctl = 0x00;//get
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(AP_VALUE_RECIPE, &pos);

    pos = 0;
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(ML_TIME_SCALE_OBJ_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_AP,
        TSYNC_ID_AP_CA_TIME_SCALE,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        AP_VALUE_RECIPE,
        ML_TIME_SCALE_OBJ_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    struct ML_TIME_SCALE_OBJ* outPayload =
        (ML_TIME_SCALE_OBJ*)GetPayload(result);

    pObj->scale = outPayload->scale;

    return ( err );
}

TSYNC_ERROR
TSYNC_AP_setTimeScale(
    TSYNC_BoardHandle   hnd,
    unsigned int nInstance,
    TSYNC_TimeScaleObj *pObj)
{
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    struct AP_TIME_SCALE_SET_CMD inPayload;
    inPayload.inst = nInstance;
    inPayload.scale.scale = pObj->scale;

    uint16_t ctl = 0x02;//set
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(AP_TIME_SCALE_SET_CMD_RECIPE, &pos);

    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(0));

    TSYNC_ERROR err = BaseTransaction(
        TSYNC_ID_AP,
        TSYNC_ID_AP_CA_TIME_SCALE,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        AP_TIME_SCALE_SET_CMD_RECIPE,
        NULL,
        result,
        handle);

    return ( err );
}

TSYNC_ERROR
TSYNC_AP_getFormat(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    AL_FMT *format)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(format);

        struct AP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(AP_FORMAT_OBJ_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_AP,
            TSYNC_ID_AP_CA_FORMAT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AP_VALUE_RECIPE,
            AP_FORMAT_OBJ_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct AP_FORMAT_OBJ* outPayload =
            (AP_FORMAT_OBJ*)GetPayload(result);

        format[0] = outPayload->fmt0;
        format[1] = outPayload->fmt1;
        format[2] = outPayload->fmt2;

    return ( err );
}

TSYNC_ERROR
TSYNC_AP_setFormat(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    AL_FMT* format)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct AP_FORMAT_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.fmt0 = format[0];
        inPayload.fmt1 = format[1];
        inPayload.fmt2 = format[2];

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AP_FORMAT_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_AP,
            TSYNC_ID_AP_CA_FORMAT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AP_FORMAT_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_AP_getMode(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    AL_OUT_MODE *mode)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(mode);

        struct AP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(AP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_AP,
            TSYNC_ID_AP_CA_MODE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AP_VALUE_RECIPE,
            AP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct AP_VALUE* outPayload =
            (AP_VALUE*)GetPayload(result);

        *mode = (AL_OUT_MODE)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_AP_setMode(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    AL_OUT_MODE mode)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct AP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = mode;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_AP,
            TSYNC_ID_AP_CA_MODE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_AP_getReqChar(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    char *req)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(req);

        struct AP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(AP_REQ_CHAR_OBJ_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_AP,
            TSYNC_ID_AP_CA_REQ_CHAR,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AP_VALUE_RECIPE,
            AP_REQ_CHAR_OBJ_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct AP_REQ_CHAR_OBJ* outPayload =
            (AP_REQ_CHAR_OBJ*)GetPayload(result);

        *req = (char)(outPayload->reqchar);

    return ( err );
}

TSYNC_ERROR
TSYNC_AP_setReqChar(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    char req)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct AP_REQ_CHAR_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.reqchar = (int32_t)req;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AP_REQ_CHAR_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_AP,
            TSYNC_ID_AP_CA_REQ_CHAR,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AP_REQ_CHAR_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_AP_getUartCfg(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    UD_CFG *pCfg)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pCfg);

        struct AP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(AP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_AP,
            TSYNC_ID_AP_CA_UART_CFG,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AP_VALUE_RECIPE,
            AP_UART_CFG_OBJ_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct AP_UART_CFG_OBJ* outPayload =
            (AP_UART_CFG_OBJ*)GetPayload(result);

        pCfg->br       = outPayload->baud;
        pCfg->numbits  = outPayload->db;
        pCfg->parity   = outPayload->par;
        pCfg->stopbits = outPayload->sb;

    return ( err );
}

TSYNC_ERROR
TSYNC_AP_setUartCfg(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    UD_CFG* pCfg)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pCfg);

        struct AP_UART_CFG_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.baud = pCfg->br;
        inPayload.db   = pCfg->numbits;
        inPayload.par  = pCfg->parity;
        inPayload.sb   = pCfg->stopbits;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AP_UART_CFG_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_AP,
            TSYNC_ID_AP_CA_UART_CFG,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AP_UART_CFG_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_AP_getNumInst(
    TSYNC_BoardHandle hnd,
    unsigned int *nInstances)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nInstances);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(AP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_AP,
            TSYNC_ID_AP_CA_NUM_INST,
            ctl,
            pyldLen,
            NULL,
            NULL,
            AP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct AP_VALUE* outPayload =
            (AP_VALUE*)GetPayload(result);

        *nInstances = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_AP_getSource(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    AO_SOURCE *source)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(source);

        struct AP_VALUE inPayload;
        inPayload.value = nInstance;
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(AP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_AP,
            TSYNC_ID_AP_CA_SOURCE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AP_VALUE_RECIPE,
            AP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct AP_VALUE* outPayload =
            (AP_VALUE*)GetPayload(result);

        *source = (AO_SOURCE)outPayload->value;

    return ( err );

}

TSYNC_ERROR
TSYNC_AP_getOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *poffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(poffset);

        struct AP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(AP_REQ_CHAR_OBJ_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_AP,
            TSYNC_ID_AP_CA_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AP_VALUE_RECIPE,
            AP_REQ_CHAR_OBJ_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct AP_REQ_CHAR_OBJ* outPayload =
            (AP_REQ_CHAR_OBJ*)GetPayload(result);

        *poffset = (int)(outPayload->reqchar);

    return ( err );
}

TSYNC_ERROR
TSYNC_AP_setOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int offset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct AP_REQ_CHAR_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.reqchar = (int32_t)offset;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(AP_REQ_CHAR_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_AP,
            TSYNC_ID_AP_CA_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            AP_REQ_CHAR_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}
