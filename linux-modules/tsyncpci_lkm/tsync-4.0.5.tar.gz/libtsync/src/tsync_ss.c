#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_ss_services.h"
#include "tsync_cs_services.h"

extern uint8_t SS_REF_OBJ_RECIPE[];
extern uint8_t SS_RESET_OBJ_RECIPE[];
extern uint8_t SS_VALUE_RECIPE[];
extern uint8_t SS_TS_REQ_RECIPE[];
extern uint8_t ML_DOYTIME_GET_RESP_RECIPE[];
extern uint8_t ML_BCDTIME_GET_RESP_RECIPE[];
extern uint8_t ML_SECTIME_GET_RESP_RECIPE[];
extern uintptr_t ML_TIME_UNION_GET_RESP_RECIPE[];

TSYNC_ERROR
TSYNC_SS_getRef(
    TSYNC_BoardHandle   hnd,
    TSYNC_ReferenceObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(SS_REF_OBJ_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_SS,
            TSYNC_ID_SS_CA_REF,
            ctl,
            pyldLen,
            NULL,
            NULL,
            SS_REF_OBJ_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct SS_REF_OBJ* outPayload =
            (SS_REF_OBJ*)GetPayload(result);

        memset(pObj->time, '\0', sizeof(pObj->time));
        memset(pObj->pps, '\0', sizeof(pObj->pps));

        memcpy(pObj->time, outPayload->time, sizeof(outPayload->time));
        memcpy(pObj->pps, outPayload->pps, sizeof(outPayload->pps));

    return ( err );
}

TSYNC_ERROR
TSYNC_SS_reset(
    TSYNC_BoardHandle  hnd,
    TSYNC_ResetObj    *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct SS_RESET_OBJ inPayload;
        inPayload.type = pObj->type;

        uint16_t ctl = 0x02;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(SS_RESET_OBJ_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_SS,
            TSYNC_ID_SS_CA_RESET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            SS_RESET_OBJ_RECIPE,
            NULL,
            result,
            handle);

    return ( err );
}

TSYNC_ERROR
TSYNC_SS_getMaxTfom(
    TSYNC_BoardHandle hnd,
    TFOM *tfom)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(SS_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_SS,
            TSYNC_ID_SS_CA_MAX_TFOM,
            ctl,
            pyldLen,
            NULL,
            NULL,
            SS_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct SS_VALUE* outPayload =
            (SS_VALUE*)GetPayload(result);

        *tfom = (TFOM)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_SS_setMaxTfom(
    TSYNC_BoardHandle hnd,
    TFOM tfom)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct SS_VALUE inPayload;
        inPayload.value = tfom;

        uint16_t ctl = 0x02;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(SS_VALUE_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_SS,
            TSYNC_ID_SS_CA_MAX_TFOM,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            SS_VALUE_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_SS_getTfom(
    TSYNC_BoardHandle hnd,
    TFOM *tfom)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(SS_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_SS,
            TSYNC_ID_SS_CA_TFOM,
            ctl,
            pyldLen,
            NULL,
            NULL,
            SS_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct SS_VALUE* outPayload =
            (SS_VALUE*)GetPayload(result);

        *tfom = (TFOM)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_SS_getInputTfom(
    TSYNC_BoardHandle hnd,
    TFOM *tfom)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(SS_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_SS,
            TSYNC_ID_SS_CA_INPUT_TFOM,
            ctl,
            pyldLen,
            NULL,
            NULL,
            SS_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct SS_VALUE* outPayload =
            (SS_VALUE*)GetPayload(result);

        *tfom = (TFOM)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_SS_getSync(
    TSYNC_BoardHandle hnd,
    int *bSync)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(SS_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_SS,
            TSYNC_ID_SS_CA_SYNC,
            ctl,
            pyldLen,
            NULL,
            NULL,
            SS_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct SS_VALUE* outPayload =
            (SS_VALUE*)GetPayload(result);

        *bSync = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_SS_getHoldover(
    TSYNC_BoardHandle hnd,
    int *bHoldover)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(SS_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_SS,
            TSYNC_ID_SS_CA_HOLDOVER,
            ctl,
            pyldLen,
            NULL,
            NULL,
            SS_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct SS_VALUE* outPayload =
            (SS_VALUE*)GetPayload(result);

        *bHoldover = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_SS_getHoldoverTO(
    TSYNC_BoardHandle hnd,
    unsigned int *nHoldoverTimeout)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(SS_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_SS,
            TSYNC_ID_SS_CA_HOLDOVER_TIMEOUT,
            ctl,
            pyldLen,
            NULL,
            NULL,
            SS_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct SS_VALUE* outPayload =
            (SS_VALUE*)GetPayload(result);

        *nHoldoverTimeout = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_SS_setHoldoverTO(
    TSYNC_BoardHandle hnd,
    unsigned int nHoldoverTimeout)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct SS_VALUE inPayload;
        inPayload.value = nHoldoverTimeout;

        uint16_t ctl = 0x02;//set
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(SS_VALUE_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_SS,
            TSYNC_ID_SS_CA_HOLDOVER_TIMEOUT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            SS_VALUE_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_SS_getTimestamp(
    TSYNC_BoardHandle hnd,
    SS_TS_SRC src,
    TSYNC_TimeObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct SS_TS_REQ inPayload;
        inPayload.src = src;
        inPayload.type = ML_TIME_DOYTIME;//pObj->type;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(SS_TS_REQ_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofUnion(ML_TIME_UNION_GET_RESP_RECIPE)));

        err = BaseTransaction(
            TSYNC_ID_SS,
            TSYNC_ID_SS_CA_TIME_STAMP,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            SS_TS_REQ_RECIPE,
            ML_DOYTIME_GET_RESP_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct ML_DOYTIME_GET_RESP* outPayload =
            (ML_DOYTIME_GET_RESP*)GetPayload(result);

        pObj->years = outPayload->time.year;
        pObj->doy = outPayload->time.doy;
        pObj->hours = outPayload->time.hour;
        pObj->minutes = outPayload->time.minute;
        pObj->seconds = outPayload->time.second;
        pObj->ns = outPayload->time.ns;

    return ( err );
}

TSYNC_ERROR
TSYNC_SS_getTimestampBcd(
    TSYNC_BoardHandle hnd,
    SS_TS_SRC src,
    TSYNC_TimeBCDObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct SS_TS_REQ inPayload;
        inPayload.src = src;
        inPayload.type = ML_TIME_BCDTIME;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(SS_TS_REQ_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofUnion(ML_TIME_UNION_GET_RESP_RECIPE)));

        err = BaseTransaction(
            TSYNC_ID_SS,
            TSYNC_ID_SS_CA_TIME_STAMP,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            SS_TS_REQ_RECIPE,
            ML_BCDTIME_GET_RESP_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct ML_BCDTIME_GET_RESP* outPayload =
            (ML_BCDTIME_GET_RESP*)GetPayload(result);

        pObj->years = outPayload->time.year;
        pObj->doy = outPayload->time.doy;
        pObj->hours = outPayload->time.hour;
        pObj->minutes = outPayload->time.minute;
        pObj->seconds = outPayload->time.second;
        pObj->ms = outPayload->time.ms;
        pObj->us = outPayload->time.us;

    return ( err );
}

TSYNC_ERROR
TSYNC_SS_getTimestampSec(
    TSYNC_BoardHandle hnd,
    SS_TS_SRC src,
    unsigned int *nSeconds,
    unsigned int *nNanos)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nSeconds);
        CHECK_NOT_NULL(nNanos);

        struct SS_TS_REQ inPayload;
        inPayload.src = src;
        inPayload.type = ML_TIME_SECONDS;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(SS_TS_REQ_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofUnion(ML_TIME_UNION_GET_RESP_RECIPE)));

        err = BaseTransaction(
            TSYNC_ID_SS,
            TSYNC_ID_SS_CA_TIME_STAMP,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            SS_TS_REQ_RECIPE,
            ML_SECTIME_GET_RESP_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct ML_SECTIME_GET_RESP* outPayload =
            (ML_SECTIME_GET_RESP*)GetPayload(result);

        *nSeconds = outPayload->time.seconds;
        *nNanos = outPayload->time.ns;

    return ( err );
}

TSYNC_ERROR
TSYNC_SS_getUptime(
    TSYNC_BoardHandle hnd,
    unsigned int *nUptime)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(SS_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_SS,
            TSYNC_ID_SS_CA_UPTIME,
            ctl,
            pyldLen,
            NULL,
            NULL,
            SS_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct SS_VALUE* outPayload =
            (SS_VALUE*)GetPayload(result);

        *nUptime = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_SS_getFreeRun(
    TSYNC_BoardHandle hnd,
    int *bFreerun)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(SS_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_SS,
            TSYNC_ID_SS_CA_FREERUN,
            ctl,
            pyldLen,
            NULL,
            NULL,
            SS_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct SS_VALUE* outPayload =
            (SS_VALUE*)GetPayload(result);

        *bFreerun = outPayload->value;

    return ( err );
}

