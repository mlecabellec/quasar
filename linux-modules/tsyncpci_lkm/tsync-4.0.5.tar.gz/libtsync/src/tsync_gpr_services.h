
#ifndef _defined_TSYNC_GPR_SERVICES_H
#define _defined_TSYNC_GPR_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_gpr_services.h
**
**  Date:       03/06/2013
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2013 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              Mar 6 2013 Creation  DPR
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_GPR                            0x45
#define TSYNC_ID_GPR_CA_NUM_INST                0x01
/*****************************************************/
#define TSYNC_ID_GPR_CA_CLOCK_IDENTITY          0x09
#define TSYNC_ID_GPR_CA_PRIORITY                0x0A
#define TSYNC_ID_GPR_CA_DOMAIN                  0x0B
#define TSYNC_ID_GPR_CA_CLOCK_MODE              0x0C
#define TSYNC_ID_GPR_CA_CLOCK_STEPS             0x0D
#define TSYNC_ID_GPR_CA_CLOCK_PORTS             0x0E
#define TSYNC_ID_GPR_CA_CLOCK_QUALITY           0x0F
#define TSYNC_ID_GPR_CA_STATISTICS              0x10
#define TSYNC_ID_GPR_CA_PARENT_DATA             0x11

#define TSYNC_ID_GPR_CA_TIME_PROP               0x13
#define TSYNC_ID_GPR_CA_USER_DESCRIPTION        0x14
#define TSYNC_ID_GPR_CA_UNCT_MASTER_ADD         0x15
#define TSYNC_ID_GPR_CA_UNCT_MASTER_DEL         0x16
#define TSYNC_ID_GPR_CA_UNCT_SLAVE_PROP         0x17
#define TSYNC_ID_GPR_CA_UNCT_MASTER_PROP        0x18
#define TSYNC_ID_GPR_CA_UNCT_MASTER_CFG         0x19
#define TSYNC_ID_GPR_CA_PORT_STATE              0x1A
#define TSYNC_ID_GPR_CA_MSG_RATES               0x1B
#define TSYNC_ID_GPR_CA_MSG_TO                  0x1C
#define TSYNC_ID_GPR_CA_DELAY_MECH              0x1D
#define TSYNC_ID_GPR_CA_BCAST_MECH              0x1E
#define TSYNC_ID_GPR_CA_STATIC_IPV4             0x1F
#define TSYNC_ID_GPR_CA_CURRENT_IPV4            0x20
#define TSYNC_ID_GPR_CA_DHCP                    0x21
#define TSYNC_ID_GPR_CA_MAC_ADDR                0x22
#define TSYNC_ID_GPR_CA_TTL                     0x23
#define TSYNC_ID_GPR_CA_ETH_TRANS               0x24
#define TSYNC_ID_GPR_CA_SYNC_ETH                0x25
#define TSYNC_ID_GPR_CA_VLAN                    0x26
#define TSYNC_ID_GPR_CA_CLASS_CFG               0x27
#define TSYNC_ID_GPR_CA_MODULE_INFO             0x28
#define TSYNC_ID_GPR_CA_SAVE_SETTINGS           0x29
#define TSYNC_ID_GPR_CA_RESET_MODULE            0x2A
#define TSYNC_ID_GPR_CA_REINIT_MODULE           0x2B
#define TSYNC_ID_GPR_CA_MODULE_STATUS           0x2C
#define TSYNC_ID_GPR_CA_BOOT_IMG                0x2D
#define TSYNC_ID_GPR_CA_CONTROL                 0x2E
#define TSYNC_ID_GPR_CA_PORT_SPEED              0x2F
#define TSYNC_ID_GPR_CA_SLAVE_STATS             0x30
#define TSYNC_ID_GPR_CA_SLAVE_SUMMARY           0x31
#define TSYNC_ID_GPR_CA_DEBUG                   0x32
#define TSYNC_ID_GPR_CA_PROFILE                 0x33
#define TSYNC_ID_GPR_CA_PPS_OFFSET              0x34

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define GPR_VALUE_FIELDS                            \
    TSYNC_X( uint32_t,          value)
    
#define GPR_VALUE_SET_CMD_FIELDS                    \
    TSYNC_X( uint32_t,          nInstance)          \
    TSYNC_X( uint32_t,          value)

#define GPL_CLOCK_ID_FIELDS                         \
    TSYNC_X_BUFFER( uint8_t,    cid,  8)

#define GPL_CLOCK_ID_SET_FIELDS                     \
    TSYNC_X( uint32_t,          nInstance)          \
    GPL_CLOCK_ID_FIELDS

#define GPL_PRIORITY_FIELDS                         \
    TSYNC_X( uint8_t,           priority1)          \
    TSYNC_X( uint8_t,           priority2)

#define GPL_PRIORITY_SET_FIELDS                     \
    TSYNC_X( uint32_t,          nInstance)          \
    GPL_PRIORITY_FIELDS

#define GPL_CLOCK_QUAL_FIELDS                       \
    TSYNC_X( uint32_t,          clockClass)         \
    TSYNC_X( uint32_t,          clockAccuracy)      \
    TSYNC_X( uint32_t,          oSLV)


#define GPL_STATISTICS_FIELDS                       \
    TSYNC_X( int64_t,           offFromMaster)      \
    TSYNC_X( int64_t,           meanPathDelay)      \
    TSYNC_X( uint16_t,          stepsRemoved)

#define GPL_PARENT_DATA_FIELDS                      \
    TSYNC_X_BUFFER( uint8_t,    parentCid,  8)      \
    TSYNC_X( uint32_t,          parentPid)          \
    TSYNC_X( uint32_t,          parentStatsCalc)    \
    TSYNC_X( uint32_t,          parentObsOSLV)      \
    TSYNC_X( uint32_t,          parentObsCPCR)      \
    TSYNC_X( uint32_t,          gmClockClass)       \
    TSYNC_X( uint32_t,          gmClockAccuracy)    \
    TSYNC_X( uint32_t,          gmOSLV)             \
    TSYNC_X_BUFFER( uint8_t,    gmCid,  8)          \
    TSYNC_X( uint32_t,          gmPid)              \
    TSYNC_X( uint8_t,           gmpriority1)        \
    TSYNC_X( uint8_t,           gmpriority2)

#define GPL_TIME_PROP_FIELDS                        \
    TSYNC_X( int32_t,           utcOffset)          \
    TSYNC_X( uint32_t,          utcOffsetValid)     \
    TSYNC_X( uint32_t,          forwardLeap)        \
    TSYNC_X( uint32_t,          backwardLeap)       \
    TSYNC_X( uint32_t,          timeTraceable)      \
    TSYNC_X( uint32_t,          freqTraceable)      \
    TSYNC_X( uint32_t,          ptpTimescale)       \
    TSYNC_X( uint32_t,           timeSource)

///

#define GPL_USER_DESC_FIELDS                        \
    TSYNC_X_BUFFER( uint8_t,    deviceName,     16)  \
    TSYNC_X_BUFFER( uint8_t,    deviceLocation, 16)

#define GPL_USER_DESC_SET_FIELDS                    \
    TSYNC_X( uint32_t,          nInstance)          \
    GPL_USER_DESC_FIELDS

#define GPL_UNCT_MASTER_ADD_FIELDS                  \
    TSYNC_X_BUFFER( uint8_t,    cid,  8)            \
    TSYNC_X( uint32_t,          pid)                \
    TSYNC_X_BUFFER( uint8_t,    ip,   4)            \
    TSYNC_X( uint8_t,           logQuerySlaveInterval)  \
    TSYNC_X( uint16_t,          durationSlaveContracts) \
    TSYNC_X( uint8_t,           logAnnSlaveInterval)    \
    TSYNC_X( uint8_t,           logSyncMasterInterval)  \
    TSYNC_X( uint8_t,           logDelayReqSlaveInterval)

#define GPL_UNCT_MASTER_ADD_SET_FIELDS              \
    TSYNC_X( uint32_t,          nInstance)          \
    GPL_UNCT_MASTER_ADD_FIELDS

#define GPL_PORT_IDENTITY_FIELDS                    \
    TSYNC_X_BUFFER( uint8_t,    cid,  8)            \
    TSYNC_X( uint32_t,          pid)

#define GPL_PORT_IDENTITY_SET_FIELDS                \
    TSYNC_X( uint32_t,          nInstance)          \
    GPL_PORT_IDENTITY_FIELDS

#define GPL_UNCT_SLAVE_PROP_FIELDS                              \
    TSYNC_X( uint32_t,          negoEnabled)                    \
    TSYNC_X_BUFFER( uint8_t,    contractAnnState,     16)       \
    TSYNC_X( uint16_t,          durationAnnContracts)           \
    TSYNC_X( uint16_t,          delayAnnContracts)              \
    TSYNC_X( uint32_t,          logAnnMsgInterval)              \
    TSYNC_X_BUFFER( uint8_t,    contractSyncState,     16)      \
    TSYNC_X( uint16_t,          durationSyncContracts)          \
    TSYNC_X( uint16_t,          delaySyncContracts)             \
    TSYNC_X( uint32_t,          logSyncMsgInterval)             \
    TSYNC_X_BUFFER( uint8_t,    contractDelayRespState,     16) \
    TSYNC_X( uint16_t,          durationDelayRespContracts)     \
    TSYNC_X( uint16_t,          delayDelayRespContracts)        \
    TSYNC_X( uint32_t,          logDelayRespMsgInterval)

#define GPL_UNCT_MASTER_PROP_FIELDS                             \
    TSYNC_X( uint32_t,          negoEnabled)                    \
    TSYNC_X( uint32_t,          nbSlaveConnected)

#define GPL_UNCT_MASTER_CFG_FIELDS                              \
    TSYNC_X( uint16_t,          minAnnInt)                      \
    TSYNC_X( uint16_t,          maxAnnDur)                      \
    TSYNC_X( uint16_t,          minSyncInt)                     \
    TSYNC_X( uint16_t,          maxSyncDur)                     \
    TSYNC_X( uint16_t,          minDRqInt)                      \
    TSYNC_X( uint16_t,          maxDRqDur)                      \
    TSYNC_X( uint16_t,          maxSlaves)

#define GPL_UNCT_MASTER_CFG_SET_FIELDS                          \
    TSYNC_X( uint32_t,          nInstance)                      \
    GPL_UNCT_MASTER_CFG_FIELDS

#define GPL_MSG_RATES_FIELDS                                    \
    TSYNC_X( uint32_t,          logAnnInterval)                  \
    TSYNC_X( uint32_t,          logSyncInterval)                 \
    TSYNC_X( uint32_t,          logDelayReqInterval)

#define GPL_MSG_RATES_SET_FIELDS                                \
    TSYNC_X( uint32_t,          nInstance)                      \
    GPL_MSG_RATES_FIELDS

#define GPL_MSG_TO_FIELDS                                       \
    TSYNC_X( uint32_t,          annRcptTimeout)                  \
    TSYNC_X( uint32_t,          syncTimeout)                     \
    TSYNC_X( uint32_t,          delayRespTimeout)

#define GPL_MSG_TO_SET_FIELDS                                   \
    TSYNC_X( uint32_t,          nInstance)                      \
    GPL_MSG_TO_FIELDS

#define GPL_IPV4_FIELDS                                         \
    TSYNC_X_BUFFER( uint8_t,    ipV4Addr,   4)                  \
    TSYNC_X_BUFFER( uint8_t,    netmask,    4)                  \
    TSYNC_X_BUFFER( uint8_t,    gateway,    4)

#define GPL_IPV4_SET_FIELDS                                     \
    TSYNC_X( uint32_t,          nInstance)                      \
    GPL_IPV4_FIELDS

#define GPL_MAC_ADDR_FIELDS                                     \
    TSYNC_X_BUFFER( uint8_t,    macAddr,  6)

#define GPL_MAC_ADDR_SET_FIELDS                                 \
    TSYNC_X( uint32_t,          nInstance)                      \
    GPL_MAC_ADDR_FIELDS

#define GPL_SYNC_ETH_ITF_FIELDS                                 \
    TSYNC_X( uint32_t,          enableSyncE)                    \
    TSYNC_X( uint32_t,          esmcEnable)                     \
    TSYNC_X( uint32_t,          esmcSigCtl)                     \
    TSYNC_X( uint32_t,          ssmCode)

#define GPL_SYNC_ETH_ITF_SET_FIELDS                             \
    TSYNC_X( uint32_t,          nInstance)                      \
    GPL_SYNC_ETH_ITF_FIELDS

#define GPL_VLAN_FIELDS                                         \
    TSYNC_X( uint32_t,          vLanIntEnable)                  \
    TSYNC_X( uint32_t,          vLanID)                         \
    TSYNC_X( uint32_t,           priorityCodePoint)

#define GPL_VLAN_SET_FIELDS                                     \
    TSYNC_X( uint32_t,          nInstance)                      \
    GPL_VLAN_FIELDS

#define GPL_MODULE_INFO_FIELDS                                  \
    TSYNC_X( uint32_t,          ptpVersionNumber)               \
    TSYNC_X( uint32_t,          softwareVersion)                \
    TSYNC_X( uint32_t,          hardwareVersion)                \
    TSYNC_X_BUFFER( uint8_t,    softDate,     12)               \
    TSYNC_X_BUFFER( uint8_t,    softTime, 9)

#define GPL_CONTROL_FIELDS                                      \
    TSYNC_X( uint32_t,          networkEn)                      \
    TSYNC_X( uint32_t,          ptpEn)

#define GPL_CONTROL_SET_FIELDS                                  \
    TSYNC_X( uint32_t,          nInstance)                      \
    GPL_CONTROL_FIELDS

#define GPL_BCAST_MECH_FIELDS                                   \
    TSYNC_X( uint32_t,          mSync)                          \
    TSYNC_X( uint32_t,          mDlyReq)                        \
    TSYNC_X( uint32_t,          uSync)                          \
    TSYNC_X( uint32_t,          uDlyReq)

#define GPL_BCAST_MECH_SET_FIELDS                                  \
    TSYNC_X( uint32_t,          nInstance)                      \
    GPL_BCAST_MECH_FIELDS

#define GPL_SLAVE_STATS_FIELDS                                  \
    TSYNC_X( uint32_t,          slaveNum)                       \
    TSYNC_X_BUFFER( uint8_t,    cid,  8)                        \
    TSYNC_X( uint32_t,          pid)                            \
    TSYNC_X_BUFFER( uint8_t,    ipV4Addr,   4)                  \
    TSYNC_X_BUFFER( uint8_t,    macAddr,    6)                  \
    TSYNC_X( uint16_t,          syncPeriod)                     \
    TSYNC_X( uint16_t,          annPeriod)                      \
    TSYNC_X( uint16_t,          dRqPeriod)                      \
    TSYNC_X( uint16_t,          syncDur)                        \
    TSYNC_X( uint16_t,          syncRem)                        \
    TSYNC_X( uint16_t,          annDur)                         \
    TSYNC_X( uint16_t,          annRem)                         \
    TSYNC_X( uint16_t,          dRqDur)                         \
    TSYNC_X( uint16_t,          dRqRem)

#define GPL_SLAVE_SUMMARY_FIELDS                                \
    TSYNC_X( uint32_t,          dRqPerSec)                      \
    TSYNC_X( uint32_t,          numUniSlaveConn)

////////////////////////////////////////////////////
#include "tsync_struct_define.h"

GEN_STRUCT(GPR_VALUE)
GEN_STRUCT(GPR_VALUE_SET_CMD)
GEN_STRUCT(GPL_CLOCK_ID)
GEN_STRUCT(GPL_CLOCK_ID_SET)
GEN_STRUCT(GPL_PRIORITY)
GEN_STRUCT(GPL_PRIORITY_SET)
GEN_STRUCT(GPL_CLOCK_QUAL)
GEN_STRUCT(GPL_STATISTICS)
GEN_STRUCT(GPL_PARENT_DATA)
GEN_STRUCT(GPL_TIME_PROP)

GEN_STRUCT(GPL_USER_DESC)
GEN_STRUCT(GPL_USER_DESC_SET)
GEN_STRUCT(GPL_UNCT_MASTER_ADD)
GEN_STRUCT(GPL_UNCT_MASTER_ADD_SET)
GEN_STRUCT(GPL_PORT_IDENTITY)
GEN_STRUCT(GPL_PORT_IDENTITY_SET)
GEN_STRUCT(GPL_UNCT_SLAVE_PROP)
GEN_STRUCT(GPL_UNCT_MASTER_PROP)
GEN_STRUCT(GPL_UNCT_MASTER_CFG)
GEN_STRUCT(GPL_UNCT_MASTER_CFG_SET)
GEN_STRUCT(GPL_MSG_RATES)
GEN_STRUCT(GPL_MSG_RATES_SET)
GEN_STRUCT(GPL_MSG_TO)
GEN_STRUCT(GPL_MSG_TO_SET)
GEN_STRUCT(GPL_IPV4)
GEN_STRUCT(GPL_IPV4_SET)
GEN_STRUCT(GPL_MAC_ADDR)
GEN_STRUCT(GPL_MAC_ADDR_SET)
GEN_STRUCT(GPL_SYNC_ETH_ITF)
GEN_STRUCT(GPL_SYNC_ETH_ITF_SET)
GEN_STRUCT(GPL_VLAN)
GEN_STRUCT(GPL_VLAN_SET)
GEN_STRUCT(GPL_MODULE_INFO)
GEN_STRUCT(GPL_CONTROL)
GEN_STRUCT(GPL_CONTROL_SET)
GEN_STRUCT(GPL_BCAST_MECH)
GEN_STRUCT(GPL_BCAST_MECH_SET)
GEN_STRUCT(GPL_SLAVE_STATS)
GEN_STRUCT(GPL_SLAVE_SUMMARY)



#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_GPR_SERVICES_H */
