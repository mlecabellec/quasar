
/***************************************************************************
**  Module:     tsync_ls_services_recipes.c
**
**  Date:       07/10/08
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/10/2008 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_ls_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(LS_ERROR_LOG)
RECIPE(LS_ALARM_OBJ)
RECIPE(LS_ALARM_FLAG)
RECIPE(LS_ALARM_SET_CMD)
RECIPE(LS_VERSION)
RECIPE(LS_SERIAL_NO)

#include "tsync_recipe_undef.h"
