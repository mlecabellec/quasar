
/***************************************************************************
**  Module:     tsync_hr_services_recipes.c
**
**  Date:       09/11/09
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2009 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              09/11/2009 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_hr_services.h"
#include "tsync_cs_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(HR_VALUE)
RECIPE(HR_VALIDITY_SET_CMD)
RECIPE(HR_DOYTIME_SET_CMD)
RECIPE(HR_LOCAL_SET_CMD)
RECIPE(HR_TIME_SCALE_SET_CMD)
RECIPE(HR_OFFSET_SET_CMD)
RECIPE(HR_MODE_SET_CMD)

#include "tsync_recipe_undef.h"
