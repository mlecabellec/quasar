#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_fm_services.h"
#include "tsync_misc_services.h"

extern uint8_t FM_VALUE_RECIPE[];
extern uint8_t FM_SET_CMD_RECIPE[];
extern uint8_t FM_FLOAT_VALUE_RECIPE[];
extern uint8_t FM_FLOAT_BUF_RECIPE[];
extern uint8_t FM_SET_FLOAT_CMD_RECIPE[];

TSYNC_ERROR
TSYNC_FM_getNumInst(
    TSYNC_BoardHandle hnd,
    unsigned int *nInstances)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nInstances);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(FM_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_FM,
            TSYNC_ID_FM_CA_NUM_INST,
            ctl,
            pyldLen,
            NULL,
            NULL,
            FM_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct FM_VALUE* outPayload =
            (FM_VALUE*)GetPayload(result);
            
        *nInstances = outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_FM_getRefFrequency(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    float *freq)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(freq);

        struct FM_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(FM_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(FM_FLOAT_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_FM,
            TSYNC_ID_FM_CA_REF_FREQUENCY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            FM_VALUE_RECIPE,
            FM_FLOAT_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct FM_FLOAT_VALUE* outPayload =
            (FM_FLOAT_VALUE*)GetPayload(result);
            
        *freq = outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_FM_setRefFrequency(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    float freq)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct FM_SET_FLOAT_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = freq;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(FM_SET_FLOAT_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_FM,
            TSYNC_ID_FM_CA_REF_FREQUENCY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            FM_SET_FLOAT_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_FM_getMinAccuracy(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    float *minacc)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(minacc);

        struct FM_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(FM_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(FM_FLOAT_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_FM,
            TSYNC_ID_FM_CA_MIN_ACCURACY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            FM_VALUE_RECIPE,
            FM_FLOAT_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct FM_FLOAT_VALUE* outPayload =
            (FM_FLOAT_VALUE*)GetPayload(result);
            
        *minacc = outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_FM_setMinAccuracy(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    float minacc)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct FM_SET_FLOAT_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = minacc;
        
        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(FM_SET_FLOAT_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_FM,
            TSYNC_ID_FM_CA_MIN_ACCURACY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            FM_SET_FLOAT_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)
        
    return ( err );
}

TSYNC_ERROR
TSYNC_FM_getFrequency(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    float *freq)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(freq);

        struct FM_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(FM_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(FM_FLOAT_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_FM,
            TSYNC_ID_FM_CA_FREQUENCY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            FM_VALUE_RECIPE,
            FM_FLOAT_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct FM_FLOAT_VALUE* outPayload =
            (FM_FLOAT_VALUE*)GetPayload(result);
            
        *freq = outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_FM_getAccuracy(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    float *acc)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(acc);

        struct FM_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(FM_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(FM_FLOAT_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_FM,
            TSYNC_ID_FM_CA_ACCURACY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            FM_VALUE_RECIPE,
            FM_FLOAT_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct FM_FLOAT_VALUE* outPayload =
            (FM_FLOAT_VALUE*)GetPayload(result);
            
        *acc = outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_FM_getAccurate(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int *acc)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(acc);

        struct FM_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(FM_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(FM_VALUE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_FM,
            TSYNC_ID_FM_CA_ACCURATE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            FM_VALUE_RECIPE,
            FM_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct FM_VALUE* outPayload =
            (FM_VALUE*)GetPayload(result);
            
        *acc = outPayload->value;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_FM_getLogFrequency(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_FmLogObj *freq)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(freq);

        struct FM_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(FM_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(FM_FLOAT_BUF_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_FM,
            TSYNC_ID_FM_CA_LOG_FREQUENCY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            FM_VALUE_RECIPE,
            FM_FLOAT_BUF_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct FM_FLOAT_BUF* outPayload =
            (FM_FLOAT_BUF*)GetPayload(result);
        
		int i;
        for(i = 0; i < FM_LOG_MAX; i++)
        {
            freq->log[i] = outPayload->log[i].value;
        }		

    return ( err );
}

TSYNC_ERROR
TSYNC_FM_getLogAccuracy(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_FmLogObj *acc)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
	
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(acc);

        struct FM_VALUE inPayload;
        inPayload.value = nInstance;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(FM_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(FM_FLOAT_BUF_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_FM,
            TSYNC_ID_FM_CA_LOG_ACCURACY,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            FM_VALUE_RECIPE,
            FM_FLOAT_BUF_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct FM_FLOAT_BUF* outPayload =
            (FM_FLOAT_BUF*)GetPayload(result);

		int i;
        for(i = 0; i < FM_LOG_MAX; i++)
        {
            acc->log[i] = outPayload->log[i].value;
        }		
        
    return ( err );
}
