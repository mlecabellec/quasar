
#ifndef _defined_TSYNC_KTYPES_H
#define _defined_TSYNC_KTYPES_H

/***************************************************************************
**  Module:     tsync_ktypes.h
**
**  Date:       08/08/07
**
**  Purpose:    IOCTL definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              08/08/2007 Multi-user enablement
**
****************************************************************************/


/******************************************************
**     Defines
******************************************************/
/*
** Subsytem Product IDs
*/

#define TSYNC_DEVID_TSAT             ( 0x9070 )
#define TSYNC_DEVID_TSAT_HB1PPS      ( 0x9072 )
#define TSYNC_DEVID_TSAT_FXA         ( TSYNC_DEVID_TSAT_HB1PPS )
#define TSYNC_DEVID_TSYNC             ( 0x9050 )
#define TSYNC_DEVID_TSYNC_M           ( 0x9051 )
#define TSYNC_DEVID_TSYNC_HB1PPS      ( 0x9052 )
#define TSYNC_DEVID_TSYNC_FXB         ( TSYNC_DEVID_TSYNC_HB1PPS )
#define TSYNC_DEVID_TSYNC_LOR1        ( TSYNC_DEVID_TSYNC_HB1PPS )
#define TSYNC_DEVID_TSYNC_M_HB1PPS    ( 0x9053 )

#define TSYNC_DEVID_PCI66_TSAT          ( 0x9170 )
#define TSYNC_DEVID_PCI66_TSAT_HB1PPS   ( 0x9172 )
#define TSYNC_DEVID_PCI66_TSAT_FXA      ( TSYNC_DEVID_PCI66_TSAT_HB1PPS )
#define TSYNC_DEVID_PCI66_TSYNC          ( 0x9150 )
#define TSYNC_DEVID_PCI66_TSYNC_M        ( 0x9151 )
#define TSYNC_DEVID_PCI66_TSYNC_HB1PPS   ( 0x9152 )
#define TSYNC_DEVID_PCI66_TSYNC_FXB      ( TSYNC_DEVID_PCI66_TSYNC_HB1PPS )
#define TSYNC_DEVID_PCI66_TSYNC_LOR1     ( TSYNC_DEVID_PCI66_TSYNC_HB1PPS )
#define TSYNC_DEVID_PCI66_TSYNC_M_HB1PPS ( 0x9153 )

/*
** COMPACT PCI BOARDS that don't seem to be supported
** any longer by current drivers. Calls to logic that
** get FPGA info, set an oscillator frequency,
** set propdelaycorrection, and set time make distinctions
** on these C-PCI boards.
*/
#define TSYNC_DEVID_7000             ( 0x7000 )
#define TSYNC_DEVID_7100             ( 0x7100 )

/*
** Seconds to wait after issue of firmware reset
** Spec says at least 8... use 10 for good measure. Its
** a diagnostic anyway.
*/
#define TSYNC_FWARE_RESET_DELAY_SEC  ( 10 )

/*
** Max offset from base register in TSYNC board
*/
#define TSYNC_MAX_REG_OFFSET         ( 0x20 )

/*
** rate and frequency options for setting heartbeat
*/
#define TSYNC_OPTION_LO_RATE         ( 1 )
#define TSYNC_OPTION_HI_RATE         ( 0 )

#define TSYNC_MAX_HI_FREQ            ( 1000000 )
#define TSYNC_MIN_HI_FREQ            ( 45.7771 )

#define TSYNC_MAX_LO_FREQ            ( 500 )
#define TSYNC_MIN_LO_FREQ            ( 0.0152593 )

/*
** sync options for setting time
*/
#define TSYNC_ARM_CLOCK              ( 1 )
#define TSYNC_SET_CLOCK              ( 0 )

/*
** NTP reference ID options for boards
*/
#define TSYNC_NTP_REF_NON_SAT        "IRIG"
#define TSYNC_NTP_REF_SAT            "GPS "
#define TSYNC_NTP_REF_LENGTH         4


/******************************************************
**     Define Structures
******************************************************/

/*
 * Date object
 */
typedef struct DateObj
{
    uint16_t    year;
    uint8_t     month;
    uint8_t     day;
} DateObj;

/*
 * Wait object
 */
typedef struct WaitObj
{
    uint32_t    ticks;
    uint32_t    seconds;
    uint16_t    days;
    uint8_t     hours;
    uint8_t     minutes;
    uint8_t     status;
} WaitObj;

/*
 * Heart object
 */
typedef struct HeartObj
{
    uint16_t    divNumber;
    uint8_t     signalType;
    uint8_t     outputType;
} HeartObj;

/*
 * Match object
 */
typedef struct MatchObj
{
    uint32_t    seconds;
    uint16_t    days;
    uint8_t     minutes;
    uint8_t     hours;
    uint8_t     matchType;
} MatchObj;

/*
 * Satellite object
 */
typedef struct SatObj
{
    uint8_t     satsTracked;
    uint8_t     satsView;
} SatObj;

/*
 * AltObj object
 */
typedef struct AltObj
{
    uint32_t    meters;
} AltObj;

/*
 * Time object
 */
typedef struct TimeObj
{
    uint32_t    secsDouble;
    uint16_t    days;
    uint16_t    year;       /* obsolete ? for CPCI board */
    uint8_t     seconds;
    uint8_t     minutes;
    uint8_t     hours;
    uint16_t    sync;
} TimeObj;

/*
 * NTP Time object
 */
typedef struct NtpTimeObj
{
    struct timeval  tv;
    TimeObj         timeObj;
    uint32_t        refId;
} NtpTimeObj;

/*
 * Memory object
 */
typedef struct MemObj
{
    uint16_t    offset;
    uint32_t    value;
} MemObj;

/*
 * structure for device info interactions with kernel
 */
typedef struct DevIDInfo
{
    uint16_t    devid;      /* PCI Device ID */
    uint16_t    options;    /* PCI Subsystem Product ID */
} DevIdObj;

/*
 * structure for latitude / logitude interactions
 */
struct latlon_kernel
{
    uint32_t    minutes;
    uint16_t    degrees;
};

/*
 * structure for time interactions with kernel
 */
struct time_kernel
{
    uint32_t    decimal_seconds;
    uint16_t    days;
    uint8_t     minutes;
    uint8_t     hours;
    uint16_t    sync;
};

#endif  /* _defined_TSYNC_KTYPES_H */
