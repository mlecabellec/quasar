#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_ip_services.h"
#include "tsync_cs_services.h"

extern uint8_t IP_VALUE_RECIPE[];
extern uint8_t IP_SET_CMD_RECIPE[];
extern uint8_t IP_INT_VALUE_RECIPE[];
extern uint8_t IP_INT_SET_CMD_RECIPE[];
extern uint8_t ML_CLK_LOCAL_RECIPE[];
extern uint8_t IP_MSG_RECIPE[];
extern uint8_t IP_MSG_SET_CMD_RECIPE[];
extern uint8_t IP_LOCAL_SET_CMD_RECIPE[];
extern uint8_t IP_CFDATA_RECIPE[];
extern uint8_t IP_CFDATA_SET_CMD_RECIPE[];
extern uint8_t ML_TIME_SCALE_OBJ_RECIPE[];
extern uint8_t IP_TIME_SCALE_SET_CMD_RECIPE[];
extern uint8_t IP_MOD_SET_CMD_RECIPE[];

TSYNC_ERROR
TSYNC_IP_getSigCtrl(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    SIG_CTL *sig)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(sig);

        struct IP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_SIG_CTL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_VALUE_RECIPE,
            IP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IP_VALUE* outPayload =
            (IP_VALUE*)GetPayload(result);

        *sig = (SIG_CTL)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_setSigCtrl(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    SIG_CTL sig)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct IP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = sig;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_SIG_CTL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_getOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *nOffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nOffset);

        struct IP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IP_INT_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_VALUE_RECIPE,
            IP_INT_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IP_INT_VALUE* outPayload =
            (IP_INT_VALUE*)GetPayload(result);

        *nOffset = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_setOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int nOffset)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct IP_INT_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = nOffset;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_INT_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_OFFSET,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_INT_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_getLocal(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_LocalClockObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct IP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(ML_CLK_LOCAL_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_LOCAL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_VALUE_RECIPE,
            ML_CLK_LOCAL_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct ML_CLK_LOCAL* outPayload =
            (ML_CLK_LOCAL*)GetPayload(result);

        pObj->rule.ref = outPayload->ref;
        pObj->rule.in.month = outPayload->in.month;
        pObj->rule.in.wom = outPayload->in.wom;
        pObj->rule.in.dow = outPayload->in.dow;
        pObj->rule.in.hour = outPayload->in.hour;
        pObj->rule.out.month = outPayload->out.month;
        pObj->rule.out.wom = outPayload->out.wom;
        pObj->rule.out.dow = outPayload->out.dow;
        pObj->rule.out.hour = outPayload->out.hour;
        pObj->rule.offset = outPayload->offset;
        pObj->tz = outPayload->tz;

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_setLocal(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_LocalClockObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct IP_LOCAL_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.ref = pObj->rule.ref;
        inPayload.in.month = pObj->rule.in.month;
        inPayload.in.wom = pObj->rule.in.wom;
        inPayload.in.dow = pObj->rule.in.dow;
        inPayload.in.hour = pObj->rule.in.hour;
        inPayload.out.month = pObj->rule.out.month;
        inPayload.out.wom = pObj->rule.out.wom;
        inPayload.out.dow = pObj->rule.out.dow;
        inPayload.out.hour = pObj->rule.out.hour;
        inPayload.offset = pObj->rule.offset;
        inPayload.tz = pObj->tz;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_LOCAL_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_LOCAL,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_LOCAL_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_getFormat(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    IL_FMT *format)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(format);

        struct IP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_FORMAT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_VALUE_RECIPE,
            IP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IP_VALUE* outPayload =
            (IP_VALUE*)GetPayload(result);

        *format = (IL_FMT)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_setFormat(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    IL_FMT format)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct IP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = format;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_FORMAT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_getAmplitude(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int *amp)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(amp);

        struct IP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_AMPLITUDE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_VALUE_RECIPE,
            IP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IP_VALUE* outPayload =
            (IP_VALUE*)GetPayload(result);

        *amp = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_setAmplitude(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int amp)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct IP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = amp;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_AMPLITUDE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_getMod(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    IL_MOD *mod)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(mod);

        struct IP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_MOD,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_VALUE_RECIPE,
            IP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IP_VALUE* outPayload =
            (IP_VALUE*)GetPayload(result);

        *mod = (IL_MOD)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_setMod(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    IL_MOD mod)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct IP_MOD_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.mod  = mod;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_MOD_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_MOD,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_MOD_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}
TSYNC_ERROR
TSYNC_IP_getFreq(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    IL_FRQ *freq)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(freq);

        struct IP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_FREQ,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_VALUE_RECIPE,
            IP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IP_VALUE* outPayload =
            (IP_VALUE*)GetPayload(result);

        *freq = (IL_FRQ)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_setFreq(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    IL_FRQ freq)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct IP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = freq;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_FREQ,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_getCodedExpr(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    IL_CE *ce)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(ce);

        struct IP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_CODED_EXP,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_VALUE_RECIPE,
            IP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IP_VALUE* outPayload =
            (IP_VALUE*)GetPayload(result);

        *ce = (IL_CE)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_setCodedExpr(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    IL_CE ce)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct IP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = ce;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_CODED_EXP,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_getCtrlField(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    IL_CF *cf)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(cf);

        struct IP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_CTRL_FLD,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_VALUE_RECIPE,
            IP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IP_VALUE* outPayload =
            (IP_VALUE*)GetPayload(result);

        *cf = (IL_CF)outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_setCtrlField(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    IL_CF cf)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct IP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = cf;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_CTRL_FLD,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_getMessage(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_IRIGMessageObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_HANDLE(pObj);

        struct IP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IP_MSG_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_MESSAGE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_VALUE_RECIPE,
            IP_MSG_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IP_MSG* outPayload =
            (IP_MSG*)GetPayload(result);
        int i;
        for(i = 0; i < TSYNC_IP_SUBFRAME_NUM; i++)
        {
            pObj->subframes[i] = outPayload->subframes[i].value;
        }

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_setMessage(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_IRIGMessageObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_HANDLE(pObj);

        struct IP_MSG_SET_CMD inPayload;
        inPayload.inst = nInstance;
        int i;
        for(i = 0; i < TSYNC_IP_SUBFRAME_NUM; i++)
        {
            inPayload.subframes[i].value = pObj->subframes[i];
        }

        uint16_t ctl = 0x02;//set
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_MSG_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_MESSAGE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_MSG_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_getCfData(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_IRIGCfDataObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct IP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IP_CFDATA_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_CFDATA,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_VALUE_RECIPE,
            IP_CFDATA_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IP_CFDATA* outPayload =
            (IP_CFDATA*)GetPayload(result);

        int i;
        for(i = 0; i < TSYNC_IP_CFDATA_NUM; i++)
        {
            pObj->cfData[i] = outPayload->cfData[i].value;
        }

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_setCfData(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_IRIGCfDataObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_HANDLE(pObj);

        struct IP_CFDATA_SET_CMD inPayload;
        inPayload.inst = nInstance;
        int i;
        for(i = 0; i < TSYNC_IR_CFDATA_NUM; i++)
        {
            inPayload.cfData[i].value = pObj->cfData[i];
        }

        uint16_t ctl = 0x02;//set
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_CFDATA_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_CFDATA,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_CFDATA_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_getNumInst(
    TSYNC_BoardHandle hnd,
    unsigned int *nInstances)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nInstances);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_NUM_INST,
            ctl,
            pyldLen,
            NULL,
            NULL,
            IP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IP_VALUE* outPayload =
            (IP_VALUE*)GetPayload(result);

        *nInstances = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_getPhase(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int *phase)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(phase);

        struct IP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_PHASE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_VALUE_RECIPE,
            IP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IP_VALUE* outPayload =
            (IP_VALUE*)GetPayload(result);

        *phase = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_setPhase(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int phase)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct IP_SET_CMD inPayload;
        inPayload.inst = nInstance;
        inPayload.value = phase;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_PHASE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_getPhaseErr(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *phErr)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(phErr);

        struct IP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IP_INT_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_PHASE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_VALUE_RECIPE,
            IP_INT_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IP_INT_VALUE* outPayload =
            (IP_INT_VALUE*)GetPayload(result);

        *phErr = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_getTimeScale(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_TimeScaleObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    struct IP_VALUE inPayload;
    inPayload.value = nInstance;

    uint16_t ctl = 0x00;//get
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(IP_VALUE_RECIPE, &pos);

    pos = 0;
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(ML_TIME_SCALE_OBJ_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_IP,
        TSYNC_ID_IP_CA_TIME_SCALE,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        IP_VALUE_RECIPE,
        ML_TIME_SCALE_OBJ_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    struct ML_TIME_SCALE_OBJ* outPayload =
        (ML_TIME_SCALE_OBJ*)GetPayload(result);

    pObj->scale = outPayload->scale;

    return ( err );
}

TSYNC_ERROR TSYNC_IP_setTimeScale (
    TSYNC_BoardHandle   hnd,
    unsigned int nInstance,
    TSYNC_TimeScaleObj *pObj)
{
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    struct IP_TIME_SCALE_SET_CMD inPayload;
    inPayload.inst = nInstance;
    inPayload.scale.scale = pObj->scale;

    uint16_t ctl = 0x02;//set
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(IP_TIME_SCALE_SET_CMD_RECIPE, &pos);

    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(0));

    TSYNC_ERROR err = BaseTransaction(
        TSYNC_ID_IP,
        TSYNC_ID_IP_CA_TIME_SCALE,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        IP_TIME_SCALE_SET_CMD_RECIPE,
        NULL,
        result,
        handle);

    return ( err );
}

TSYNC_ERROR
TSYNC_IP_getType(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    IL_MOD *type)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(type);

        struct IP_VALUE inPayload;
        inPayload.value = nInstance;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IP_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IP_VALUE_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IP,
            TSYNC_ID_IP_CA_TYPE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IP_VALUE_RECIPE,
            IP_VALUE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IP_VALUE* outPayload =
            (IP_VALUE*)GetPayload(result);

        *type = (IL_MOD)outPayload->value;

    return ( err );
}
