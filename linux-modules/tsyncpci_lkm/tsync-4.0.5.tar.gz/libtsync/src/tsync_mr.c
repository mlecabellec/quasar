#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_mr_services.h"
#include "tsync_cs_services.h"
#include "tsync_misc_services.h"

extern uint8_t MR_VALUE_RECIPE[];
extern uint8_t MR_SVALUE_RECIPE[];
extern uint8_t EL_VALIDITY_RECIPE[];
extern uint8_t MR_VALIDITY_SET_CMD_RECIPE[];
extern uint8_t MR_UTC_OFF_SET_CMD_RECIPE[];
extern uint8_t MR_USE_CS_OFF_SET_CMD_RECIPE[];
extern uint8_t EL_REF_ID_RECIPE[];

extern uint8_t ML_DOYTIME_GET_RESP_RECIPE[];
extern uintptr_t ML_TIME_UNION_GET_RESP_RECIPE[];


TSYNC_ERROR
TSYNC_MR_setValidity(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int bTimeValid,
    int bPpsValid)
{
    struct MR_VALIDITY_SET_CMD inPayload;
    uint16_t ctl;
    uint8_t  pos;
    uint32_t pyldLen;

    TSYNC_TransResult result;

    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);

    inPayload.nInstance = nInstance;
    inPayload.timeValid = bTimeValid;
    inPayload.ppsValid  = bPpsValid;

    ctl = 0x02;
    pos = 0;
    pyldLen = sizeofRecipe(MR_VALIDITY_SET_CMD_RECIPE, &pos);

    result = (TSYNC_TransResult) TSYNC_ALLOCA(SizeOfResult(0));

    err = BaseTransaction(
        TSYNC_ID_MR,
        TSYNC_ID_MR_CA_VALIDITY,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        MR_VALIDITY_SET_CMD_RECIPE,
        NULL,
        result,
        handle);

    CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_MR_getValidity(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *bTimeValid,
    int *bPpsValid)
{
    struct MR_VALUE inPayload;
    struct EL_VALIDITY* outPayload;
    uint16_t ctl;
    uint8_t pos;
    uint32_t pyldLen;

    TSYNC_TransResult result;

    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(bTimeValid);
    CHECK_NOT_NULL(bPpsValid);

    inPayload.value = nInstance;

    ctl = 0x00; /* get */
    pos = 0;
    pyldLen = sizeofRecipe(MR_VALUE_RECIPE, &pos);

    pos = 0;
    result = (TSYNC_TransResult) TSYNC_ALLOCA(
             SizeOfResult(sizeofRecipe(EL_VALIDITY_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_MR,
        TSYNC_ID_MR_CA_VALIDITY,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        MR_VALUE_RECIPE,
        EL_VALIDITY_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    outPayload = (EL_VALIDITY*) GetPayload(result);

    *bTimeValid = outPayload->timeValid;
    *bPpsValid = outPayload->ppsValid;

    return ( err );
}

TSYNC_ERROR
TSYNC_MR_getTime(
    TSYNC_BoardHandle  hnd,
    unsigned int nInstance,
    TSYNC_TimeObj     *Timep )
{
    struct MR_VALUE inPayload;
    struct ML_DOYTIME* outPayload;
    uint16_t ctl;
    uint8_t  pos;
    uint32_t pyldLen;

    TSYNC_TransResult result;

    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(Timep);

    inPayload.value = nInstance;

    ctl = 0x00; /* get */
    pos = 0;
    pyldLen = sizeofRecipe(MR_VALUE_RECIPE, &pos);

    pos = 0;
    result = (TSYNC_TransResult) TSYNC_ALLOCA(
             SizeOfResult(sizeofUnion(ML_TIME_UNION_GET_RESP_RECIPE)));

    err = BaseTransaction(
        TSYNC_ID_MR,
        TSYNC_ID_MR_CA_TIME,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        MR_VALUE_RECIPE,
        ML_DOYTIME_GET_RESP_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err);

    outPayload = (ML_DOYTIME*) GetPayload(result);

    Timep->years = outPayload->year;
    Timep->doy = outPayload->doy;
    Timep->hours = outPayload->hour;
    Timep->minutes = outPayload->minute;
    Timep->seconds = outPayload->second;
    Timep->ns = outPayload->ns;

    return ( err );
}

TSYNC_ERROR
TSYNC_MR_getRefId(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    TSYNC_RefIdObj *pObj)
{
    struct MR_VALUE inPayload;
    struct EL_REF_ID* outPayload;
    uint16_t ctl;
    uint8_t  pos;
    uint32_t pyldLen;

    TSYNC_TransResult result;

    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    inPayload.value = nInstance;

    ctl = 0x00;
    pos = 0;
    pyldLen = sizeofRecipe(MR_VALUE_RECIPE, &pos);

    pos = 0;
    result = (TSYNC_TransResult) TSYNC_ALLOCA(
             SizeOfResult(sizeofRecipe(EL_REF_ID_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_MR,
        TSYNC_ID_MR_CA_REF_ID,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        MR_VALUE_RECIPE,
        EL_REF_ID_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    outPayload = (EL_REF_ID*) GetPayload(result);

    memset(pObj->refid, '\0', sizeof(pObj->refid));
    memcpy(pObj->refid, outPayload->ref, sizeof(outPayload->ref));

    return ( err );
}

TSYNC_ERROR
TSYNC_MR_getUTCOffset(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int *utcOff)
{
    uint16_t ctl;
    uint8_t  pos;
    uint32_t pyldLen;
    struct MR_VALUE inPayload;
    struct MR_SVALUE* outPayload;
    TSYNC_TransResult result;

    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(utcOff);

    inPayload.value = nInstance;

    ctl = 0x00;
    pos = 0;
    pyldLen = sizeofRecipe(MR_SVALUE_RECIPE, &pos);
    pos = 0;

    result = (TSYNC_TransResult) TSYNC_ALLOCA(
              SizeOfResult(sizeofRecipe(MR_SVALUE_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_MR,
        TSYNC_ID_MR_CA_UTC_OFF,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        MR_VALUE_RECIPE,
        MR_SVALUE_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    outPayload = (MR_SVALUE*) GetPayload(result);

    *utcOff = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_MR_setUTCOffset (
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int utcOff)
{
    struct MR_UTC_OFF_SET_CMD inPayload;
    uint16_t ctl;
    uint8_t  pos;
    uint32_t pyldLen;

    TSYNC_TransResult result;

    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);

    inPayload.nInstance = nInstance;
    inPayload.utcOff = utcOff;

    ctl = 0x02;
    pos = 0;
    pyldLen = sizeofRecipe(MR_UTC_OFF_SET_CMD_RECIPE, &pos);

    result = (TSYNC_TransResult) TSYNC_ALLOCA(SizeOfResult(0));

    err = BaseTransaction(
        TSYNC_ID_MR,
        TSYNC_ID_MR_CA_UTC_OFF,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        MR_UTC_OFF_SET_CMD_RECIPE,
        NULL,
        result,
        handle);

    CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_MR_useCSOff(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    unsigned int useCsOff)
{
    struct MR_USE_CS_OFF_SET_CMD inPayload;
    uint16_t ctl;
    uint8_t  pos;
    uint32_t pyldLen;

    TSYNC_TransResult result;

    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);

    inPayload.nInstance = nInstance;
    inPayload.useCSOff = useCsOff;

    ctl = 0x02;
    pos = 0;
    pyldLen = sizeofRecipe(MR_USE_CS_OFF_SET_CMD_RECIPE, &pos);

    result = (TSYNC_TransResult) TSYNC_ALLOCA(SizeOfResult(0));

    err = BaseTransaction(
        TSYNC_ID_MR,
        TSYNC_ID_MR_CA_USE_CS_OFF,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        MR_USE_CS_OFF_SET_CMD_RECIPE,
        NULL,
        result,
        handle);

    CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_MR_getUseCSOff(
    TSYNC_BoardHandle hnd,
    unsigned int nInstance,
    int          *CSOffUsed)
{
    struct MR_VALUE inPayload;
    struct MR_VALUE* outPayload;
    uint16_t ctl;
    uint8_t pos;
    uint32_t pyldLen;

    TSYNC_TransResult result;

    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(CSOffUsed);

    inPayload.value = nInstance;

    ctl = 0x00; /* get */
    pos = 0;
    pyldLen = sizeofRecipe(MR_VALUE_RECIPE, &pos);

    pos = 0;
    result = (TSYNC_TransResult) TSYNC_ALLOCA(
             SizeOfResult(sizeofRecipe(MR_VALUE_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_MR,
        TSYNC_ID_MR_CA_USE_CS_OFF,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        MR_VALUE_RECIPE,
        MR_VALUE_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    outPayload = (MR_VALUE*) GetPayload(result);

    *CSOffUsed = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_MR_getNumInst(
    TSYNC_BoardHandle hnd,
    unsigned int *nInstances)
{
    struct MR_VALUE* outPayload;
    uint16_t ctl;
    uint8_t pos;
    uint32_t pyldLen;

    TSYNC_TransResult result;

    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(nInstances);

    ctl = 0x00;
    pos = 0;
    pyldLen = 0;

    result = (TSYNC_TransResult)TSYNC_ALLOCA(
             SizeOfResult(sizeofRecipe(MR_VALUE_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_MR,
        TSYNC_ID_MR_CA_NUM_INST,
        ctl,
        pyldLen,
        NULL,
        NULL,
        MR_VALUE_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    outPayload = (MR_VALUE*)GetPayload(result);

    *nInstances = outPayload->value;

    return ( err );
}
