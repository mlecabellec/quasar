#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_in_services.h"

extern uint8_t IN_VALUE_RECIPE[];
extern uint8_t IN_RESULT_RECIPE[];
extern uint8_t IN_STATUS_RECIPE[];

TSYNC_ERROR
TSYNC_IN_getStatus(
    TSYNC_BoardHandle hnd,
    unsigned int pageNum,
    TSYNC_InitStatusResult *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct IN_VALUE inPayload;
        inPayload.value = pageNum;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(IN_VALUE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(IN_STATUS_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_IN,
            TSYNC_ID_IN_CA_STATUS,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            IN_VALUE_RECIPE,
            IN_STATUS_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct IN_STATUS* outPayload =
            (IN_STATUS*)GetPayload(result);

        pObj->pageNum = outPayload->page;
        pObj->more = outPayload->more;

        int i;
        for(i = 0; i < TSYNC_INIT_RESULT_NUM; i++)
        {
            pObj->results[i].result = (TSYNC_ERROR)(outPayload->results[i].result + EC_BOARD_OPT_OFFSET);

            memset(pObj->results[i].module, '\0', sizeof(pObj->results[i].module));
            memcpy(pObj->results[i].module, outPayload->results[i].module, sizeof(outPayload->results[i].module));
        }

    return ( err );
}
