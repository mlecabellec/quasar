
/***************************************************************************
**  Module:     tsync_ha_services_recipes.c
**
**  Date:       07/16/08
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/16/2008 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_ha_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(CI_CAP)
RECIPE(CI_CAP_PAGE)
RECIPE(CI_CAP_GET_CMD)

#include "tsync_recipe_undef.h"
