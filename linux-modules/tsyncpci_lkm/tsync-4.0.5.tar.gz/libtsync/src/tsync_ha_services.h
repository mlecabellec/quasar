
#ifndef _defined_TSYNC_HA_SERVICES_H
#define _defined_TSYNC_HA_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_ha_services.h
**
**  Date:       07/16/08
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/16/2008 Creation
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define HA_CMD_GET_CAPS                 0x1
#define HA_CMD_GET_CAPS_IID             0x1

typedef uint32_t CI_ITEM;

/******************************************************
**     Define Enumerations
******************************************************/

/*typedef enum
{
CI_ACC_NONE = 0,
CI_ACC_GET = 1,
CI_ACC_SET = 2,
CI_ACC_BOTH = 3
} CI_ACCESS;*/

/******************************************************
**     Define Structures
******************************************************/

#define CI_CAP_FIELDS                    \
    TSYNC_X( CI_ITEM,       item)            \
    TSYNC_X( CI_ACCESS,     access)

#define CI_CAP_PAGE_FIELDS                    \
    TSYNC_X( uint32_t,       pgno)            \
    TSYNC_X( uint32_t,     more)                \
    TSYNC_X_ARRAY( CI_CAP,     caps, TSYNC_CAPABILITIES_PER_PAGE)

#define CI_CAP_GET_CMD_FIELDS                    \
    TSYNC_X( uint32_t,       pgno)


#include "tsync_struct_define.h"

GEN_STRUCT(CI_CAP)
GEN_STRUCT(CI_CAP_PAGE)
GEN_STRUCT(CI_CAP_GET_CMD)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_HA_SERVICES_H */
