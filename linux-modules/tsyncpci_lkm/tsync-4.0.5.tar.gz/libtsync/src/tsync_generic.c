#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "ddtsync.h"
#include "tsync_macros.h"
#include "tsync_driver_interface.h"

TSYNC_ERROR tsync_getset(TSYNC_IOCTL_ID ioctlID,
                         TSYNC_BoardHandle handle,
                         DEST_ID dest,
                         ITEM_ID iid,
                         void* inPayload,
                         uint32_t inLength,
                         void* outPayload,
                         uint32_t maxOutLength,
                         uint32_t* actualOutLength) {
    TSYNC_BoardObj *hnd = (TSYNC_BoardObj*)handle;
    struct ioctl_trans_di* it;
    unsigned int itAllocationLength;

    CHECK_HANDLE(hnd);
    if (inLength > 0) {
        CHECK_NOT_NULL(inPayload);
    }
    if (maxOutLength > 0) {
        CHECK_NOT_NULL(outPayload);
    }
    CHECK_NOT_NULL(actualOutLength);

    itAllocationLength =
        (sizeof(ioctl_trans_di) - DI_PAYLOADS_STARTER_LENGTH) +
        inLength + maxOutLength;

    it = (ioctl_trans_di*)TSYNC_ALLOCA(itAllocationLength);
    if (it == NULL) {
        return TSYNC_OUT_OF_MEM;
    }
    memset(it, 0, itAllocationLength);

    it->dest = dest;
    if (dest == DEST_ID_FW) {
        it->iid = iid.fid;
    }
    else {
        it->iid = iid.hid;
    }

    it->inPayloadOffset = 0;
    if (inLength > 0) {
        memcpy(it->payloads, inPayload, inLength);
    }

    it->inLength = inLength;

    it->outPayloadOffset = inLength;
    it->maxOutLength = maxOutLength;

    /*
     * make the ioctl call
     */
    TSYNC_ERROR rc =
        TSYNC_ioctl( hnd,
                     ioctlID,
                     it,
                     itAllocationLength);

    if (rc != TSYNC_SUCCESS) {
        return rc;
    }

    *actualOutLength = it->actualOutLength;
    memcpy(outPayload, &it->payloads[it->outPayloadOffset],
           it->actualOutLength);

    rc = it->status;
    return rc;
}

TSYNC_ERROR
TSYNC_get(
    TSYNC_BoardHandle handle,
    DEST_ID dest,
    ITEM_ID iid,
    void* inPayload,
    uint32_t inLength,
    void* outPayload,
    uint32_t maxOutLength,
    uint32_t* actualOutLength)
{
    return tsync_getset(TSYNC_GET, handle, dest, iid, inPayload,
                        inLength,
                        outPayload, maxOutLength,
                        actualOutLength);
}

TSYNC_ERROR
TSYNC_set(
    TSYNC_BoardHandle handle,
    DEST_ID dest,
    ITEM_ID iid,
    void* inPayload,
    uint32_t inLength,
    void* outPayload,
    uint32_t maxOutLength,
    uint32_t* actualOutLength)
{
    return tsync_getset(TSYNC_SET, handle, dest, iid, inPayload,
                        inLength,
                        outPayload, maxOutLength,
                        actualOutLength);
}

TSYNC_ERROR
TSYNC_waitFor(
    TSYNC_BoardHandle handle,
    INT_TYPE intType,
    uint32_t index)
{
    TSYNC_BoardObj *hnd = (TSYNC_BoardObj*)handle;

    CHECK_HANDLE(hnd);

    struct ioctl_trans_di_wait it;
    it.intType = intType;
    it.index = index;

    /*
     * make the ioctl call
     */
    TSYNC_ERROR rc =
        TSYNC_ioctl( hnd,
                     TSYNC_WAIT,
                     &it,
                     sizeof(it));

	it.status = rc;
	return it.status;
}

TSYNC_ERROR
TSYNC_waitForTo(
	TSYNC_BoardHandle handle,
	INT_TYPE intType,
	uint32_t index,
	int32_t  timeout)
{
	TSYNC_BoardObj *hnd = (TSYNC_BoardObj*)handle;

	CHECK_HANDLE(hnd);

	struct ioctl_trans_di_wait_to it;
	it.intType = intType;
	it.index = index;
	it.to = timeout;

	/*
	* make the ioctl call
	*/
	TSYNC_ERROR rc =
		TSYNC_ioctl(hnd,
			TSYNC_WAIT_TO,
			&it,
			sizeof(it));

	it.status = rc;
	return it.status;
}
