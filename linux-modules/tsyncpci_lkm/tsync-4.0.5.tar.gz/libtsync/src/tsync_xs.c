#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_xs_services.h"

extern uint8_t METER_HANDLE_RECIPE[];
extern uint8_t XS_WIN_SIZE_GET_CMD_RECIPE[];
extern uint8_t XS_WIN_SIZE_GET_RESP_RECIPE[];
extern uint8_t XS_WIN_SIZE_SET_CMD_RECIPE[];
extern uint8_t XS_METER_DATA_RECIPE[];
extern uint8_t XS_COMMAND_RECIPE[];

TSYNC_ERROR
TSYNC_XS_register(
    TSYNC_BoardHandle  hnd,
    TSYNC_MeterHandle *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(METER_HANDLE_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_XS,
            TSYNC_ID_XS_CA_REGISTER,
            ctl,
            pyldLen,
            NULL,
            NULL,
            METER_HANDLE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct METER_HANDLE* outPayload =
            (METER_HANDLE*)GetPayload(result);
        
        pObj->hnd = outPayload->hnd;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_XS_unregister(
    TSYNC_BoardHandle  hnd,
    TSYNC_MeterHandle *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct METER_HANDLE inPayload;
        inPayload.hnd = pObj->hnd;
        
        uint16_t ctl = 0x02;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(METER_HANDLE_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_XS,
            TSYNC_ID_XS_CA_UNREGISTER,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            METER_HANDLE_RECIPE,
            NULL,
            result,
            handle);

    return ( err );
}

TSYNC_ERROR
TSYNC_XS_getWindowSize(
    TSYNC_BoardHandle      hnd,
    TSYNC_MeterWinSizeObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct XS_WIN_SIZE_GET_CMD inPayload;
        inPayload.hnd = pObj->hnd;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(XS_WIN_SIZE_GET_CMD_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(XS_WIN_SIZE_GET_RESP_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_XS,
            TSYNC_ID_XS_CA_WINDOW_SIZE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            XS_WIN_SIZE_GET_CMD_RECIPE,
            XS_WIN_SIZE_GET_RESP_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct XS_WIN_SIZE_GET_RESP* outPayload =
            (XS_WIN_SIZE_GET_RESP*)GetPayload(result);

        pObj->size = outPayload->size;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_XS_setWindowSize(
    TSYNC_BoardHandle      hnd,
    TSYNC_MeterWinSizeObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct XS_WIN_SIZE_SET_CMD inPayload;
        inPayload.hnd = pObj->hnd;
        inPayload.size = pObj->size;
        
        uint16_t ctl = 0x02;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(XS_WIN_SIZE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_XS,
            TSYNC_ID_XS_CA_WINDOW_SIZE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            XS_WIN_SIZE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

    return ( err );
}

TSYNC_ERROR
TSYNC_XS_getMeterData(
    TSYNC_BoardHandle   hnd,
    TSYNC_MeterDataObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct METER_HANDLE inPayload;
        inPayload.hnd = pObj->hnd;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(METER_HANDLE_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(XS_METER_DATA_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_XS,
            TSYNC_ID_XS_CA_METER_DATA,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            METER_HANDLE_RECIPE,
            XS_METER_DATA_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct XS_METER_DATA* outPayload =
            (XS_METER_DATA*)GetPayload(result);
        
        pObj->state = outPayload->state;
        pObj->size = outPayload->size;
        pObj->elapsed = outPayload->elapsed;
        pObj->frAccum = outPayload->frAccum;
        pObj->frPrev = outPayload->frPrev;
        pObj->phStart = outPayload->phStart;
        pObj->phAccum = outPayload->phAccum;
        pObj->phPrev = outPayload->phPrev;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_XS_meterCmd(
    TSYNC_BoardHandle      hnd,
    TSYNC_MeterCommandObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct XS_COMMAND inPayload;
        inPayload.hnd = pObj->hnd;
        inPayload.command = pObj->command;
        
        uint16_t ctl = 0x02;//set
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(XS_COMMAND_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
        
        err = BaseTransaction(
            TSYNC_ID_XS,
            TSYNC_ID_XS_CA_METER_CMD,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            XS_COMMAND_RECIPE,
            NULL,
            result,
            handle);

    return ( err );
}

