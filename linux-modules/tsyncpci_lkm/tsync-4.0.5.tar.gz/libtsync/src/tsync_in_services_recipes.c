
/***************************************************************************
**  Module:     tsync_in_services_recipes.c
**
**  Date:       07/28/08
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/28/2008 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_in_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(IN_VALUE)
RECIPE(IN_RESULT)
RECIPE(IN_STATUS)

#include "tsync_recipe_undef.h"
