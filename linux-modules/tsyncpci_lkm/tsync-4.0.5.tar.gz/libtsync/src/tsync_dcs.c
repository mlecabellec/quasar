#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_dcs_services.h"
#include "tsync_misc_services.h"

extern uint8_t DCS_VALUE_RECIPE[];
extern uint8_t DCS_INT_VALUE_RECIPE[];
extern uint8_t DCS_OC_HDR_RECIPE[];
extern uint8_t DCS_OC_SFI_RECIPE[];
extern uint8_t DCS_OC_LFI_RECIPE[];
extern uint8_t DCS_OC_FI_RECIPE[];
extern uint8_t DCS_FILE_OPTION_RECIPE[];

TSYNC_ERROR
TSYNC_DCS_getCardInfo(
    TSYNC_BoardHandle hnd,
    unsigned int nSlot,
    TSYNC_OptCardHdrObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    struct DCS_VALUE inPayload;
    inPayload.value = nSlot;

    uint16_t ctl = 0x00;//get
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(DCS_VALUE_RECIPE, &pos);

    pos = 0;
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(DCS_OC_HDR_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_DCS,
        TSYNC_ID_DCS_CA_OC_INFO,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        DCS_VALUE_RECIPE,
        DCS_OC_HDR_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    struct DCS_OC_HDR* outPayload =
        (DCS_OC_HDR*)GetPayload(result);

    pObj->id = outPayload->id;
    pObj->ver = outPayload->ver;
    pObj->cish.pldId = outPayload->cish.pldId;
    pObj->cish.pldVer = outPayload->cish.pldVer;
    pObj->cish.rsv1 = 0;
    pObj->cish.rsv2 = 0;
    pObj->cish.num = outPayload->cish.numFeats;

    return ( err );
}

TSYNC_ERROR
TSYNC_DCS_getFeatureByIdx(
    TSYNC_BoardHandle hnd,
    TSYNC_OptCardSlotIdxObj *pInObj,
    TSYNC_OptCardFeatInstObj *pOutObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pInObj);
    CHECK_NOT_NULL(pOutObj);

    struct DCS_OC_SFI inPayload;
    inPayload.slot = pInObj->slot;
    inPayload.idx = pInObj->idx;

    uint16_t ctl = 0x00;//get
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(DCS_OC_SFI_RECIPE, &pos);

    pos = 0;
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(DCS_OC_FI_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_DCS,
        TSYNC_ID_DCS_CA_OC_FEAT_IDX,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        DCS_OC_SFI_RECIPE,
        DCS_OC_FI_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    struct DCS_OC_FI* outPayload =
        (DCS_OC_FI*)GetPayload(result);

    pOutObj->featId = outPayload->id;
    pOutObj->inst = outPayload->inst;
#ifdef NIOS
    pOutObj->version = outPayload->version;
#endif

    return ( err );
}

TSYNC_ERROR
TSYNC_DCS_getInstance(
    TSYNC_BoardHandle hnd,
    TSYNC_OptCardSlotFeatInstObj *pObj,
    int *nInstance)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);
    CHECK_NOT_NULL(nInstance);

    struct DCS_OC_LFI inPayload;
    inPayload.slot = pObj->slot;
    inPayload.id = pObj->featId;
    inPayload.inst = pObj->inst;

    uint16_t ctl = 0x00;//get
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(DCS_OC_LFI_RECIPE, &pos);

    pos = 0;
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(DCS_INT_VALUE_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_DCS,
        TSYNC_ID_DCS_CA_INSTANCE,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        DCS_OC_LFI_RECIPE,
        DCS_INT_VALUE_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    struct DCS_INT_VALUE* outPayload =
        (DCS_INT_VALUE*)GetPayload(result);

    *nInstance = outPayload->value;

    return ( err );
}

TSYNC_ERROR
TSYNC_DCS_getSlot(
    TSYNC_BoardHandle hnd,
    TSYNC_OptCardFeatInstObj *pObj,
    int *nSlot)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);
    CHECK_NOT_NULL(nSlot);

    struct DCS_OC_FI inPayload;
    inPayload.id = pObj->featId;
    inPayload.inst = pObj->inst;

    uint16_t ctl = 0x00;//get
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(DCS_OC_FI_RECIPE, &pos);

    pos = 0;
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(DCS_INT_VALUE_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_DCS,
        TSYNC_ID_DCS_CA_SLOT,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        DCS_OC_FI_RECIPE,
        DCS_INT_VALUE_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    struct DCS_INT_VALUE* outPayload =
        (DCS_INT_VALUE*)GetPayload(result);

    *nSlot = outPayload->value;

    return ( err );
}

/*
    * Function:    TSYNC_DCS_getOptions()
    * Description: Gets access of available licensed options
    *
    * Parameters:
    *   IN:  hnd    - Board handle
    *        *pObj  - Id and system instance of feature
    *   OUT: *fileOption - List od license type available
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    TSYNC_ERROR TSYNC_DCS_getOptions(
        TSYNC_BoardHandle         hnd,
        TSYNC_FileOptionObj      *fileOption)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
	int i;
	
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(fileOption);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen =  0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(DCS_FILE_OPTION_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_DCS,
            TSYNC_ID_DCS_CA_GET_OPTIONS,
            ctl,
            pyldLen,
            NULL,
            NULL,
            DCS_FILE_OPTION_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct DCS_FILE_OPTION* outPayload =
            (DCS_FILE_OPTION*)GetPayload(result);

        memset(fileOption->type, '\0', sizeof(fileOption->type));

		
		if (outPayload->length > DCS_TYPE_LICENSE_MAX)
			fileOption->length = DCS_TYPE_LICENSE_MAX;
		else fileOption->length = outPayload->length;
        
		for (i=0; i<DCS_TYPE_LICENSE_MAX; i++)
			fileOption->type[i] = outPayload->type[i];

    return ( err );

}
		
/*
    * Function:    TSYNC_DCS_checkOption()
    * Description: Gets access of the availability of a specified 
	*              licensed options
    *
    * Parameters:
    *   IN:  hnd    - Board handle
    *        *pObj  - Id and system instance of feature
             licenseType - Type of license LCS_MULTIGNSS or LCS_SKYLIGHT 
    *   OUT: *licenseStatus - License available or not
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    TSYNC_ERROR TSYNC_DCS_checkOption(
        TSYNC_BoardHandle         hnd,
       	int                      licenseType,
        int                      *licenseStatus)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(licenseStatus);

    struct DCS_VALUE inPayload;
    inPayload.value = licenseType;

    uint16_t ctl = 0x00;//get
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(DCS_VALUE_RECIPE, &pos);

    pos = 0;
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(DCS_VALUE_RECIPE, &pos)));

    err = BaseTransaction(
        TSYNC_ID_DCS,
        TSYNC_ID_DCS_CA_CHECK_OPTION,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        DCS_VALUE_RECIPE,
        DCS_VALUE_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)

    struct DCS_VALUE* outPayload =
        (DCS_VALUE*)GetPayload(result);

    *licenseStatus = outPayload->value;
   
    return ( err );
}

/*
    * Function:    TSYNC_DCS_deleteOption()
    * Description: Delete specified option
    *
    * Parameters:
    *   IN:  hnd    - Board handle
    *        *pObj  - Id and system instance of feature
             licenseType - Type of license LCS_MULTIGNSS or LCS_SKYLIGHT 
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    TSYNC_ERROR TSYNC_DCS_deleteOption(
        TSYNC_BoardHandle         hnd,
       	int                      licenseType)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);

    struct DCS_VALUE inPayload;
    inPayload.value = licenseType;

    uint16_t ctl = 0x00;//get
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(DCS_VALUE_RECIPE, &pos);

    pos = 0;
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(0));

    err = BaseTransaction(
        TSYNC_ID_DCS,
        TSYNC_ID_DCS_CA_DELETE_OPTION,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        DCS_VALUE_RECIPE,
        NULL,
        result,
        handle);

    CHECK_SUCCESS(err)

    return ( err );
}
