#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_ha_services.h"

extern uint8_t CI_CAP_GET_CMD_RECIPE[];

extern uint8_t CI_CAP_PAGE_RECIPE[];


TSYNC_ERROR
TSYNC_HA_getCaps(
    TSYNC_BoardHandle hnd,
    unsigned int pageNum,
    TSYNC_CapabilityPageObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct CI_CAP_GET_CMD inPayload;
        inPayload.pgno = pageNum;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(CI_CAP_GET_CMD_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(CI_CAP_PAGE_RECIPE, &pos)));

        err = BaseTransaction(
            HA_CMD_GET_CAPS,
            HA_CMD_GET_CAPS_IID,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            CI_CAP_GET_CMD_RECIPE,
            CI_CAP_PAGE_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct CI_CAP_PAGE* outPayload =
            (CI_CAP_PAGE*)GetPayload(result);

        pObj->pageNum = outPayload->pgno;
        pObj->more = outPayload->more;

        int i;
        for(i = 0; i < TSYNC_CAPABILITIES_PER_PAGE; i++)
        {
            pObj->caps[i].cai    = ((outPayload->caps[i].item) >> 8) & 0xFF;
            pObj->caps[i].iid    = ((outPayload->caps[i].item) >> 0) & 0xFF;
            pObj->caps[i].access = outPayload->caps[i].access;
        }

    return ( err );
}
