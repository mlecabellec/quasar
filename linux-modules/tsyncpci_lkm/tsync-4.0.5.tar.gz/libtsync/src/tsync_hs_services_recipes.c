
/***************************************************************************
**  Module:     tsync_hs_services_recipes.c
**
**  Date:       09/10/09
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2020 Orolia  All rights reserved.
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_hs_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(HS_VALUE)
RECIPE(HS_LCL_STATUS)
RECIPE(HS_LCL_CTL)
RECIPE(HS_STATUS)
RECIPE(HS_CTL_SET)

#include "tsync_recipe_undef.h"
