#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_ec_services.h"

extern uint8_t LED_GET_CMD_RECIPE[];
extern uint8_t LED_MODE_GET_RESP_RECIPE[];
extern uint8_t LED_MODE_SET_CMD_RECIPE[];
extern uint8_t LED_STATE_GET_RESP_RECIPE[];
extern uint8_t LED_STATE_SET_CMD_RECIPE[];
extern uint8_t LED_BLACKOUT_GET_RESP_RECIPE[];
extern uint8_t LED_BLACKOUT_SET_CMD_RECIPE[];

TSYNC_ERROR
TSYNC_EC_getMode(
    TSYNC_BoardHandle hnd,
    LE_INDEX index,
    EC_MODE *mode)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(mode);

        struct LED_GET_CMD inPayload;
        inPayload.index = index;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(LED_GET_CMD_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(LED_MODE_GET_RESP_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_EC,
            TSYNC_ID_EC_CA_MODE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            LED_GET_CMD_RECIPE,
            LED_MODE_GET_RESP_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct LED_MODE_GET_RESP* outPayload =
            (LED_MODE_GET_RESP*)GetPayload(result);

        *mode = outPayload->mode;

    return ( err );
}

TSYNC_ERROR
TSYNC_EC_setMode(
    TSYNC_BoardHandle hnd,
    LE_INDEX index,
    EC_MODE mode)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct LED_MODE_SET_CMD inPayload;
        inPayload.index = index;
        inPayload.mode = mode;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(LED_MODE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_EC,
            TSYNC_ID_EC_CA_MODE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            LED_MODE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_EC_getState(
    TSYNC_BoardHandle hnd,
    LE_INDEX index,
    EC_STATE *state)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(state);

        struct LED_GET_CMD inPayload;
        inPayload.index = index;

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(LED_GET_CMD_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(LED_STATE_GET_RESP_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_EC,
            TSYNC_ID_EC_CA_STATE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            LED_GET_CMD_RECIPE,
            LED_STATE_GET_RESP_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct LED_STATE_GET_RESP* outPayload =
            (LED_STATE_GET_RESP*)GetPayload(result);

        *state = outPayload->state;

    return ( err );
}

TSYNC_ERROR
TSYNC_EC_setState(
    TSYNC_BoardHandle hnd,
    LE_INDEX index,
    EC_STATE state)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct LED_STATE_SET_CMD inPayload;
        inPayload.index = index;
        inPayload.state = state;

        uint16_t ctl = 0x02;
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(LED_STATE_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_EC,
            TSYNC_ID_EC_CA_STATE,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            LED_STATE_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err)

    return ( err );
}

TSYNC_ERROR
TSYNC_EC_getBlackoutMode(
    TSYNC_BoardHandle  hnd,
    EC_BLACKOUT_MODE  *mode)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(mode);

        struct LED_GET_CMD inPayload;

        uint16_t ctl = 0x00; // get.
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(LED_GET_CMD_RECIPE, &pos);

        pos = 0;
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(LED_BLACKOUT_GET_RESP_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_EC,
            TSYNC_ID_EC_CA_BLACKOUT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            LED_GET_CMD_RECIPE,
            LED_BLACKOUT_GET_RESP_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err);

        struct LED_BLACKOUT_GET_RESP* outPayload =
            (LED_BLACKOUT_GET_RESP*)GetPayload(result);

        *mode = (EC_BLACKOUT_MODE)outPayload->mode;

    return ( err );
}

TSYNC_ERROR
TSYNC_EC_setBlackoutMode(
    TSYNC_BoardHandle hnd,
    EC_BLACKOUT_MODE  mode)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct LED_BLACKOUT_SET_CMD inPayload;
        inPayload.mode = mode;

        uint16_t ctl = 0x02; // set.
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(LED_BLACKOUT_SET_CMD_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));

        err = BaseTransaction(
            TSYNC_ID_EC,
            TSYNC_ID_EC_CA_BLACKOUT,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            LED_BLACKOUT_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

        CHECK_SUCCESS(err);

    return ( err );
}

