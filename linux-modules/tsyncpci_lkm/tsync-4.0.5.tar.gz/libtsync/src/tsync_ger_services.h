
#ifndef _defined_TSYNC_GER_SERVICES_H
#define _defined_TSYNC_GER_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_ger_services.h
**
**  Date:       12/15/2016
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2016 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              12/15/2016 Creation
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_GER                      0x48
#define TSYNC_ID_GER_CA_NUM_INST          0x00
#define TSYNC_ID_GER_CA_TYPE              0x01
#define TSYNC_ID_GER_CA_VALIDITY          0x02
#define TSYNC_ID_GER_CA_CUSTOM_MSG        0x03
#define TSYNC_ID_GER_CA_OFFSET            0x04
#define TSYNC_ID_GER_CA_TIME_SCALE        0x05
#define TSYNC_ID_GER_CA_REF_ID            0x06


/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define GER_VALUE_FIELDS                        \
    TSYNC_X( uint32_t,         value)

#define GER_OFFSET_SET_CMD_FIELDS                        \
    TSYNC_X( uint32_t,         nInstance)                        \
    TSYNC_X( uint32_t,         nOffset)

#define GER_CUSTOM_MSG_FIELDS                    \
    TSYNC_X(            uint32_t,   len)    \
    TSYNC_X_BUFFER(     int8_t,     msg,    1000)

#define GER_CUSTOM_MSG_SET_CMD_FIELDS                    \
    TSYNC_X(            uint32_t,   nInstance)                        \
    TSYNC_X(            uint32_t,   len)    \
    TSYNC_X_BUFFER(     int8_t,     msg,    1000)



	
#include "tsync_struct_define.h"

GEN_STRUCT(GER_VALUE)
GEN_STRUCT(GER_CUSTOM_MSG)
GEN_STRUCT(GER_CUSTOM_MSG_SET_CMD)
GEN_STRUCT(GER_OFFSET_SET_CMD)




#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_GR_SERVICES_H */
