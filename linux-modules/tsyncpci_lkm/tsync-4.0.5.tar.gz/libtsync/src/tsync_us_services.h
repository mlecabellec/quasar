
#ifndef _defined_TSYNC_US_SERVICES_H
#define _defined_TSYNC_US_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_us_services.h
**
**  Date:       07/10/08
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/10/2008 Creation
**
****************************************************************************/

#include "tsync_fs_services.h"

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_US                     0x26
#define TSYNC_ID_US_CA_START            0x00
#define TSYNC_ID_US_CA_DATA             0x01
#define TSYNC_ID_US_CA_END              0x02
#define TSYNC_ID_US_CA_CANCEL           0x03
#define TSYNC_ID_US_CA_STATE            0x04
#define TSYNC_ID_US_CA_START_OC         0x05
#define TSYNC_ID_US_CA_START_COMP       0x06

/******************************************************
**     Define Enumerations
******************************************************/


typedef enum
{
    US_PROC_IDLE = 0,
    US_PROC_DOWNLOAD = 1,
    US_PROC_CRC_RAM = 2,
    US_PROC_ERASE = 3,
    US_PROC_PROGRAM = 4,
    US_PROC_CRC_FLASH = 5,
    US_PROC_FAILED = 6
} US_PROCESS;

/******************************************************
**     Define Structures
******************************************************/

#define UPDATE_START_CMD_FIELDS                    \
    TSYNC_X( UL_IMG,    typeHack)            \
    TSYNC_X_STRUCT( UL_IMG_HDR,    hdr)

#define UPDATE_START_OC_CMD_FIELDS              \
    TSYNC_X_STRUCT( UL_IMG_ID,     imgId)       \
    TSYNC_X_STRUCT( UL_IMG_HDR,    hdr)

#define UPDATE_START_COMP_CMD_FIELDS              \
    TSYNC_X_STRUCT( UL_IMG_ID,     imgId)       \
    TSYNC_X_STRUCT( UL_IMG_HDR,    hdr)

#define DATA_CMD_FIELDS                            \
    TSYNC_X(        UL_IMG,     image)            \
    TSYNC_X_BUFFER(    uint8_t,     data,    1024)

#define US_STATE_FIELDS                        \
    TSYNC_X( UL_IMG,         image)            \
    TSYNC_X( US_PROCESS,    step)            \
    TSYNC_X( uint32_t,        complete)


#include "tsync_struct_define.h"

GEN_STRUCT(UPDATE_START_CMD)
GEN_STRUCT(UPDATE_START_OC_CMD)
GEN_STRUCT(UPDATE_START_COMP_CMD)
GEN_STRUCT(DATA_CMD)
GEN_STRUCT(US_STATE)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_US_SERVICES_H */
