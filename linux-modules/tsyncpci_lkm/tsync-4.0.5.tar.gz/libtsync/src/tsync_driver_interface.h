
#ifndef _defined_TSYNC_DRIVER_INTERFACE_H
#define _defined_TSYNC_DRIVER_INTERFACE_H 1

#include "tsync.h"
#include "ddtsync.h"

TSYNC_ERROR TSYNC_openImpl(TSYNC_BoardHandle* hnd, const char *deviceName);
TSYNC_ERROR TSYNC_closeImpl(TSYNC_BoardHandle hnd);
TSYNC_ERROR TSYNC_ioctl(TSYNC_BoardHandle hnd,
                        TSYNC_IOCTL_ID id,
                        void* data,
                        unsigned int dataLength);

#endif  /* _defined_TSYNC_DRIVER_INTERFACE_H */
