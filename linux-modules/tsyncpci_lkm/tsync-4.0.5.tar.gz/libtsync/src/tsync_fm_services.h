
#ifndef _defined_TSYNC_FM_SERVICES_H
#define _defined_TSYNC_FM_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_fm_services.h
**
**  Date:       09/09/09
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2009 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              09/09/2009 Creation
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_FM                       0x46
#define TSYNC_ID_FM_CA_NUM_INST           0x01
#define TSYNC_ID_FM_CA_REF_FREQUENCY      0x02
#define TSYNC_ID_FM_CA_MIN_ACCURACY       0x03
#define TSYNC_ID_FM_CA_FREQUENCY          0x04
#define TSYNC_ID_FM_CA_ACCURACY           0x05
#define TSYNC_ID_FM_CA_ACCURATE           0x06
#define TSYNC_ID_FM_CA_LOG_FREQUENCY      0x07
#define TSYNC_ID_FM_CA_LOG_ACCURACY       0x08

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define FM_VALUE_FIELDS           \
    TSYNC_X(uint32_t, value)

#define FM_SET_CMD_FIELDS    \
    TSYNC_X(uint32_t, inst)       \
    TSYNC_X(uint32_t, value)

#define FM_FLOAT_VALUE_FIELDS           \
    TSYNC_X(float, value)

#define FM_SET_FLOAT_CMD_FIELDS   \
    TSYNC_X(uint32_t, inst)       \
    TSYNC_X(float, value)

#define FM_FLOAT_BUF_FIELDS       \
    TSYNC_X_ARRAY(  FM_FLOAT_VALUE,   log,    FM_LOG_MAX)

	
#include "tsync_struct_define.h"

GEN_STRUCT(FM_VALUE)
GEN_STRUCT(FM_SET_CMD)
GEN_STRUCT(FM_FLOAT_VALUE)
GEN_STRUCT(FM_FLOAT_BUF)
GEN_STRUCT(FM_SET_FLOAT_CMD)


#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_FM_SERVICES_H */
