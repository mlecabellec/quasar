
/***************************************************************************
**  Module:     tsync_fp_services_recipes.c
**
**  Date:       08/05/08
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              08/05/2008 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_fp_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(FP_SET_CMD)
RECIPE(FP_VALUE)
RECIPE(FP_FREQ)

#include "tsync_recipe_undef.h"
