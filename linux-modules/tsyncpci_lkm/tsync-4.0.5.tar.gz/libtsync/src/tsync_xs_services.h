
#ifndef _defined_TSYNC_XS_SERVICES_H
#define _defined_TSYNC_XS_SERVICES_H 1

/***************************************************************************
**  Module:     tsync_xs_services.h
**
**  Date:       07/22/08
**
**  Purpose:    Definitions and intermediate data structures
**              used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/22/2008 Creation
**
****************************************************************************/

/******************************************************
**     Defines
******************************************************/

#define TSYNC_ID_XS                         0x21
#define TSYNC_ID_XS_CA_REGISTER             0x00
#define TSYNC_ID_XS_CA_UNREGISTER           0x01
#define TSYNC_ID_XS_CA_METER_CMD            0x02
#define TSYNC_ID_XS_CA_WINDOW_SIZE          0x03
#define TSYNC_ID_XS_CA_METER_DATA           0x04

/******************************************************
**     Define Enumerations
******************************************************/

/******************************************************
**     Define Structures
******************************************************/

#define METER_HANDLE_FIELDS                    \
    TSYNC_X( TSYNC_METER_HANDLE,     hnd)

#define XS_WIN_SIZE_GET_CMD_FIELDS                    \
    TSYNC_X( TSYNC_METER_HANDLE,     hnd)

#define XS_WIN_SIZE_GET_RESP_FIELDS                    \
    TSYNC_X( uint32_t,     size)

#define XS_WIN_SIZE_SET_CMD_FIELDS                      \
    TSYNC_X( TSYNC_METER_HANDLE,    hnd)               \
    TSYNC_X( uint32_t,              size)

#define XS_METER_DATA_FIELDS                     \
    TSYNC_X( XS_STATE,      state)                        \
    TSYNC_X( uint32_t,      size)                        \
    TSYNC_X( uint32_t,      elapsed)                        \
    TSYNC_X( float,         frAccum)                        \
    TSYNC_X( float,         frPrev)                        \
    TSYNC_X( float,         phStart)                        \
    TSYNC_X( float,         phAccum)                        \
    TSYNC_X( float,         phPrev)

#define XS_COMMAND_FIELDS                       \
    TSYNC_X( TSYNC_METER_HANDLE,     hnd)       \
    TSYNC_X( XS_CMD,                 command)



#include "tsync_struct_define.h"

GEN_STRUCT(METER_HANDLE)
GEN_STRUCT(XS_WIN_SIZE_GET_CMD)
GEN_STRUCT(XS_WIN_SIZE_GET_RESP)
GEN_STRUCT(XS_WIN_SIZE_SET_CMD)
GEN_STRUCT(XS_METER_DATA)
GEN_STRUCT(XS_COMMAND)

#include "tsync_struct_undef.h"

#endif  /* _defined_TSYNC_XS_SERVICES_H */
