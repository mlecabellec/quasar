
/***************************************************************************
**  Module:     tsync_pr_services_recipes.h
**
**  Date:       07/28/08
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2006 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              07/28/2008 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_pr_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(PR_VALUE)
RECIPE(PR_OFFSET_SET_CMD)
RECIPE(PR_EDGE_SET_CMD)

#include "tsync_recipe_undef.h"
