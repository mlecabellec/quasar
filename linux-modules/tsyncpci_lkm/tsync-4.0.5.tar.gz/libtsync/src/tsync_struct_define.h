#if defined(__GNUC__) || defined(__SUNPRO_C) || defined(lint)
#   define PACKED __attribute__((packed))
#elif defined(_MSC_VER)
#   define PACKED
#   pragma pack(push,1)
#else
#   error Structures must be packed. Do it yourself depending on your compiler.
#endif

#define TSYNC_X(fieldType, fieldName) fieldType fieldName;
#define TSYNC_X_BUFFER(fieldType, fieldName, fieldLength) fieldType fieldName[fieldLength];
#define TSYNC_X_ARRAY(fieldType, fieldName, fieldLength) fieldType fieldName[fieldLength];
#define TSYNC_X_STRUCT(fieldType, fieldName) fieldType fieldName;
#define GEN_STRUCT(structSource)    \
typedef struct PACKED structSource{ \
       structSource##_FIELDS        \
}structSource ;                       /* Look at KTS-660 and KTS-669 for
                                         explanation about packed attribute */

