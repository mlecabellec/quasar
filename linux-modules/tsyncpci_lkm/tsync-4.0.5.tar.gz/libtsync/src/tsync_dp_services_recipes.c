
/***************************************************************************
**  Module:     tsync_dp_services_recipes.c
**
**  Date:       09/10/09
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2009 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              09/10/2009 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_dp_services.h"
#include "tsync_cs_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(DP_VALUE)
RECIPE(DP_SET_CMD)
RECIPE(DP_LOCAL_SET_CMD)
RECIPE(DP_TIME_SCALE_SET_CMD)

#include "tsync_recipe_undef.h"
