#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "tsync.h"
#include "tsync_trans.h"
#include "tsync_base_transaction.h"
#include "tsync_macros.h"

#include "tsync_cs_services.h"

extern uint8_t ML_DOYTIME_GET_RESP_RECIPE[];
extern uint8_t ML_NEXTSEC_GET_RESP_RECIPE[];
extern uint8_t ML_TIME_GET_RECIPE[];
extern uint8_t ML_TIME_SCALE_OBJ_RECIPE[];
extern uint8_t ML_TIME_SCALE_OFFSET_GET_CMD_RECIPE[];
extern uint8_t ML_TIME_SCALE_OFFSET_GET_RESP_RECIPE[];
extern uint8_t ML_TIME_SCALE_OFFSET_SET_CMD_RECIPE[];
extern uint8_t CS_TIME_DISCONT_RECIPE[];
extern uint8_t ML_LEAP_SEC_RECIPE[];
extern uint8_t ML_TIMEZONE_OFFSET_RECIPE[];
extern uint8_t ML_DST_RULE_RECIPE[];
extern uint8_t ML_YEAR_RECIPE[];
extern uint8_t ML_SECTIME_GET_RESP_RECIPE[];
extern uint8_t ML_BCDTIME_GET_RESP_RECIPE[];
extern uint8_t ML_DOYTIME_SET_CMD_RECIPE[];
extern uint8_t ML_SUBSEC_ADJUST_RECIPE[];
extern uint8_t ML_SECTIME_SET_CMD_RECIPE[];
extern uint8_t ML_BCDTIME_SET_CMD_RECIPE[];
extern uint8_t CS_DST_STATE_RECIPE[];
extern uintptr_t ML_TIME_UNION_RECIPE[];
extern uintptr_t ML_TIME_UNION_GET_RESP_RECIPE[];
extern uintptr_t ML_TIME_UNION_SET_CMD_RECIPE[];

/**********************************************************************
*
* FUNCTION:     TSYNC_CS_getTime
*
* DESCRIPTION:  Routine retrieves the current time from  the
*               TSYNC board. ( Julian date )
*
* Arguments:    Pointer to TSYNC_BoardObj handle
*               Pointer to TSYNC_TimeObj object
*
* RETURNS:      TSYNC_SUCCESS    - success
*               TSYNC_HANDLE_ERR - invalid arg pointers
*               TSYNC_COMM_ERR   - error interacting with device
*
**********************************************************************/
TSYNC_ERROR
TSYNC_CS_getTime(
    TSYNC_BoardHandle  hnd,
    TSYNC_TimeObj     *Timep )
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(Timep);

        struct ML_TIME_GET inPayload;
        inPayload.type = ML_TIME_DOYTIME;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(ML_TIME_GET_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofUnion(ML_TIME_UNION_GET_RESP_RECIPE)));
        
        err = BaseTransaction(
            TSYNC_ID_CS,
            TSYNC_ID_CS_CA_TIME,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            ML_TIME_GET_RECIPE,
            ML_DOYTIME_GET_RESP_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct ML_DOYTIME_GET_RESP* outPayload =
            (ML_DOYTIME_GET_RESP*)GetPayload(result);

        Timep->years = outPayload->time.year;
        Timep->doy = outPayload->time.doy;
        Timep->hours = outPayload->time.hour;
        Timep->minutes = outPayload->time.minute;
        Timep->seconds = outPayload->time.second;
        Timep->ns = outPayload->time.ns;
        
    return ( err );
}

/**********************************************************************
*
* FUNCTION:     TSYNC_CS_getNextSec
*
* DESCRIPTION:  Routine retrieves the current time from  the
*               TSYNC board. ( Julian date )
*
* Arguments:    Pointer to TSYNC_BoardObj handle
*               Pointer to TSYNC_TimeObj object
*
* RETURNS:      TSYNC_SUCCESS    - success
*               TSYNC_HANDLE_ERR - invalid arg pointers
*               TSYNC_COMM_ERR   - error interacting with device
*
**********************************************************************/
TSYNC_ERROR
TSYNC_CS_getNextSec(
    TSYNC_BoardHandle  hnd,
    TSYNC_TimeObj     *Timep )
{
    TSYNC_ERROR err = TSYNC_SUCCESS;

    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(Timep);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(ML_NEXTSEC_GET_RESP_RECIPE, &pos)));

        err = BaseTransaction(
            TSYNC_ID_CS,
            TSYNC_ID_CS_CA_NEXT_SEC,
            ctl,
            pyldLen,
            NULL,
            NULL,
            ML_NEXTSEC_GET_RESP_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)

        struct ML_NEXTSEC_GET_RESP* outPayload =
            (ML_NEXTSEC_GET_RESP*)GetPayload(result);

        Timep->years = outPayload->time.year;
        Timep->doy = outPayload->time.doy;
        Timep->hours = outPayload->time.hour;
        Timep->minutes = outPayload->time.minute;
        Timep->seconds = outPayload->time.second;
        Timep->ns = outPayload->time.ns;

    return ( err );
}

TSYNC_ERROR
TSYNC_CS_getTimeScale(
    TSYNC_BoardHandle   hnd,
    TSYNC_TimeScaleObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    uint16_t ctl = 0x00;//get
    uint8_t  pos = 0;
    uint32_t pyldLen = 0;

    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(ML_TIME_SCALE_OBJ_RECIPE, &pos)));
    
    err = BaseTransaction(
        TSYNC_ID_CS,
        TSYNC_ID_CS_CA_TIME_SCALE,
        ctl,
        pyldLen,
        NULL,
        NULL,
        ML_TIME_SCALE_OBJ_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)
    
    struct ML_TIME_SCALE_OBJ* outPayload =
        (ML_TIME_SCALE_OBJ*)GetPayload(result);
        
    pObj->scale = outPayload->scale;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_CS_getTimeScaleOff(
    TSYNC_BoardHandle         hnd,
    TSYNC_TimeScaleOffsetObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    uint16_t ctl = 0x00;//get
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(ML_TIME_SCALE_OFFSET_GET_CMD_RECIPE, &pos);
    
    struct ML_TIME_SCALE_OFFSET_GET_CMD inPayload;
    inPayload.scale = pObj->scale;

    pos = 0;
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(ML_TIME_SCALE_OFFSET_GET_RESP_RECIPE, &pos)));
    
    err = BaseTransaction(
        TSYNC_ID_CS,
        TSYNC_ID_CS_CA_TIME_SCALE_OFF,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        ML_TIME_SCALE_OFFSET_GET_CMD_RECIPE,
        ML_TIME_SCALE_OFFSET_GET_RESP_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)
    
    struct ML_TIME_SCALE_OFFSET_GET_RESP* outPayload =
        (ML_TIME_SCALE_OFFSET_GET_RESP*)GetPayload(result);
        
    pObj->offset = outPayload->tsOffset;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_CS_getTimeDiscont(
    TSYNC_BoardHandle     hnd,
    TSYNC_TimeDiscontObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = 0;

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofRecipe(CS_TIME_DISCONT_RECIPE, &pos)));
        
        err = BaseTransaction(
            TSYNC_ID_CS,
            TSYNC_ID_CS_CA_TIME_DISCONT,
            ctl,
            pyldLen,
            NULL,
            NULL,
            CS_TIME_DISCONT_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct CS_TIME_DISCONT* outPayload =
            (CS_TIME_DISCONT*)GetPayload(result);

        pObj->newTime.years = outPayload->newDt.year;
        pObj->newTime.doy = outPayload->newDt.doy;
        pObj->newTime.hours = outPayload->newDt.hour;
        pObj->newTime.minutes = outPayload->newDt.minute;
        pObj->newTime.seconds = outPayload->newDt.second;
        pObj->newTime.ns = outPayload->newDt.ns;
        
        pObj->effectiveTime.years = outPayload->effDt.year;
        pObj->effectiveTime.doy = outPayload->effDt.doy;
        pObj->effectiveTime.hours = outPayload->effDt.hour;
        pObj->effectiveTime.minutes = outPayload->effDt.minute;
        pObj->effectiveTime.seconds = outPayload->effDt.second;
        pObj->effectiveTime.ns = outPayload->effDt.ns;
        
        pObj->bActive = outPayload->bActive;
    
    return ( err );
}

TSYNC_ERROR
TSYNC_CS_getLeapSec(
    TSYNC_BoardHandle        hnd,
    TSYNC_TimeLeapSecondObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    uint16_t ctl = 0x00;//get
    uint8_t  pos = 0;
    uint32_t pyldLen = 0;

    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(ML_LEAP_SEC_RECIPE, &pos)));
    
    err = BaseTransaction(
        TSYNC_ID_CS,
        TSYNC_ID_CS_CA_LEAP_SEC,
        ctl,
        pyldLen,
        NULL,
        NULL,
        ML_LEAP_SEC_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)
    
    struct ML_LEAP_SEC* outPayload =
        (ML_LEAP_SEC*)GetPayload(result);
        
    pObj->offset = outPayload->offset;
    
    pObj->utcDate.years = outPayload->utcDate.year;
    pObj->utcDate.doy = outPayload->utcDate.doy;
    pObj->utcDate.hours = outPayload->utcDate.hour;
    pObj->utcDate.minutes = outPayload->utcDate.minute;
    pObj->utcDate.seconds = outPayload->utcDate.second;
    pObj->utcDate.ns = outPayload->utcDate.ns;
        
        
    return ( err );
}

TSYNC_ERROR
TSYNC_CS_getTimeZoneOff(
    TSYNC_BoardHandle        hnd,
    TSYNC_TimeZoneOffsetObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    uint16_t ctl = 0x00;//get
    uint8_t  pos = 0;
    uint32_t pyldLen = 0;

    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(ML_TIMEZONE_OFFSET_RECIPE, &pos)));
    
    err = BaseTransaction(
        TSYNC_ID_CS,
        TSYNC_ID_CS_CA_TIME_ZONE_OFF,
        ctl,
        pyldLen,
        NULL,
        NULL,
        ML_TIMEZONE_OFFSET_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)
    
    struct ML_TIMEZONE_OFFSET* outPayload =
        (ML_TIMEZONE_OFFSET*)GetPayload(result);
        
    pObj->tzOffset = outPayload->tzOffset;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_CS_getDstRule(
    TSYNC_BoardHandle     hnd,
    TSYNC_TimeDSTRuleObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    uint16_t ctl = 0x00;//get
    uint8_t  pos = 0;
    uint32_t pyldLen = 0;

    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(ML_DST_RULE_RECIPE, &pos)));
    
    err = BaseTransaction(
        TSYNC_ID_CS,
        TSYNC_ID_CS_CA_DST_RULE,
        ctl,
        pyldLen,
        NULL,
        NULL,
        ML_DST_RULE_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)
    
    struct ML_DST_RULE* outPayload =
        (ML_DST_RULE*)GetPayload(result);
        
    pObj->ref = outPayload->ref;
    
    pObj->in.month = outPayload->in.month;
    pObj->in.wom = outPayload->in.wom;
    pObj->in.dow = outPayload->in.dow;
    pObj->in.hour = outPayload->in.hour;
    
    pObj->out.month = outPayload->out.month;
    pObj->out.wom = outPayload->out.wom;
    pObj->out.dow = outPayload->out.dow;
    pObj->out.hour = outPayload->out.hour;
    
    pObj->offset = outPayload->offset;
    
        
    return ( err );
}

TSYNC_ERROR
TSYNC_CS_getYear(
    TSYNC_BoardHandle  hnd,
    TSYNC_TimeYearObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    uint16_t ctl = 0x00;//get
    uint8_t  pos = 0;
    uint32_t pyldLen = 0;

    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(ML_YEAR_RECIPE, &pos)));
    
    err = BaseTransaction(
        TSYNC_ID_CS,
        TSYNC_ID_CS_CA_YEAR,
        ctl,
        pyldLen,
        NULL,
        NULL,
        ML_YEAR_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)
    
    struct ML_YEAR* outPayload =
        (ML_YEAR*)GetPayload(result);
        
    pObj->year = outPayload->year;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_CS_getTimeSec(
    TSYNC_BoardHandle hnd,
    unsigned int *nSeconds,
    unsigned int *nNanos)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(nSeconds);
        CHECK_NOT_NULL(nNanos);

        struct ML_TIME_GET inPayload;
        inPayload.type = ML_TIME_SECONDS;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(ML_TIME_GET_RECIPE, &pos);
        
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofUnion(ML_TIME_UNION_GET_RESP_RECIPE)));
        
        err = BaseTransaction(
            TSYNC_ID_CS,
            TSYNC_ID_CS_CA_TIME,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            ML_TIME_GET_RECIPE,
            ML_SECTIME_GET_RESP_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct ML_SECTIME_GET_RESP* outPayload =
            (ML_SECTIME_GET_RESP*)GetPayload(result);

        *nSeconds = outPayload->time.seconds;
        *nNanos = outPayload->time.ns;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_CS_getTimeBcd(
    TSYNC_BoardHandle hnd,
    TSYNC_TimeBCDObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct ML_TIME_GET inPayload;
        inPayload.type = ML_TIME_BCDTIME;
        
        uint16_t ctl = 0x00;//get
        uint8_t  pos = 0;
        uint32_t pyldLen = sizeofRecipe(ML_TIME_GET_RECIPE, &pos);

        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(sizeofUnion(ML_TIME_UNION_GET_RESP_RECIPE)));
        
        err = BaseTransaction(
            TSYNC_ID_CS,
            TSYNC_ID_CS_CA_TIME,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            ML_TIME_GET_RECIPE,
            ML_BCDTIME_GET_RESP_RECIPE,
            result,
            handle);

        CHECK_SUCCESS(err)
        
        struct ML_BCDTIME_GET_RESP* outPayload =
            (ML_BCDTIME_GET_RESP*)GetPayload(result);

        pObj->years = outPayload->time.year;
        pObj->doy = outPayload->time.doy;
        pObj->hours = outPayload->time.hour;
        pObj->minutes = outPayload->time.minute;
        pObj->seconds = outPayload->time.second;
        pObj->ms = outPayload->time.ms;
        pObj->us = outPayload->time.us;
        
    return ( err );
}

TSYNC_ERROR
TSYNC_CS_getDstState(
    TSYNC_BoardHandle      hnd,
    TSYNC_TimeDSTStateObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    uint16_t ctl = 0x00;//get
    uint8_t  pos = 0;
    uint32_t pyldLen = 0;

    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(sizeofRecipe(CS_DST_STATE_RECIPE, &pos)));
    
    err = BaseTransaction(
        TSYNC_ID_CS,
        TSYNC_ID_CS_CA_DST_STATE,
        ctl,
        pyldLen,
        NULL,
        NULL,
        CS_DST_STATE_RECIPE,
        result,
        handle);

    CHECK_SUCCESS(err)
    
    struct CS_DST_STATE* outPayload =
        (CS_DST_STATE*)GetPayload(result);
        
    pObj->state = outPayload->bState;
        
    return ( err );
}

/*==========================================================================
  TSYNC_CS_setTime
==========================================================================*/

TSYNC_ERROR TSYNC_CS_setTime (
    TSYNC_BoardHandle  hnd,
    TSYNC_TimeObj     *pObj)
{
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    struct ML_DOYTIME_SET_CMD inPayload;
    inPayload.type = ML_TIME_DOYTIME;
    inPayload.time.year = pObj->years;
    inPayload.time.doy = pObj->doy;
    inPayload.time.hour = pObj->hours;
    inPayload.time.minute = pObj->minutes;
    inPayload.time.second = pObj->seconds;
    inPayload.time.ns = pObj->ns;
    inPayload.typeHack = inPayload.type;
    
    uint16_t ctl = 0x02;//set
    uint32_t pyldLen = sizeofUnion(ML_TIME_UNION_SET_CMD_RECIPE);

    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(0));
        
    TSYNC_ERROR err = BaseTransaction(
        TSYNC_ID_CS,
        TSYNC_ID_CS_CA_TIME,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        ML_DOYTIME_SET_CMD_RECIPE,
        NULL,
        result,
        handle);
    
    return ( err );
}

TSYNC_ERROR TSYNC_CS_setTimeScale (
    TSYNC_BoardHandle   hnd,
    TSYNC_TimeScaleObj *pObj)
{
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);
    
    uint16_t ctl = 0x02;//set
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(ML_TIME_SCALE_OBJ_RECIPE, &pos);
    
    struct ML_TIME_SCALE_OBJ inPayload;
    inPayload.scale = pObj->scale;

    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(0));
    
    TSYNC_ERROR err = BaseTransaction(
        TSYNC_ID_CS,
        TSYNC_ID_CS_CA_TIME_SCALE,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        ML_TIME_SCALE_OBJ_RECIPE,
        NULL,
        result,
        handle);
    
    return ( err );
}

TSYNC_ERROR TSYNC_CS_setTimeScaleOff (TSYNC_BoardHandle hnd, TSYNC_TimeScaleOffsetObj *pObj)
{
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);
    
    uint16_t ctl = 0x02;//set
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(ML_TIME_SCALE_OFFSET_SET_CMD_RECIPE, &pos);
    
    struct ML_TIME_SCALE_OFFSET_SET_CMD inPayload;
    inPayload.scale = pObj->scale;
    inPayload.tsOffset = pObj->offset;

    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(0));
    
    TSYNC_ERROR err = BaseTransaction(
        TSYNC_ID_CS,
        TSYNC_ID_CS_CA_TIME_SCALE_OFF,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        ML_TIME_SCALE_OFFSET_SET_CMD_RECIPE,
        NULL,
        result,
        handle);
    
    return ( err );
}

TSYNC_ERROR TSYNC_CS_subsecAdj (
    TSYNC_BoardHandle       hnd,
    TSYNC_TimeSubsecAdjObj *pObj)
{
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);
    
    uint16_t ctl = 0x02;//set
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(ML_SUBSEC_ADJUST_RECIPE, &pos);
    
    struct ML_SUBSEC_ADJUST inPayload;
    inPayload.ssAdjust = pObj->adjust;

    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(0));
    
    TSYNC_ERROR err = BaseTransaction(
        TSYNC_ID_CS,
        TSYNC_ID_CS_CA_TIME_SUBSEC_ADJ,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        ML_SUBSEC_ADJUST_RECIPE,
        NULL,
        result,
        handle);
    
    return ( err );
}

TSYNC_ERROR TSYNC_CS_setTimeDiscont (
    TSYNC_BoardHandle     hnd,
    TSYNC_TimeDiscontObj *pObj)
{
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);
    
    uint16_t ctl = 0x02;//set
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(CS_TIME_DISCONT_RECIPE, &pos);
    
    struct CS_TIME_DISCONT inPayload;
    inPayload.newDt.year = pObj->newTime.years;
    inPayload.newDt.doy = pObj->newTime.doy;
    inPayload.newDt.hour = pObj->newTime.hours;
    inPayload.newDt.minute = pObj->newTime.minutes;
    inPayload.newDt.second = pObj->newTime.seconds;
    inPayload.newDt.ns = pObj->newTime.ns;
    
    inPayload.effDt.year = pObj->effectiveTime.years;
    inPayload.effDt.doy = pObj->effectiveTime.doy;
    inPayload.effDt.hour = pObj->effectiveTime.hours;
    inPayload.effDt.minute = pObj->effectiveTime.minutes;
    inPayload.effDt.second = pObj->effectiveTime.seconds;
    inPayload.effDt.ns = pObj->effectiveTime.ns;
    
    inPayload.bActive = pObj->bActive;
    
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(0));
    
    TSYNC_ERROR err = BaseTransaction(
        TSYNC_ID_CS,
        TSYNC_ID_CS_CA_TIME_DISCONT,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        CS_TIME_DISCONT_RECIPE,
        NULL,
        result,
        handle);
    
    return ( err );
}

TSYNC_ERROR TSYNC_CS_setLeapSec (
    TSYNC_BoardHandle        hnd,
    TSYNC_TimeLeapSecondObj *pObj)
{
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);
    
    uint16_t ctl = 0x02;//set
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(ML_LEAP_SEC_RECIPE, &pos);
    
    struct ML_LEAP_SEC inPayload;
    inPayload.offset = pObj->offset;
    inPayload.utcDate.year = pObj->utcDate.years;
    inPayload.utcDate.doy = pObj->utcDate.doy;
    inPayload.utcDate.hour = pObj->utcDate.hours;
    inPayload.utcDate.minute = pObj->utcDate.minutes;
    inPayload.utcDate.second = pObj->utcDate.seconds;
    inPayload.utcDate.ns = pObj->utcDate.ns;
    
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(0));
    
    TSYNC_ERROR err = BaseTransaction(
        TSYNC_ID_CS,
        TSYNC_ID_CS_CA_LEAP_SEC,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        ML_LEAP_SEC_RECIPE,
        NULL,
        result,
        handle);
    
    return ( err );
}

TSYNC_ERROR TSYNC_CS_setTimeZoneOff (
    TSYNC_BoardHandle        hnd,
    TSYNC_TimeZoneOffsetObj *pObj)
{
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);
    
    uint16_t ctl = 0x02;//set
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(ML_TIMEZONE_OFFSET_RECIPE, &pos);
    
    struct ML_TIMEZONE_OFFSET inPayload;
    inPayload.tzOffset = pObj->tzOffset;
    
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(0));
    
    TSYNC_ERROR err = BaseTransaction(
        TSYNC_ID_CS,
        TSYNC_ID_CS_CA_TIME_ZONE_OFF,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        ML_TIMEZONE_OFFSET_RECIPE,
        NULL,
        result,
        handle);
    
    return ( err );
}

TSYNC_ERROR TSYNC_CS_setDstRule (
    TSYNC_BoardHandle     hnd,
    TSYNC_TimeDSTRuleObj *pObj)
{
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);
    
    uint16_t ctl = 0x02;//set
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(ML_DST_RULE_RECIPE, &pos);
    
    struct ML_DST_RULE inPayload;
    inPayload.ref = pObj->ref;
    
    inPayload.in.month = pObj->in.month;
    inPayload.in.wom = pObj->in.wom;
    inPayload.in.dow = pObj->in.dow;
    inPayload.in.hour = pObj->in.hour;
    
    inPayload.out.month = pObj->out.month;
    inPayload.out.wom = pObj->out.wom;
    inPayload.out.dow = pObj->out.dow;
    inPayload.out.hour = pObj->out.hour;
    
    inPayload.offset = pObj->offset;
    
    
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(0));
    
    TSYNC_ERROR err = BaseTransaction(
        TSYNC_ID_CS,
        TSYNC_ID_CS_CA_DST_RULE,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        ML_DST_RULE_RECIPE,
        NULL,
        result,
        handle);
    
    return ( err );
}

TSYNC_ERROR TSYNC_CS_setYear (
    TSYNC_BoardHandle  hnd,
    TSYNC_TimeYearObj *pObj)
{
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);
    
    uint16_t ctl = 0x02;//set
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(ML_YEAR_RECIPE, &pos);
    
    struct ML_YEAR inPayload;
    inPayload.year = pObj->year;
    
    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(0));
    
    TSYNC_ERROR err = BaseTransaction(
        TSYNC_ID_CS,
        TSYNC_ID_CS_CA_YEAR,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        ML_YEAR_RECIPE,
        NULL,
        result,
        handle);
    
    return ( err );
}

TSYNC_ERROR
TSYNC_CS_setTimeSec(
    TSYNC_BoardHandle hnd,
    unsigned int nSeconds,
    unsigned int nNanos)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);

        struct ML_SECTIME_SET_CMD inPayload;
        inPayload.type = ML_TIME_SECONDS;
        inPayload.time.seconds = nSeconds;
        inPayload.time.ns = nNanos;
        inPayload.typeHack = inPayload.type;
        
        uint16_t ctl = 0x02;//set
        uint32_t pyldLen = sizeofUnion(ML_TIME_UNION_SET_CMD_RECIPE);
    
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
            
        err = BaseTransaction(
            TSYNC_ID_CS,
            TSYNC_ID_CS_CA_TIME,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            ML_SECTIME_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

    return ( err );
}

TSYNC_ERROR
TSYNC_CS_setTimeBcd(
    TSYNC_BoardHandle hnd,
    TSYNC_TimeBCDObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

        CHECK_HANDLE(hnd);
        CHECK_NOT_NULL(pObj);

        struct ML_BCDTIME_SET_CMD inPayload;
        inPayload.type = ML_TIME_BCDTIME;
        inPayload.time.year = pObj->years;
        inPayload.time.doy = pObj->doy;
        inPayload.time.hour = pObj->hours;
        inPayload.time.minute = pObj->minutes;
        inPayload.time.second = pObj->seconds;
        inPayload.time.ms = pObj->ms;
        inPayload.time.us = pObj->us;
        inPayload.typeHack = inPayload.type;
        
        uint16_t ctl = 0x02;//set
        uint32_t pyldLen = sizeofUnion(ML_TIME_UNION_SET_CMD_RECIPE);
    
        TSYNC_TransResult result =
            (TSYNC_TransResult)TSYNC_ALLOCA(
            SizeOfResult(0));
            
        err = BaseTransaction(
            TSYNC_ID_CS,
            TSYNC_ID_CS_CA_TIME,
            ctl,
            pyldLen,
            (uint8_t*) (&inPayload),
            ML_BCDTIME_SET_CMD_RECIPE,
            NULL,
            result,
            handle);

    return ( err );
}

TSYNC_ERROR
TSYNC_CS_setDstState(
    TSYNC_BoardHandle      hnd,
    TSYNC_TimeDSTStateObj *pObj)
{
    TSYNC_ERROR err = TSYNC_SUCCESS;
    
    TSYNC_BoardObj *handle = (TSYNC_BoardObj*)hnd;

    CHECK_HANDLE(hnd);
    CHECK_NOT_NULL(pObj);

    struct CS_DST_STATE inPayload;
    inPayload.bState = pObj->state;

    uint16_t ctl = 0x02;//set
    uint8_t  pos = 0;
    uint32_t pyldLen = sizeofRecipe(CS_DST_STATE_RECIPE, &pos);

    TSYNC_TransResult result =
        (TSYNC_TransResult)TSYNC_ALLOCA(
        SizeOfResult(0));
    
    err = BaseTransaction(
        TSYNC_ID_CS,
        TSYNC_ID_CS_CA_DST_STATE,
        ctl,
        pyldLen,
        (uint8_t*) (&inPayload),
        CS_DST_STATE_RECIPE,
        NULL,
        result,
        handle);
        
    return ( err );
}
