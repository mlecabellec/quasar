
/***************************************************************************
**  Module:     tsync_ap_services_recipes.c
**
**  Date:       09/10/09
**
**  Purpose:    Recipes used by the driver and TSYNC API library routines
**
** (C) Copyright 2009 Spectracom Corporation  All rights reserved.
**
****************************************************************************
** Modifications:
**
**              09/10/2009 Creation
**
****************************************************************************/

#include <stdlib.h>

#include "tsync_trans.h"
#include "tsync_ap_services.h"
#include "tsync_cs_services.h"

/******************************************************
**     Define Objects
******************************************************/

#include "tsync_recipe_define.h"

RECIPE(AP_VALUE)
RECIPE(AP_SET_CMD)
RECIPE(AP_REQ_CHAR_OBJ)
RECIPE(AP_REQ_CHAR_SET_CMD)
RECIPE(AP_UART_CFG_OBJ)
RECIPE(AP_UART_CFG_SET_CMD)
RECIPE(AP_LOCAL_SET_CMD)
RECIPE(AP_TIME_SCALE_SET_CMD)
RECIPE(AP_FORMAT_OBJ)
RECIPE(AP_FORMAT_SET_CMD)

#include "tsync_recipe_undef.h"
