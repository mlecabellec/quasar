# libtsync

This library is used to interface your application with your Tsync card via the
Tsync driver.

## Building

    $ cd src/
    $ make
    # make install
