#ifndef __TSYNC_HW_NONKTS_FUNC_H__
#define __TSYNC_HW_NONKTS_FUNC_H__ 1

#include "tsync_driver_helpers.h"

#include "ddtsync.h"
#include "tsync_error_codes.h"


TSYNC_ERROR hw_nonkts_get_trans(uint16_t iid,
                                TPRO_INSTANCE_T *hw,
                                uint8_t *inPayload,
                                uint32_t inLength,
                                uint8_t *outPayload,
                                uint32_t maxOutLength,
                                uint32_t *actualOutLength);

TSYNC_ERROR hw_nonkts_set_trans(uint16_t iid,
                                TPRO_INSTANCE_T *hw,
                                uint8_t *inPayload,
                                uint32_t inLength,
                                uint8_t *outPayload,
                                uint32_t maxOutLength,
                                uint32_t *actualOutLength);

#endif
