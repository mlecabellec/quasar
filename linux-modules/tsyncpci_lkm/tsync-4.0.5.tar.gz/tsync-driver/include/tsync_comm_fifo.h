#ifndef __TSYNC_COMM_FIFO_H__
#define __TSYNC_COMM_FIFO_H__ 1

#include "tsync_driver_helpers.h"

#include "tsync_error_codes.h"

TSYNC_ERROR readWordsFromFIFO(TPRO_INSTANCE_T *hw,
                              void *destination, int nWords,
                              int *timeoutRemaining);

int writeWordsToFIFO(TPRO_INSTANCE_T *hw, void *source, int nWords);

int writeWordToFIFO(TPRO_INSTANCE_T *hw, uint16_t value);

int tsyncFlushFifos(TPRO_INSTANCE_T *hw);
#endif
