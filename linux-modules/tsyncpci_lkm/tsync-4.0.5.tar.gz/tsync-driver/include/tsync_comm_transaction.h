#ifndef __TSYNC_COMM_TRANSACTION_H__
#define __TSYNC_COMM_TRANSACTION_H__ 1

#include "tsync_driver_helpers.h"
#include "ddtsync.h"

typedef struct ioctl_trans
{
    // input parameters
    uint8_t*        inBuffer;
    size_t        inBufferLength;
    uint8_t*        outBuffer;
    uint32_t        maxOutBufferLength;
    // output parameters
    uint32_t        actOutBufferLength;
    TSYNC_ERROR     status;
}ioctl_trans;


unsigned char tsyncLocalTransaction(TPRO_INSTANCE_T *hw, ioctl_trans *transaction);

#endif
