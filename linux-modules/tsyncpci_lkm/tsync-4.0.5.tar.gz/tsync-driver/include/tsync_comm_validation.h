#ifndef __tsync_comm_validation_h__
#define __tsync_comm_validation_h__ 1

#include "tsync_driver_helpers.h"
#include "tsync_error_codes.h"

uint16_t tsync_comm_calculate_checksum(void *buffer, size_t bufferLength);
unsigned int tsync_comm_validate_packet(void *packet);

#define INVALID_SEQUENCE_NUMBER 0xff;
uint8_t tsync_comm_get_next_seq_num(void);

TSYNC_ERROR tsync_check_board_connection_health(TPRO_INSTANCE_T *hw);
#endif
