#ifndef __tsync_types__
#define __tsync_types__ 1

typedef enum {

#ifdef NIOS

/*** Memory Map for NIOS / Device Tree Access ***/

    tsync_super_second_offset = 0x04A0,
    tsync_nano_sub_second_offset = 0x04A8,
    tsync_super_second_binary_offset = 0x04AC,
    
    tsync_gpio_output_0_high_match_offset = 0x4A10,
    tsync_gpio_output_0_low_match_offset = 0x4A20,
    tsync_gpio_output_1_high_match_offset = 0x4C10,
    tsync_gpio_output_1_low_match_offset = 0x4C20,
    tsync_gpio_output_2_high_match_offset = 0x4E10,
    tsync_gpio_output_2_low_match_offset = 0x4E20,
    tsync_gpio_output_3_high_match_offset = 0x5010,
    tsync_gpio_output_3_low_match_offset = 0x5020,

    tsync_temperature_offset = 0x0E0E,
    tsync_temperature_offset_ss =  0x0EFF,//Placeholder data to allow compilation
    tsync_timestamp_status_offset = 0x0600,
    tsync_timestamp_fifo_offset = 0x0602,

    tsync_fpga_status_offset = 0x0E00,
    tsync_fpga_revision_id_offset = 0x0E02,

    tsync_interrupt_mask_offset = 0x0E04,
    tsync_interrupt_status_offset = 0x0E06,

    tsync_fifo_status_offset = 0x0A00,
    tsync_fifo_transmit_offset = 0x0C40,
    tsync_fifo_receive_offset = 0x0C80,

#else

/*** Memory Map for PCI Access ***/

    tsync_super_second_offset = 0x000,
    tsync_nano_sub_second_offset = 0x008,
    tsync_super_second_binary_offset = 0x00c,
    
    tsync_gpio_output_0_high_match_offset = 0x040,
    tsync_gpio_output_0_low_match_offset = 0x050,
    tsync_gpio_output_1_high_match_offset = 0x060,
    tsync_gpio_output_1_low_match_offset = 0x070,
    tsync_gpio_output_2_high_match_offset = 0x080,
    tsync_gpio_output_2_low_match_offset = 0x090,
    tsync_gpio_output_3_high_match_offset = 0x0A0,
    tsync_gpio_output_3_low_match_offset = 0x0B0,

    tsync_temperature_offset = 0x0CA,
    tsync_temperature_offset_ss = 0x0CE,
    
    tsync_timestamp_status_offset = 0x020,
    tsync_timestamp_fifo_offset = 0x022,

    tsync_fpga_status_offset = 0x0C0,
    tsync_fpga_revision_id_offset = 0x0C2,

    tsync_interrupt_mask_offset = 0x0C4,
    tsync_interrupt_status_offset = 0x0C6,

    tsync_fifo_status_offset = 0x160,
    tsync_fifo_transmit_offset = 0x180,
    tsync_fifo_receive_offset = 0x1C0,

#endif
#ifdef LAFAYETTE
    tsync_keypad_offset = 0x0C8,
    tsync_lcd_interface_offset = 0x0CA,
    tsync_power_status_offset = 0x0CC,
    tsync_fan_en = 0x0D0,
#endif

} tsync_register_offsets;

#define MAX_TRANSACTION_BUFFER_WORDS 1280
#define MAX_HW_REQUEST_LENGTH 1280
#define MAX_HW_RESPONSE_LENGTH (16*1280)

#define TSYNC_INTERRUPT_COUNT 15

#endif
