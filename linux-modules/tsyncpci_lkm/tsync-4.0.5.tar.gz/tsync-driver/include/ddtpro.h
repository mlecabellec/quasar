/*******************************************************************************
**
**  Module  : ddtpro.h
**  Date    : 04/05/06
**  Purpose : This is the TPRO-PCI device driver include file. It provides
**            data structures for the TPRO-PCI driver to use along with the
**            valid ioctls.
**
**  Copyright(C) 2006 Spectracom Corporation. All Rights Reserved.
**
**  This program is free software; you can redistribute it and/or modify
**  it under the terms of the GNU General Public License as published by
**  the Free Software Foundation; either version 2 of the License, or
**  (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software
**  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
**
*******************************************************************************/
#ifndef _defined_DDTPRO_
#define _defined_DDTPRO_

#include <asm/ioctl.h>

#ifdef __KERNEL__
#include <linux/version.h>
#include <linux/types.h>
#include <linux/time.h>

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(3,17,0))
#include <linux/ktime.h>
#include <linux/timekeeping.h>
#endif
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(5,5,0))
#include <asm-generic/posix_types.h>
#define timeval __kernel_old_timeval
#define timespec __kernel_old_timespec
#define ktime_to_timeval ns_to_kernel_old_timeval
static inline void getnstimeofday(struct timespec *ts)
{
  struct timespec64 ts64;
  ktime_get_real_ts64(&ts64);
  *ts = *(const struct timespec*)&ts64;
}
#endif

#else
#include <sys/types.h>
#include <sys/time.h>
#endif

/*******************************************************************************
** Defined Structures
*******************************************************************************/

/*
** TPRO BOARD OBJECT
*/
typedef struct BoardObj {

  int            file_descriptor;
  unsigned short devid;
  unsigned short options;
  unsigned char  firmware[5];
  unsigned char  FPGA[5];
  unsigned char  driver[7];

} BoardObj;

/*
** ALTITUDE OBJECT
*/
typedef struct AltObj {

  unsigned int meters;

} AltObj;

/*
** DATE OBJECT
*/
typedef struct DateObj {

  unsigned short year;
  unsigned char  month;
  unsigned char  day;

} DateObj;

/*
** LONGITUDE/LATITUDE OBJECT
*/
typedef struct LongLat
{

  unsigned short degrees;
  unsigned int   minutes;

} LongObj, LatObj;

/*
** MATCH OBJECT
*/
typedef struct MatchObj {

  unsigned char   matchType;
  unsigned int    seconds;
  unsigned char   minutes;
  unsigned char   hours;
  unsigned short  days;

} MatchObj;

/*
** SATINFO OBJECT
*/
typedef struct SatObj {

  unsigned char satsTracked;
  unsigned char satsView;

} SatObj;

/*
** HEARTBEAT OBJECT
*/
typedef struct HeartObj {

  unsigned char  signalType;  /* square or pulse */
  unsigned char  outputType;  /* jamming option */
  unsigned short divNumber;   /* divide number */

} HeartObj;

/*
** TIME OBJECT
*/
typedef struct TimeObj {

  unsigned char  syncOption;  /* -M option */
  unsigned int   secsDouble;  /* seconds floating pt */
  unsigned char  seconds;     /* seconds whole num */
  unsigned char  minutes;
  unsigned char  hours;
  unsigned short days;
  unsigned short year;
  unsigned short flags;      /* bit 2 SYNC, bit 1 TCODE; all others 0 */

} TimeObj;

/*
** NTP TIME OBJECT
*/
typedef struct NtpTimeObj {

    TimeObj        timeObj;
    struct timeval tv;
    unsigned int   refId;

} NtpTimeObj;

struct timeval_compat {
    int tv_sec;
    int tv_usec;
};

typedef struct NtpTimeObj_Compat
{
    TimeObj         timeObj;
    struct timeval_compat tv;
    unsigned int    refId;
} NtpTimeObj_Compat;

/*
** WAIT OBJECT
*/
typedef struct WaitObj {

  int            jiffies; /* # jiffies to wait */
  unsigned int   seconds;
  unsigned char  minutes;
  unsigned char  hours;
  unsigned short days;

} WaitObj;

/*
** MEM OBJECT FOR PEEK/POKE
*/
typedef struct MemObj {

  unsigned short offset;
  unsigned short value;
  unsigned long  l_value;

} MemObj;


/*******************************************************************************
            IOCTLs
*******************************************************************************/

#define IOCTL_TPRO_ID                  't'

#define IOCTL_TPRO_CMD_OPEN                 0
#define IOCTL_TPRO_CMD_GET_ALTITUDE         1
#define IOCTL_TPRO_CMD_GET_DATE             2
#define IOCTL_TPRO_CMD_GET_DRIVER           3
#define IOCTL_TPRO_CMD_GET_FIRMWARE         4
#define IOCTL_TPRO_CMD_GET_FPGA             5
#define IOCTL_TPRO_CMD_GET_LATITUDE         6
#define IOCTL_TPRO_CMD_GET_LONGITUDE        7
#define IOCTL_TPRO_CMD_GET_SAT_INFO         8
#define IOCTL_TPRO_CMD_GET_TIME             9
#define IOCTL_TPRO_CMD_RESET_FIRMWARE      10
#define IOCTL_TPRO_CMD_SET_HEARTBEAT       11
#define IOCTL_TPRO_CMD_SET_MATCHTIME       12
#define IOCTL_TPRO_CMD_SET_OSCILLATOR      13
#define IOCTL_TPRO_CMD_SET_PROP_DELAY_CORR 14
#define IOCTL_TPRO_CMD_SET_TIME            15
#define IOCTL_TPRO_CMD_SET_YEAR            16
#define IOCTL_TPRO_CMD_SIM_EVENT           17
#define IOCTL_TPRO_CMD_SYNCH_CONTROL       18
#define IOCTL_TPRO_CMD_SYNCH_STATUS        19
#define IOCTL_TPRO_CMD_WAIT_EVENT          20
#define IOCTL_TPRO_CMD_WAIT_HEART          21
#define IOCTL_TPRO_CMD_WAIT_MATCH          22
#define IOCTL_TPRO_CMD_PEEK                23
#define IOCTL_TPRO_CMD_POKE                24
#define IOCTL_TPRO_CMD_GET_NTP_TIME        25
#define IOCTL_TSYNC_CMD_GET                26
#define IOCTL_TSYNC_CMD_SET                27
#define IOCTL_TSYNC_CMD_WAIT               28
#define IOCTL_TSYNC_CMD_WAIT_TO            29
#define IOCTL_TPRO_CMD_COUNT               30 /* Number of commands. */

#define IOCTL_TPRO_OPEN                _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_OPEN, \
                                             BoardObj)
#define IOCTL_TPRO_GET_ALTITUDE        _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_GET_ALTITUDE, \
                                             AltObj)
#define IOCTL_TPRO_GET_DATE            _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_GET_DATE, \
                                             DateObj)
#define IOCTL_TPRO_GET_DRIVER          _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_GET_DRIVER, \
                                             unsigned char*)
#define IOCTL_TPRO_GET_FIRMWARE        _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_GET_FIRMWARE, \
                                             unsigned char*)
#define IOCTL_TPRO_GET_FPGA            _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_GET_FPGA, \
                                             unsigned char*)
#define IOCTL_TPRO_GET_LATITUDE        _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_GET_LATITUDE, \
                                             LatObj)
#define IOCTL_TPRO_GET_LONGITUDE       _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_GET_LONGITUDE, \
                                             LongObj)
#define IOCTL_TPRO_GET_SAT_INFO        _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_GET_SAT_INFO, \
                                             SatObj)
#define IOCTL_TPRO_GET_TIME            _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_GET_TIME, \
                                             TimeObj)
#define IOCTL_TPRO_RESET_FIRMWARE      _IO(IOCTL_TPRO_ID, \
                                           IOCTL_TPRO_CMD_RESET_FIRMWARE)
#define IOCTL_TPRO_SET_HEARTBEAT       _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_SET_HEARTBEAT, \
                                             HeartObj)
#define IOCTL_TPRO_SET_MATCHTIME       _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_SET_MATCHTIME, \
                                             MatchObj)
#define IOCTL_TPRO_SET_OSCILLATOR      _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_SET_OSCILLATOR, \
                                             unsigned char*)
#define IOCTL_TPRO_SET_PROP_DELAY_CORR _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_SET_PROP_DELAY_CORR, \
                                             int*)
#define IOCTL_TPRO_SET_TIME            _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_SET_TIME, \
                                             TimeObj)
#define IOCTL_TPRO_SET_YEAR            _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_SET_YEAR, \
                                             unsigned short*)
#define IOCTL_TPRO_SIM_EVENT           _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_SIM_EVENT, \
                                             unsigned char*)
#define IOCTL_TPRO_SYNCH_CONTROL       _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_SYNCH_CONTROL, \
                                             unsigned char*)
#define IOCTL_TPRO_SYNCH_STATUS        _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_SYNCH_STATUS, \
                                             unsigned char*)
#define IOCTL_TPRO_WAIT_EVENT          _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_WAIT_EVENT, \
                                             WaitObj)
#define IOCTL_TPRO_WAIT_HEART          _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_WAIT_HEART, \
                                             HeartObj)
#define IOCTL_TPRO_WAIT_MATCH          _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_WAIT_MATCH, \
                                             MatchObj)
#define IOCTL_TPRO_PEEK                _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_PEEK, \
                                             MemObj)
#define IOCTL_TPRO_POKE                _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_POKE, \
                                             MemObj)
#define IOCTL_TPRO_GET_NTP_TIME        _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_GET_NTP_TIME, \
                                             NtpTimeObj)
#define IOCTL_TPRO_GET_NTP_TIME_COMPAT _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TPRO_CMD_GET_NTP_TIME, \
                                             NtpTimeObj_Compat)
#define IOCTL_TSYNC_GET                _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TSYNC_CMD_GET, \
                                             ioctl_trans_di)
#define IOCTL_TSYNC_SET                _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TSYNC_CMD_SET, \
                                             ioctl_trans_di)
#define IOCTL_TSYNC_WAIT               _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TSYNC_CMD_WAIT, \
                                             ioctl_trans_di_wait)
#define IOCTL_TSYNC_WAIT_TO            _IOWR(IOCTL_TPRO_ID, \
                                             IOCTL_TSYNC_CMD_WAIT_TO, \
                                             ioctl_trans_di_wait_to)


#endif  // _defined_DDTPRO_
