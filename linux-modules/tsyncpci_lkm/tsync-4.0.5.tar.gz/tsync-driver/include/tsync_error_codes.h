#ifndef __tsync_error_codes_h__
#define __tsync_error_codes_h__ 1

#ifdef __cplusplus
extern "C" {
#endif

#ifndef DLL_EXPORT
#define DLL_EXPORT /* */
#endif

/* WARNING: X Macros!
 *
 * X Macros will help us keep the list of error conditions tightly
 * coupled with meaningful text messages for users.
 */

#define TSYNC_GET_ERROR_CLASS(err)  (err / 10000)
#define TSYNC_GET_ERROR_CODE(err)   (err % 10000)

#define TSYNC_ERROR_CLASS_FIELDS \
    TSYNC_X( EC_STANDARD        , 0   , "standard") \
    TSYNC_X( EC_BOARD_RC        , 1   , "board rc") \
    TSYNC_X( EC_BOARD_OPT       , 2   , "board opt") \
    TSYNC_X( EC_DRIVER          , 3   , "driver")

typedef enum{
#define TSYNC_X(name, value, string) name##_OFFSET = value * 10000,
    TSYNC_ERROR_CLASS_FIELDS
#undef TSYNC_X
}TSYNC_ERROR_CLASS;



#define TSYNC_ERROR_CODE_FIELDS                                                \
    TSYNC_X( TSYNC_SUCCESS                    , 0   , EC_STANDARD, "success")          \
    TSYNC_X( TSYNC_HANDLE_ERR                 , 1   , EC_STANDARD, "error bad handle") \
    TSYNC_X( TSYNC_OBJECT_ERR                 , 2   , EC_STANDARD, "error creating obj") \
    TSYNC_X( TSYNC_CLOSE_HANDLE_ERR           , 3   , EC_STANDARD, "err closing device") \
    TSYNC_X( TSYNC_DEVICE_NOT_OPEN_ERR        , 4   , EC_STANDARD, "device not opened") \
    TSYNC_X( TSYNC_INVALID_BOARD_TYPE_ERR     , 5   , EC_STANDARD, "invalid device")   \
    TSYNC_X( TSYNC_FREQ_ERR                   , 6   , EC_STANDARD, "invalid frequency") \
    TSYNC_X( TSYNC_YEAR_PARM_ERR              , 7   , EC_STANDARD, "invalid year")     \
    TSYNC_X( TSYNC_DAY_PARM_ERR               , 8   , EC_STANDARD, "invalid day")      \
    TSYNC_X( TSYNC_HOUR_PARM_ERR              , 9   , EC_STANDARD, "invalid hour")     \
    TSYNC_X( TSYNC_MIN_PARM_ERR               , 10  , EC_STANDARD, "invalid minutes")  \
    TSYNC_X( TSYNC_SEC_PARM_ERR               , 11  , EC_STANDARD, "invalid seconds")  \
    TSYNC_X( TSYNC_DELAY_PARM_ERR             , 12  , EC_STANDARD, "invalid delay")    \
    TSYNC_X( TSYNC_TIMEOUT_ERR                , 13  , EC_STANDARD, "device timed out") \
    TSYNC_X( TSYNC_COMM_ERR                   , 14  , EC_STANDARD, "communication error") \
    TSYNC_X( TSYNC_DEV_BUSY                   , 15  , EC_STANDARD, "device busy ") \
    TSYNC_X( TSYNC_MATCH_PARM_ERR             , 16  , EC_STANDARD, "invalid match type") \
    TSYNC_X( TSYNC_NULL_POINTER               , 17  , EC_STANDARD, "NULL pointer") \
    TSYNC_X( TSYNC_INVALID_INPUT              , 18  , EC_STANDARD, "invalid input") \
    TSYNC_X( TSYNC_OUT_OF_MEM                 , 19  , EC_STANDARD, "out of memory") \
    TSYNC_X( TSYNC_BUFFER_OVERRUN             , 20  , EC_STANDARD, "buffer overrun")

#define TSYNC_HA_RC_FIELDS                                 \
    TSYNC_X( HA_RC_NO_ERROR         , 0   , EC_BOARD_RC, "success")          \
    TSYNC_X( HA_RC_INVALID_MSG      , 1   , EC_BOARD_RC, "invalid message") \
    TSYNC_X( HA_RC_UNKNOWN_ID       , 2   , EC_BOARD_RC, "unknown id") \
    TSYNC_X( HA_RC_INVALID_OP       , 3   , EC_BOARD_RC, "invalid op") \
    TSYNC_X( HA_RC_INVALID_PARAM    , 4   , EC_BOARD_RC, "invalid param") \
    TSYNC_X( HA_RC_TIMEOUT          , 5   , EC_BOARD_RC, "timeout")   \
    TSYNC_X( HA_RC_CMD_ERR          , 6   , EC_BOARD_RC, "command error")

#define TSYNC_RC_FIELDS                                     \
    TSYNC_X( RC_NO_ERROR            , 0   , EC_BOARD_OPT, "success") \
    TSYNC_X( RC_NULL                , 1   , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_BAD_PARAM           , 2   , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_BAD_HANDLE          , 3   , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_WRONG_TASK          , 4   , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_STUB_FUNC           , 5   , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_UNINITIALIZED       , 6   , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_READ_ERR            , 7   , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_WRITE_ERR           , 8   , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_TABLE_FULL          , 9   , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_ITEM_NOT_FOUND      , 10  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_ITEM_NOT_SETABLE    , 11  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_ITEM_NOT_GETABLE    , 12  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_MUTEX_ERR           , 13  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_SEMAPHORE_ERR       , 14  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_OPEN_ERR            , 15  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_TABLE_ERR           , 16  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_EVENT_ERR           , 17  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_QUEUE_ERR           , 18  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_TASK_ERR            , 19  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_WAIT_ERR            , 20  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_TIMEOUT             , 21  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_IOCTL_ERR           , 22  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_UNEXPECTED_MSG      , 23  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_IMG_ERR             , 24  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_TIMER_ERR           , 25  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_DUPLICATE           , 26  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_NOT_ENABLED         , 27  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_BAD_CONFIG          , 28  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_BAD_CHORE           , 29  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_BAD_TSIP_ID         , 30  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_BUF_TOO_SMALL       , 31  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_BAD_LENGTH          , 32  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_BAD_TIME            , 33  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_CONSOLE             , 34  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_PIPE_ERR            , 35  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_PIPE_FULL           , 36  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_PIPE_EMPTY          , 37  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_ANTENNA_ERR         , 38  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_CHG_PENDING         , 39  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_BAD_CHANNEL         , 40  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_TIME_MATCH          , 41  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_PHASE_ERROR         , 42  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_WRONG_MODE          , 43  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_NO_CARD             , 44  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_BAD_SLOT            , 45  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_BAD_CHKSUM          , 46  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_UNSUPPORTED         , 47  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_OSC_PROBLEM         , 48  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_BAD_STATE           , 49  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_BAD_RESPONSE        , 50  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_NO_RESPONSE         , 51  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_MODE_CHANGE         , 52  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_SYNTAX_ERROR        , 53  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_UNKNOWN_MSG         , 54  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_ILLEGAL_OP          , 55  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_BUSY                , 56  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_LICENSE_NOT_FOUND   , 57  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_REACHED_LIMIT       , 58  , EC_BOARD_OPT, "opt err") \
    TSYNC_X( RC_INVALID_VERSION     , 59  , EC_BOARD_OPT, "opt err")

    
#define TSYNC_DRIVER_ERROR_FIELDS                                       \
TSYNC_X( TSYNC_DRV_NO_ERROR,                0, EC_DRIVER, "success")    \
TSYNC_X( TSYNC_DRV_BUFFER_OVERFLOW,         1, EC_DRIVER, "buffer overflow") \
TSYNC_X( TSYNC_DRV_FIFO_READ_TIMEOUT,       2, EC_DRIVER, "FIFO read timeout") \
TSYNC_X( TSYNC_DRV_CONNECTION_ERR,          3, EC_DRIVER, "connection error") \
TSYNC_X( TSYNC_DRV_USERSPACE_ACCESS,        4, EC_DRIVER, "unable to access user-space memory") \
TSYNC_X( TSYNC_DRV_QUEUE_EMPTY,             5, EC_DRIVER, "attempt to read from empty queue") \
TSYNC_X( TSYNC_DRV_INVALID_INDEX,           6, EC_DRIVER, "invalid index") \
TSYNC_X( TSYNC_DRV_FW_TRANS_ERROR,          7, EC_DRIVER, "firmware transaction error") \
TSYNC_X( TSYNC_DRV_HW_TRANS_ERROR,          8, EC_DRIVER, "hardware transaction error") \
TSYNC_X( TSYNC_DRV_NOT_IMPLEMENTED,         9, EC_DRIVER, "function not yet implemented") \
TSYNC_X( TSYNC_DRV_INT_WAIT_TIMEOUT,       10, EC_DRIVER, "interrupt wait timed out") \
TSYNC_X( TSYNC_DRV_INT_WAIT_ERROR,         11, EC_DRIVER, "interrupt wait error")

#define TSYNC_ALL_ERROR_FIELDS                  \
    TSYNC_ERROR_CODE_FIELDS                     \
    TSYNC_HA_RC_FIELDS                          \
    TSYNC_RC_FIELDS                             \
    TSYNC_DRIVER_ERROR_FIELDS

#define TSYNC_ERROR_FROM_CLASS_ERROR(class, error) (error + class##_OFFSET)

#define TSYNC_X(name, value, class, string) name = TSYNC_ERROR_FROM_CLASS_ERROR(class, value),
typedef enum{
    TSYNC_ALL_ERROR_FIELDS
}TSYNC_ERROR;
#undef TSYNC_X

DLL_EXPORT
const char * tsync_strerror(TSYNC_ERROR err);

#ifdef __cplusplus
}
#endif

#endif
