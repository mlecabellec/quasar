#ifndef __TSYNC_HW__
#define __TSYNC_HW__ 1

#include "tsync_nonkts_hw.h"

#define TSYNC_TIMESTAMP_DATA_NUM        ( 512 )

typedef enum
{
    INT_1PPS = 0, // 1PPS Received
    INT_SVC_REQ = 1, // Timing System Service Request
    INT_LCL_UC_FIFO_EMPTY = 2, // Local / uC Bus FIFO Empty
    INT_LCL_UC_FIFO_OVER = 3, // Local / uC Bus FIFO Overflow
    INT_UC_LCL_FIFO_DATA = 4, // uC / Local Bus FIFO Data Ready
    INT_UC_LCL_FIFO_OVER = 5, // uC / Lcoal Bus FIFO Overflow
    INT_GPIO_IN = 6, // GPIO Input Event
    INT_TMSTMP = 7, // Timestamp Data Ready
    INT_GPIO_OUT = 8 // GPIO Output Event
} INT_TYPE;

typedef enum
{
    DEST_ID_FW = 0x1,           // Access to the firmware using
                                // HIDD defined transactions
                                // utilizing the HIP defined
                                // protocol
    DEST_ID_HW = 0x2,           // Access to hardware in directly
                                // addressable memory space
    DEST_ID_HW_NONKTS = 0x3     // Access to non-KTS hardware in directly
                                // addressable memory space
} DEST_ID;

typedef uint16_t FW_ITEM;

typedef enum
{
    HW_SYS_TIME = 0x0100,
    HW_SEC_TIME = 0x0101,
    HW_TMSTMP_EN = 0x0200,
    HW_TMSTMP_REQ = 0x0201,
    HW_TMSTMP_CLR = 0x0202,
    HW_TMSTMP_CNT = 0x0203,
    HW_TMSTMP_DATA = 0x0204,
    HW_TMSTMP_SINGLE = 0x0205,
    HW_GPO_MTCH_HI = 0x0300,
    HW_GPO_MTCH_LO = 0x0301,
    HW_FPGA_ID = 0x0400,
    HW_INT_MASK = 0x0401,
    HW_INT_CNT = 0x0402,
    HW_INT_CNT_CLR = 0x0403,
    HW_INT_TS = 0x0404,
    HW_KTS_TEMPERATURE  = 0x1100,
    HW_KTS_TEMPERATURE_SS  = 0x1101,

} HW_ITEM;

typedef union
{
    FW_ITEM fid;            // cai/iid pair as described in
                            // each HIDD defined transaction
    HW_ITEM hid;            // HW transaction item
    HW_NONKTS_ITEM hnkid;   // Non-KTS HW transaction item
} ITEM_ID;

typedef enum
{
    TMSTMP_SRC_HOST = 0x0,
    TMSTMP_SRC_GPI_0 = 0x1,
    TMSTMP_SRC_GPI_1 = 0x2,
    TMSTMP_SRC_GPI_2 = 0x3,
    TMSTMP_SRC_GPI_3 = 0x4,
    TMSTMP_SRC_HOST_AND_GPI_0 = 0x5,
    TMSTMP_SRC_COUNT
} TMSTMP_SRC;

typedef enum
{
    ID_PIN_ALL = -1,

    ID_PIN_MIN = 0,
    ID_PIN_0   = 0,
    ID_PIN_1   = 1,
    ID_PIN_2   = 2,
    ID_PIN_3   = 3,
    ID_PIN_4   = 4,
    ID_PIN_5   = 5,
    ID_PIN_6   = 6,
    ID_PIN_7   = 7,

    // Add more GPIO Inputs here

    ID_PIN_NUM = 4 // [FUTURE]      // Number of GPI pins

} ID_PIN;

typedef enum
{
    OD_PIN_ALL = -1,

    OD_PIN_MIN = 0,

    OD_PIN_0   = 0,
    OD_PIN_1   = 1,
    OD_PIN_2   = 2,
    OD_PIN_3   = 3,
    OD_PIN_4   = 4,
    OD_PIN_5   = 5,
    OD_PIN_6   = 6,
    OD_PIN_7   = 7,

    OD_PIN_NUM = 4                  // Number of GPO ([FUTURE] 8)

} OD_PIN;

#endif
