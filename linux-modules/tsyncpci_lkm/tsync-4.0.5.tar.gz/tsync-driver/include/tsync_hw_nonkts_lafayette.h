#ifndef __TSYNC_HW_NONKTS_LAFAYETTE_H__
#define __TSYNC_HW_NONKTS_LAFAYETTE_H__

#include "tsync_lcd.h"


#define LCD_XFER_TIME       (10)    /* Number of clock cycles per transfer */


inline void wait_lcd(TPRO_INSTANCE_T *hw,
                            uint16_t busybit) {

    uint32_t loop = 0;
    uint16_t status = 0;

    /* Wait for the specified busy bit in the status register to clear.
     * Poll for the number of clock cycles in a transfer.  If it doesn't
     * respond after that, screw it, just go anyway so we don't hang.
     */
    for (loop = 0; loop < LCD_XFER_TIME; loop++) {
        status = TSYNC_READ_REG(tsync_lcd_interface_offset);
        if ((status & busybit) == 0) {
            break;
        }
    }

} /* end of wait_lcd */


inline void write_lcd(TPRO_INSTANCE_T *hw,
                             uint16_t value) {

    /* Wait until LCD is done processing a write */
    wait_lcd(hw, LCD_WRITE_BUSY);

    TSYNC_WRITE_REG(value, tsync_lcd_interface_offset);

} /* end of write_lcd */


TSYNC_ERROR get_hw_keypad(TPRO_INSTANCE_T *hw,
                          uint8_t  *outPayload,
                          uint32_t maxOutLength,
                          uint32_t *actualResultBytes) {

    const unsigned int outLength = sizeof(uint16_t);
    uint16_t readVal = 0;

    if (maxOutLength < outLength) {
        *actualResultBytes = 0;
        return TSYNC_DRV_BUFFER_OVERFLOW;
    }

    readVal = TSYNC_READ_REG(tsync_keypad_offset);

    memcpy(outPayload, &readVal, outLength);
    *actualResultBytes = outLength;

    return TSYNC_SUCCESS;

} /* end of get_hw_keypad */


TSYNC_ERROR get_hw_power_status(TPRO_INSTANCE_T *hw,
                                uint8_t  *outPayload,
                                uint32_t maxOutLength,
                                uint32_t *actualResultBytes) {

    const unsigned int outLength = sizeof(uint16_t);
    uint16_t readVal = 0;

    if (maxOutLength < outLength) {
        *actualResultBytes = 0;
        return TSYNC_DRV_BUFFER_OVERFLOW;
    }

    readVal = TSYNC_READ_REG(tsync_power_status_offset);

    memcpy(outPayload, &readVal, outLength);
    *actualResultBytes = outLength;

    return TSYNC_SUCCESS;

} /* end of get_hw_power_status */



TSYNC_ERROR get_hw_lcd_byte(TPRO_INSTANCE_T *hw,
                            uint8_t  *inPayload,
                            uint32_t  inLength,
                            uint8_t  *outPayload,
                            uint32_t  maxOutLength,
                            uint32_t *actualResultBytes) {

    const unsigned int expectedInLength = sizeof(uint32_t);
    const unsigned int outLength = sizeof(uint32_t);
    uint32_t value = 0;
    uint32_t writeVal = 0;
    uint16_t readVal = 0;

    if (inLength < expectedInLength) {
        TPRO_PRINT("get_hw_lcd_byte expected %u bytes in, got %u.\n",
                   expectedInLength, inLength);
        *actualResultBytes = 0;
        return TSYNC_DRV_BUFFER_OVERFLOW;
    }

    if (maxOutLength < outLength) {
        *actualResultBytes = 0;
        return TSYNC_DRV_BUFFER_OVERFLOW;
    }

    memcpy(&writeVal, inPayload, expectedInLength);
    write_lcd(hw, (uint16_t)writeVal);

    /* Wait until LCD is done processing a read */
    wait_lcd(hw, LCD_READ_BUSY);

    readVal = TSYNC_READ_REG(tsync_lcd_interface_offset);

    /* Zero out all but the last byte */
    value = ((uint32_t)readVal & 0x000000FF);

    memcpy(outPayload, &value, outLength);
    *actualResultBytes = outLength;

    return TSYNC_SUCCESS;

} /* end of get_hw_lcd_byte */


TSYNC_ERROR set_hw_lcd_value(TPRO_INSTANCE_T *hw,
                             uint8_t *inPayload,
                             uint32_t inLength) {

    const unsigned int expectedInLength = sizeof(uint32_t);
    uint32_t value;

    if (inLength < expectedInLength) {
        TPRO_PRINT("set_hw_lcd_value expects %u bytes of inPayload, got %u.\n",
                   expectedInLength, inLength);
        return TSYNC_DRV_BUFFER_OVERFLOW;
    }

    memcpy(&value, inPayload, expectedInLength);
    write_lcd(hw, (uint16_t)value);

    return TSYNC_SUCCESS;

} /* end of set_hw_lcd_value */


TSYNC_ERROR get_hw_fan_enabled(TPRO_INSTANCE_T *hw,
                               uint8_t  *outPayload,
                               uint32_t maxOutLength,
                               uint32_t *actualResultBytes) {

    const unsigned int outLength = sizeof(uint16_t);
    uint16_t readVal = 0;

    if (maxOutLength < outLength) {
        *actualResultBytes = 0;
        return TSYNC_DRV_BUFFER_OVERFLOW;
    }

    readVal = TSYNC_READ_REG(tsync_fan_en);

    memcpy(outPayload, &readVal, outLength);
    *actualResultBytes = outLength;

    return TSYNC_SUCCESS;

} /* end of get_hw_fan_enabled */

TSYNC_ERROR set_hw_fan_enabled(TPRO_INSTANCE_T *hw,
                               uint8_t *inPayload,
                               uint32_t inLength) {

    const unsigned int expectedInLength = sizeof(TSYNCD_Boolean);
    uint16_t fanReg;

    TSYNCD_Boolean enable;

    if (inLength < expectedInLength) {
        TPRO_PRINT("set_hw_fan_enabled expects %u bytes of inPayload, got %u.\n",
                   expectedInLength, inLength);
        return TSYNC_DRV_BUFFER_OVERFLOW;
    }

    memcpy(&enable, inPayload, expectedInLength);

    fanReg = TSYNC_READ_REG(tsync_fan_en);

    if (enable == TDB_FALSE) {
        fanReg &= ~0x1;
    }
    else {
        fanReg |= 0x1;
    }

    TSYNC_WRITE_REG(fanReg, tsync_fan_en);
    return TSYNC_SUCCESS;
} /* end of set_hw_fan_enabled */

#endif // __TSYNC_HW_NONKTS_LAFAYETTE_H__