#ifndef __TSYNC_HW_FUNC_H__
#define __TSYNC_HW_FUNC_H__ 1

#include "tsync_driver_helpers.h"

#include "ddtsync.h"
#include "tsync_error_codes.h"

typedef struct ioctl_trans_hw
{
    // input parameters
    uint16_t        dest;
    uint16_t        iid;

    uint8_t*        inPayload;
    uint32_t        inLength;
    uint8_t*        outPayload;
    uint32_t        maxOutLength;

    // output parameters
    uint32_t        actualOutLength;
    TSYNC_ERROR     status;
}ioctl_trans_hw;


TSYNC_ERROR intBitFromTypeAndIndex(INT_TYPE intType, uint32_t index,
                                   unsigned int *bit);

/* for argument enableMask, TDB_TRUE = interrupt is masked, TDB_FALSE
 * = interrupt is allowed */
TSYNC_ERROR set_hw_int_mask_by_index(TPRO_INSTANCE_T *hw,
                                     unsigned int interruptIndex,
                                     TSYNCD_Boolean enableMask);

TSYNC_ERROR hw_handle_get(TPRO_INSTANCE_T *hw,
                          ioctl_trans_hw *transaction);

TSYNC_ERROR hw_handle_set(TPRO_INSTANCE_T *hw,
                          ioctl_trans_hw *transaction);


void logTsyncInterruptWord(TPRO_INSTANCE_T *hw, char *message, uint16_t interruptWord);

uint16_t tsync_read_interrupt_status(TPRO_INSTANCE_T *hw);
TSYNC_ERROR tsync_initialize_board(TPRO_INSTANCE_T *hw);
#endif
