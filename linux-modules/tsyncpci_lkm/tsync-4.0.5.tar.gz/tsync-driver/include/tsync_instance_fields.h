
    /*
    ** Timestamp queues
    */
    
    gpio_timestamp_queue_t gpioTimestampQueue[TMSTMP_SRC_COUNT];
    
    /* 
    ** room for transactions en route to and from user space in tsyncDoTransaction.
    */
    uint16_t userRequestTransactionBuffer[MAX_TRANSACTION_BUFFER_WORDS];
    uint16_t userResultTransactionBuffer[MAX_TRANSACTION_BUFFER_WORDS];

    /* 
    ** room for transactions to be prepped before they go to the board
    ** in tsyncLocalTransaction.
    */
    uint16_t localRequestBuffer[MAX_TRANSACTION_BUFFER_WORDS];
    uint16_t localResponseBuffer[MAX_TRANSACTION_BUFFER_WORDS];

    /*
    ** scratch space for use by get and set ioctls
    */
    uint8_t localHWRequestBuffer[MAX_HW_REQUEST_LENGTH];
    uint8_t localHWResponseBuffer[MAX_HW_RESPONSE_LENGTH];

