#ifndef __TSYNC_GPIO_STAMP_QUEUE_STRUCTS_H__
#define __TSYNC_GPIO_STAMP_QUEUE_STRUCTS_H__ 1

#include "tsync_hw.h"

typedef struct {
    uint16_t superSecLow;
    uint16_t superSecMidLow;
    uint16_t superSecMidHigh;
    uint16_t superSecHigh;
    uint16_t subSecLow;
    uint16_t subSecHigh;
} gpio_timestamp_t;

typedef struct {
    gpio_timestamp_t gpioTimestampRingBuffer[TSYNC_TIMESTAMP_DATA_NUM];
    unsigned int writeIndex;
    unsigned int readIndex;
    unsigned int timestampCount;
} gpio_timestamp_queue_t;

#endif
