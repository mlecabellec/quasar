#ifndef __ddtsync_h__
#define __ddtsync_h__ 1

#include "tsync_error_codes.h"
#include "tsync_hw.h"

/*
 * driver level error codes
 */
typedef enum
{
    IOCTL_SUCCESS = 0,
    IOCTL_ERROR = 1,
} ioctl_status;

/*
 * driver level bool
 */
typedef enum
{
    TDB_FALSE = 0,
    TDB_TRUE = 1,
} TSYNCD_Boolean;

/*
 * the three commands that the driver understands
 */
typedef enum {
    TSYNC_GET,
    TSYNC_SET,
    TSYNC_WAIT,
    TSYNC_WAIT_TO
} TSYNC_IOCTL_ID;

/*
 * structures for ioctl interactions with driver
 */

#define DI_PAYLOADS_STARTER_LENGTH 4
typedef struct ioctl_trans_di {

    // input parameters
    uint16_t        dest;
    uint16_t        iid;

    uint32_t        inPayloadOffset;
    uint32_t        inLength;
    uint32_t        outPayloadOffset;
    uint32_t        maxOutLength;

    // output parameters
    uint32_t        actualOutLength;
    TSYNC_ERROR     status;

    // Input and output

    // The payloads field MUST be last in ioctl_trans_di.
    uint8_t         payloads[DI_PAYLOADS_STARTER_LENGTH];

}ioctl_trans_di;

/*
 * structure for ioctl interactions with driver
 */
typedef struct ioctl_trans_di_wait
{
    // input parameters
    INT_TYPE        intType;
    uint32_t        index;
    // output parameters
    TSYNC_ERROR     status;
}ioctl_trans_di_wait;

typedef struct ioctl_trans_di_wait_to
{
    // input parameters
    INT_TYPE        intType;
    uint32_t        index;
    int32_t         to;
    // output parameters
    TSYNC_ERROR     status;
}ioctl_trans_di_wait_to;

/*
 * structure for time interactions with driver
 */
typedef struct TSYNCD_TimeObj
{
    uint32_t years;
    uint32_t doy;
    uint32_t hours;
    uint32_t minutes;
    uint32_t seconds;
    uint32_t ns;
}TSYNCD_TimeObj;

/*
 * structure for time seconds interactions with driver
 */
typedef struct TSYNCD_TimeSecondsObj
{
    uint32_t seconds;
    uint32_t ns;
}TSYNCD_TimeSecondsObj;

/*
 * structure for time interactions with hardware
 */
typedef struct TSYNCD_HWTimeObj
{
    TSYNCD_TimeObj time;
    TSYNCD_Boolean bSync;
}TSYNCD_HWTimeObj;

/*
 * structure for time interactions with hardware
 */
typedef struct TSYNCD_HWTimeSecondsObj
{
    TSYNCD_TimeSecondsObj time;
    TSYNCD_Boolean        bSync;
}TSYNCD_HWTimeSecondsObj;

/*
 * structure for time data interactions with hardware
 */
typedef struct TSYNCD_HWTimeDataObj
{
    TSYNCD_HWTimeObj data[TSYNC_TIMESTAMP_DATA_NUM];
}TSYNCD_HWTimeDataObj;

/*
 * structure for gpo match interactions
 */
typedef struct TSYNCD_MatchTimeObj
{
    OD_PIN          index;
    TSYNCD_TimeObj  time;
}TSYNCD_MatchTimeObj;

/*
 * structure for fpga interactions
 */
typedef struct TSYNCD_FPGAInfoObj
{
    uint16_t        id;
    uint16_t        rev;
}TSYNCD_FPGAInfoObj;

/*
 * structure for interrupt mask get interactions
 */
typedef struct TSYNCD_InterruptMaskGetObj
{
    INT_TYPE         intType;
    uint32_t         index;
}TSYNCD_InterruptMaskGetObj;

/*
 * structure for interrupt mask set interactions
 */
typedef struct TSYNCD_InterruptMaskSetObj
{
    INT_TYPE         intType;
    uint32_t         index;
    TSYNCD_Boolean   bEnable;
}TSYNCD_InterruptMaskSetObj;


#endif
