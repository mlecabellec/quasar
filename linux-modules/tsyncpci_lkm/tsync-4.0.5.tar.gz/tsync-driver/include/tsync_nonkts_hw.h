#ifndef __TSYNC_NONKTS_HW__
#define __TSYNC_NONKTS_HW__ 1


typedef enum
{
	HW_NONKTS_START  = 0x1100,

#ifdef LAFAYETTE
        HW_NONKTS_LCD    = 0x1100,
        HW_NONKTS_KEYPAD = 0x1200,
        HW_NONKTS_POWER  = 0x1300,
        HW_FAN_EN        = 0x1400,
#endif

} HW_NONKTS_ITEM;

#endif
