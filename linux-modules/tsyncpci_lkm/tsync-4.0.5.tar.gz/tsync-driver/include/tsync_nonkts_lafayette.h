#ifndef __TSYNC_NONKTS_LAFAYETTE_H__
#define __TSYNC_NONKTS_LAFAYETTE_H__

#include "tsync_lcd.h"

/* Hardware Interface ====================================================*/

/*
* Function:    TSYNC_HW_getLcdSize()
* Description: Get the number of rows and columns on the LCD.
*
* Parameters:
*   IN:  handle           - Board handle
*   OUT: col              - Pointer to the number of supported columns
*        row              - Pointer to the number of supported rows
*
* Returns: (TSYNC_SUCCESS) Success
*/
DLL_EXPORT
TSYNC_ERROR TSYNC_HW_getLcdSize(TSYNC_BoardHandle handle,
                                unsigned int * col,
                                unsigned int * row);

/*
* Function:    TSYNC_HW_fillLcd()
* Description: Fill the LCD display with a specified pattern.
*
* Parameters:
*   IN:  handle           - Board handle
*        pattern          - Pattern to fill into the LCD
*
* Returns: (TSYNC_SUCCESS) Success
*/
DLL_EXPORT
TSYNC_ERROR TSYNC_HW_fillLcd(TSYNC_BoardHandle handle, unsigned int pattern);

/*
* Function:    TSYNC_HW_setLcdActive()
* Description: Set the enable state of the LCD (1=on, 0=off)
*
* Parameters:
*   IN:  handle           - Board handle
*        enable           - Enable state of the LCD (1=on, 0=off)
*
* Returns: (TSYNC_SUCCESS) Success
*/
DLL_EXPORT
TSYNC_ERROR TSYNC_HW_setLcdActive(TSYNC_BoardHandle handle, unsigned int enable);

/*
* Function:    TSYNC_HW_setLcdStartLine()
* Description: Set the start line on the LCD.
*
* Parameters:
*   IN:  handle           - Board handle
*        line             - Start line of the LCD
*
* Returns: (TSYNC_SUCCESS) Success
*/
DLL_EXPORT
TSYNC_ERROR TSYNC_HW_setLcdStartLine(TSYNC_BoardHandle handle, unsigned int line);

/*
* Function:    TSYNC_HW_setLcdAdc()
* Description: Set the ADC for the LCD.
*
* Parameters:
*   IN:  handle           - Board handle
*        reverse          - ADC Direction (1=reverse, 0=normal)
*
* Returns: (TSYNC_SUCCESS) Success
*/
DLL_EXPORT
TSYNC_ERROR TSYNC_HW_setLcdAdc(TSYNC_BoardHandle handle, unsigned int reverse);

/*
* Function:    TSYNC_HW_setLcdStaticDrv()
* Description: Set the static drive state for the LCD.
*
* Parameters:
*   IN:  handle           - Board handle
*        on               - Static drive state (1=on, 0=off)
*
* Returns: (TSYNC_SUCCESS) Success
*/
DLL_EXPORT
TSYNC_ERROR TSYNC_HW_setLcdStaticDrv(TSYNC_BoardHandle handle, unsigned int on);

/*
* Function:    TSYNC_HW_setLcdDuty()
* Description: Set the duty cycle of the LCD.
*
* Parameters:
*   IN:  handle           - Board handle
*        by32             - Duty cycle settings (1=1/32, 0=1/16)
*
* Returns: (TSYNC_SUCCESS) Success
*/
DLL_EXPORT
TSYNC_ERROR TSYNC_HW_setLcdDuty(TSYNC_BoardHandle handle, unsigned int by32);

/*
* Function:    TSYNC_HW_resetLcd()
* Description: Reset the LCD.
*
* Parameters:
*   IN:  handle           - Board handle
*
* Returns: (TSYNC_SUCCESS) Success
*/
DLL_EXPORT
TSYNC_ERROR TSYNC_HW_resetLcd(TSYNC_BoardHandle handle);

/*
* Function:    TSYNC_HW_setLcdRmw()
* Description: Set the Read-Modify-Write state of the LCD.
*
* Parameters:
*   IN:  handle           - Board handle
*        on               - RMW state (1=RMW, 0=normal)
*
* Returns: (TSYNC_SUCCESS) Success
*/
DLL_EXPORT
TSYNC_ERROR TSYNC_HW_setLcdRmw(TSYNC_BoardHandle handle, unsigned int on);

/*
* Function:    TSYNC_HW_initLcd()
* Description: Initialize the LCD.
*
* Parameters:
*   IN:  handle           - Board handle
*
* Returns: (TSYNC_SUCCESS) Success
*/
DLL_EXPORT
TSYNC_ERROR TSYNC_HW_initLcd(TSYNC_BoardHandle handle);

/*
* Function:    TSYNC_HW_readLcd()
* Description: Read an image on the LCD.
*
* Parameters:
*   IN:  handle           - Board handle
*        img              - Pointer to the image structure to read into.
*
* Returns: (TSYNC_SUCCESS) Success
*/
DLL_EXPORT
TSYNC_ERROR TSYNC_HW_readLcd(TSYNC_BoardHandle handle, LCD_IMAGE * img);

/*
* Function:    TSYNC_HW_writeLcd()
* Description: Write an image to the LCD.
*
* Parameters:
*   IN:  handle           - Board handle
*        img              - Pointer to the image structure to write from.
*
* Returns: (TSYNC_SUCCESS) Success
*/
DLL_EXPORT
TSYNC_ERROR TSYNC_HW_writeLcd(TSYNC_BoardHandle handle, LCD_IMAGE * img);

/*
* Function:    TSYNC_HW_getKeypad()
* Description: Read the Keypad register. (Any read clears the register)
*
* Parameters:
*   IN:  handle           - Board handle
*        keys             - Pointer to contents of Keypad Register
*
* Returns: (TSYNC_SUCCESS) Success
*/
DLL_EXPORT
TSYNC_ERROR TSYNC_HW_getKeypad(TSYNC_BoardHandle handle, unsigned int * keys);

/*
* Function:    TSYNC_HW_getPowerStatus()
* Description: Read the Power Status register.
*
* Parameters:
*   IN:  handle           - Board handle
*        status           - Pointer to contents of Power Status Register
*
* Returns: (TSYNC_SUCCESS) Success
*/
DLL_EXPORT
TSYNC_ERROR TSYNC_HW_getPowerStatus(TSYNC_BoardHandle handle, unsigned int * status);

   /*
    * Function:    TSYNC_HW_getFanEnable()
    * Description: Get the current enable/disable state of the Fan.
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *   OUT: bEnable           - The enable result
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HW_getFanEnable(TSYNC_BoardHandle  handle, int *bEnable);

    /*
    * Function:    TSYNC_HW_setFanEnable()
    * Description: Set the current enable/disable state of Fan.
    *
    * Parameters:
    *   IN:  hnd               - Board handle
    *        bEnable           - The enable information
    *
    * Returns: (TSYNC_SUCCESS) Success
    */
    DLL_EXPORT
    TSYNC_ERROR TSYNC_HW_setFanEnable(TSYNC_BoardHandle handle, int bEnable);



#endif // __TSYNC_NONKTS_LAFAYETTE_H__
