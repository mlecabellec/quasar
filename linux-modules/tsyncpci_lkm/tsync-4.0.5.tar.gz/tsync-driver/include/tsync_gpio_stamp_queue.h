#ifndef __GPIO_QUEUE_H__
#define __GPIO_QUEUE_H__ 1

#include "tsync_driver_helpers.h"
#include "tsync_error_codes.h"
#include "tsync_gpio_stamp_queue_structs.h"

TSYNC_ERROR gpioQueueInit(TPRO_INSTANCE_T *hw, unsigned int iGpio);
TSYNC_ERROR gpioQueueAdd(TPRO_INSTANCE_T *hw, unsigned int iGpio, 
                         gpio_timestamp_t *timestamp);

TSYNC_ERROR gpioQueueRemove(TPRO_INSTANCE_T *hw, unsigned int iGpio, 
                            gpio_timestamp_t *timestamp);
TSYNC_ERROR gpioQueueCount(TPRO_INSTANCE_T *hw, unsigned int iGpio, 
                           unsigned int *count);
TSYNC_ERROR gpioQueueDrainBoardFIFO(TPRO_INSTANCE_T *hw);
#endif
